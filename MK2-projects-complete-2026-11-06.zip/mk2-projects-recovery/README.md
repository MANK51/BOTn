# MK~2 — Complete available project recovery package

Prepared: **2026-11-06**.

**Read [START_HERE.md](START_HERE.md) first.** The ready-to-use AI restoration task is [AI_RESTORE_PROMPT.txt](AI_RESTORE_PROMPT.txt).

Included: 12 source projects, 1,185 source files and 119 original Git commits in standalone bundles.

- [Project index](PROJECTS.md) and [restoration guide](RESTORE_GUIDE.md).
- [Machine-readable requirements](requirements.json).
- [Source checksums and snapshots](manifest.json).
- [Recorded project metadata](catalog.json).

Verify the package before making changes:

```sh
python3 scripts/verify_integrity.py
```

All tracked source files are included as available, including assets, lockfiles, schemas, migration files, original hosting manifests and tracked project archives. Dependencies can be reinstalled from included lockfiles.

Production database contents, runtime upload buckets and credential values are not present in source control. The two registered empty-source projects are documented rather than reconstructed. External app downloads linked by Getsup are not the source of that app.
