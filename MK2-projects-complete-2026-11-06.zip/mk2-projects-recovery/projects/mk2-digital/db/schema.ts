import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const projects = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(), description: text("description").notNull().default(""),
  category: text("category").notNull().default("أخرى"), url: text("url").notNull().default(""),
  image: text("image").notNull().default(""), technologies: text("technologies").notNull().default(""),
  featured: integer("featured").notNull().default(0), visible: integer("visible").notNull().default(1),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_projects_visible").on(t.visible)]);

export const socialAccounts = sqliteTable("social_accounts", {
  id: integer("id").primaryKey({ autoIncrement: true }), platform: text("platform").notNull(),
  username: text("username").notNull().default(""), url: text("url").notNull(),
  visible: integer("visible").notNull().default(1), sortOrder: integer("sort_order").notNull().default(0),
}, (t) => [uniqueIndex("uq_social_platform").on(t.platform)]);
export const settings = sqliteTable("site_settings", { key: text("key").primaryKey(), value: text("value").notNull().default("") });
export const messages = sqliteTable("messages", {
  id: integer("id").primaryKey({ autoIncrement: true }), name: text("name").notNull(), email: text("email").notNull(),
  subject: text("subject").notNull(), body: text("body").notNull(), read: integer("read").notNull().default(0),
  ipHash: text("ip_hash").notNull().default(""), createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_messages_ip_time").on(t.ipHash,t.createdAt)]);
export const visits = sqliteTable("visits", { id: integer("id").primaryKey({ autoIncrement: true }), day: text("day").notNull(), visitor: text("visitor").notNull() }, (t)=>[index("idx_visits_day").on(t.day),index("idx_visits_visitor").on(t.visitor)]);
export const linkClicks = sqliteTable("link_clicks", { id: integer("id").primaryKey({ autoIncrement: true }), platform: text("platform").notNull(), createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`) }, (t)=>[index("idx_clicks_platform").on(t.platform)]);
export const adminUsers = sqliteTable("admin_users", { id: integer("id").primaryKey({ autoIncrement: true }), username: text("username").notNull().unique(), salt: text("salt").notNull(), passwordHash: text("password_hash").notNull(), createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`) });
