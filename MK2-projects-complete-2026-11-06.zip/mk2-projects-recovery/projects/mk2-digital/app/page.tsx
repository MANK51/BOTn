import type { Metadata } from "next";
import { cookies } from "next/headers";
import Home from "./home-client";
import { getPublicContent } from "../lib/public-content";
import { resolveSiteSeo, SITE_NAME, SITE_URL } from "../lib/site-seo";
import { AJR_COOKIE, selectInitialVerseId } from "../lib/ajr/selection";

export const metadata: Metadata = { alternates: { canonical: SITE_URL } };

export default async function Page() {
  const data = await getPublicContent();
  const initialAjrId = selectInitialVerseId((await cookies()).get(AJR_COOKIE)?.value);
  const seo = resolveSiteSeo(data?.settings ?? {});
  const personId = `${SITE_URL}#person`;
  const websiteId = `${SITE_URL}#website`;
  const sameAs = (data?.socials ?? []).map(account => account.url).filter(url => /^https:\/\//i.test(url));
  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite", "@id": websiteId, url: SITE_URL,
        name: SITE_NAME, alternateName: ["MK2", "MK2 Space", "MK~2", "مساحه Mk2"],
        description: seo.description, inLanguage: "ar", publisher: { "@id": personId },
      },
      {
        "@type": "Person", "@id": personId, name: data?.settings.name || "MK~2",
        alternateName: "MK2", url: SITE_URL, ...(sameAs.length ? { sameAs } : {}),
      },
      {
        "@type": "ProfilePage", "@id": `${SITE_URL}#profile`, url: SITE_URL,
        name: SITE_NAME, description: seo.description, inLanguage: "ar",
        isPartOf: { "@id": websiteId }, mainEntity: { "@id": personId },
      },
    ],
  };
  return <>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replace(/</g, "\\u003c") }} />
    <Home initialData={data} initialAjrId={initialAjrId} />
  </>;
}
