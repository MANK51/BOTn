import Link from "next/link";
import type { Metadata } from "next";
import { ArrowUpLeft, Orbit } from "lucide-react";
import { getDb } from "../db";
import { settings } from "../db/schema";

export const metadata: Metadata = {
  title: "الصفحة غير موجودة | مساحة MK2",
  robots: { index: false, follow: false },
  alternates: { canonical: null },
  openGraph: null,
  twitter: null,
};

export default async function NotFound(){let themeBg="#f8f6f2",themeAccent="#4c392a";try{const rows=await getDb().select({key:settings.key,value:settings.value}).from(settings);for(const row of rows){if(row.key==="themeBg"&&/^#[\da-f]{6}$/i.test(row.value))themeBg=row.value;if(row.key==="themeAccent"&&/^#[\da-f]{6}$/i.test(row.value))themeAccent=row.value}}catch{}return <main className="not-found" style={{"--bg":themeBg,"--violet":themeAccent} as React.CSSProperties}><div className="notfound-orbit"><Orbit size={108} strokeWidth={.65}/><span>404</span></div><span className="notfound-label">MK~2 / PAGE NOT FOUND</span><h1>هذه الصفحة خارج<br/><em>مدارنا.</em></h1><p>يبدو أن الرابط تغيّر أو لم يعد موجودًا.</p><Link href="/" className="button button-primary">العودة للرئيسية <ArrowUpLeft size={17}/></Link><div className="notfound-signature">MK<span>~</span>2 · DIGITAL SPACE</div></main>}
