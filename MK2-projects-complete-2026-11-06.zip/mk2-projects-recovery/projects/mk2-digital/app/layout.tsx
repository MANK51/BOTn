import type { Metadata, Viewport } from "next";
import { getDb } from "../db";
import { settings } from "../db/schema";
import { eq } from "drizzle-orm";
import { resolveSiteSeo, SITE_NAME, SITE_ORIGIN, SITE_URL } from "../lib/site-seo";
import "./globals.css";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  let saved: Record<string, string> = {};
  try {
    saved = Object.fromEntries((await getDb().select().from(settings)).map(({ key, value }) => [key, value]));
  } catch {
    // Keep reliable defaults if the database is temporarily unavailable.
  }
  const seo = resolveSiteSeo(saved);
  return {
  metadataBase: new URL(SITE_ORIGIN),
  title: seo.title,
  description: seo.description,
  applicationName: SITE_NAME,
  openGraph: {
    type: "website", locale: "ar_SA", siteName: SITE_NAME,
    title: seo.title, description: seo.description, url: SITE_URL,
    images: [{ url: "/hero-portrait.jpg", width: 720, height: 1280, alt: "مساحة MK2 — الموقع الشخصي" }],
  },
  twitter: { card: "summary_large_image", title: seo.title, description: seo.description, images: ["/hero-portrait.jpg"] },
  icons: { icon: "/favicon.svg", shortcut: "/favicon.ico", apple: "/apple-touch-icon.png" },
  robots: { index: true, follow: true },
  };
}
export async function generateViewport(): Promise<Viewport> {
  let themeColor = "#000000";
  try {
    const db = getDb();
    const [saved] = await db.select({ value: settings.value }).from(settings).where(eq(settings.key, "themeBg")).limit(1);
    if (saved?.value && /^#[0-9a-fA-F]{6}$/.test(saved.value)) themeColor = saved.value;
  } catch {
    // Use the base theme if the settings store is temporarily unavailable.
  }
  return { themeColor, width: "device-width", initialScale: 1, viewportFit: "cover" };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
