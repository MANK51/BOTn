import type { MetadataRoute } from "next";
import { asc, eq } from "drizzle-orm";
import { getDb } from "../db";
import { projects } from "../db/schema";
import { SITE_ORIGIN, SITE_URL } from "../lib/site-seo";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const items = await getDb()
    .select({ id: projects.id })
    .from(projects)
    .where(eq(projects.visible, 1))
    .orderBy(asc(projects.id));

  return [
    { url: SITE_URL },
    ...items.map(({ id }) => ({ url: `${SITE_ORIGIN}/projects/${id}` })),
  ];
}
