import { asc, desc, eq } from "drizzle-orm";import { getDb } from "../../../db";import { projects, settings, socialAccounts, visits } from "../../../db/schema";
import { projectUrl } from "../../../lib/project-url";
import { resolveSiteSeo } from "../../../lib/site-seo";
export async function GET(req:Request){try{const db=getDb();let visitor=req.headers.get("cookie")?.match(/(?:^|;\s*)mk2_visitor=([^;]+)/)?.[1];const fresh=!visitor;if(!visitor)visitor=crypto.randomUUID();const day=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Riyadh"}).format(new Date());await db.insert(visits).values({day,visitor});const flags=Object.fromEntries((await db.select().from(settings)).map(x=>[x.key,x.value]));
// Apply the reference palette once; later changes made in the admin remain intact.
if(flags.referencePaletteInitialized!=="1"){
  await db.batch([
    db.insert(settings).values({key:"themeBg",value:"#000000"}).onConflictDoUpdate({target:settings.key,set:{value:"#000000"}}),
    db.insert(settings).values({key:"themeAccent",value:"#A3E635"}).onConflictDoUpdate({target:settings.key,set:{value:"#A3E635"}}),
    db.insert(settings).values({key:"referencePaletteInitialized",value:"1"}).onConflictDoUpdate({target:settings.key,set:{value:"1"}}),
  ]);
  flags.themeBg="#000000";
  flags.themeAccent="#A3E635";
  flags.referencePaletteInitialized="1";
}
let accounts=await db.select().from(socialAccounts).orderBy(asc(socialAccounts.sortOrder));if(flags.socialsInitialized!=="1"){if(!accounts.length){await db.insert(socialAccounts).values([{platform:"TikTok",username:"@4ikv",url:"https://www.tiktok.com/@4ikv",sortOrder:1},{platform:"Snapchat",username:"Snapchat",url:"https://snapchat.com/t/HWVk421E",sortOrder:2}]).onConflictDoNothing();accounts=await db.select().from(socialAccounts).orderBy(asc(socialAccounts.sortOrder))}await db.insert(settings).values({key:"socialsInitialized",value:"1"}).onConflictDoNothing()}if(flags.projectsInitialized!=="1"){const count=(await db.select().from(projects).limit(1)).length;if(!count)await db.insert(projects).values({title:"تحدي اليوم",description:"منصة تفاعلية عربية تختبر المعرفة مع تجربة سهلة وواضحة.",category:"موقع إلكتروني",url:"https://games.mk2space.cfd/",featured:1,sortOrder:0}).onConflictDoNothing();await db.insert(settings).values({key:"projectsInitialized",value:"1"}).onConflictDoNothing()}const [items,values]=await Promise.all([db.select().from(projects).where(eq(projects.visible,1)).orderBy(desc(projects.featured),asc(projects.sortOrder),desc(projects.createdAt)),db.select().from(settings)]);const headers=new Headers({"cache-control":"no-store"});if(fresh)headers.append("set-cookie",`mk2_visitor=${visitor}; Path=/; Max-Age=31536000; SameSite=Lax; Secure`);const storedSettings=Object.fromEntries(values.map(x=>[x.key,x.value]));const seo=resolveSiteSeo(storedSettings);return Response.json({projects:items.map(item=>({...item,url:projectUrl(item.url)})),socials:accounts.filter(x=>x.visible),settings:{...storedSettings,seoTitle:seo.title,seoDescription:seo.description}},{headers})}catch{return Response.json({error:"المحتوى غير متاح مؤقتًا"},{status:503})}}
