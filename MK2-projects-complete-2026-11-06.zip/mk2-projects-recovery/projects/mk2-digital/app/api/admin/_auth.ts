import { env } from "cloudflare:workers";
import { scrypt } from "node:crypto";
import { eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { adminUsers } from "../../../db/schema";

const encoder = new TextEncoder();
const SCRYPT_OPTIONS = { N: 16_384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

const b64 = (bytes: Uint8Array) =>
  btoa(String.fromCharCode(...bytes))
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replaceAll("=", "");

const un64 = (value: string) =>
  Uint8Array.from(
    atob(value.replaceAll("-", "+").replaceAll("_", "/") + "===".slice((value.length + 3) % 4)),
    (character) => character.charCodeAt(0),
  );

async function derive(password: string, salt: Uint8Array) {
  return await attempt(
    "password-kdf",
    () => new Promise<Uint8Array>((resolve, reject) => {
      scrypt(password, salt, 32, SCRYPT_OPTIONS, (error, key) => {
        if (error) reject(error);
        else resolve(new Uint8Array(key));
      });
    }),
  );
}

function logAuthFailure(stage: string, error: unknown) {
  // Log only a stage and error class; never log usernames, passwords, or tokens.
  console.error("MK~2 admin authentication failure", stage, error instanceof Error ? error.name : "UnknownError");
}

async function attempt<T>(stage: string, action: () => Promise<T>): Promise<T> {
  try {
    return await action();
  } catch (error) {
    logAuthFailure(stage, error);
    if (error instanceof Error && !(error as Error & { authStage?: string }).authStage) Object.assign(error, { authStage: stage });
    throw error;
  }
}

async function sign(value: string) {
  const secret = env.ADMIN_SESSION_SECRET;
  if (!secret) throw new Error("SessionSecretMissing");
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64(new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(value))));
}

export async function bootstrapAdmin() {
  const db = await attempt("database-binding", async () => getDb());
  const rows = await attempt("bootstrap-read", () => db.select().from(adminUsers).limit(1));
  if (rows.length) return;

  const username = env.ADMIN_USERNAME?.trim();
  const password = env.ADMIN_PASSWORD;
  if (!username || !password) {
    console.error("MK~2 admin authentication failure", "bootstrap-config-missing", Boolean(username), Boolean(password));
    throw new Error("AdminBootstrapConfigMissing");
  }

  const salt = await attempt("bootstrap-salt", async () => crypto.getRandomValues(new Uint8Array(16)));
  const hash = await attempt("bootstrap-hash", () => derive(password, salt));
  await attempt("bootstrap-write", () =>
    db.insert(adminUsers).values({ username, salt: b64(salt), passwordHash: b64(hash) }).onConflictDoNothing(),
  );
}

export async function login(username: string, password: string) {
  await bootstrapAdmin();
  const row = (
    await attempt("admin-lookup", () =>
      getDb().select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1),
    )
  )[0];
  if (!row) return false;

  const actual = await attempt("password-verify", () => derive(password, un64(row.salt)));
  const expected = un64(row.passwordHash);
  if (actual.length !== expected.length) return false;
  let difference = 0;
  for (let index = 0; index < actual.length; index++) difference |= actual[index] ^ expected[index];
  if (difference !== 0) return false;

  const payload = b64(encoder.encode(JSON.stringify({ u: row.username, e: Date.now() + 8 * 60 * 60 * 1000, n: crypto.randomUUID() })));
  const signature = await attempt("session-sign", () => sign(payload));
  return `${payload}.${signature}`;
}

export async function isAdmin(request: Request) {
  const cookie = request.headers
    .get("cookie")
    ?.split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith("mk2_admin="))
    ?.slice("mk2_admin=".length);
  if (!cookie) return false;

  const [payload, signature, ...rest] = cookie.split(".");
  if (!payload || !signature || rest.length) return false;
  try {
    if ((await sign(payload)) !== signature) return false;
    const data = JSON.parse(new TextDecoder().decode(un64(payload)));
    if (typeof data.u !== "string" || data.e < Date.now()) return false;
    return !!(await getDb().select({ id: adminUsers.id }).from(adminUsers).where(eq(adminUsers.username, data.u)).limit(1)).length;
  } catch {
    return false;
  }
}

export async function updateCredentials(request: Request, currentPassword: string, username: string, password: string) {
  const cookie = request.headers
    .get("cookie")
    ?.split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith("mk2_admin="))
    ?.slice("mk2_admin=".length);
  if (!cookie) return null;

  const [payload, signature, ...rest] = cookie.split(".");
  if (!payload || !signature || rest.length || (await sign(payload)) !== signature) return null;
  let current: string;
  try {
    const data = JSON.parse(new TextDecoder().decode(un64(payload)));
    if (data.e < Date.now()) return null;
    current = data.u;
  } catch {
    return null;
  }

  const db = getDb();
  const row = (await db.select().from(adminUsers).where(eq(adminUsers.username, current)).limit(1))[0];
  if (!row) return null;
  const oldHash = await derive(currentPassword, un64(row.salt));
  const expected = un64(row.passwordHash);
  if (oldHash.length !== expected.length) return null;
  let difference = 0;
  for (let index = 0; index < oldHash.length; index++) difference |= oldHash[index] ^ expected[index];
  if (difference !== 0) return null;

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await derive(password, salt);
  await db.update(adminUsers).set({ username, salt: b64(salt), passwordHash: b64(hash) }).where(eq(adminUsers.id, row.id));
  const nextPayload = b64(encoder.encode(JSON.stringify({ u: username, e: Date.now() + 8 * 60 * 60 * 1000, n: crypto.randomUUID() })));
  return `${nextPayload}.${await sign(nextPayload)}`;
}

export const sessionCookie = (token: string) =>
  `mk2_admin=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`;

export const clearSessionCookie = () => "mk2_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0";
