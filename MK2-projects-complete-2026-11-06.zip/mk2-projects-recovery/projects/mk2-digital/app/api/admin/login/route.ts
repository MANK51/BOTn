import { login, sessionCookie } from "../_auth";
export async function POST(request:Request){
 try{const body=await request.json() as {username?:string;password?:string};const username=body.username?.trim()??"",password=body.password??"";
  if(username.length>80||password.length>256||!username||!password)return Response.json({error:"بيانات الدخول غير صحيحة"},{status:400});
  const token=await login(username,password);if(!token)return Response.json({error:"اسم المستخدم أو كلمة المرور غير صحيحة"},{status:401});
  return Response.json({ok:true},{headers:{"set-cookie":sessionCookie(token),"cache-control":"no-store"}});
 }catch(error){console.error("MK~2 admin login request failed",error instanceof Error?error.name:"UnknownError");return Response.json({error:"تعذّر التحقق الآن. تأكد من إعداد الموقع وحاول مجددًا."},{status:503})}
}
