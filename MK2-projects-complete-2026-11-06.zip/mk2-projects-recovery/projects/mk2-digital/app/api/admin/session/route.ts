import { clearSessionCookie, isAdmin } from "../_auth";
export async function GET(request:Request){return Response.json({authenticated:await isAdmin(request)},{headers:{"cache-control":"no-store"}})}
export async function DELETE(){return Response.json({ok:true},{headers:{"set-cookie":clearSessionCookie()}})}
