import { env } from "cloudflare:workers";

type RouteProps = { params: Promise<{ path: string[] }> };

export async function GET(_request: Request, { params }: RouteProps) {
  const { path } = await params;
  const key = path.join("/");

  // Only serve the portfolio images written by the authenticated upload route.
  if (!/^portfolio\/[a-zA-Z0-9-]+\.(jpg|jpeg|png|webp|avif)$/i.test(key)) {
    return new Response("Not found", { status: 404 });
  }

  const item = await env.BUCKET?.get(key);
  if (!item) return new Response("Not found", { status: 404 });

  return new Response(item.body, {
    headers: {
      "content-type": item.httpMetadata?.contentType ?? "application/octet-stream",
      "cache-control": "public, max-age=31536000, immutable",
      "x-content-type-options": "nosniff",
    },
  });
}
