import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { and, eq, inArray } from "drizzle-orm";
import { ArrowRight, ArrowUpLeft, ExternalLink } from "lucide-react";
import { getDb } from "../../../db";
import { projects, settings } from "../../../db/schema";
import { projectUrl } from "../../../lib/project-url";
import { SITE_NAME, SITE_ORIGIN } from "../../../lib/site-seo";
import "../../globals.css";

type Props={params:Promise<{id:string}>};
async function findProject(id:string){const n=Number(id);if(!Number.isInteger(n))return null;return (await getDb().select().from(projects).where(and(eq(projects.id,n),eq(projects.visible,1))).limit(1))[0]??null}
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const project = await findProject(id);
  if (!project) {
    return {
      title: { absolute: `المشروع غير موجود | ${SITE_NAME}` },
      robots: { index: false, follow: false },
      alternates: { canonical: null },
      openGraph: null,
      twitter: null,
    };
  }

  const title = `${project.title} | ${SITE_NAME}`;
  const description = project.description || `${project.title} — من مشاريع ${SITE_NAME}.`;
  const canonical = `${SITE_ORIGIN}/projects/${project.id}`;
  return {
    title: { absolute: title },
    description,
    alternates: { canonical },
    openGraph: { type: "website", siteName: SITE_NAME, title, description, url: canonical },
    twitter: { card: "summary", title, description },
  };
}
export default async function ProjectPage({params}:Props){const {id}=await params;const project=await findProject(id);if(!project||!project.visible)notFound();let themeBg="#000000",themeAccent="#A3E635";try{const rows=await getDb().select({key:settings.key,value:settings.value}).from(settings).where(inArray(settings.key,["themeBg","themeAccent"]));for(const row of rows){if(row.key==="themeBg"&&/^#[\da-f]{6}$/i.test(row.value))themeBg=row.value;if(row.key==="themeAccent"&&/^#[\da-f]{6}$/i.test(row.value))themeAccent=row.value}}catch{}return <main className="project-detail" style={{"--bg":themeBg,"--accent":themeAccent,"--violet":themeAccent} as React.CSSProperties}><header className="detail-nav"><Link href="/" className="detail-logo">MK<span>~</span>2</Link><Link href="/#work" className="detail-back"><ArrowRight size={15}/> العودة للأعمال</Link></header><div className="detail-shell"><div className="detail-kicker">MK~2 / SELECTED WORK <span>0{project.id}</span></div><h1>{project.title}</h1><p className="detail-lede">{project.description}</p><div className="detail-cover">{project.image&&<img src={project.image} alt={project.title}/>}<div className="detail-cover-art"><span>{project.category}</span><b>{project.title}</b><small>MK~2 / CASE STUDY</small></div></div><div className="detail-meta"><div><span>التصنيف</span><b>{project.category}</b></div><div><span>تاريخ الإضافة</span><b>{project.createdAt.slice(0,10)}</b></div><div><span>التقنيات</span><b>{project.technologies||"تصميم وتطوير رقمي"}</b></div></div><div className="detail-description"><span className="section-kicker">عن المشروع</span><p>{project.description}</p>{project.url&&<a className="button button-primary" href={projectUrl(project.url)} target="_blank" rel="noreferrer"><span>زيارة المشروع</span><ExternalLink size={16}/></a>}</div><footer className="detail-footer"><Link href="/#work"><ArrowRight size={15}/> مشروع آخر</Link><span>MK~2 — تصميم وتجربة رقمية</span><Link href="/#contact">لديك فكرة؟ <ArrowUpLeft size={15}/></Link></footer></div></main>}
