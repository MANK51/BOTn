"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowUpLeft, Send } from "lucide-react";
import { projectUrl } from "../lib/project-url";
import "./reference.css";
import AjrVerse from "../components/ajr-verse";

type Project = { id: number; title: string; description: string; category: string; url: string; technologies?: string; visible: number };
type Social = { id: number; platform: string; username: string; url: string; visible: number };
export type HomeData = { projects: Project[]; socials: Social[]; settings: Record<string, string> };
const defaults: HomeData = {
  projects: [{ id: 0, title: "تحدي اليوم", description: "منصة تفاعلية عربية تختبر المعرفة مع تجربة سهلة وواضحة.", category: "موقع إلكتروني", url: "https://games.mk2space.cfd/", visible: 1 }],
  socials: [{ id: 0, platform: "TikTok", username: "@4ikv", url: "https://www.tiktok.com/@4ikv", visible: 1 }, { id: 1, platform: "Snapchat", username: "Snapchat", url: "https://snapchat.com/t/HWVk421E", visible: 1 }],
  settings: { name: "MK~2", tagline: "هنا تتحول الأفكار إلى مشاريع، والإبداع إلى تجارب رقمية استثنائية.", about: "أبني تجارب رقمية تجمع بين الفكرة، التصميم، والبرمجة.", skills: "تطوير الويب، تصميم الواجهات، تجارب رقمية تفاعلية", themeBg: "#000000", themeAccent: "#A3E635" },
};
const platformIcons: Record<string, { slug: string; color: string }> = {
  TikTok: { slug: "tiktok", color: "ffffff" }, Snapchat: { slug: "snapchat", color: "fffc00" },
  Instagram: { slug: "instagram", color: "e4405f" }, Telegram: { slug: "telegram", color: "26a5e4" },
  YouTube: { slug: "youtube", color: "ff0033" }, X: { slug: "x", color: "ffffff" }, Twitter: { slug: "x", color: "ffffff" },
  Discord: { slug: "discord", color: "5865f2" }, GitHub: { slug: "github", color: "ffffff" }, WhatsApp: { slug: "whatsapp", color: "25d366" },
};
function SocialIcon({ platform }: { platform: string }) {
  const meta = platformIcons[platform];
  return meta ? <img src={`/social-icons/${meta.slug}.svg`} width={22} height={22} alt="" aria-hidden="true" /> : <ArrowUpLeft size={22} aria-hidden="true" />;
}

export default function Home({ initialData, initialAjrId }: { initialData?: HomeData; initialAjrId?: string }) {
  const [data, setData] = useState<HomeData>(() => initialData ? { ...initialData, settings: { ...defaults.settings, ...initialData.settings } } : defaults);
  const [menu, setMenu] = useState(false), [scrolled, setScrolled] = useState(false), [busy, setBusy] = useState(false), [notice, setNotice] = useState("");
  const menuRef = useRef<HTMLDivElement>(null), menuButton = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/public", { signal: controller.signal }).then(async response => {
      if (!response.ok) return;
      const d = await response.json() as Partial<HomeData>;
      setData({ projects: Array.isArray(d.projects) ? d.projects : defaults.projects, socials: Array.isArray(d.socials) ? d.socials : defaults.socials, settings: { ...defaults.settings, ...d.settings } });
    }).catch(() => {});
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll(); window.addEventListener("scroll", onScroll, { passive: true });
    return () => { controller.abort(); window.removeEventListener("scroll", onScroll); };
  }, []);
  useEffect(() => {
    if (!menu) return;
    const outside = (event: PointerEvent) => { if (!menuRef.current?.contains(event.target as Node)) setMenu(false); };
    const escape = (event: KeyboardEvent) => { if (event.key === "Escape") { setMenu(false); menuButton.current?.focus(); } };
    document.addEventListener("pointerdown", outside); document.addEventListener("keydown", escape);
    return () => { document.removeEventListener("pointerdown", outside); document.removeEventListener("keydown", escape); };
  }, [menu]);
  const settings = data.settings, name = settings.name || "MK~2";
  const socials = data.socials.filter(s => s.visible !== 0), projects = data.projects.filter(p => p.visible !== 0);
  const skills = (settings.skills || defaults.settings.skills).split(/[،,\n]/).map(s => s.trim()).filter(Boolean);
  const show = (key: string) => settings[key] !== "0";
  const defaultOrder = ["about", "skills", "work", "social", "contact"];
  const sectionOrder = (() => {
    try {
      const order: unknown = JSON.parse(settings.sectionOrder || "[]");
      return Array.isArray(order) && order.length === 5 && new Set(order).size === 5 && order.every(id => defaultOrder.includes(id)) ? order as string[] : defaultOrder;
    } catch { return defaultOrder; }
  })();
  const position = (id: string) => ({ order: sectionOrder.indexOf(id) + 1 });
  const contactPosition = Math.min(...[show("showSocials") ? sectionOrder.indexOf("social") + 1 : 6, show("showContact") ? sectionOrder.indexOf("contact") + 1 : 6]);
  const firstSection = sectionOrder.find(id => ({ about: show("showAbout"), skills: show("showSkills"), work: show("showProjects"), social: show("showSocials"), contact: show("showContact") })[id]);
  const trackSocial = (platform: string) => { fetch("/api/click", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ platform }), keepalive: true }).catch(() => {}); };
  const background = /^#[\da-f]{6}$/i.test(settings.themeBg) ? settings.themeBg : "#000000";
  const accent = /^#[\da-f]{6}$/i.test(settings.themeAccent) ? settings.themeAccent : "#A3E635";
  return <main className="reference-site" data-motion={settings.motionEnabled === "0" ? "off" : "on"} data-strength={settings.motionStrength || "medium"} style={{ "--bg": background, "--accent": accent, "--accent-dim": `${accent}80`, "--accent-glow": `${accent}1f`, "--accent-ghost": `${accent}0f`, "--border-accent": `${accent}33` } as React.CSSProperties}>
    <nav className={`ref-nav${scrolled ? " ref-nav--scrolled" : ""}`} aria-label="التنقل الرئيسي">
      <a href="#home" className="ref-nav__logo" dir="ltr" aria-label="مساحة MK2 — الرئيسية">{name}</a>
      <div className="ref-nav__menu-wrapper" ref={menuRef}>
        <button ref={menuButton} className="ref-nav__menu-btn" onClick={() => setMenu(!menu)} aria-label="القائمة" aria-expanded={menu} aria-controls="site-menu"><span /><span /><span /></button>
        <div id="site-menu" className={`ref-nav__dropdown${menu ? " ref-nav__dropdown--open" : ""}`} inert={!menu}>
          {show("showAbout") && <a href="#about" className="ref-nav__dropdown-link" onClick={() => setMenu(false)}>عنّي</a>}
          {show("showProjects") && <a href="#work" className="ref-nav__dropdown-link" onClick={() => setMenu(false)}>أعمالي</a>}
          {(show("showSocials") || show("showContact")) && <a href="#contact" className="ref-nav__dropdown-link" onClick={() => setMenu(false)}>تواصل</a>}
          <a href="/admin" className="ref-nav__dropdown-link ref-nav__admin" onClick={() => setMenu(false)}>لوحة الإدارة</a>
        </div>
      </div>
    </nav>
    <section id="home" className="ref-hero" aria-label="المقدمة">
      <img className="ref-hero__poster" src="/hero-portrait.jpg" alt="" aria-hidden="true" fetchPriority="high" />
      <div className="ref-hero__grid" aria-hidden="true" />
      <div className="ref-container ref-hero__content">
        <h1 className="ref-hero__name" dir="ltr">{name}<span className="ref-hero__cursor" aria-hidden="true" /></h1>
        <p className="ref-hero__surname">عالمي الرقمي</p>
        <p className="ref-hero__title">{skills.slice(0, 3).map((skill, index) => <span key={`${skill}-${index}`}>{index > 0 && <span className="ref-hero__dot" aria-hidden="true">• &nbsp;</span>}{skill}</span>)}</p>
        <p className="ref-hero__tagline">{settings.tagline}</p>
        <AjrVerse initialVerseId={initialAjrId} />
        {show("showSocials") && <div className="ref-hero__socials">{socials.map((s, i) => <a key={`${s.id}-${i}`} href={s.url} target="_blank" rel="noopener noreferrer" aria-label={s.platform} onClick={() => trackSocial(s.platform)} style={{ "--social-color": `#${platformIcons[s.platform]?.color || "ffffff"}` } as React.CSSProperties}><SocialIcon platform={s.platform} /></a>)}</div>}
        {firstSection && <a href={`#${firstSection === "social" ? "contact" : firstSection}`} className="ref-hero__scroll" aria-label="تعرّف عليّ"><ArrowDown size={20} aria-hidden="true" /></a>}
      </div>
    </section>
    {show("showAbout") && <section id="about" className="ref-section" style={position("about")}><div className="ref-container">
      <h2 className="ref-section__title">من أنا</h2>
      <div className="ref-glass ref-about__card"><div className="ref-about__status"><span className="ref-about__status-dot" />متاح لمشاريع مختارة</div><p className="ref-about__text">{settings.about}</p></div>
    </div></section>}
    {show("showSkills") && <section id="skills" className="ref-section" style={position("skills")}><div className="ref-container"><h2 className="ref-section__title">ماذا أتقن</h2><div className="ref-skills__grid">{skills.map((skill, i) => <span className="ref-pill" key={`${skill}-${i}`}>{skill}</span>)}</div></div></section>}
    {show("showProjects") && <section id="work" className="ref-section" style={position("work")}><div className="ref-container">
      <h2 className="ref-section__title">أعمالي</h2>
      <div className="ref-projects__grid">{projects.map((project, i) => <article className="ref-project-card ref-glass" key={`${project.id}-${i}`}>
        <div className="ref-project-card__accent" aria-hidden="true" /><h3 className="ref-project-card__name">{project.title}</h3><p className="ref-project-card__subtitle">{project.category}</p><p className="ref-project-card__desc">{project.description}</p>
        {project.technologies && <div className="ref-project-card__tags">{project.technologies.split(/[،,]/).map(tag => tag.trim()).filter(Boolean).map(tag => <span className="ref-tag" key={tag}>{tag}</span>)}</div>}
        {(project.id || project.url) ? <a href={project.id ? `/projects/${project.id}` : projectUrl(project.url)} className="ref-project-card__link" target={project.id ? undefined : "_blank"} rel={project.id ? undefined : "noopener noreferrer"}>استعراض المشروع <ArrowUpLeft size={14} aria-hidden="true" /></a> : null}
      </article>)}</div>
    </div></section>}
    {(show("showSocials") || show("showContact")) && <section id="contact" className="ref-section" style={{order:contactPosition}}><div className="ref-container ref-container--narrow" id="social">
      <h2 className="ref-section__title">تواصل معي</h2>
      {show("showSocials") && <div className="ref-links__list">{socials.map((s, i) => <a key={`${s.id}-${i}`} className="ref-link-card ref-glass" href={s.url} target="_blank" rel="noopener noreferrer" onClick={() => trackSocial(s.platform)}><span className="ref-link-card__icon"><SocialIcon platform={s.platform} /></span><span className="ref-link-card__body"><span className="ref-link-card__platform">{s.platform}</span><span className="ref-link-card__handle">{s.username}</span></span><ArrowUpLeft className="ref-link-card__arrow" size={14} aria-hidden="true" /></a>)}</div>}
      {show("showContact") && <details className="ref-message"><summary>أرسل رسالة</summary>
        <form className="ref-contact-form" onSubmit={async event => {
          event.preventDefault(); if (busy) return;
          const form = event.currentTarget, body = Object.fromEntries(new FormData(form).entries());
          setBusy(true); setNotice("");
          try {
            const response = await fetch("/api/contact", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
            const result = await response.json().catch(() => ({})) as { error?: string };
            setNotice(response.ok ? "وصلت رسالتك — شكرًا لك." : (result.error || "تعذّر حفظ الرسالة الآن. حاول مرة أخرى بعد قليل."));
            if (response.ok) form.reset();
          } catch { setNotice("تعذّر الاتصال الآن. تحقق من الشبكة وحاول مرة أخرى."); }
          finally { setBusy(false); }
        }}>
          <label>الاسم<input required name="name" placeholder="كيف أناديك؟" maxLength={80} autoComplete="name" /></label>
          <label>البريد الإلكتروني<input required type="email" name="email" placeholder="you@example.com" maxLength={140} autoComplete="email" /></label>
          <label>موضوع الرسالة<input required name="subject" placeholder="فكرة، مشروع، أو سؤال" maxLength={120} /></label>
          <label>رسالتك<textarea required name="body" placeholder="أخبرني قليلًا عن فكرتك..." rows={4} maxLength={2000} /></label>
          <input name="website" className="ref-honeypot" tabIndex={-1} aria-hidden="true" autoComplete="off" />
          <button type="submit" disabled={busy} aria-busy={busy}>{busy ? "جارٍ الإرسال…" : "إرسال الرسالة"} <Send size={14} aria-hidden="true" style={{ display: "inline", verticalAlign: "middle", marginInlineStart: 6 }} /></button>
          {notice && <p className="ref-contact-notice" role="status">{notice}</p>}
        </form>
      </details>}
    </div></section>}
    <footer className="ref-footer"><div className="ref-container"><p className="ref-footer__text">مساحة MK2 — {name} © ٢٠٢٦</p></div></footer>
  </main>;
}
