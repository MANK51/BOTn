export interface AjrVerse {
  readonly id: string;
  readonly surah: number;
  readonly ayah: number;
  readonly surahName: string;
  readonly text: string;
}

export interface AjrConfig {
  dataUrl?: string;
  fullDataUrl?: string;
  sourceId?: string;
  updateIntervalMs?: number;
  transitionMs?: number;
  minReadingTimeMs?: number;
  readingMsPerWord?: number;
  storageKey?: string | null;
  selection?: "shuffle-bag";
  respectReducedMotion?: boolean;
}

export interface AjrOptions {
  configUrl?: string;
  config?: AjrConfig;
  data?: unknown;
  initialVerseId?: string;
  onError?: (error: Error) => void;
  onVerseChange?: (verse: AjrVerse) => void;
}

export interface AjrController {
  destroy(): void;
  refresh(): Promise<boolean>;
  getCurrentVerse(): AjrVerse | null;
}

export function createAjrWidget(element: HTMLElement, options?: AjrOptions): Promise<AjrController>;
