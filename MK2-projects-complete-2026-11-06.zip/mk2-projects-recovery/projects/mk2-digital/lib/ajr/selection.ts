import corpus from "./ajr-home.json";

export const AJR_COOKIE = "ajr_last_verse";
export const ajrCorpus = corpus;

export function selectInitialVerseId(savedId?: string): string {
  if (savedId && corpus.verses.some(verse => verse.id === savedId)) return savedId;
  // Stable for first-time visits on the same UTC day. No generated Quran text.
  const day = Math.floor(Date.now() / 86400000);
  return corpus.verses[day % corpus.verses.length].id;
}
