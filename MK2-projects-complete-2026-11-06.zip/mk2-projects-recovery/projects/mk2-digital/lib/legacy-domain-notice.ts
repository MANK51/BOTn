const LEGACY_HOST = "mk2-digital.m2000m1400.chatgpt.site";
const NEW_SITE = "https://me.mk2space.cfd/";

const notice = `<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#000000">
  <meta name="robots" content="noindex, follow">
  <title>تم الانتقال لدومين جديد — MK~2</title>
  <link rel="canonical" href="${NEW_SITE}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    *{box-sizing:border-box}
    html{color-scheme:dark;background:#000}
    body{margin:0;min-height:100vh;min-height:100svh;display:grid;place-items:center;padding:24px;font-family:"IBM Plex Sans Arabic",sans-serif;color:#f5f5f5;text-align:center;background:radial-gradient(ellipse at 50% 30%,#a3e6350b,transparent 60%),#000}
    main{width:100%;max-width:550px;padding:clamp(32px,7vw,56px) 24px;border:1px solid #ffffff12;border-radius:24px;background:linear-gradient(180deg,#ffffff07,#ffffff02)}
    .brand{margin:0 0 28px;color:#a3e635;font-size:22px;font-weight:700;letter-spacing:.04em}
    h1{margin:0;font-size:clamp(28px,6vw,40px);line-height:1.6;font-weight:600}
    h1 span{color:#a3e635}
    p{margin:16px 0 30px;color:#a1a1aa;font-size:16px;line-height:1.9}
    a{display:flex;flex-direction:column;align-items:center;gap:4px;width:100%;padding:16px 20px;border-radius:14px;background:#a3e635;color:#101506;text-decoration:none;font-size:17px;font-weight:600;transition:background .2s}
    a:hover{background:#b5ed61}
    a:focus-visible{outline:3px solid #fff;outline-offset:5px}
    a small{font-size:13px;font-weight:500;overflow-wrap:anywhere}
  </style>
</head>
<body>
  <main>
    <div class="brand" dir="ltr">MK~2</div>
    <h1>تم الانتقال <span>لدومين جديد</span></h1>
    <p>تقدر تزور موقعي من الرابط الجديد.</p>
    <a href="${NEW_SITE}"><span>الانتقال للموقع الجديد</span><small dir="ltr">me.mk2space.cfd</small></a>
  </main>
</body>
</html>`;

export function legacyDomainNotice(request: Request): Response | null {
  const url = new URL(request.url);
  if (url.hostname !== LEGACY_HOST || url.pathname !== "/" || !["GET", "HEAD"].includes(request.method)) return null;

  return new Response(request.method === "HEAD" ? null : notice, {
    status: 200,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "cache-control": "no-store",
      "x-robots-tag": "noindex, follow",
    },
  });
}
