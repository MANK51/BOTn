const customProjectOrigins = new Map<string, string>([
  ["https://challenge-today.m2000m1400.chatgpt.site", "https://games.mk2space.cfd"],
  ["http://challenge-today.m2000m1400.chatgpt.site", "https://games.mk2space.cfd"],
  ["https://mkk2movi.m2000m1400.chatgpt.site", "https://movie.mk2space.cfd"],
  ["http://mkk2movi.m2000m1400.chatgpt.site", "https://movie.mk2space.cfd"],
  ["https://qudrat-review.m2000m1400.chatgpt.site", "https://qudrat.mk2space.cfd"],
  ["http://qudrat-review.m2000m1400.chatgpt.site", "https://qudrat.mk2space.cfd"],
  ["https://mk2-realms.m2000m1400.chatgpt.site", "https://realms.mk2space.cfd"],
  ["http://mk2-realms.m2000m1400.chatgpt.site", "https://realms.mk2space.cfd"],
  ["https://a-heart-for-you.m2000m1400.chatgpt.site", "https://love.mk2space.cfd"],
  ["http://a-heart-for-you.m2000m1400.chatgpt.site", "https://love.mk2space.cfd"],
]);

export function projectUrl(value: string): string {
  try {
    const url = new URL(value);
    if ((url.protocol !== "http:" && url.protocol !== "https:") || url.username || url.password) return value;
    const origin = customProjectOrigins.get(url.origin);
    return origin ? `${origin}${url.pathname}${url.search}${url.hash}` : value;
  } catch {
    return value;
  }
}
