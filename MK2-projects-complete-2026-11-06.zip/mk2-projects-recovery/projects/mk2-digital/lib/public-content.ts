import { asc, desc, eq } from "drizzle-orm";
import { cache } from "react";
import { getDb } from "../db";
import { projects, settings, socialAccounts } from "../db/schema";
import type { HomeData } from "../app/home-client";
import { projectUrl } from "./project-url";
import { resolveSiteSeo } from "./site-seo";

// Read the first HTML response without recording a second visit or running the
// public API's initialization writes.
export const getPublicContent = cache(async (): Promise<HomeData | undefined> => {
  try {
    const db = getDb();
    const [items, accounts, values] = await Promise.all([
      db.select().from(projects).where(eq(projects.visible, 1)).orderBy(desc(projects.featured), asc(projects.sortOrder), desc(projects.createdAt)),
      db.select().from(socialAccounts).where(eq(socialAccounts.visible, 1)).orderBy(asc(socialAccounts.sortOrder)),
      db.select().from(settings),
    ]);
    const saved = Object.fromEntries(values.map(({ key, value }) => [key, value]));
    const seo = resolveSiteSeo(saved);
    return {
      projects: items.map(item => ({ ...item, url: projectUrl(item.url) })),
      socials: accounts,
      settings: { ...saved, seoTitle: seo.title, seoDescription: seo.description },
    };
  } catch {
    return undefined;
  }
});
