export const SITE_NAME = "مساحة MK2";
export const SITE_ORIGIN = "https://me.mk2space.cfd";
export const SITE_URL = `${SITE_ORIGIN}/`;
export const SEO_TITLE = "مساحة MK2 | الموقع الشخصي ومشاريعي";
export const SEO_DESCRIPTION = "مساحة MK2 (MK2 Space): موقعي الشخصي لعرض مشاريعي وأعمالي واهتماماتي في الحاسب الآلي والتكنولوجيا وتطوير الويب، وروابط التواصل معي.";

export function resolveSiteSeo(saved: Record<string, string>) {
  const title = saved.seoTitle?.trim();
  const description = saved.seoDescription?.trim();
  return {
    title: !title || title === "MK~2 — عالمي الرقمي" ? SEO_TITLE : title,
    description: !description || description === "ملف MK~2 الإبداعي: أعمال ومشاريع وتجارب رقمية تصنع الفرق." ? SEO_DESCRIPTION : description,
  };
}
