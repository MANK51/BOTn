"use client";

import { memo, useEffect, useRef } from "react";
import { createAjrWidget, type AjrController } from "../lib/ajr/ajr-update.js";
import config from "../lib/ajr/ajr-config.json";
import { AJR_COOKIE, ajrCorpus } from "../lib/ajr/selection";
import "../lib/ajr/ajr-style.css";
import "./ajr-verse.css";

function AjrVerse({ initialVerseId }: { initialVerseId?: string }) {
  const element = useRef<HTMLElement>(null);
  const first = ajrCorpus.verses.find(verse => verse.id === initialVerseId) ?? ajrCorpus.verses[0];

  useEffect(() => {
    if (!element.current) return;
    const root = element.current;
    let mounted = true;
    let controller: AjrController | undefined;

    createAjrWidget(root, {
      data: ajrCorpus,
      initialVerseId: first.id,
      config: { ...config, selection: "shuffle-bag", storageKey: "ajr:mk2:verse:v1" },
      onVerseChange(verse) {
        // The server reads only this validated ID; never cookie-supplied text.
        document.cookie = `${AJR_COOKIE}=${verse.id}; Path=/; Max-Age=31536000; SameSite=Lax${location.protocol === "https:" ? "; Secure" : ""}`;
        root.dataset.ajrVerse = verse.id;
      },
    }).then(instance => {
      if (!mounted) instance.destroy();
      else { controller = instance; root.dataset.ajrReady = "true"; }
    }).catch(() => {
      // The complete server-rendered source verse remains visible on failure.
    });

    return () => { mounted = false; controller?.destroy(); };
  }, [first.id]);

  return <section ref={element} className="ajr-verse ref-ajr" dir="rtl" lang="ar" role="region" aria-label="آية قرآنية" aria-live="off" data-ajr-verse={first.id}>
    <p className="ajr-verse__text">{first.text}</p>
    <p className="ajr-verse__reference">سورة {first.surahName} · الآية {new Intl.NumberFormat("ar", { useGrouping: false }).format(first.ayah)}</p>
    <a className="ajr-verse__source" href="https://tanzil.net" rel="external">تنزيل</a>
  </section>;
}

export default memo(AjrVerse);
