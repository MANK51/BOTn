"use client";

import { useEffect, useRef } from "react";

type Point = { x: number; y: number; vx: number; vy: number; size: number; phase: number };

export function ParticleField({ enabled = true, strength = "medium" }: { enabled?: boolean; strength?: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d", { alpha: true, desynchronized: true });
    if (!canvas || !context) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const finePointer = window.matchMedia("(pointer: fine)");
    const pointer = { x: -1000, y: -1000 };
    let points: Point[] = [];
    let width = 0;
    let height = 0;
    let frame = 0;
    let lastFrame = 0;
    let visible = true;

    const isAnimated = () => enabled && !reducedMotion.matches;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      const ratio = Math.min(window.devicePixelRatio || 1, 1.35);
      canvas.width = Math.max(1, Math.round(width * ratio));
      canvas.height = Math.max(1, Math.round(height * ratio));
      context.setTransform(ratio, 0, 0, ratio, 0, 0);
      const density = strength === "low" ? 0.65 : strength === "high" ? 1.2 : 1;
      const target = Math.min(44, Math.max(12, Math.round((width * height) / 21_000 * density)));
      points = Array.from({ length: target }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * (strength === "low" ? 0.07 : strength === "high" ? 0.17 : 0.12),
        vy: (Math.random() - 0.5) * (strength === "low" ? 0.07 : strength === "high" ? 0.17 : 0.12),
        size: 0.7 + Math.random() * 1.25,
        phase: Math.random() * Math.PI * 2,
      }));
      draw(0, true);
    };

    const draw = (time: number, staticFrame = false) => {
      if (!staticFrame && (!visible || document.hidden || !isAnimated() || time - lastFrame < 32)) {
        if (isAnimated()) frame = requestAnimationFrame(draw);
        return;
      }
      lastFrame = time;
      context.clearRect(0, 0, width, height);
      const interactionRadius = finePointer.matches ? Math.min(175, width * 0.24) : 0;

      for (let i = 0; i < points.length; i++) {
        const point = points[i];
        if (!staticFrame && isAnimated()) {
          point.x += point.vx;
          point.y += point.vy;
          if (point.x < -8) point.x = width + 8;
          if (point.x > width + 8) point.x = -8;
          if (point.y < -8) point.y = height + 8;
          if (point.y > height + 8) point.y = -8;

          if (interactionRadius) {
            const dx = point.x - pointer.x;
            const dy = point.y - pointer.y;
            const distance = Math.hypot(dx, dy);
            if (distance > 0 && distance < interactionRadius) {
              const force = (1 - distance / interactionRadius) * 0.018;
              point.x += (dx / distance) * force * 14;
              point.y += (dy / distance) * force * 14;
            }
          }
        }

        const alpha = 0.25 + (Math.sin(time * 0.00055 + point.phase) + 1) * 0.2;
        context.beginPath();
        context.arc(point.x, point.y, point.size, 0, Math.PI * 2);
        context.fillStyle = `rgba(211, 165, 255, ${staticFrame || !isAnimated() ? 0.45 : alpha})`;
        context.fill();

        for (let j = i + 1; j < points.length; j++) {
          const other = points[j];
          const distance = Math.hypot(point.x - other.x, point.y - other.y);
          if (distance > 112) continue;
          context.beginPath();
          context.moveTo(point.x, point.y);
          context.lineTo(other.x, other.y);
          context.strokeStyle = `rgba(148, 70, 205, ${(1 - distance / 112) * 0.11})`;
          context.lineWidth = 0.65;
          context.stroke();
        }
      }
      if (!staticFrame && isAnimated()) frame = requestAnimationFrame(draw);
    };

    const onPointerMove = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect();
      pointer.x = event.clientX - rect.left;
      pointer.y = event.clientY - rect.top;
    };
    const onVisibility = () => {
      if (!document.hidden && visible && isAnimated()) frame = requestAnimationFrame(draw);
    };
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible && isAnimated()) frame = requestAnimationFrame(draw);
    }, { threshold: 0.02 });

    observer.observe(canvas);
    if (enabled && finePointer.matches) window.addEventListener("pointermove", onPointerMove, { passive: true });
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("resize", resize, { passive: true });
    reducedMotion.addEventListener("change", onVisibility);
    resize();
    if (isAnimated()) frame = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      window.removeEventListener("pointermove", onPointerMove);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("resize", resize);
      reducedMotion.removeEventListener("change", onVisibility);
    };
  }, [enabled, strength]);

  return <canvas ref={canvasRef} className="particle-field" aria-hidden="true" />;
}
