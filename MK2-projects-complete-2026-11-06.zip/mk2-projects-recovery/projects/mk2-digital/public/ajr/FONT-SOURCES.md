# خط قرآني مستقل اختياري

أضيف خط **Amiri Quran Regular 1.003** من المستودع الرسمي لـ Google Fonts. هذا الخط ليس مستخرجًا من تطبيق «آية ويدجت»، ولم يُثبت أنه الخط المستخدم في التطبيق. لم يُعدّل الخط أو يُحوّل أو يُجزّأ.

المصممون بحسب بيانات Google Fonts: Khaled Hosny وSebastian Kosch. مشروع المصدر: [aliftype/amiri](https://github.com/aliftype/amiri). تاريخ الحصول على الملف: 22 أكتوبر 2026.

## الملفات الأصلية المسموح بإعادة توزيعها

| المسار | الحجم بالبايت | SHA-256 |
| --- | ---: | --- |
| original-resources/fonts/AmiriQuran-Regular.ttf | 136920 | e2a47644762d16bdfb6d33e0d8db8c6ff30beae84150ef5a705316bbd829455c |
| original-resources/fonts/OFL.txt | 4392 | b32e3b24e2a943b8acbf6ab8d5499bfed737d5176091b7341a8c1e7fbcdeb0fa |

روابط التنزيل الأصلية:

- [AmiriQuran-Regular.ttf](https://raw.githubusercontent.com/google/fonts/main/ofl/amiriquran/AmiriQuran-Regular.ttf).
- [OFL.txt](https://raw.githubusercontent.com/google/fonts/main/ofl/amiriquran/OFL.txt).
- [بيانات Google Fonts الرسمية](https://raw.githubusercontent.com/google/fonts/main/ofl/amiriquran/METADATA.pb)، قُرئت للتحقق من اسم العائلة والإصدار ومصدر الخط ولم تُضمّن في الحزمة.

ترخيص الخط **SIL Open Font License 1.1**؛ يجيز التضمين وإعادة التوزيع مع بقاء إشعار الحقوق والترخيص، ولا يسمح ببيع الخط وحده. النسخة الكاملة من الترخيص محفوظة دون تعديل في `OFL.txt`. لا يغيّر تضمين الخط ترخيص نص القرآن أو ترخيص ملفات AJR البرمجية.

إشعار الحقوق الأصلي:

```text
Copyright 2010-2022 The Amiri Quran Project Authors (https://github.com/aliftype/amiri).
```

## نطاق التحقق

فُحص جدول Unicode `cmap` في ملف TTF الأصلي بواسطة fontTools. جميع نقاط Unicode السبعين المستخدمة في حقول `text` لآيات `ajr.json` موجودة في الخط؛ لا توجد نقطة مفقودة. يحتوي الملف أيضًا على جداول التشكيل `GSUB` و`GPOS` و`GDEF`، وتعلن بياناته الداخلية اسم العائلة Amiri Quran، والنمط Regular، والإصدار 1.003، وترخيص OFL 1.1.

هذا تحقق من تغطية المحارف والبنية، وليس ادعاء باختبار بصري شامل لكل آية أو لكل إصدار Safari. يلزم اختبار التشكيل والارتفاع والالتفاف بصريًا في الموقع الفعلي. استخدم الملف الكامل لتجنّب إسقاط علامات قرآنية عند إنشاء مجموعة خط جزئية.

## مثال اختياري للتضمين المحلي

اضبط المسار بحسب مكان نشر الملفات. احتفظ بملف `OFL.txt` مع نسخ الخط الموزعة:

```css
@font-face {
  font-family: "AJR Amiri Quran";
  src: url("./original-resources/fonts/AmiriQuran-Regular.ttf") format("truetype");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
}

/* طبّق المتغير في نطاق قسم AJR فقط وفق واجهة التنسيق في مشروعك. */
.ajr-verse {
  --ajr-font: "AJR Amiri Quran", "Traditional Arabic", serif;
}
```

هذه مواصفات تضمين مستقلة؛ لم يُعدّل هذا العمل أي موقع أو ينسخ خطًا من التطبيق.
