// Private Sites CMS. Hosted authentication is supplied by Sites dispatch.
const CONFIG_KEY = 'cms/settings.json';
const JSON_HEADERS = {'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'};
const DEFAULT_SETTINGS = {
  name:'Getsup', code:'0000', logo:'/uploads/panel_7_logo.png?v=1792874342',
  wa:'https://wa.me/966509950582',
  links:{ios:'https://apps.apple.com/app/id6823128480',android:'https://play.google.com/store/apps/details?id=com.gw.player',win:'https://apps.microsoft.com/detail/9n3lfnh297mn?ocid=webpdpshare&hl=ar-SA&gl=SA',apk:''},
  accent:'#987fd2',accentLight:'#c6b9e6',heroTitle:'برنامج واحد',heroHighlight:'لكل أجهزتك.',
  heroDescription:'مشغّل احترافي بتجربة سينمائية — على الآيفون، الأندرويد، التلفزيون والكمبيوتر. فعّله بكود واحد وابدأ خلال ثوانٍ.',
  supportTitle:'Getsup في خدمتك',supportDescription:'للاشتراك أو أي استفسار، تواصل معنا مباشرة على الواتساب.'
};
function json(value,status=200){return new Response(JSON.stringify(value),{status,headers:JSON_HEADERS});}
function html(value,status=200){return new Response(value,{status,headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'strict-origin-when-cross-origin','x-frame-options':'SAMEORIGIN'}});}
function escapeHTML(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function scriptJSON(value){return JSON.stringify(value).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');}
function requireIdentity(request){return Boolean(request.headers.get('oai-authenticated-user-id'));}
function validURL(value,local=false){
 if(!value)return true;
 if(/[\"'<>`\x00-\x20\x7f]/.test(value))return false;
 if(local && /^\/(?:uploads|media)\/[A-Za-z0-9_./?=&%-]+$/.test(value) && !value.includes('..'))return true;
 try{const u=new URL(value);return u.protocol==='https:' && !u.username && !u.password;}catch{return false;}
}
function validate(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('إعدادات الموقع غير صالحة.');
 const limits={name:80,code:80,logo:2000,wa:2000,heroTitle:120,heroHighlight:120,heroDescription:1200,supportTitle:150,supportDescription:1200};
 const result={};
 for(const [key,max] of Object.entries(limits)){
  const value=input[key];if(typeof value!=='string'||value.length>max)throw new Error('تحقق من الحقل: '+key);
  result[key]=value.trim();
 }
 if(!result.name||!result.heroTitle||!result.heroHighlight)throw new Error('الاسم وعنوان الصفحة مطلوبان.');
 if(!validURL(result.logo,true)||!validURL(result.wa))throw new Error('استخدم رابط HTTPS صحيحًا للشعار والتواصل.');
 for(const key of ['accent','accentLight']){if(typeof input[key]!=='string'||!/^#[0-9a-f]{6}$/i.test(input[key]))throw new Error('اللون غير صالح.');result[key]=input[key].toLowerCase();}
 result.links={};
 for(const key of ['ios','android','win','apk']){const value=input.links?.[key];if(typeof value!=='string'||value.length>2000||!validURL(value))throw new Error('رابط التحميل غير صالح: '+key);result.links[key]=value.trim();}
 return result;
}
async function readSettings(env){
 if(!env.BUCKET)throw new Error('Storage binding BUCKET is unavailable');
 const object=await env.BUCKET.get(CONFIG_KEY);
 if(!object)return {settings:structuredClone(DEFAULT_SETTINGS),updatedAt:null,version:'initial'};
 const data=await object.json();
 return {settings:validate(data.settings),updatedAt:data.updatedAt,version:object.etag};
}
function rgb(hex){return [1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)).join(',');}
function renderSite(s){
 let page=SITE_HTML;
 const cfg={dist:true,name:s.name,code:s.code,logo:s.logo,wa:s.wa,links:{...s.links,ms:s.links.win},custom:{tv:false,win:false,ios:false}};
 page=page.replace('<h1 class="rv">برنامج واحد<br><span class="gold">لكل أجهزتك.</span></h1>',()=>'<h1 class="rv">'+escapeHTML(s.heroTitle)+'<br><span class="gold">'+escapeHTML(s.heroHighlight)+'</span></h1>');
 page=page.replace(/(<p class="lead rv" id="lead">)[\s\S]*?(<\/p>)/,()=>'<p class="lead rv" id="lead">'+escapeHTML(s.heroDescription)+'</p>');
 page=page.replace(/href="([^"]*)"/g,(all,href)=>{
  const raw=href.replace(/&amp;/g,'&');
  for(const [key,original] of Object.entries(DEFAULT_SETTINGS.links))if(original && raw===original)return 'href="'+escapeHTML(s.links[key]||'#')+'"';
  return all;
 });
 page=page.replace('href="https://wa.me/966509950582"',()=> 'href="'+escapeHTML(s.wa||'#')+'"');
 page=page.replace(/<title>[\s\S]*?<\/title>/,()=>'<title>'+escapeHTML(s.name)+' — حمّل التطبيق</title>');
 page=page.replace('</head>',()=>'<style>:root{--a:'+rgb(s.accent)+';--a2:'+rgb(s.accentLight)+'}</style></head>');
 const extra='<script>document.getElementById("ft").textContent='+scriptJSON(s.supportTitle)+';document.getElementById("fp").textContent='+scriptJSON(s.supportDescription)+';document.querySelectorAll(".wa").forEach(function(a){a.href='+scriptJSON(s.wa||'#')+'});</script>';
 page=page.replace(/^var CFG=.*;$/m,()=> 'var CFG='+scriptJSON(cfg)+';');
 return page.replace('</body>',()=>extra+'</body>');
}
function errorPage(){return html('<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><title>خطأ مؤقت</title><body style="background:#05060d;color:#f5f6fb;font:18px Tahoma;padding:60px"><h1>تعذّر تحميل إعدادات الموقع</h1><p>حاول تحديث الصفحة بعد قليل.</p></body></html>',503);}
export default {
 async fetch(request,env,ctx){
  const url=new URL(request.url),path=url.pathname;
  try{
   if(path==='/admin'||path==='/admin/'){
    if(!requireIdentity(request))return html('<a href="/signin-with-chatgpt?return_to=%2Fadmin" target="_top">تسجيل الدخول بحساب ChatGPT</a>',401);
    return html(ADMIN_HTML);
   }
   if(path.startsWith('/api/')){
    if(!requireIdentity(request))return json({error:'يلزم تسجيل الدخول لإدارة الموقع.'},401);
    if(request.method!=='GET' && request.headers.get('origin')!==url.origin)return json({error:'مصدر الطلب غير مسموح.'},403);
    if(path==='/api/settings'&&request.method==='GET')return json(await readSettings(env));
    if(path==='/api/settings'&&request.method==='PUT'){
     if(!(request.headers.get('content-type')||'').startsWith('application/json'))return json({error:'صيغة الطلب غير صالحة.'},415);
     if(Number(request.headers.get('content-length')||0)>24000)return json({error:'الإعدادات أكبر من الحد المسموح.'},413);
     const raw=await request.text();if(raw.length>24000)return json({error:'الإعدادات أكبر من الحد المسموح.'},413);
     let body,settings;try{body=JSON.parse(raw);settings=validate(body.settings);}catch(e){return json({error:e.message||'الإعدادات غير صالحة.'},400);}
     const current=await readSettings(env);
     if(body.version!==current.version)return json({error:'تغيّرت الإعدادات في نافذة أخرى. أعد تحميل أحدث نسخة قبل الحفظ.'},409);
     const updatedAt=new Date().toISOString();
     const onlyIf=current.version==='initial'?{etagDoesNotMatch:'*'}:{etagMatches:current.version};
     const result=await env.BUCKET.put(CONFIG_KEY,JSON.stringify({settings,updatedAt}),{onlyIf,httpMetadata:{contentType:'application/json'}});
     if(!result)return json({error:'حُفظ تعديل آخر أثناء الحفظ. أعد تحميل أحدث نسخة.'},409);
     return json({settings,updatedAt,version:result.etag});
    }
    if(path==='/api/uploads'&&request.method==='POST'){
     const mime=request.headers.get('content-type')||'';const allowed={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'};
     if(!allowed[mime])return json({error:'ارفع صورة PNG أو JPG أو WebP.'},415);
     if(Number(request.headers.get('content-length')||0)>2097152)return json({error:'الحد الأقصى للصورة 2 ميجابايت.'},413);
     const buffer=await request.arrayBuffer();if(buffer.byteLength>2097152||buffer.byteLength<12)return json({error:'حجم الصورة غير صالح.'},413);
     const b=new Uint8Array(buffer);
     const ok=mime==='image/png'?[137,80,78,71,13,10,26,10].every((v,i)=>b[i]===v):mime==='image/jpeg'?b[0]===255&&b[1]===216&&b[2]===255:String.fromCharCode(...b.slice(0,4))==='RIFF'&&String.fromCharCode(...b.slice(8,12))==='WEBP';
     if(!ok)return json({error:'محتوى الملف لا يطابق صيغة الصورة.'},400);
     if(!env.BUCKET)return json({error:'خدمة التخزين غير متاحة.'},503);
     const key='media/'+crypto.randomUUID()+'.'+allowed[mime];
     await env.BUCKET.put(key,buffer,{httpMetadata:{contentType:mime}});
     return json({url:'/'+key},201);
    }
    return json({error:'المسار أو الطريقة غير متاحة.'},404);
   }
   if(path.startsWith('/media/')){
    if(!/^\/media\/[a-f0-9-]+\.(png|jpg|webp)$/.test(path))return new Response('Not found',{status:404});
    const object=await env.BUCKET?.get(path.slice(1));if(!object)return new Response('Not found',{status:404});
    return new Response(object.body,{headers:{'content-type':object.httpMetadata?.contentType||'application/octet-stream','cache-control':'public, max-age=31536000, immutable','x-content-type-options':'nosniff'}});
   }
   if(EMBEDDED_ASSETS[path]){
    const asset=EMBEDDED_ASSETS[path];const data=Uint8Array.from(atob(asset.base64),c=>c.charCodeAt(0));
    return new Response(data,{headers:{'content-type':asset.type,'cache-control':'public, max-age=86400','x-content-type-options':'nosniff'}});
   }
   if((path==='/'||path==='/download/getsupstore')&&(request.method==='GET'||request.method==='HEAD')){
    const data=await readSettings(env);const response=html(renderSite(data.settings));
    return request.method==='HEAD'?new Response(null,{status:200,headers:response.headers}):response;
   }
   return new Response('Not found',{status:404});
  }catch(error){console.error('CMS request failed:',error?.message);return path.startsWith('/api/')?json({error:'تعذّر الوصول للتخزين. لم يتم تأكيد الحفظ؛ حدّث الإعدادات قبل المحاولة مجددًا.'},503):errorPage();}
 }
};
