import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const template=await readFile(new URL('../site/index.html',import.meta.url),'utf8');
const runtime=await readFile(new URL('../worker/runtime.js',import.meta.url),'utf8');
const tv=await readFile(new URL('../site/download/shot/tv.jpg',import.meta.url));
const source='const SITE_HTML='+JSON.stringify(template)+';const ADMIN_HTML="admin";const EMBEDDED_ASSETS='+JSON.stringify({'/download/shot/tv.jpg':{type:'image/jpeg',base64:tv.toString('base64')}})+';'+runtime;
const {default:worker}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
class Bucket{
 constructor(){this.objects=new Map();this.seq=0;}
 async get(key){const r=this.objects.get(key);if(!r)return null;return {...r,json:async()=>JSON.parse(r.value),body:r.value};}
 async put(key,value,options={}){
  const old=this.objects.get(key),condition=options.onlyIf;
  if(condition?.etagDoesNotMatch==='*'&&old)return null;
  if(condition?.etagMatches&&old?.etag!==condition.etagMatches)return null;
  const etag='v'+(++this.seq);this.objects.set(key,{value,etag,httpMetadata:options.httpMetadata});return {etag};
 }
}
const origin='https://example.chatgpt.site';
function req(path,method='GET',body,identity=true,headers={}){return new Request(origin+path,{method,headers:{...(identity?{'oai-authenticated-user-id':'owner-local-id'}:{}),...(method!=='GET'?{'origin':origin,'content-type':'application/json'}:{}),...headers},...(body===undefined?{}:{body:typeof body==='string'?body:JSON.stringify(body)})});}
async function get(env){const r=await worker.fetch(req('/api/settings'),env,{});assert.equal(r.status,200);return r.json();}
test('admin and settings reject unauthenticated requests',async()=>{
 const env={BUCKET:new Bucket()};
 for(const p of ['/admin','/api/settings'])assert.equal((await worker.fetch(req(p,'GET',undefined,false),env,{})).status,401);
});
test('persistent saves update rendered source and reject stale edits',async()=>{
 const env={BUCKET:new Bucket()},first=await get(env);assert.equal(first.version,'initial');
 const s={...first.settings,name:'اختبار <script>',heroTitle:'عنوان جديد',code:'1234',links:{...first.settings.links,win:'https://example.com/download?a=1&b=2'}};
 const saved=await worker.fetch(req('/api/settings','PUT',{settings:s,version:first.version}),env,{});assert.equal(saved.status,200);
 const latest=await get(env);assert.equal(latest.settings.code,'1234');assert.equal(latest.version,'v1');
 const home=await (await worker.fetch(req('/'),env,{})).text();
 assert.ok(home.includes('عنوان جديد'));assert.ok(home.includes('اختبار &lt;script&gt;'));assert.ok(!home.includes('اختبار <script>'));
 const cfg=JSON.parse(home.match(/^var CFG=(.*);$/m)[1]);assert.equal(cfg.links.win,'https://example.com/download?a=1&b=2');assert.equal(cfg.name,s.name);
 assert.equal((await worker.fetch(req('/api/settings','PUT',{settings:s,version:first.version}),env,{})).status,409);
});
test('write origin and unsafe URLs are rejected without changing stored configuration',async()=>{
 const env={BUCKET:new Bucket()},first=await get(env);
 assert.equal((await worker.fetch(req('/api/settings','PUT',first,true,{origin:'https://evil.example'}),env,{})).status,403);
 const invalid={...first.settings,wa:'javascript:alert(1)'};
 assert.equal((await worker.fetch(req('/api/settings','PUT',{settings:invalid,version:first.version}),env,{})).status,400);
 const injected={...first.settings,logo:'https://x.invalid/" onerror="alert(1)'};
 assert.equal((await worker.fetch(req('/api/settings','PUT',{settings:injected,version:first.version}),env,{})).status,400);
 assert.equal((await get(env)).version,'initial');
});
test('logo upload validates image bytes, stores and serves the file',async()=>{
 const env={BUCKET:new Bucket()};
 const bad=await worker.fetch(req('/api/uploads','POST','<script>alert(1)</script>',true,{'content-type':'image/png'}),env,{});assert.equal(bad.status,400);
 const png=Uint8Array.from([137,80,78,71,13,10,26,10,0,0,0,0]);
 const upload=new Request(origin+'/api/uploads',{method:'POST',headers:{origin,'oai-authenticated-user-id':'owner-local-id','content-type':'image/png'},body:png});
 const result=await worker.fetch(upload,env,{});assert.equal(result.status,201);const data=await result.json();
 const asset=await worker.fetch(req(data.url),env,{});assert.equal(asset.status,200);assert.equal(asset.headers.get('content-type'),'image/png');
});
test('embedded original assets and missing storage failures are explicit',async()=>{
 const env={BUCKET:new Bucket()};
 const image=await worker.fetch(req('/download/shot/tv.jpg?v=original'),env,{});assert.equal(image.status,200);assert.equal((await image.arrayBuffer()).byteLength,32948);
 assert.equal((await worker.fetch(req('/api/settings'),{},{})).status,503);
 assert.equal((await worker.fetch(req('/'),{},{})).status,503);
});
