# Getsup private administration

Original download-page design with a private server-backed administration panel at `/admin`.

- Edit brand name, activation code, images, theme colors, hero/support text, app download URLs and WhatsApp.
- Settings are persisted as a configuration document in the Site's managed R2 binding `BUCKET`.
- Original screenshots/logo are embedded into the Worker and served from their original paths.
- Uploaded logos are validated as PNG/JPEG/WebP, limited to 2 MiB, and stored in the managed bucket.
- Administration relies on this Site's confirmed owner-private Sites access policy and authenticated request headers. Preserve that policy. Do not make this shared administration endpoint public without adding owner authorization.
- Every write checks same-origin requests and configuration versions; concurrent edits return a conflict.
- The original external gw-player.uk site is not connected. Nothing in this application grants access to or modifies that external server.

Source: `site/index.html`, `admin/index.html`, `worker/runtime.js`.

Build: `node scripts/build.mjs`. Tests: `node --test tests/worker.test.mjs` after building.

Deployable output: `dist/server/index.js` and `dist/.openai/hosting.json`. The original UI comes from https://gw-player.uk/download/getsupstore as explicitly requested by the user.
