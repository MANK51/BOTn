import { getChatGPTUser } from '@/app/chatgpt-auth';
import { json, readWriteBody, registryError, updateProject } from '@/lib/registry';

export const dynamic = 'force-dynamic';

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const user = await getChatGPTUser();
    if (!user) return json({ error: 'سجّل الدخول لتعديل الموقع.' }, 401);
    const { id } = await params;
    if (!id || id.length > 100) return json({ error: 'الموقع غير موجود.' }, 404);
    const body = await readWriteBody(request);
    return json({ project: await updateProject(user.userId, id, body) });
  } catch (error) { return registryError(error); }
}
