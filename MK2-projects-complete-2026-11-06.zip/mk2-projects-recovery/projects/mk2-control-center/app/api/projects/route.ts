import { getChatGPTUser } from '@/app/chatgpt-auth';
import { createProject, json, listProjects, readWriteBody, registryError } from '@/lib/registry';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await getChatGPTUser();
    if (!user) return json({ error: 'سجّل الدخول لعرض مواقعك.' }, 401);
    return json({ projects: await listProjects(user.userId) });
  } catch (error) { return registryError(error); }
}

export async function POST(request: Request) {
  try {
    const user = await getChatGPTUser();
    if (!user) return json({ error: 'سجّل الدخول لإضافة موقع.' }, 401);
    const body = await readWriteBody(request);
    return json({ project: await createProject(user.userId, body) }, 201);
  } catch (error) { return registryError(error); }
}
