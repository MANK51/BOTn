import { requireChatGPTUser, chatGPTSignOutPath } from './chatgpt-auth';
import { listProjects } from '../lib/registry';
import Dashboard from './Dashboard';
export const dynamic = 'force-dynamic';
export default async function Home() {
  const user = await requireChatGPTUser('/');
  try {
    const projects = await listProjects(user.userId);
    return <Dashboard initialProjects={projects} email={user.email} signOutUrl={chatGPTSignOutPath('/')} />;
  } catch {
    return <main className="standalone-error" dir="rtl"><h1>تعذّر تحميل مواقعك</h1><p>لم نتمكن من الوصول إلى بيانات اللوحة الآن. أعد تحميل الصفحة للمحاولة مرة أخرى.</p><a href="/">إعادة المحاولة</a></main>;
  }
}
