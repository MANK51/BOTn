import { integer, primaryKey, sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const projectOverrides = sqliteTable('project_overrides', {
  userId: text('user_id').notNull(),
  projectId: text('project_id').notNull(),
  payload: text('payload').notNull(),
  custom: integer('custom', { mode: 'boolean' }).notNull().default(false),
  savedAt: text('saved_at').notNull(),
}, (table) => [primaryKey({ columns: [table.userId, table.projectId] })]);
