CREATE TABLE `project_overrides` (
	`user_id` text NOT NULL,
	`project_id` text NOT NULL,
	`payload` text NOT NULL,
	`custom` integer DEFAULT false NOT NULL,
	`saved_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `project_id`)
);
