export type Project = {
 id: string; name: string; description: string; url: string | null; adminUrl: string | null;
 category: string; icon: string; color: string; published: boolean; access: 'public'|'private'|'unknown';
 version: number; updatedAt: string; adminHint: string; features: string[]; notes: string; favorite: boolean; custom?: boolean;
};

export const seedProjects: Project[] = [
  {
    "id": "appgprj_6ac85112969881919c25aed1da110cb3",
    "name": "عالمي الرقمي",
    "description": "الموقع الشخصي الاحترافي لـ MK~2 لعرض الأعمال والمشاريع والحسابات.",
    "url": "https://me.mk2space.cfd",
    "adminUrl": "https://me.mk2space.cfd/admin",
    "category": "شخصي",
    "icon": "sparkles",
    "color": "violet",
    "published": true,
    "access": "public",
    "version": 25,
    "updatedAt": "2026-10-22T09:37:35.500764+00:00",
    "adminHint": "سجّل الدخول بحساب الإدارة الخاص بالموقع.",
    "features": [
      "المشاريع والحسابات",
      "تصميم الموقع",
      "الرسائل والزيارات"
    ],
    "notes": "",
    "favorite": true
  },
  {
    "id": "appgprj_6ac64c24c8e8819199f48546a57afc76",
    "name": "MKk2movi",
    "description": "مكتبة للأفلام والمسلسلات ذات التراخيص المفتوحة، مع مصادر المشاهدة وبيانات الترخيص.",
    "url": "https://movie.mk2space.cfd",
    "adminUrl": "https://movie.mk2space.cfd/admin",
    "category": "ترفيه",
    "icon": "film",
    "color": "red",
    "published": true,
    "access": "public",
    "version": 47,
    "updatedAt": "2026-10-21T16:27:03.069889+00:00",
    "adminHint": "سجّل الدخول باسم المستخدم وكلمة مرور إدارة الأفلام.",
    "features": [
      "الأفلام والسيرفرات",
      "الرئيسية والتصميم",
      "الإحصاءات وسجل التعديلات"
    ],
    "notes": "",
    "favorite": true
  },
  {
    "id": "appgprj_6acfb490469c81919684cc4b8aac97ac",
    "name": "MK~2 Reality Engine",
    "description": "عوالم ثلاثية الأبعاد وتجارب تفاعلية مع أدوات إنشاء ومشاركة المشاهد.",
    "url": "https://mk2-reality-engine.m2000m1400.chatgpt.site",
    "adminUrl": "https://mk2-reality-engine.m2000m1400.chatgpt.site/",
    "category": "ألعاب",
    "icon": "cube",
    "color": "indigo",
    "published": true,
    "access": "private",
    "version": 1,
    "updatedAt": "2026-10-14T17:24:32.350360+00:00",
    "adminHint": "افتح الموقع، ثم ادخل بحساب ADMIN واختر Admin. الإدارة تتطلب اتصال الخادم الخاص بالمشروع.",
    "features": [
      "إدارة العوالم",
      "أدوار المستخدمين",
      "سجل النشاط"
    ],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6ace5c890e848191a8875d8fc095513b",
    "name": "لك قلب",
    "description": "اكتب اسمك، وشاهد قلبًا ورديًا يتكون من كلمات I love you، مع لوحة إدارة بسيطة للزوار.",
    "url": "https://love.mk2space.cfd",
    "adminUrl": "https://love.mk2space.cfd/admin",
    "category": "تجارب",
    "icon": "heart",
    "color": "pink",
    "published": true,
    "access": "public",
    "version": 5,
    "updatedAt": "2026-10-14T02:20:15.073148+00:00",
    "adminHint": "أدخل كلمة مرور لوحة «لك قلب».",
    "features": [
      "أسماء الزوار",
      "إحصاءات المشاركات",
      "الزيارات والإحالات"
    ],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6accd25a95d48191a7ddf32610e405c6",
    "name": "مراجعات القدرات",
    "description": "منصة عربية لمراجعة اختبار القدرات، تجمع المراجعات والقنوات والدورات المجانية وخطة المذاكرة.",
    "url": "https://qudrat.mk2space.cfd",
    "adminUrl": "https://qudrat.mk2space.cfd/admin",
    "category": "تعليم",
    "icon": "book",
    "color": "blue",
    "published": true,
    "access": "public",
    "version": 5,
    "updatedAt": "2026-10-12T13:34:16.236854+00:00",
    "adminHint": "سجّل الدخول بحساب مسجل بصلاحية مدير.",
    "features": [
      "بنك الأسئلة والمراجعات",
      "المصادر والمقاطع",
      "الحسابات والنتائج"
    ],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6ac92ea21b288191b77f5c1d2d721330",
    "name": "MK~2 REALMS",
    "description": "منصة عوالم وتحديات تفاعلية داخل Telegram مع بوت ولوحة إدارة.",
    "url": "https://realms.mk2space.cfd",
    "adminUrl": "https://realms.mk2space.cfd/admin",
    "category": "ألعاب",
    "icon": "layers",
    "color": "teal",
    "published": true,
    "access": "public",
    "version": 4,
    "updatedAt": "2026-10-10T02:05:37.239024+00:00",
    "adminHint": "الدخول بحساب ChatGPT المالك أو حساب فريق موثّق.",
    "features": [
      "العوالم والتحديات",
      "المستخدمون والفرق",
      "المكافآت والإعدادات"
    ],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6ac7030540388191839ab20801d7ad5e",
    "name": "تحدي اليوم",
    "description": "منصة عربية للمسابقات الثقافية والتحدي من 100 سؤال",
    "url": "https://games.mk2space.cfd",
    "adminUrl": "https://games.mk2space.cfd/",
    "category": "تعليم",
    "icon": "trophy",
    "color": "amber",
    "published": true,
    "access": "public",
    "version": 10,
    "updatedAt": "2026-10-08T11:44:59.079306+00:00",
    "adminHint": "سجّل الدخول إلى الموقع بحساب المدير، ثم اختر «الإدارة».",
    "features": [
      "الأسئلة والمسابقات",
      "المستخدمون والصلاحيات",
      "النتائج والشهادات"
    ],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6ac687fe6aa481919b8bbd2127783115",
    "name": "كودك — مولّد الأكواد",
    "description": "أداة عربية لتحويل الأفكار إلى مشاريع برمجية صغيرة قابلة للمعاينة والتحميل.",
    "url": "https://codek-micro-tools.m2000m1400.chatgpt.site",
    "adminUrl": "https://codek-micro-tools.m2000m1400.chatgpt.site/generator.html",
    "category": "أدوات",
    "icon": "code",
    "color": "orange",
    "published": true,
    "access": "public",
    "version": 5,
    "updatedAt": "2026-10-07T19:00:19.851919+00:00",
    "adminHint": "افتح المولّد، ثم اختر «لوحة الإدارة» وسجّل الدخول. بعض إعدادات القوالب محلية داخل المتصفح.",
    "features": [
      "إحصاءات الزيارات",
      "إحصاءات المستخدمين",
      "إعدادات القوالب المحلية"
    ],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6ad9ce57eb388191a32c488af5b04d5e",
    "name": "آية ويدجت — نسخة الويب",
    "description": "نسخة ويب من تجربة آية ويدجت، بالآيات والخط المستخرجين من التطبيق المرفق.",
    "url": null,
    "adminUrl": null,
    "category": "تجارب",
    "icon": "moon",
    "color": "teal",
    "published": false,
    "access": "private",
    "version": 0,
    "updatedAt": "2026-10-22T08:50:45.767627+00:00",
    "adminHint": "المشروع غير منشور ولا توجد لوحة إدارة مرتبطة به.",
    "features": [],
    "notes": "",
    "favorite": false
  },
  {
    "id": "appgprj_6ac8e4f941f88191ac546926090ae88f",
    "name": "كاشف API",
    "description": "أداة بسيطة لفحص توثيق API المنشور للعامة لمواقع الويب.",
    "url": null,
    "adminUrl": null,
    "category": "أدوات",
    "icon": "terminal",
    "color": "slate",
    "published": false,
    "access": "private",
    "version": 0,
    "updatedAt": "2026-10-09T12:58:46.593687+00:00",
    "adminHint": "المشروع غير منشور ولا توجد لوحة إدارة مرتبطة به.",
    "features": [],
    "notes": "",
    "favorite": false
  }
];

