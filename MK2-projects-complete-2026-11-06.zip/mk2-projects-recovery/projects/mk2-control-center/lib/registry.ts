import { env } from 'cloudflare:workers';
import { seedProjects, type Project } from './projects';

export class RegistryError extends Error {
  constructor(message: string, readonly status = 400) { super(message); }
}

type Editable = Pick<Project, 'name' | 'description' | 'url' | 'adminUrl' | 'notes' | 'favorite' | 'category'>;
type StoredRow = { project_id: string; payload: string; custom: number; saved_at: string };
const TEXT_LIMITS = { name: 120, description: 600, notes: 4000, category: 60 } as const;
const MAX_PROJECTS = 300;

function database() {
  if (!env.DB) throw new Error('Database unavailable');
  return env.DB;
}

function safeUrl(value: unknown): string | null {
  if (value === null || value === '') return null;
  if (typeof value !== 'string' || value.length > 2048) throw new RegistryError('أدخل رابطًا صحيحًا يبدأ بـ https://.');
  let parsed: URL;
  try { parsed = new URL(value.trim()); } catch { throw new RegistryError('أدخل رابطًا صحيحًا يبدأ بـ https://.'); }
  const host = parsed.hostname.toLowerCase();
  const labels = host.split('.');
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || (parsed.port && parsed.port !== '443') ||
      labels.length < 2 || !/^[a-z0-9.-]+$/.test(host) || !/[a-z]/.test(labels.at(-1) || '') ||
      labels.some(label => !label || label.startsWith('-') || label.endsWith('-')) ||
      /(^|\.)(localhost|local|internal|test|invalid|example|onion)$/.test(host)) {
    throw new RegistryError('استخدم رابط HTTPS لموقع منشور، دون بيانات دخول داخل الرابط.');
  }
  return parsed.href;
}

export function validatePatch(input: unknown, creating = false): Partial<Editable> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new RegistryError('بيانات الموقع غير صحيحة.');
  const source = input as Record<string, unknown>;
  const patch: Partial<Editable> = {};
  for (const [field, limit] of Object.entries(TEXT_LIMITS)) {
    if (!(field in source)) continue;
    if (typeof source[field] !== 'string' || (source[field] as string).length > limit) {
      throw new RegistryError(`تأكد من النص المدخل؛ الحد الأقصى ${limit} حرفًا.`);
    }
    const text = (source[field] as string).trim();
    if ((field === 'name' || field === 'category') && !text) throw new RegistryError('اسم الموقع والتصنيف مطلوبان.');
    Object.assign(patch, { [field]: text });
  }
  for (const field of ['url', 'adminUrl'] as const) {
    if (field in source) patch[field] = safeUrl(source[field]);
  }
  if ('favorite' in source) {
    if (typeof source.favorite !== 'boolean') throw new RegistryError('قيمة المفضلة غير صحيحة.');
    patch.favorite = source.favorite;
  }
  if (creating && !patch.name) throw new RegistryError('اكتب اسم الموقع.');
  return patch;
}

function editable(project: Project): Editable {
  return {
    name: project.name, description: project.description, url: project.url,
    adminUrl: project.adminUrl, notes: project.notes, favorite: project.favorite,
    category: project.category,
  };
}

function customProject(id: string, patch: Partial<Editable>, savedAt = new Date().toISOString()): Project {
  return {
    id, name: patch.name || 'موقع جديد', description: patch.description || '',
    url: patch.url || null, adminUrl: patch.adminUrl || null,
    category: patch.category || 'أخرى', icon: 'globe', color: 'violet',
    published: Boolean(patch.url), access: 'unknown', version: 0,
    updatedAt: savedAt, adminHint: 'افتح لوحة الإدارة المرتبطة وسجّل الدخول بحساب الموقع عند الحاجة.',
    features: [], notes: patch.notes || '', favorite: patch.favorite || false, custom: true,
  };
}

export async function listProjects(userId: string): Promise<Project[]> {
  const rows = await database().prepare(
    'SELECT project_id, payload, custom, saved_at FROM project_overrides WHERE user_id = ? ORDER BY saved_at ASC',
  ).bind(userId).all<StoredRow>();
  const overrides = new Map(rows.results.map(row => [row.project_id, row]));
  const result = seedProjects.map(seed => {
    const row = overrides.get(seed.id);
    overrides.delete(seed.id);
    return row ? { ...seed, ...validatePatch(JSON.parse(row.payload)) } : { ...seed };
  });
  for (const row of overrides.values()) {
    if (row.custom) result.push(customProject(row.project_id, validatePatch(JSON.parse(row.payload), true), row.saved_at));
  }
  return result;
}

export async function createProject(userId: string, input: unknown): Promise<Project> {
  const patch = validatePatch(input, true);
  const count = await database().prepare('SELECT COUNT(*) AS total FROM project_overrides WHERE user_id = ? AND custom = 1')
    .bind(userId).first<{ total: number }>();
  if ((count?.total || 0) + seedProjects.length >= MAX_PROJECTS) throw new RegistryError('وصلت إلى الحد الأقصى للمواقع المرتبطة.', 409);
  const project = customProject('custom_' + crypto.randomUUID(), patch);
  await database().prepare('INSERT INTO project_overrides (user_id, project_id, payload, custom, saved_at) VALUES (?, ?, ?, 1, ?)')
    .bind(userId, project.id, JSON.stringify(editable(project)), project.updatedAt).run();
  return project;
}

export async function updateProject(userId: string, id: string, input: unknown): Promise<Project> {
  const patch = validatePatch(input);
  const projects = await listProjects(userId);
  const previous = projects.find(project => project.id === id);
  if (!previous) throw new RegistryError('هذا الموقع غير موجود في قائمتك.', 404);
  const project: Project = { ...previous, ...patch };
  const savedAt = new Date().toISOString();
  if (project.custom) {
    project.published = Boolean(project.url);
    project.updatedAt = savedAt;
  }
  await database().prepare(
    'INSERT INTO project_overrides (user_id, project_id, payload, custom, saved_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(user_id, project_id) DO UPDATE SET payload = excluded.payload, saved_at = excluded.saved_at',
  ).bind(userId, id, JSON.stringify(editable(project)), project.custom ? 1 : 0, savedAt).run();
  return project;
}

export function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store', Vary: 'Cookie' } });
}

export async function readWriteBody(request: Request) {
  if (request.headers.get('origin') !== new URL(request.url).origin) throw new RegistryError('تعذر التحقق من مصدر الطلب. أعد فتح اللوحة.', 403);
  if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') throw new RegistryError('صيغة الطلب غير صحيحة.', 415);
  if (Number(request.headers.get('content-length') || 0) > 20000) throw new RegistryError('البيانات أكبر من الحد المسموح.', 413);
  const raw = await request.text();
  if (raw.length > 20000) throw new RegistryError('البيانات أكبر من الحد المسموح.', 413);
  try { return JSON.parse(raw); } catch { throw new RegistryError('صيغة البيانات غير صحيحة.'); }
}

export function registryError(error: unknown) {
  return error instanceof RegistryError
    ? json({ error: error.message }, error.status)
    : json({ error: 'تعذر حفظ أو تحميل المواقع الآن. حاول مرة أخرى.' }, 503);
}
