"use client";

import { FormEvent, useCallback, useEffect, useRef, useState } from "react";
import type { CatalogScope } from "../lib/vidsrc-catalog-types";
import "./series-library.css";

export type SeriesLibraryItem = {
  id: string;
  title: string;
  originalTitle: string;
  poster: string | null;
  backdrop: string | null;
  description: string;
  year: string;
  rating: string;
  genre: string;
  genreIds: number[];
};

type CatalogResponse = {
  items: SeriesLibraryItem[];
  page: number;
  totalPages: number;
  totalResults: number;
  hasMore: boolean;
  metadataSource: "tmdb" | "vidsrc";
  partial: boolean;
  enabled: boolean;
  scope?: CatalogScope;
  year?: number | null;
  partialReason?: "scoped-search" | "provider-fallback";
  totalResultsExact?: boolean;
  metadataIncomplete?: boolean;
};

const scopes: ReadonlyArray<{ id: CatalogScope; label: string }> = [
  { id: "arabic", label: "عربي" },
  { id: "gulf", label: "خليجي" },
  { id: "shahid", label: "أعمال شاهد" },
  { id: "all", label: "الكل" },
];

const genres = [
  ["", "كل التصنيفات"],
  ["10759", "أكشن ومغامرة"],
  ["16", "رسوم متحركة"],
  ["35", "كوميديا"],
  ["80", "جريمة"],
  ["99", "وثائقي"],
  ["18", "دراما"],
  ["10751", "عائلي"],
  ["9648", "غموض"],
  ["10765", "خيال علمي وفانتازيا"],
  ["10764", "برامج واقعية"],
  ["10768", "حرب وسياسة"],
] as const;

const formatCount = (value: number) => new Intl.NumberFormat("ar").format(value);
const productionYears = Array.from({ length: new Date().getUTCFullYear() - 1899 }, (_, index) => String(new Date().getUTCFullYear() - index));
const searchLabels: Record<CatalogScope, string> = { arabic: "المسلسلات العربية", gulf: "المسلسلات الخليجية", shahid: "أعمال شاهد", all: "كل المسلسلات" };

function PlayIcon() {
  return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.7c0-.8.9-1.3 1.6-.9l10 6.3c.7.4.7 1.4 0 1.8l-10 6.3c-.7.4-1.6-.1-1.6-.9V5.7Z" /></svg>;
}

function seriesLabel(item: SeriesLibraryItem) {
  return [item.title, item.year, item.originalTitle !== item.title ? item.originalTitle : ""].filter(Boolean).join(" · ");
}

function SeriesPoster({ item }: { item: SeriesLibraryItem }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [item.poster]);
  return (
    <span className="series-directory-poster">
      {item.poster && !failed ? (
        <img src={item.poster} alt={`بوستر ${item.title}`} loading="lazy" decoding="async" onError={() => setFailed(true)} />
      ) : (
        <span className="series-directory-no-poster"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><rect x="7" y="12" width="34" height="25" rx="5" /><path d="m17 6 7 6 7-6M18 42h12m-6-5v5" /><path d="m21 20 9 5-9 5z" /></svg><span>{item.title}</span></span>
      )}
      <span className="series-directory-badge">مسلسل</span>
      {Number(item.rating) > 0 && <span className="series-directory-poster-rating"><span aria-hidden="true">★</span><span aria-label={`التقييم ${item.rating} من 10`}>{item.rating}</span></span>}
      <span className="series-directory-play"><PlayIcon /></span>
    </span>
  );
}

export default function SeriesLibrary({ onOpen, onFeatured }: { onOpen: (item: SeriesLibraryItem) => void; onFeatured?: (item: SeriesLibraryItem) => void }) {
  const [draftQuery, setDraftQuery] = useState("");
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("");
  const [scope, setScope] = useState<CatalogScope>("arabic");
  const [yearsByScope, setYearsByScope] = useState<Record<CatalogScope, string>>({ arabic: "", gulf: "", shahid: "", all: "" });
  const year = yearsByScope[scope];
  const [items, setItems] = useState<SeriesLibraryItem[]>([]);
  const [catalog, setCatalog] = useState<Omit<CatalogResponse, "items"> | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const requestId = useRef(0);
  const activeRequest = useRef<AbortController | null>(null);
  const featuredCallback = useRef(onFeatured);
  const failedRequest = useRef<{ page: number; replace: boolean } | null>(null);

  useEffect(() => { featuredCallback.current = onFeatured; }, [onFeatured]);

  const loadCatalog = useCallback(async (page: number, replace: boolean) => {
    activeRequest.current?.abort();
    const controller = new AbortController();
    activeRequest.current = controller;
    const currentRequest = ++requestId.current;
    setError("");
    if (replace) {
      setLoading(true);
      setLoadingMore(false);
      setItems([]);
      setCatalog(null);
    } else {
      setLoadingMore(true);
    }
    try {
      const parameters = new URLSearchParams({ page: String(page), scope });
      if (query) parameters.set("q", query);
      if (genre) parameters.set("genre", genre);
      if (year) parameters.set("year", year);
      const response = await fetch(`/api/vidsrc/catalog?${parameters}`, { signal: controller.signal, cache: "no-store" });
      const data = await response.json() as CatalogResponse & { error?: string };
      if (currentRequest !== requestId.current || controller.signal.aborted) return;
      if (!response.ok) throw new Error(data.error || "تعذّر تحميل المسلسلات. حاول مرة أخرى.");
      if (!Array.isArray(data.items) || typeof data.enabled !== "boolean") throw new Error("تعذّر تحميل المسلسلات. حاول مرة أخرى.");
      setEnabled(data.enabled);
      failedRequest.current = null;
      if (!data.enabled) {
        setItems([]);
        setCatalog(null);
        return;
      }
      setItems((previous) => {
        if (replace) return data.items;
        const existingIds = new Set(previous.map((item) => item.id));
        return [...previous, ...data.items.filter((item) => !existingIds.has(item.id))];
      });
      setCatalog({ page: data.page, totalPages: data.totalPages, totalResults: data.totalResults, hasMore: data.hasMore, metadataSource: data.metadataSource, partial: data.partial, enabled: data.enabled, scope: data.scope, year: data.year, partialReason: data.partialReason, totalResultsExact: data.totalResultsExact, metadataIncomplete: data.metadataIncomplete });
      if (page === 1 && !query && !genre && !year) {
        const featured = data.items.find((item) => item.backdrop || item.poster);
        if (featured) featuredCallback.current?.(featured);
      }
    } catch (failure) {
      if (currentRequest !== requestId.current || controller.signal.aborted) return;
      failedRequest.current = { page, replace };
      setError(failure instanceof Error ? failure.message : "تعذّر تحميل المسلسلات. حاول مرة أخرى.");
    } finally {
      if (currentRequest === requestId.current && !controller.signal.aborted) {
        setLoading(false);
        setLoadingMore(false);
      }
    }
  }, [query, genre, scope, year]);

  useEffect(() => {
    void loadCatalog(1, true);
    return () => {
      activeRequest.current?.abort();
      requestId.current += 1;
    };
  }, [loadCatalog, refresh]);

  useEffect(() => {
    const reload = () => {
      activeRequest.current?.abort();
      requestId.current += 1;
      setEnabled(null);
      setItems([]);
      setCatalog(null);
      setLoading(true);
      setRefresh((value) => value + 1);
    };
    window.addEventListener("mk2-catalog-refresh", reload);
    return () => window.removeEventListener("mk2-catalog-refresh", reload);
  }, []);

  const prepareCatalogReload = () => {
    activeRequest.current?.abort();
    requestId.current += 1;
    failedRequest.current = null;
    setItems([]);
    setCatalog(null);
    setLoading(true);
    setLoadingMore(false);
  };

  const search = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const nextQuery = draftQuery.trim();
    prepareCatalogReload();
    setQuery(nextQuery);
    if (nextQuery === query) setRefresh((value) => value + 1);
  };

  const selectScope = (nextScope: CatalogScope) => {
    if (nextScope === scope) return;
    prepareCatalogReload();
    setScope(nextScope);
  };

  const resetSearch = () => {
    prepareCatalogReload();
    setDraftQuery("");
    setQuery("");
    setGenre("");
    setYearsByScope((previous) => ({ ...previous, [scope]: "" }));
  };

  if (enabled === false) return null;

  return (
    <section className="series-directory" dir="rtl" aria-labelledby="series-directory-heading" aria-busy={loading || loadingMore}>
      <div className="series-directory-toolbar">
        <div className="series-directory-heading">
          <span className="section-kicker">حكايتك التالية تبدأ هنا</span>
          <h2 id="series-directory-heading">مكتبة المسلسلات</h2>
          <p>تصفّح الأعمال، تعرّف على القصة، واختر حلقتك.</p>
        </div>
        <form className="series-directory-search" onSubmit={search} role="search" aria-label={`البحث في ${searchLabels[scope]}`}>
          <label className="series-directory-search-input">
            <span className="series-directory-sr-only">اسم المسلسل</span>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></svg>
            <input type="search" value={draftQuery} onChange={(event) => setDraftQuery(event.target.value)} placeholder={`ابحث في ${searchLabels[scope]}`} aria-describedby="series-directory-search-scope" maxLength={100} enterKeyHint="search" />
          </label>
          <button type="submit" className="series-directory-search-button">بحث</button>
        </form>
      </div>
      <div className="series-directory-scopes" role="group" aria-label="أقسام المسلسلات">
        {scopes.map((item) => <button key={item.id} type="button" className={`series-directory-scope${scope === item.id ? " is-active" : ""}`} data-catalog-scope={item.id} aria-pressed={scope === item.id} onClick={() => selectScope(item.id)}>{item.label}</button>)}
      </div>
      <p id="series-directory-search-scope" className="series-directory-scope-note">البحث داخل {searchLabels[scope]}{year ? ` · إنتاج ${year}` : ""}.</p>
      {scope === "shahid" && <p className="series-directory-scope-note">أعمال مرتبطة بشاهد في بيانات TMDb؛ توفّر الحلقات يختلف حسب سيرفر المشاهدة.</p>}
      <div className="series-directory-controls">
        <label className="series-directory-genre"><span>التصنيف</span><select value={genre} onChange={(event) => { prepareCatalogReload(); setGenre(event.target.value); }}>{genres.map(([id, name]) => <option key={id} value={id}>{name}</option>)}</select></label>
        <label className="series-directory-year-filter"><span>سنة الإنتاج</span><select data-catalog-year aria-describedby="series-directory-year-note" value={year} onChange={(event) => { const nextYear = event.target.value; if (nextYear === year) return; prepareCatalogReload(); setYearsByScope((previous) => ({ ...previous, [scope]: nextYear })); }}><option value="">كل السنوات</option>{productionYears.map((value) => <option key={value} value={value}>{value}</option>)}</select></label>
        {(query || genre || year) && <button type="button" className="series-directory-clear" onClick={resetSearch}>مسح الفلاتر</button>}
        <p className="series-directory-count" aria-live="polite" aria-atomic="true">{loading ? "جارٍ تحميل المسلسلات…" : catalog ? `${formatCount(items.length)} مسلسل${query ? ` · نتائج «${query}»` : ""}${year ? ` · إنتاج ${year}` : ""}` : ""}</p>
      </div>
      <p id="series-directory-year-note" className="series-directory-year-note">السنة بحسب بداية عرض المسلسل.</p>
      {catalog?.partial && <p className="series-directory-notice" role="status">{catalog.partialReason === "scoped-search" ? `نعرض نتائج البحث المطابقة لهذا القسم${catalog.hasMore ? "؛ اعرض المزيد لفحص بقية النتائج." : "."}` : "القائمة المختصرة متاحة حاليًا؛ الفلاتر والبحث يشملان هذه الأعمال."}</p>}
      {catalog?.metadataIncomplete && <div className="series-directory-metadata-notice" role="status"><p>تعذّر التحقق من بيانات بعض الأعمال؛ قد تظهر نتائج إضافية عند إعادة المحاولة.</p><button type="button" data-catalog-retry-metadata className="series-directory-action" disabled={loadingMore} onClick={() => void loadCatalog(catalog.page, catalog.page === 1)}>إعادة التحقق من النتائج</button></div>}
      {query && items.length > 0 && <p className="series-directory-search-hint">الاسم الأصلي وسنة الإصدار يميّزان الأعمال التي تحمل الاسم نفسه.</p>}
      {loading ? (
        <div className="series-directory-loading" role="status"><span className="series-directory-sr-only">نجهّز مكتبة المسلسلات…</span><div className="series-directory-skeleton-grid" aria-hidden="true">{Array.from({ length: 5 }, (_, index) => <span className="series-directory-skeleton" key={index}><span /><span /><span /></span>)}</div></div>
      ) : (
        <>
          {items.length > 0 && <div className="series-directory-grid" aria-label="المسلسلات">
            {items.map((item) => <button type="button" className="series-directory-card" data-series-id={item.id} key={item.id} onClick={() => onOpen(item)} aria-label={`عرض مسلسل ${seriesLabel(item)} والمواسم والحلقات`}>
              <SeriesPoster item={item} />
              <span className="series-directory-card-info">
                <span className="series-directory-title-row"><span className="series-directory-title">{item.title}</span>{item.year && <span className="series-directory-year" aria-label={`سنة الإصدار ${item.year}`}>{item.year}</span>}</span>
                {item.originalTitle && item.originalTitle !== item.title && <span className="series-directory-original-title" dir="auto">{item.originalTitle}</span>}
                {item.genre && <span className="series-directory-card-genre">{item.genre}</span>}
                <span className="series-directory-watch"><span>عرض الحلقات</span><span className="series-directory-arrow" aria-hidden="true">←</span></span>
              </span>
            </button>)}
          </div>}
          {error ? <div className="series-directory-message" role="alert"><p>{error}</p><button type="button" className="series-directory-action" onClick={() => { const retry = failedRequest.current ?? { page: 1, replace: true }; void loadCatalog(retry.page, retry.replace); }}>حاول مرة أخرى</button></div> : items.length === 0 && <div className="series-directory-message"><p>{catalog?.metadataIncomplete ? "لم يكتمل التحقق من بيانات الأعمال؛ أعد التحقق من النتائج قبل متابعة البحث." : catalog?.hasMore ? "لم يظهر عمل مطابق في النتائج المفحوصة حتى الآن؛ اعرض المزيد لمتابعة البحث." : query || genre || year ? `لا توجد مسلسلات مطابقة لهذه الفلاتر في ${searchLabels[scope]}.` : `لا توجد مسلسلات متاحة حاليًا في ${searchLabels[scope]}.`}</p>{(query || genre || year) && !catalog?.hasMore && !catalog?.metadataIncomplete && <button type="button" className="series-directory-action" onClick={resetSearch}>مسح الفلاتر وتصفّح القسم</button>}</div>}
          {catalog?.hasMore && !error && <div className="series-directory-more"><button type="button" className="series-directory-action" disabled={loadingMore} onClick={() => void loadCatalog(catalog.page + 1, false)}>{loadingMore && <span className="series-directory-spinner" aria-hidden="true" />}{loadingMore ? "جارٍ تحميل المزيد…" : "عرض المزيد من المسلسلات"}</button></div>}
        </>
      )}
      {catalog?.metadataSource === "tmdb" && <div className="series-directory-credit"><a href="https://www.themoviedb.org" target="_blank" rel="noopener noreferrer" aria-label="بيانات الأعمال من TMDb"><img src="/tmdb-logo.svg" alt="TMDb" width="110" height="15" loading="lazy" /></a><span>البوسترات وبيانات المسلسلات من TMDb. هذا المنتج يستخدم TMDb API لكنه غير معتمد أو مصدّق من TMDb.</span></div>}
    </section>
  );
}
