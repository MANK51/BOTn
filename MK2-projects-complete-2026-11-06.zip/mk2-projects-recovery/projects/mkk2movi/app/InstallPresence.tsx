"use client";
import { useEffect } from "react";
import { shouldRecordInstallPresence, type InstallPlatform } from "../lib/app-installation-types";
import type { PublicSiteAccount } from "../lib/account-security";

/** Reports genuine standalone openings only; visiting the site or accepting a prompt does not count. */
export default function InstallPresence({ account }: { account: PublicSiteAccount | null }) {
  useEffect(() => {
    if (!account) return;
    const controller = new AbortController();
    const media = window.matchMedia("(display-mode: standalone)");
    const storageKey = `mk2-install-presence-v1:${account.id}`;
    let inFlight = false;
    let lastAttempt = 0;
    let lastSuccess = 0;
    try { lastSuccess = Number(localStorage.getItem(storageKey)) || 0; } catch { /* Private browsing still records at most once per open. */ }
    function installed() { return media.matches || (navigator as Navigator & { standalone?: boolean }).standalone === true; }
    function platform(): InstallPlatform {
      if (/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1)) return "ios";
      if (/Android/i.test(navigator.userAgent)) return "android";
      return /Windows|Mac|Linux/i.test(navigator.platform) ? "desktop" : "unknown";
    }
    async function report() {
      const now = Date.now();
      if (!installed() || document.visibilityState === "hidden" || inFlight || controller.signal.aborted || now - lastAttempt < 60_000 || !shouldRecordInstallPresence(lastSuccess, now)) return;
      lastAttempt = now;
      inFlight = true;
      try {
        const response = await fetch("/api/account/installations", { method: "POST", credentials: "same-origin", cache: "no-store", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ displayMode: "standalone", platform: platform() }), signal: controller.signal });
        if (!response.ok) return;
        const result = await response.json() as { ok?: boolean; recordedAt?: string };
        const recordedAt = Date.parse(result.recordedAt ?? "");
        if (result.ok && Number.isFinite(recordedAt)) {
          lastSuccess = recordedAt;
          try { localStorage.setItem(storageKey, String(recordedAt)); } catch { /* Server also throttles one update per account per day. */ }
        }
      } catch { /* Telemetry must never interrupt watching or signing in. */ }
      finally { inFlight = false; }
    }
    const check = () => { void report(); };
    check();
    window.addEventListener("pageshow", check);
    document.addEventListener("visibilitychange", check);
    media.addEventListener("change", check);
    return () => { controller.abort(); window.removeEventListener("pageshow", check); document.removeEventListener("visibilitychange", check); media.removeEventListener("change", check); };
  }, [account?.id]);
  return null;
}
