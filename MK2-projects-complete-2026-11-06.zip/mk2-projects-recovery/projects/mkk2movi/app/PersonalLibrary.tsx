"use client";

import { useState } from "react";
import { Bookmark, Clock3, Heart, Play, Trash2 } from "lucide-react";
import type { CinemaItem } from "../lib/cinema-types";
import { clearViewerLibrary, continueViewerEntries, removeViewerEntry, viewerLibraryStorageIsPersistent, type ViewerCollection, type ViewerEntry } from "../lib/viewer-library";
import { useViewerLibrary } from "./UserActions";
import "./personal-library.css";

const tabs = [
  { id: "continue", label: "أكمل المشاهدة", icon: Play }, { id: "favorites", label: "المفضلة", icon: Heart },
  { id: "watchLater", label: "أشاهد لاحقًا", icon: Bookmark }, { id: "history", label: "السجل", icon: Clock3 },
] as const;
type Tab = typeof tabs[number]["id"];

export function PersonalLibrary({ onOpen, signedIn }: { onOpen: (item: CinemaItem, position?: { season?: number; episode?: number }) => void; signedIn: boolean }) {
  const library = useViewerLibrary();
  const [tab, setTab] = useState<Tab>("continue");
  const [confirmClear, setConfirmClear] = useState(false);
  const [status, setStatus] = useState("");
  const continued = continueViewerEntries(library);
  const entries = tab === "continue" ? continued : library[tab];
  const total = library.favorites.length + library.watchLater.length + library.history.length;
  const count = (id: Tab) => id === "continue" ? continued.length : library[id].length;
  function remove(entry: ViewerEntry) { removeViewerEntry(tab === "continue" ? "history" : tab as ViewerCollection, entry.key); setStatus(`أُزيل ${entry.item.title} من القائمة`); }

  return <section className="personal-library" id="my-library" aria-labelledby="personal-library-title" dir="rtl">
    <div className="personal-library-heading"><div><span className="personal-library-eyebrow">مساحتك الخاصة</span><h2 id="personal-library-title">مكتبتي</h2><p>{viewerLibraryStorageIsPersistent() ? "قوائمك وسجلك محفوظة على هذا المتصفح." : "التخزين الدائم محظور في متصفحك؛ تبقى الاختيارات لهذه الجلسة فقط."} {signedIn ? "يمكنك مزامنتها مع حساب الموقع من زر المزامنة." : "لن تحتاج إلى حساب لحفظ اختياراتك هنا."}</p></div>
      {total > 0 && <button type="button" className="viewer-clear-button" onClick={() => setConfirmClear(!confirmClear)}><Trash2 size={16} />مسح مكتبتي</button>}
    </div>
    {confirmClear && <div className="viewer-clear-confirm" role="alert"><p>سيُحذف سجل المشاهدة والمفضلة وقائمة لاحقًا من هذا المتصفح، ومن حسابك عند تفعيل المزامنة.</p><button type="button" onClick={() => { clearViewerLibrary(); setConfirmClear(false); setStatus("تم مسح مكتبتك"); }}>تأكيد المسح</button><button type="button" onClick={() => setConfirmClear(false)}>إلغاء</button></div>}
    <div className="personal-library-tabs" role="tablist" aria-label="قوائم مكتبتي">{tabs.map(({ id, label, icon: Icon }) => <button key={id} type="button" id={`viewer-tab-${id}`} role="tab" aria-selected={tab === id} aria-controls="personal-library-panel" tabIndex={tab === id ? 0 : -1} onKeyDown={(event) => { if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return; event.preventDefault(); const index = tabs.findIndex((entry) => entry.id === tab); const next = event.key === "Home" ? 0 : event.key === "End" ? tabs.length - 1 : (index + (event.key === "ArrowLeft" ? 1 : -1) + tabs.length) % tabs.length; setTab(tabs[next].id); document.getElementById(`viewer-tab-${tabs[next].id}`)?.focus(); }} onClick={() => setTab(id)}><Icon size={17} />{label}<span>{count(id).toLocaleString("ar")}</span></button>)}</div>
    <div className="personal-library-panel" id="personal-library-panel" role="tabpanel" aria-labelledby={`viewer-tab-${tab}`}>
      {entries.length === 0 ? <div className="personal-library-empty"><Bookmark size={30} /><h3>{tab === "continue" ? "حلقتك القادمة تنتظرك" : "قائمتك تبدأ باختيار"}</h3><p>{tab === "continue" ? "يظهر هنا تقدمك عند وصول بيانات مشاهدة فعلية من المشغل. بعض السيرفرات الخارجية لا تدعم إرسال التقدم." : tab === "history" ? "افتح عملًا من المكتبة ليظهر في سجلك هنا." : "استخدم القلب أو زر أشاهد لاحقًا على أي عمل لحفظه هنا."}</p></div> : <div className="personal-library-grid">{entries.map((entry) => {
        const progress = entry.progress;
        const percent = progress ? Math.min(100, Math.round(progress.currentTime / progress.duration * 100)) : 0;
        return <article className="personal-library-card" key={entry.key}>
          <button type="button" className="personal-library-open" onClick={() => onOpen(entry.item, tab === "continue" && progress ? { season: progress.season, episode: progress.episode } : undefined)} aria-label={`فتح ${entry.item.title}`}>
            <div className="personal-library-poster"><span className="personal-library-poster-fallback" aria-hidden="true">MK2</span>{entry.item.poster && <img src={entry.item.poster} alt="" loading="lazy" decoding="async" onError={(event) => { event.currentTarget.style.visibility = "hidden"; }} />}<span className="personal-library-play"><Play size={20} fill="currentColor" /></span>{tab === "continue" && progress && <span className="personal-library-progress" role="progressbar" aria-label="تقدم المشاهدة" aria-valuenow={percent} aria-valuemin={0} aria-valuemax={100}><i style={{ width: `${percent}%` }} /></span>}</div>
            <h3>{entry.item.title}</h3><p>{entry.item.year}{entry.item.year ? " · " : ""}{entry.item.mediaType === "tv" ? "مسلسل" : "فيلم"}</p>
            {tab === "continue" && progress && <small>{entry.item.mediaType === "tv" ? `الموسم ${progress.season} · الحلقة ${progress.episode}` : "فتح الفيلم"} · {percent.toLocaleString("ar")}%</small>}
          </button><button type="button" className="personal-library-remove" title="إزالة من القائمة" aria-label={`إزالة ${entry.item.title} من القائمة`} onClick={() => remove(entry)}><Trash2 size={15} /></button>
        </article>;
      })}</div>}
    </div><span className="viewer-sr-only" role="status">{status}</span>
  </section>;
}
