"use client";

import { useEffect, useRef, useState, type RefObject } from "react";
import { enterPlayerFullscreen, exitPlayerFullscreen, fullscreenElement, type PlayerFullscreenMode } from "../lib/native-player";

export function PlayerFullscreen({ containerRef, videoRef, resetKey }: { containerRef: RefObject<HTMLDivElement | null>; videoRef: RefObject<HTMLVideoElement | null>; resetKey: string }) {
  const [mode, setMode] = useState<PlayerFullscreenMode | null>(null);
  const modeRef = useRef(mode);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const busyRef = useRef(false);
  const restoreRef = useRef<(() => void) | null>(null);
  const generationRef = useRef(0);
  modeRef.current = mode;

  useEffect(() => {
    const container = containerRef.current;
    const video = videoRef.current;
    if (!container) return;
    setMode(null);
    const dismiss = () => { restoreRef.current?.(); restoreRef.current = null; modeRef.current = null; setMode(null); buttonRef.current?.focus({ preventScroll: true }); };
    const standardChange = () => {
      if (fullscreenElement(document) === container) {
        if (modeRef.current === "viewport") { restoreRef.current?.(); restoreRef.current = null; }
        modeRef.current = "standard"; setMode("standard");
      } else if (modeRef.current === "standard") dismiss();
    };
    const nativeBegin = () => {
      // A slow native transition may arrive after the viewport fallback began.
      restoreRef.current?.(); restoreRef.current = null;
      modeRef.current = "native"; setMode("native");
    };
    const nativeEnd = () => dismiss();
    const keydown = (event: KeyboardEvent) => {
      if (!modeRef.current) return;
      if (event.key === "Escape") {
        event.preventDefault(); event.stopImmediatePropagation();
        void exitPlayerFullscreen(video, document); dismiss(); return;
      }
      if (event.key !== "Tab" || modeRef.current === "native") return;
      const elements = Array.from(container.querySelectorAll<HTMLElement>('button:not([disabled]), video[controls], iframe, [tabindex="0"]'));
      const first = elements[0]; const last = elements.at(-1);
      if (!first || !last) return;
      if (event.shiftKey && (document.activeElement === first || !container.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !container.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
      event.stopPropagation();
    };
    document.addEventListener("fullscreenchange", standardChange);
    document.addEventListener("webkitfullscreenchange", standardChange);
    document.addEventListener("keydown", keydown, true);
    video?.addEventListener("webkitbeginfullscreen", nativeBegin);
    video?.addEventListener("webkitendfullscreen", nativeEnd);
    return () => {
      ++generationRef.current;
      if (modeRef.current) void exitPlayerFullscreen(video, document);
      restoreRef.current?.(); restoreRef.current = null; modeRef.current = null;
      document.removeEventListener("fullscreenchange", standardChange);
      document.removeEventListener("webkitfullscreenchange", standardChange);
      document.removeEventListener("keydown", keydown, true);
      video?.removeEventListener("webkitbeginfullscreen", nativeBegin);
      video?.removeEventListener("webkitendfullscreen", nativeEnd);
    };
  }, [containerRef, videoRef, resetKey]);

  async function toggle() {
    const container = containerRef.current;
    if (!container || busyRef.current) return;
    busyRef.current = true;
    const generation = generationRef.current;
    try {
      if (modeRef.current) {
        await exitPlayerFullscreen(videoRef.current, document);
        restoreRef.current?.(); restoreRef.current = null;
        modeRef.current = null; setMode(null);
      } else {
        const shell = container.closest<HTMLElement>(".series-detail-shell");
        const overflow = shell?.style.overflow;
        const scrollTop = shell?.scrollTop || 0;
        const focus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
        restoreRef.current = () => {
          container.classList.remove("is-viewport-fullscreen");
          shell?.classList.remove("has-viewport-player");
          if (shell && overflow !== undefined) { shell.style.overflow = overflow; shell.scrollTop = scrollTop; }
          if (focus?.isConnected) focus.focus({ preventScroll: true });
        };
        const next = await enterPlayerFullscreen(videoRef.current, container);
        if (!container.isConnected || generation !== generationRef.current) { await exitPlayerFullscreen(videoRef.current, document); return; }
        if (next === "viewport") {
          container.classList.add("is-viewport-fullscreen");
          const shell = container.closest<HTMLElement>(".series-detail-shell");
          if (shell) { shell.classList.add("has-viewport-player"); shell.style.overflow = "hidden"; }
        }
        modeRef.current = next; setMode(next);
        if (next !== "native") buttonRef.current?.focus({ preventScroll: true });
      }
    } finally { busyRef.current = false; }
  }

  return <button ref={buttonRef} type="button" className="series-detail-fullscreen" aria-label={mode ? "الخروج من ملء الشاشة" : "ملء الشاشة"} aria-pressed={Boolean(mode)} onClick={() => void toggle()}><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" aria-hidden="true">{mode ? <path d="M9 3v6H3m12-6v6h6M9 21v-6H3m12 6v-6h6" /> : <path d="M9 3H3v6m12-6h6v6M3 15v6h6m12-6v6h-6" />}</svg><span>{mode ? "إغلاق" : "ملء الشاشة"}</span></button>;
}
