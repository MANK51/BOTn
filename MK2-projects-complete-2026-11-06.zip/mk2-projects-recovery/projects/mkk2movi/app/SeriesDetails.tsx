"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { PlaybackLink } from "../lib/playback";
import { PLAYER_FRAME_SANDBOX } from "../lib/playback-frame-policy";
import { seriesPlayerFrameUrl } from "../lib/player-frame-url";
import { hasPlaybackProgress, nextUnfailedPlayerServer, readPlayerProgress, readPlayerSignal } from "../lib/player-signal";
import type { SeriesDetailsEpisode, SeriesDetailsResponse, SeriesDetailsSelection } from "../lib/series-details-types";
import type { CinemaItem } from "../lib/cinema-types";
import { getViewerResume, recordViewerProgress, recordViewerVisit } from "../lib/viewer-library";
import { nativePlaybackError } from "../lib/native-player";
import { PlayerFullscreen } from "./PlayerFullscreen";
import { UserActions } from "./UserActions";
import { CinemaDetailExtras, playbackStarted, playbackTime, reliableTmdbId, useTitleMetadata } from "./CinemaDetailExtras";
import "./series-details.css";

const numbers = new Intl.NumberFormat("ar");
const loadError = "تعذّر تحميل تفاصيل المسلسل. حاول مرة أخرى.";

function PlayIcon() {
  return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.7c0-.8.9-1.3 1.6-.9l10 6.3c.7.4.7 1.4 0 1.8l-10 6.3c-.7.4-1.6-.1-1.6-.9V5.7Z" /></svg>;
}

function ArrowIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m10 6 6 6-6 6M16 12H4" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function safeServerUrl(server: PlaybackLink) {
  try {
    const url = new URL(server.url);
    return url.protocol === "https:" && !url.username && !url.password ? url : null;
  } catch { return null; }
}

function videoSource(episode: SeriesDetailsEpisode) {
  if (!episode.videoUrl || typeof window === "undefined") return "";
  try {
    const url = new URL(episode.videoUrl, window.location.origin);
    return url.origin === window.location.origin && ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch { return ""; }
}

function isPlayable(episode: SeriesDetailsEpisode) {
  return Boolean(videoSource(episode) || episode.servers.some((server) => safeServerUrl(server)));
}

function episodeLabel(episode: SeriesDetailsEpisode) {
  return `الحلقة ${numbers.format(episode.episode)}`;
}

function seasonLabel(season: number, name?: string) {
  if (season === 0) return "الحلقات الخاصة";
  const label = name?.trim();
  return !label || /^(?:Season|Series|الموسم)\s*\d+$/i.test(label) ? `الموسم ${numbers.format(season)}` : label;
}

function officialSourcesUrl(selection: SeriesDetailsSelection) {
  const id = selection.source === "automatic" ? selection.id : selection.source === "embed" ? /^tv:tmdb:(\d+)$/.exec(selection.id)?.[1] : "";
  return id && /^[1-9]\d*$/.test(id) && Number.isSafeInteger(Number(id)) && Number(id) <= 2147483647 ? `https://www.themoviedb.org/tv/${id}/watch` : "";
}

function episodeName(episode: SeriesDetailsEpisode) {
  const title = episode.title.trim();
  return /^(?:الحلقة\s*\d+|Episode\s*\d+|الموسم\s*\d+\s*[·-]\s*الحلقة\s*\d+)$/i.test(title) ? "" : title;
}

function formattedDate(value?: string) {
  if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return "";
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isNaN(date.getTime()) ? "" : new Intl.DateTimeFormat("ar", { year: "numeric", month: "short", day: "numeric", timeZone: "UTC" }).format(date);
}

function Artwork({ src, fallback = "", className, alt, eager = false }: { src: string; fallback?: string; className: string; alt: string; eager?: boolean }) {
  const [failed, setFailed] = useState<string[]>([]);
  useEffect(() => setFailed([]), [src, fallback]);
  const image = [src, fallback].find((candidate) => candidate && !failed.includes(candidate));
  return <span className={className}>
    {image ? <img src={image} alt={alt} loading={eager ? "eager" : "lazy"} decoding="async" onError={() => setFailed((previous) => [...previous, image])} /> : <span className="series-detail-art-fallback" aria-hidden="true"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="6" y="10" width="36" height="28" rx="5" /><path d="m20 18 12 6-12 6V18ZM12 5l5 5m8-5 5 5m-18 28 5 5m8-5 5 5" /></svg></span>}
  </span>;
}

export default function SeriesDetails({ selection, onClose, onOpenSimilar, siteName = "MK2Movie" }: { selection: SeriesDetailsSelection; onClose: () => void; onOpenSimilar?: (item: CinemaItem) => void; siteName?: string }) {
  const [data, setData] = useState<SeriesDetailsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [pendingSeason, setPendingSeason] = useState<number | undefined>();
  const [activeEpisodeId, setActiveEpisodeId] = useState<string | null>(null);
  const [serverId, setServerId] = useState("");
  const viewerServerRef = useRef("");
  const [playerLoading, setPlayerLoading] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const [frameError, setFrameError] = useState(false);
  const [playerSlow, setPlayerSlow] = useState(false);
  const [playerStarted, setPlayerStarted] = useState(false);
  const [playerNotice, setPlayerNotice] = useState("");
  const [playerRevision, setPlayerRevision] = useState(0);
  const failedServersRef = useRef(new Set<string>());
  const playerAttemptRef = useRef("");
  const [expandedSynopsis, setExpandedSynopsis] = useState(false);
  const [resumeTime, setResumeTime] = useState(0);
  const [nativePaused, setNativePaused] = useState(true);
  const [nativeErrorMessage, setNativeErrorMessage] = useState("");
  const nativeVideoRef = useRef<HTMLVideoElement>(null);
  const playerContainerRef = useRef<HTMLDivElement>(null);
  const frameProgressRef = useRef<{ episodeId: string; season: number; episode: number; currentTime: number; duration: number } | null>(null);
  const initialEpisodeHandled = useRef(false);
  const startedEpisodes = useRef(new Set<string>());
  const selectionTmdbId = reliableTmdbId(selection.source === "automatic" ? selection.id : /^tv:tmdb:(\d+)$/.exec(selection.id)?.[1] || selection.tmdbId);
  const { metadata, failed: metadataFailed, retryMetadata } = useTitleMetadata("tv", selectionTmdbId);
  const request = useRef<AbortController | null>(null);
  const requestVersion = useRef(0);
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const playerRef = useRef<HTMLElement>(null);
  const playerFrameRef = useRef<HTMLIFrameElement>(null);
  const playerHeadingRef = useRef<HTMLHeadingElement>(null);
  const episodesRef = useRef<HTMLElement>(null);
  const episodesHeadingRef = useRef<HTMLHeadingElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  const load = useCallback(async (season?: number) => {
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    const version = ++requestVersion.current;
    setPendingSeason(season);
    setLoading(true);
    setError("");
    setActiveEpisodeId(null);
    setVideoError(false);
    setFrameError(false);
    setPlayerNotice("");
    failedServersRef.current.clear();
    try {
      const query = new URLSearchParams({ source: selection.source, id: selection.id });
      if (season !== undefined) query.set("season", String(season));
      const response = await fetch(`/api/series-details?${query}`, { cache: "no-store", signal: controller.signal });
      const result = await response.json() as SeriesDetailsResponse & { error?: string };
      if (controller.signal.aborted || version !== requestVersion.current) return;
      if (!response.ok) throw new Error(result.error || loadError);
      if (!result || typeof result.title !== "string" || !Array.isArray(result.episodes) || !Array.isArray(result.seasons)) throw new Error(loadError);
      setData(result);
      setPendingSeason(result.season);
    } catch (failure) {
      if (controller.signal.aborted || version !== requestVersion.current) return;
      setError(failure instanceof Error ? failure.message : loadError);
    } finally {
      if (!controller.signal.aborted && version === requestVersion.current) setLoading(false);
    }
  }, [selection.id, selection.source]);

  useEffect(() => {
    setData(null);
    setExpandedSynopsis(false);
    initialEpisodeHandled.current = false;
    const season = Number.isSafeInteger(selection.season) && selection.season! >= 0 && selection.season! <= 1000 ? selection.season : undefined;
    void load(season);
    return () => { request.current?.abort(); ++requestVersion.current; };
  }, [load, selection.season]);

  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus({ preventScroll: true });
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); onCloseRef.current(); return; }
      if (event.key !== "Tab" || !dialogRef.current) return;
      const elements = Array.from(dialogRef.current.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], select:not([disabled]), video[controls], iframe, [tabindex="0"]')).filter((element) => element.offsetParent !== null);
      const first = elements[0];
      const last = elements[elements.length - 1];
      if (!first || !last) return;
      if (event.shiftKey && (document.activeElement === first || !dialogRef.current.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !dialogRef.current.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", handleKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKey);
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, []);

  useEffect(() => {
    if (!activeEpisodeId) return;
    playerHeadingRef.current?.focus({ preventScroll: true });
    playerRef.current?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
  }, [activeEpisodeId]);

  const title = data?.title || metadata?.item.title || selection.title || "تفاصيل المسلسل";
  const poster = data?.poster || metadata?.item.poster || selection.poster || "";
  const description = data?.description || metadata?.item.description || selection.description || "";
  const year = data?.year || metadata?.item.year || selection.year || "";
  const officialWatchUrl = metadata?.officialWatchUrl || officialSourcesUrl(selection);
  const libraryItem = useMemo<CinemaItem>(() => ({
    ...(metadata?.item ?? {}), id: selection.id, source: selection.source, mediaType: "tv", title,
    poster, description, year, rating: data?.rating || metadata?.item.rating || "", genre: data?.genre || metadata?.item.genre || "",
    ...(selectionTmdbId ? { tmdbId: selectionTmdbId } : {}),
  }), [metadata, selection.id, selection.source, selectionTmdbId, title, poster, description, year, data?.rating, data?.genre]);
  const episodes = loading || error ? [] : data?.episodes ?? [];
  const activeEpisode = episodes.find((episode) => episode.id === activeEpisodeId);
  const availableServers = activeEpisode?.servers.filter((server) => safeServerUrl(server)) ?? [];
  const currentServer = availableServers.find((server) => server.id === serverId) || availableServers[0];
  const currentVideo = activeEpisode ? videoSource(activeEpisode) : "";
  const frameSource = currentServer && activeEpisode ? seriesPlayerFrameUrl(currentServer) : "";
  const playerAttempt = `${activeEpisodeId ?? ""}:${currentVideo || frameSource}:${playerRevision}`;
  playerAttemptRef.current = playerAttempt;
  const savedSignalIdentity = /^tv:(tmdb|imdb):([^:]+)$/.exec(selection.id);
  const signalMediaId = selection.source === "automatic" ? selection.id : savedSignalIdentity?.[2] || "";
  const signalIdSource = selection.source === "automatic" ? "tmdb" : savedSignalIdentity?.[1] === "imdb" ? "imdb" : "tmdb";
  const firstEpisode = episodes[0];
  const nextEpisode = activeEpisode ? episodes.find((episode) => episode.season === activeEpisode.season && episode.episode === activeEpisode.episode + 1 && isPlayable(episode)) : undefined;
  const previousEpisode = activeEpisode ? episodes.find((episode) => episode.season === activeEpisode.season && episode.episode === activeEpisode.episode - 1 && isPlayable(episode)) : undefined;
  const hasOriginalTitle = data?.originalTitle && data.originalTitle.toLocaleLowerCase() !== title.toLocaleLowerCase();
  const availableSeasons = data?.seasons.filter((season) => season.published !== false && season.episodeCount > 0).length || 0;
  const seasonSummary = availableSeasons === 1 ? "موسم متاح" : availableSeasons === 2 ? "موسمان متاحان" : `${numbers.format(availableSeasons)} ${availableSeasons < 11 ? "مواسم متاحة" : "موسمًا متاحًا"}`;

  useEffect(() => {
    if ((data || metadata) && libraryItem.title.trim()) recordViewerVisit(libraryItem);
    // A visit is recorded once after the requested title is resolved.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [libraryItem.id, libraryItem.source, libraryItem.title, Boolean(data || metadata)]);

  const resolvedTitle = data?.title || metadata?.item.title || "";
  useEffect(() => {
    if (!resolvedTitle.trim()) return;
    const previousTitle = document.title;
    const pageTitle = `${resolvedTitle} | ${siteName}`;
    document.title = pageTitle;
    return () => { if (document.title === pageTitle) document.title = previousTitle; };
  }, [resolvedTitle, siteName]);

  useEffect(() => {
    if (loading || !data || initialEpisodeHandled.current) return;
    initialEpisodeHandled.current = true;
    if (!Number.isSafeInteger(selection.episode) || selection.episode! < 1) return;
    const episode = data.episodes.find((entry) => entry.episode === selection.episode && entry.season === (selection.season ?? data.season));
    if (episode && isPlayable(episode)) watch(episode);
  }, [loading, data, selection.episode, selection.season]);

  function saveNativeProgress(video: HTMLVideoElement, force = false) {
    if (!activeEpisode || !hasPlaybackProgress(video.currentTime, video.duration)) return;
    recordViewerProgress(libraryItem, { season: activeEpisode.season, episode: activeEpisode.episode, episodeId: activeEpisode.id, currentTime: video.currentTime, duration: video.duration, force });
    if (!video.paused && !video.seeking && !startedEpisodes.current.has(activeEpisode.id)) {
      startedEpisodes.current.add(activeEpisode.id);
      playbackStarted(libraryItem);
    }
  }

  useEffect(() => {
    const save = () => {
      if (nativeVideoRef.current) saveNativeProgress(nativeVideoRef.current, true);
      const progress = frameProgressRef.current;
      if (progress && progress.episodeId === activeEpisode?.id) recordViewerProgress(libraryItem, { ...progress, force: true });
    };
    const onVisibility = () => { if (document.visibilityState === "hidden") save(); };
    window.addEventListener("pagehide", save);
    document.addEventListener("visibilitychange", onVisibility);
    return () => { save(); window.removeEventListener("pagehide", save); document.removeEventListener("visibilitychange", onVisibility); };
  }, [activeEpisode?.id, libraryItem]);

  useEffect(() => {
    setPlayerSlow(false);
    setPlayerStarted(false);
    setResumeTime(0);
    setNativePaused(true);
    setNativeErrorMessage("");
  }, [playerAttempt]);

  useEffect(() => {
    if (!currentVideo || !playerLoading) return;
    const timer = window.setTimeout(() => {
      setPlayerLoading(false);
      setPlayerSlow(true);
      setNativePaused(nativeVideoRef.current?.paused ?? true);
      setPlayerNotice("لم يبدأ الفيديو بعد. اضغط تشغيل الفيديو، أو أعد المحاولة إذا استمر التوقف.");
    }, 15000);
    return () => window.clearTimeout(timer);
  }, [currentVideo, playerLoading, playerAttempt]);

  useEffect(() => {
    if (!activeEpisodeId || playerStarted || videoError || frameError) return;
    const timer = window.setTimeout(() => { setPlayerSlow(true); setPlayerLoading(false); }, 15000);
    return () => window.clearTimeout(timer);
  }, [activeEpisodeId, playerAttempt, playerStarted, videoError, frameError]);

  const handleFrameFailure = useCallback((failedServerId: string, attempt: string) => {
    if (attempt !== playerAttemptRef.current || !activeEpisode || currentServer?.id !== failedServerId || failedServersRef.current.has(failedServerId)) return;
    failedServersRef.current.add(failedServerId);
    const nextId = nextUnfailedPlayerServer(availableServers.map((server) => server.id), failedServerId, failedServersRef.current);
    const next = availableServers.find((server) => server.id === nextId);
    setPlayerStarted(false);
    setPlayerSlow(false);
    if (next) {
      // Automatic recovery stays on this episode and preserves the viewer's explicit preference.
      setServerId(next.id);
      setPlayerLoading(true);
      setFrameError(false);
      setPlayerNotice(`تعذّر التشغيل على ${currentServer.name}. نجرّب ${next.name} للحلقة نفسها.`);
    } else {
      setPlayerLoading(false);
      setFrameError(true);
      setPlayerNotice("تعذّر التشغيل على السيرفرات التي جُرّبت لهذه الحلقة. يمكنك إعادة المحاولة أو اختيار حلقة أو موسم آخر.");
    }
  }, [activeEpisode, currentServer, availableServers]);

  useEffect(() => {
    if (!frameSource || !currentServer || !activeEpisode || currentVideo) return;
    const onProviderSignal = (event: MessageEvent) => {
      if (playerAttemptRef.current !== playerAttempt || failedServersRef.current.has(currentServer.id)) return;
      const frameWindow = playerFrameRef.current?.contentWindow;
      const signal = readPlayerSignal({ providerId: currentServer.id, frameUrl: frameSource, mediaId: signalMediaId, idSource: signalIdSource, season: activeEpisode.season, episode: activeEpisode.episode }, { origin: event.origin, sourceMatches: Boolean(frameWindow) && event.source === frameWindow, data: event.data });
      if (signal === "error") handleFrameFailure(currentServer.id, playerAttempt);
      else if (signal === "progress") {
        setPlayerLoading(false);
        setPlayerStarted(true);
        setPlayerSlow(false);
        const progress = readPlayerProgress({ providerId: currentServer.id, frameUrl: frameSource, mediaId: signalMediaId, idSource: signalIdSource, season: activeEpisode.season, episode: activeEpisode.episode }, { origin: event.origin, sourceMatches: Boolean(frameWindow) && event.source === frameWindow, data: event.data });
        if (progress) {
          frameProgressRef.current = { season: activeEpisode.season, episode: activeEpisode.episode, episodeId: activeEpisode.id, ...progress };
          recordViewerProgress(libraryItem, frameProgressRef.current);
        }
        if (!startedEpisodes.current.has(activeEpisode.id)) { startedEpisodes.current.add(activeEpisode.id); playbackStarted(libraryItem); }
      }
    };
    window.addEventListener("message", onProviderSignal);
    return () => window.removeEventListener("message", onProviderSignal);
  }, [frameSource, currentServer, activeEpisode, currentVideo, playerAttempt, signalMediaId, signalIdSource, handleFrameFailure, libraryItem]);

  function watch(episode: SeriesDetailsEpisode) {
    if (!isPlayable(episode)) return;
    if (activeEpisodeId === episode.id) {
      playerHeadingRef.current?.focus({ preventScroll: true });
      playerRef.current?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
      return;
    }
    setServerId(episode.servers.find((server) => server.id === viewerServerRef.current && safeServerUrl(server))?.id || episode.servers.find((server) => safeServerUrl(server))?.id || "");
    setVideoError(false);
    setFrameError(false);
    setPlayerNotice("");
    setPlayerStarted(false);
    setPlayerSlow(false);
    failedServersRef.current.clear();
    setPlayerLoading(true);
    setActiveEpisodeId(episode.id);
  }

  function requestNativePlay(video: HTMLVideoElement) {
    const attempt = playerAttemptRef.current;
    setPlayerNotice("");
    setVideoError(false);
    setNativeErrorMessage("");
    setPlayerLoading(video.readyState < HTMLMediaElement.HAVE_FUTURE_DATA);
    const failure = (error: unknown) => {
      if (attempt !== playerAttemptRef.current || nativeVideoRef.current !== video || !video.isConnected) return;
      const name = error && typeof error === "object" && "name" in error ? error.name : "";
      if (name === "AbortError") return;
      setPlayerLoading(false);
      setNativePaused(true);
      if (name === "NotAllowedError") {
        setPlayerNotice("المتصفح يحتاج ضغطة منك. اضغط تشغيل الفيديو للمتابعة.");
      } else {
        setNativeErrorMessage("تعذّر تشغيل الفيديو. قد تكون صيغته أو ترميزه غير مدعومين في هذا المتصفح، أو المصدر غير متاح.");
        setVideoError(true);
      }
    };
    try {
      void Promise.resolve(video.play()).then(() => {
        if (attempt !== playerAttemptRef.current || nativeVideoRef.current !== video) return;
        setNativePaused(video.paused);
        if (!video.paused) { setPlayerLoading(false); setPlayerSlow(false); }
      }).catch(failure);
    } catch (error) { failure(error); }
  }

  function nativeReady(video: HTMLVideoElement) {
    setPlayerLoading(false);
    setNativePaused(video.paused);
  }

  function nativeFailure(video: HTMLVideoElement) {
    setPlayerLoading(false);
    setNativePaused(true);
    setNativeErrorMessage(nativePlaybackError(video.error?.code));
    setVideoError(true);
  }

  function chooseServer(id: string) {
    const next = availableServers.find((server) => server.id === id);
    if (!next) return;
    viewerServerRef.current = next.id;
    if (next.id === currentServer?.id) {
      if (failedServersRef.current.has(next.id)) retryPlayer();
      return;
    }
    failedServersRef.current.delete(next.id);
    setServerId(next.id);
    setPlayerLoading(true);
    setPlayerStarted(false);
    setPlayerSlow(false);
    setVideoError(false);
    setFrameError(false);
    setPlayerNotice(`تم اختيار ${next.name} للحلقة الحالية.`);
  }

  function tryAnotherServer() {
    if (availableServers.length < 2) {
      setPlayerNotice("لا يوجد سيرفر آخر متاح لهذه الحلقة حاليًا. يمكنك إعادة تشغيل السيرفر الحالي.");
      return;
    }
    const currentIndex = availableServers.findIndex((server) => server.id === currentServer?.id);
    chooseServer(availableServers[(currentIndex + 1) % availableServers.length].id);
  }

  function retryPlayer() {
    setVideoError(false);
    setFrameError(false);
    setPlayerNotice("");
    setPlayerLoading(true);
    setPlayerStarted(false);
    setPlayerSlow(false);
    failedServersRef.current.clear();
    setPlayerRevision((revision) => revision + 1);
  }

  function browseEpisodes() {
    setActiveEpisodeId(null);
    requestAnimationFrame(() => {
      episodesHeadingRef.current?.focus({ preventScroll: true });
      episodesRef.current?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
    });
  }

  return <div ref={dialogRef} className={`series-detail-shell${activeEpisode ? " series-detail-watching" : ""}`} role="dialog" aria-modal="true" aria-labelledby="series-detail-title" dir="rtl" data-series-details-id={selection.id}>
    <header className="series-detail-topbar">
      <button ref={closeRef} type="button" className="series-detail-back" onClick={onClose}><ArrowIcon /><span>العودة للمكتبة</span></button>
      <span className="series-detail-top-title">{title}</span>
      <span className="series-detail-top-label">مسلسل</span>
    </header>

    <section className="series-detail-hero" aria-label="عن المسلسل">
      <Artwork src={data?.backdrop || metadata?.item.backdrop || ""} fallback={poster} className="series-detail-backdrop" alt="" eager />
      <div className="series-detail-hero-shade" />
      <div className="series-detail-hero-content">
        <div className="series-detail-intro">
          <span className="series-detail-eyebrow"><span />مسلسل</span>
          <h1 id="series-detail-title">{title}</h1>
          {hasOriginalTitle && <p className="series-detail-original" dir="auto">{data!.originalTitle}</p>}
          <div className="series-detail-facts">
            {year && <span dir="ltr">{year}</span>}
            {libraryItem.genre && <span>{libraryItem.genre}</span>}
            {libraryItem.rating && <span className="series-detail-rating"><span aria-hidden="true">★</span> {libraryItem.rating}</span>}
            {availableSeasons > 0 && <span>{seasonSummary}</span>}
          </div>
          {description && <div className="series-detail-synopsis-wrap"><p className={`series-detail-synopsis${expandedSynopsis ? " is-expanded" : ""}`}>{description}</p>{description.length > 320 && <button type="button" className="series-detail-synopsis-toggle" aria-expanded={expandedSynopsis} onClick={() => setExpandedSynopsis((expanded) => !expanded)}>{expandedSynopsis ? "عرض أقل" : "القصة كاملة"}</button>}</div>}
          <div className="series-detail-hero-actions">
            <button type="button" className="series-detail-button series-detail-primary" disabled={!firstEpisode || !isPlayable(firstEpisode)} onClick={() => firstEpisode && watch(firstEpisode)}><PlayIcon /><span>{firstEpisode ? `شاهد ${episodeLabel(firstEpisode)}` : "شاهد الحلقة الأولى"}</span></button>
            <button type="button" className="series-detail-button series-detail-secondary" onClick={browseEpisodes}><span>تصفح الحلقات</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m7 10 5 5 5-5" strokeLinecap="round" strokeLinejoin="round" /></svg></button>
          </div>
          <UserActions item={libraryItem} />
        </div>
        <Artwork src={poster} className="series-detail-main-poster" alt={`ملصق ${title}`} eager />
      </div>
    </section>

    {activeEpisode && <section ref={playerRef} className="series-detail-cinema" aria-labelledby="series-detail-player-title">
      <div className="series-detail-cinema-heading">
        <div><span className="series-detail-kicker">{seasonLabel(activeEpisode.season)}</span><h2 id="series-detail-player-title" ref={playerHeadingRef} tabIndex={-1}>{episodeLabel(activeEpisode)}{episodeName(activeEpisode) && <span> · {episodeName(activeEpisode)}</span>}</h2></div>
        <button type="button" className="series-detail-text-button" onClick={browseEpisodes}>كل الحلقات <ArrowIcon /></button>
      </div>
      <div ref={playerContainerRef} className="series-detail-player" data-series-episode={activeEpisode.episode} data-series-server-id={currentVideo ? "upload" : currentServer?.id}>
        {currentVideo ? <video key={`${activeEpisode.id}:${playerRevision}`} ref={nativeVideoRef} src={currentVideo} controls autoPlay playsInline preload="metadata" poster={activeEpisode.still || poster || undefined} aria-label={`${title} · ${episodeLabel(activeEpisode)}`} onCanPlay={(event) => nativeReady(event.currentTarget)} onLoadedData={(event) => nativeReady(event.currentTarget)} onLoadedMetadata={(event) => { const video = event.currentTarget; nativeReady(video); const saved = getViewerResume(libraryItem, { season: activeEpisode.season, episode: activeEpisode.episode, episodeId: activeEpisode.id }); const time = saved && saved.currentTime >= 5 && saved.currentTime < video.duration * .95 ? saved.currentTime : 0; setResumeTime(time); if (time > 0) { video.pause(); setNativePaused(true); } else if (video.paused) requestNativePlay(video); }} onPlay={() => setNativePaused(false)} onPlaying={(event) => { nativeReady(event.currentTarget); setPlayerSlow(false); }} onWaiting={(event) => { if (!event.currentTarget.paused) setPlayerLoading(true); }} onTimeUpdate={(event) => { setNativePaused(event.currentTarget.paused); if (hasPlaybackProgress(event.currentTarget.currentTime, event.currentTarget.duration)) { setPlayerLoading(false); setPlayerStarted(true); setPlayerSlow(false); saveNativeProgress(event.currentTarget); } }} onPause={(event) => { setNativePaused(true); setPlayerLoading(false); saveNativeProgress(event.currentTarget, true); }} onEnded={(event) => { setNativePaused(true); setPlayerLoading(false); saveNativeProgress(event.currentTarget, true); }} onError={(event) => nativeFailure(event.currentTarget)} /> : frameSource ? <iframe key={`${activeEpisode.id}:${currentServer?.id}:${playerRevision}`} ref={playerFrameRef} src={frameSource} title={`${title} · ${episodeLabel(activeEpisode)} · ${currentServer?.name}`} sandbox={PLAYER_FRAME_SANDBOX} allow="autoplay; fullscreen; encrypted-media; picture-in-picture" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen onLoad={() => { if (playerAttemptRef.current === playerAttempt) setPlayerLoading(false); }} onError={() => { if (currentServer) handleFrameFailure(currentServer.id, playerAttempt); }} /> : <p className="series-detail-player-empty">لا يوجد سيرفر متاح لهذه الحلقة حاليًا.</p>}
        {currentVideo && nativePaused && resumeTime === 0 && !videoError && <button type="button" className="series-detail-native-play" onClick={() => { const video = nativeVideoRef.current; if (video) requestNativePlay(video); }} aria-label={`تشغيل ${episodeLabel(activeEpisode)}`}><PlayIcon /><span>تشغيل الفيديو</span></button>}
        <PlayerFullscreen containerRef={playerContainerRef} videoRef={nativeVideoRef} resetKey={playerAttempt} />
        {playerLoading && <span className="series-detail-player-loading" role="status"><span className="series-detail-spinner" /><span>{playerSlow ? "يستغرق المشغل وقتًا أطول…" : "جارٍ تجهيز المشغل…"}</span></span>}
      </div>
      {currentVideo && resumeTime > 0 && <div className="series-detail-resume" role="status"><span>لديك موضع مشاهدة محفوظ لهذه الحلقة.</span><button type="button" onClick={() => { const video = nativeVideoRef.current; if (!video || !Number.isFinite(video.duration) || resumeTime >= video.duration) return; video.currentTime = resumeTime; setResumeTime(0); requestNativePlay(video); }}>تابع من <bdi>{playbackTime(resumeTime)}</bdi></button><button type="button" onClick={() => { setResumeTime(0); const video = nativeVideoRef.current; if (video) { video.currentTime = 0; requestNativePlay(video); } }}>من البداية</button></div>}
      {!currentVideo && <div className="series-detail-server-picker">
        <div className="series-detail-server-heading"><h3>سيرفرات المشاهدة</h3><span>خيارات المشاهدة: {numbers.format(availableServers.length)}</span></div>
        <label className="series-detail-server-select"><span>سيرفر المشاهدة</span><select aria-label="اختر سيرفر المشاهدة" value={currentServer?.id ?? ""} disabled={!availableServers.length} onChange={(event) => chooseServer(event.target.value)}>{availableServers.length ? availableServers.map((server, index) => <option key={server.id} value={server.id}>{server.name}{index === 0 ? " · افتراضي" : ""}</option>) : <option value="">لا يوجد سيرفر متاح</option>}</select></label>
        <div className="series-detail-servers" role="group" aria-label="سيرفرات المشاهدة">{availableServers.map((server, index) => <button key={server.id} data-series-server-id={server.id} type="button" aria-pressed={currentServer?.id === server.id} onClick={() => chooseServer(server.id)}>{server.name}{index === 0 && <span>افتراضي</span>}</button>)}</div>
      </div>}
      <div className="series-detail-watch-controls">
        <div className="series-detail-player-actions"><button type="button" className="series-detail-text-button" onClick={retryPlayer}>إعادة تشغيل المشغل</button>{!currentVideo && <button type="button" className="series-detail-button series-detail-secondary series-detail-alternative" onClick={tryAnotherServer}>جرّب سيرفرًا آخر</button>}</div>
        <div className="series-detail-episode-navigation">{previousEpisode && <button type="button" className="series-detail-button series-detail-secondary series-detail-next" onClick={() => watch(previousEpisode)}><span>الحلقة السابقة</span></button>}{nextEpisode && <button type="button" className="series-detail-button series-detail-secondary series-detail-next" onClick={() => watch(nextEpisode)}><span>الحلقة التالية</span><PlayIcon /></button>}</div>
      </div>
      {!currentVideo && <p className="series-detail-server-help">الحلقة لا تعمل أو تعرض محتوى مختلفًا؟ جرّب سيرفرًا آخر. ظهور بيانات الحلقة لا يؤكد توفر الفيديو لدى سيرفر المشاهدة.</p>}
      {!currentVideo && officialWatchUrl && <p className="series-detail-server-help">إذا لم تتوفر الحلقة على السيرفرات، راجع <a href={officialWatchUrl} target="_blank" rel="noopener noreferrer">مصادر المشاهدة الرسمية لهذا المسلسل</a>.</p>}
      {playerNotice && <p className="series-detail-server-notice" role="status">{playerNotice}</p>}
      {playerSlow && !playerStarted && !videoError && !frameError && <p className="series-detail-server-notice" role="status">إذا لم يبدأ الفيديو، يمكنك <button type="button" onClick={retryPlayer}>إعادة المحاولة</button>{!currentVideo && <> أو <button type="button" onClick={tryAnotherServer}>تجربة سيرفر آخر</button></>}. ظهور المشغل وحده لا يؤكد توفر الحلقة.</p>}
      {(videoError || frameError) && <p className="series-detail-inline-error" role="alert">{frameError ? "تعذّر تشغيل الحلقة على السيرفر الحالي." : nativeErrorMessage || "تعذّر تشغيل هذه الحلقة."} <button type="button" onClick={retryPlayer}>إعادة المحاولة</button>{!currentVideo && <> أو <button type="button" onClick={tryAnotherServer}>جرّب سيرفرًا آخر</button></>}.</p>}
      {activeEpisode.description && <p className="series-detail-episode-summary">{activeEpisode.description}</p>}
    </section>}

    <section ref={episodesRef} className="series-detail-episodes" aria-labelledby="series-detail-episodes-title" aria-busy={loading}>
      <div className="series-detail-section-heading">
        <div><span className="series-detail-kicker">اختر ما تشاهده</span><h2 ref={episodesHeadingRef} tabIndex={-1} id="series-detail-episodes-title">الحلقات</h2></div>
        {!!data?.seasons.length && <label className="series-detail-season-picker"><span>الموسم</span><select aria-label="اختر الموسم" value={pendingSeason ?? data.season} onChange={(event) => { void load(Number(event.target.value)); }}>{data.seasons.map((season) => <option key={season.season} value={season.season}>{seasonLabel(season.season, season.name)}{season.published === false ? " · لم يُنشر بعد" : ""}</option>)}</select></label>}
      </div>
      {!!data?.seasons.length && <div className="series-detail-season-tabs" role="group" aria-label="المواسم">{data.seasons.map((season) => <button key={season.season} type="button" aria-pressed={(pendingSeason ?? data.season) === season.season} onClick={() => { if (loading || data.season !== season.season || error) void load(season.season); }}>{seasonLabel(season.season, season.name)}{season.published === false && <small>قريبًا</small>}</button>)}</div>}
      <div className="series-detail-episode-status" aria-live="polite">{!loading && !error && episodes.length > 0 && <span>{seasonLabel(data!.season)} <span aria-hidden="true">·</span> {numbers.format(episodes.length)} {selection.source === "automatic" ? "حلقة في هذا الموسم" : "حلقة متاحة"}</span>}</div>
      {loading ? <div className="series-detail-loading" role="status"><span className="series-detail-spinner" /><span>جارٍ تحميل الحلقات…</span></div> : error ? <div className="series-detail-message" role="alert"><p>{error}</p><button type="button" className="series-detail-button series-detail-secondary" onClick={() => { void load(pendingSeason); }}>إعادة المحاولة</button></div> : episodes.length === 0 ? <div className="series-detail-message"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><rect x="8" y="11" width="32" height="25" rx="4" /><path d="M18 42h12m-6-6v6m-9-21h18" /></svg><p>{data?.enabled === false ? "المشاهدة غير متاحة لهذا المسلسل حاليًا." : "لا توجد حلقات منشورة في هذا الموسم حتى الآن."}</p>{data?.seasons.some((season) => season.season !== data.season && season.episodeCount > 0) && <span>اختر موسمًا آخر من القائمة.</span>}</div> : <div className="series-detail-episode-grid">{episodes.map((episode) => {
        const date = formattedDate(episode.airDate);
        const playable = isPlayable(episode);
        const name = episodeName(episode);
        return <button key={episode.id} type="button" className={`series-detail-episode-card${activeEpisodeId === episode.id ? " is-playing" : ""}`} disabled={!playable} aria-label={`${episodeLabel(episode)}${name ? `: ${name}` : ""}${!playable ? " · المشاهدة غير متاحة" : ""}`} aria-current={activeEpisodeId === episode.id ? "true" : undefined} onClick={() => watch(episode)}>
          <span className="series-detail-episode-art"><Artwork src={episode.still || ""} fallback={poster} className={`series-detail-episode-image${!episode.still && poster ? " is-poster" : ""}`} alt="" /><span className="series-detail-episode-number">{numbers.format(episode.episode)}</span><span className="series-detail-episode-play"><PlayIcon /></span>{episode.runtime && episode.runtime > 0 ? <span className="series-detail-duration">{numbers.format(episode.runtime)} د</span> : null}{activeEpisodeId === episode.id && <span className="series-detail-playing-tag">تشاهد الآن</span>}</span>
          <span className="series-detail-episode-copy"><span className="series-detail-episode-title">{episodeLabel(episode)}{name && <span> · {name}</span>}</span>{episode.description && <span className="series-detail-episode-description">{episode.description}</span>}<span className="series-detail-episode-meta">{!playable ? "المشاهدة غير متاحة" : date || "اختر الحلقة للمشاهدة"}</span></span>
        </button>;
      })}</div>}
    </section>
    <CinemaDetailExtras metadata={metadata} onOpenSimilar={onOpenSimilar} failed={metadataFailed} onRetry={retryMetadata} />
    <div className="series-detail-bottom-space" />
  </div>;
}
