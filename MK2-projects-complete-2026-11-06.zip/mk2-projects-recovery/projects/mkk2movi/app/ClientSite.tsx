"use client";

export { default } from "./CinemaSite";
