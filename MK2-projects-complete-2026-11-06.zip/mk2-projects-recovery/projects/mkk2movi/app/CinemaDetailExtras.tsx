"use client";

import { useEffect, useState } from "react";
import type { CinemaItem, CinemaTitleResponse } from "../lib/cinema-types";

export function reliableTmdbId(value: string | undefined): string {
  return value && /^[1-9]\d*$/.test(value) && Number.isSafeInteger(Number(value)) && Number(value) <= 2147483647 ? value : "";
}

export function useTitleMetadata(type: "tv" | "movie", tmdbId: string) {
  const [metadata, setMetadata] = useState<CinemaTitleResponse | null>(null);
  const [failed, setFailed] = useState(false);
  const [revision, setRevision] = useState(0);
  useEffect(() => {
    setMetadata(null);
    setFailed(false);
    if (!reliableTmdbId(tmdbId)) return;
    const controller = new AbortController();
    void (async () => {
      try {
        const response = await fetch(`/api/cinema/title?type=${type}&id=${encodeURIComponent(tmdbId)}`, { signal: controller.signal });
        const result = await response.json() as CinemaTitleResponse;
        if (!response.ok || !result?.item || result.item.mediaType !== type || result.item.tmdbId !== tmdbId || !Array.isArray(result.cast) || !Array.isArray(result.similar)) throw new Error("metadata");
        if (!controller.signal.aborted) setMetadata(result);
      } catch { if (!controller.signal.aborted) setFailed(true); }
    })();
    return () => controller.abort();
  }, [type, tmdbId, revision]);
  return { metadata, failed, retryMetadata: () => setRevision((value) => value + 1) };
}

export function CinemaDetailExtras({ metadata, onOpenSimilar, failed, onRetry }: { metadata: CinemaTitleResponse | null; onOpenSimilar?: (item: CinemaItem) => void; failed?: boolean; onRetry?: () => void }) {
  return <>
    {failed && <p className="series-detail-metadata-notice">تعذّر تحميل معلومات فريق العمل والاقتراحات. {onRetry && <button type="button" onClick={onRetry}>إعادة المحاولة</button>}</p>}
    {!!metadata?.cast.length && <section className="series-detail-extras" aria-labelledby="detail-cast-title"><div className="series-detail-section-heading"><div><span className="series-detail-kicker">أمام الكاميرا</span><h2 id="detail-cast-title">طاقم التمثيل</h2></div></div><div className="series-detail-cast">{metadata.cast.slice(0, 12).map((person) => <div className="series-detail-cast-person" key={person.id}><span className="series-detail-cast-photo">{person.photo ? <img src={person.photo} alt="" loading="lazy" decoding="async" onError={(event) => { event.currentTarget.hidden = true; }} /> : <span aria-hidden="true">◌</span>}</span><strong>{person.name}</strong>{person.character && <span>{person.character}</span>}</div>)}</div></section>}
    {!!metadata?.similar.length && onOpenSimilar && <section className="series-detail-extras" aria-labelledby="detail-similar-title"><div className="series-detail-section-heading"><div><span className="series-detail-kicker">من عالم هذا العمل</span><h2 id="detail-similar-title">قد يعجبك أيضًا</h2></div></div><div className="series-detail-similar">{metadata.similar.slice(0, 10).map((item) => <button type="button" key={`${item.mediaType}:${item.id}`} onClick={() => onOpenSimilar(item)} aria-label={`${item.title}${item.year ? ` · ${item.year}` : ""}`}><span className="series-detail-similar-art">{item.poster ? <img src={item.poster} alt="" loading="lazy" decoding="async" onError={(event) => { event.currentTarget.hidden = true; }} /> : <span aria-hidden="true">▶</span>}{item.rating && <small>★ {item.rating}</small>}</span><strong>{item.title}</strong><span>{item.year} · {item.mediaType === "movie" ? "فيلم" : "مسلسل"}</span></button>)}</div></section>}
  </>;
}

export function playbackStarted(item: CinemaItem) {
  window.dispatchEvent(new CustomEvent("mk2-playback-started", { detail: { item } }));
}

export function playbackTime(value: number) {
  const seconds = Math.max(0, Math.floor(value));
  const minutes = Math.floor(seconds / 60);
  return `${minutes}:${String(seconds % 60).padStart(2, "0")}`;
}
