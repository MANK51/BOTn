import { getSiteAccount } from "../../lib/site-accounts";
import ClientSite from "../ClientSite";
import MaintenanceScreen from "../MaintenanceScreen";
import MaintenanceAdmin from "../MaintenanceAdmin";
import { SITE_MAINTENANCE } from "../../lib/site-maintenance";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  if (SITE_MAINTENANCE) return <><MaintenanceScreen /><MaintenanceAdmin /></>;
  const account = await getSiteAccount();
  return (
    <ClientSite
      initialAccount={account}
      adminInitiallyOpen
    />
  );
}
