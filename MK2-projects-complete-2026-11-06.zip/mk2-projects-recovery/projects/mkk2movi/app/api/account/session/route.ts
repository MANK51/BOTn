import { accountSessionResponse } from "../../../../lib/site-accounts";
export const dynamic = "force-dynamic";
export const GET = accountSessionResponse;
