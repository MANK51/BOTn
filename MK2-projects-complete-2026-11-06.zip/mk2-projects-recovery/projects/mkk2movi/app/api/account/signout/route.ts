import { accountSignoutResponse } from "../../../../lib/site-accounts";
export const POST = accountSignoutResponse;
