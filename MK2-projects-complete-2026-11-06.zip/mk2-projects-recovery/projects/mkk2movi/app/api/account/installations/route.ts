import { getSiteAccount } from "../../../../lib/site-accounts";
import { isAccountWriteAllowed, readAccountJson } from "../../../../lib/account-security";
import { parseInstallEvidence } from "../../../../lib/app-installation-types";
import { recordInstalledAccount } from "../../../../lib/app-installations";
const headers = { "Cache-Control": "private, no-store", "Vary": "Cookie" };
export async function POST(request: Request) {
  if (!isAccountWriteAllowed(request)) return Response.json({ error: "طلب غير مسموح." }, { status: 403, headers });
  if (request.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase() !== "application/json") return Response.json({ error: "صيغة الطلب غير مدعومة." }, { status: 415, headers });
  try {
    const account = await getSiteAccount(request);
    if (!account) return Response.json({ error: "سجّل الدخول أولًا." }, { status: 401, headers });
    let body: unknown;
    try { body = await readAccountJson(request); }
    catch (error) { return Response.json({ error: error instanceof RangeError ? "الطلب أكبر من الحد المسموح." : "بيانات الطلب غير صالحة." }, { status: error instanceof RangeError ? 413 : 400, headers }); }
    const evidence = parseInstallEvidence(body);
    if (!evidence) return Response.json({ error: "لا يوجد فتح للتطبيق بوضع مستقل." }, { status: 400, headers });
    return Response.json({ ok: true, recordedAt: await recordInstalledAccount(account, evidence) }, { headers });
  } catch { return Response.json({ error: "تعذر تسجيل فتح التطبيق. حاول لاحقًا." }, { status: 503, headers }); }
}
