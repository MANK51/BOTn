"use client";

import { useState, useSyncExternalStore } from "react";
import { Bookmark, Check, Heart, Share2 } from "lucide-react";
import type { CinemaItem } from "../lib/cinema-types";
import { buildMediaShareUrl } from "../lib/media-links";
import { emptyViewerLibrary, readViewerLibrary, toggleViewerList, viewerItemKey, VIEWER_LIBRARY_EVENT, VIEWER_LIBRARY_KEY } from "../lib/viewer-library";
import "./personal-library.css";

const serverLibrary = emptyViewerLibrary();
function subscribe(listener: () => void) {
  const storage = (event: StorageEvent) => { if (event.key === VIEWER_LIBRARY_KEY || event.key === null) listener(); };
  window.addEventListener(VIEWER_LIBRARY_EVENT, listener);
  window.addEventListener("storage", storage);
  return () => { window.removeEventListener(VIEWER_LIBRARY_EVENT, listener); window.removeEventListener("storage", storage); };
}
export function useViewerLibrary() { return useSyncExternalStore(subscribe, readViewerLibrary, () => serverLibrary); }

export function UserActions({ item, compact = false }: { item: CinemaItem; compact?: boolean }) {
  const library = useViewerLibrary();
  const key = viewerItemKey(item);
  const favorite = library.favorites.some((row) => row.key === key);
  const later = library.watchLater.some((row) => row.key === key);
  const [status, setStatus] = useState("");
  const [manualShare, setManualShare] = useState("");

  async function share() {
    const url = new URL(buildMediaShareUrl(item), window.location.origin).href;
    setManualShare("");
    if (navigator.share) {
      try { await navigator.share({ title: `${item.title} — MK2Movie`, url }); return; }
      catch (error) { if (error instanceof Error && error.name === "AbortError") return; }
    }
    try { await navigator.clipboard.writeText(url); setStatus("نُسخ رابط العمل"); }
    catch { setManualShare(url); setStatus("انسخ الرابط أدناه للمشاركة"); }
  }

  return <div className={`viewer-actions${compact ? " viewer-actions-compact" : ""}`} onClick={(event) => event.stopPropagation()}>
    <button type="button" className={favorite ? "is-selected" : ""} aria-pressed={favorite} title={favorite ? "إزالة من المفضلة" : "إضافة إلى المفضلة"} onClick={() => { toggleViewerList(item, "favorites"); setStatus(favorite ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة"); }}><Heart size={compact ? 17 : 18} fill={favorite ? "currentColor" : "none"} /><span className={compact ? "viewer-sr-only" : ""}>{favorite ? "في المفضلة" : "المفضلة"}</span></button>
    <button type="button" className={later ? "is-selected" : ""} aria-pressed={later} title={later ? "إزالة من أشاهد لاحقًا" : "إضافة إلى أشاهد لاحقًا"} onClick={() => { toggleViewerList(item, "watchLater"); setStatus(later ? "أُزيل من أشاهد لاحقًا" : "أُضيف إلى أشاهد لاحقًا"); }}>{later ? <Check size={compact ? 17 : 18} /> : <Bookmark size={compact ? 17 : 18} />}<span className={compact ? "viewer-sr-only" : ""}>{later ? "في قائمتي" : "أشاهد لاحقًا"}</span></button>
    {!compact && <button type="button" onClick={share}><Share2 size={18} /><span>مشاركة</span></button>}
    <span className="viewer-sr-only" role="status" aria-live="polite">{status}</span>
    {manualShare && <label className="viewer-share-fallback">رابط المشاركة<input readOnly value={manualShare} onFocus={(event) => event.target.select()} dir="ltr" /></label>}
  </div>;
}
