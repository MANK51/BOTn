import { MK2_PERSONAL_SITE, SITE_RELEASE } from "../lib/site-release";

export default function MaintenanceScreen() {
  return (
    <main className="maintenance-page">
      <div className="maintenance-backdrop" aria-hidden="true">
        <span className="maintenance-orb maintenance-orb-gold" />
        <span className="maintenance-orb maintenance-orb-blue" />
        <span className="maintenance-orb maintenance-orb-soft" />
        <svg className="maintenance-waves" viewBox="0 0 1440 520" preserveAspectRatio="none">
          <path d="M-80 180 C170 80 280 280 520 180 S870 80 1110 180 1390 280 1520 160" />
          <path d="M-80 230 C170 130 280 330 520 230 S870 130 1110 230 1390 330 1520 210" />
          <path d="M-80 280 C170 180 280 380 520 280 S870 180 1110 280 1390 380 1520 260" />
          <path d="M-80 330 C170 230 280 430 520 330 S870 230 1110 330 1390 430 1520 310" />
        </svg>
      </div>
      <a className="maintenance-brand" href="/" aria-label="MK2">
        <span className="maintenance-mark">M</span>
        <span>MK<span>2</span></span>
      </a>
      <section className="maintenance-card" aria-labelledby="maintenance-title">
        <span className="maintenance-badge"><i /> نعمل على تحسين التجربة</span>
        <div className="maintenance-icon" aria-hidden="true">🛠️</div>
        <h1 id="maintenance-title">الموقع تحت الصيانة</h1>
        <p>نرتّب المكان ونجهّز تحديثات جديدة. بنرجع لكم قريبًا.</p>
        <div className="maintenance-rule"><span /></div>
        <div className="maintenance-footer"><span>شكرًا لصبركم</span><span className="maintenance-footer-brand">MK<span>2</span></span></div>
      </section>
      <footer className="maintenance-caption" aria-label="معلومات الموقع">
        <span>MK2 · تجربة مشاهدة أفضل</span>
        <span>الإصدار <bdi>{SITE_RELEASE}</bdi></span>
        <a className="maintenance-personal-link" href={MK2_PERSONAL_SITE} target="_blank" rel="noopener noreferrer" aria-label="MK~2 — الموقع الشخصي">MK~2</a>
      </footer>
    </main>
  );
}
