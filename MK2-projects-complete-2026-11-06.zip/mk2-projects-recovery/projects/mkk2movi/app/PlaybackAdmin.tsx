"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { defaultPlaybackSettings, getPlaybackLinks, normalizePlaybackSettings, type EmbedInput, type PlaybackSettings, type PlaybackProviderConfig } from "../lib/playback";
import type { AutomaticSeriesResponse } from "../lib/vidsrc-catalog-types";
import { PLAYER_FRAME_SANDBOX } from "../lib/playback-frame-policy";
import "./playback-admin.css";

type PlaybackLink = ReturnType<typeof getPlaybackLinks>[number];
type ManagedItem = EmbedInput & {
  id: string;
  title: string;
  poster: string;
  description: string;
  year: string;
  genre: string;
  verifiedUrls: string[];
  serverIds?: string[];
  preferredServerId?: string;
};
type MediaForm = Omit<ManagedItem, "id" | "season" | "episode" | "verifiedUrls" | "serverIds" | "preferredServerId"> & { season: string; episode: string };
type TmdbResult = { id: number; name: string; description: string; posterUrl: string; year: string; rating: string };
type Snapshot = { settings: PlaybackSettings; items: ManagedItem[] };
type Preview = { serverId: PlaybackLink["id"]; url: string; baseUrl: string; inputKey: string; attempt: number };
type Notice = { text: string; error: boolean };
type LoadedSeason = { inputKey: string; data: AutomaticSeriesResponse & { year?: string; genre?: string } };
type MetadataField = "title" | "poster" | "description" | "year" | "genre";
type SeriesMetadata = Pick<MediaForm, MetadataField> & { id: string; mediaType: "tv"; seasons: { season: number; name: string; episodeCount: number }[] };
const metadataFields: MetadataField[] = ["title", "poster", "description", "year", "genre"];

const emptyMedia: MediaForm = {
  mediaType: "tv", idSource: "tmdb", mediaId: "", season: "1", episode: "1",
  title: "", poster: "", description: "", year: "", genre: "",
};

function errorText(error: unknown) {
  return error instanceof Error ? error.message : "تعذر إتمام الطلب. حاول مجددًا.";
}

function mediaInput(form: MediaForm): EmbedInput {
  return {
    mediaType: form.mediaType,
    idSource: form.idSource,
    mediaId: form.mediaId.trim(),
    season: form.mediaType === "tv" ? Number(form.season) : 0,
    episode: form.mediaType === "tv" ? Number(form.episode) : 1,
  };
}

function titleIdentity(form: MediaForm) {
  return JSON.stringify([form.mediaType, form.idSource, form.mediaId.trim()]);
}

function isAutomaticTitle(form: MediaForm) {
  return form.mediaType === "tv" && form.idSource === "tmdb" && /^[1-9]\d*$/.test(form.mediaId.trim()) && Number(form.mediaId) <= 2147483647;
}

function parseSnapshot(data: Record<string, unknown>): Snapshot {
  if (!data.settings || typeof data.settings !== "object" || !Array.isArray(data.items)) {
    throw new Error("وصلت استجابة غير مكتملة من خدمة إدارة السيرفرات.");
  }
  return { settings: normalizePlaybackSettings(data.settings), items: data.items as ManagedItem[] };
}

function matchesPlaybackDetails(detail: Record<string, unknown>, input: EmbedInput) {
  const present = (value: unknown) => value !== undefined && value !== null && value !== "";
  for (const key of input.idSource === "tmdb" ? ["tmdbId", "mtmdbId", "tmdb_id"] : ["imdbId", "imdb_id"]) {
    if (present(detail[key]) && String(detail[key]) !== input.mediaId) return false;
  }
  if (present(detail.mediaId) && String(detail.mediaId) !== input.mediaId) return false;
  if (present(detail.mediaType)) {
    const reportedType = detail.mediaType === "series" ? "tv" : detail.mediaType;
    if (reportedType !== input.mediaType) return false;
  }
  if (input.mediaType === "tv") {
    if (present(detail.season) && Number(detail.season) !== input.season) return false;
    if (present(detail.episode) && Number(detail.episode) !== input.episode) return false;
  }
  return true;
}

export default function PlaybackAdmin() {
  const [settings, setSettings] = useState<PlaybackSettings>(() => normalizePlaybackSettings(defaultPlaybackSettings));
  const [savedSettings, setSavedSettings] = useState<PlaybackSettings>(() => normalizePlaybackSettings(defaultPlaybackSettings));
  const [items, setItems] = useState<ManagedItem[]>([]);
  const [form, setForm] = useState<MediaForm>({ ...emptyMedia });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [action, setAction] = useState<"settings" | "publish" | "delete" | "search" | null>(null);
  const [wholeSeason, setWholeSeason] = useState(true);
  const [loadedSeason, setLoadedSeason] = useState<LoadedSeason | null>(null);
  const [seasonLoading, setSeasonLoading] = useState(false);
  const [seasonError, setSeasonError] = useState("");
  const [metadataLoading, setMetadataLoading] = useState(false);
  const [metadataError, setMetadataError] = useState("");
  const [metadataReload, setMetadataReload] = useState(0);
  const [loadedMetadata, setLoadedMetadata] = useState<{ inputKey: string; data: SeriesMetadata } | null>(null);
  const [auditWarning, setAuditWarning] = useState("");
  const [notice, setNotice] = useState<Notice | null>(null);
  const [selectedServer, setSelectedServer] = useState<PlaybackLink["id"]>("vidsrc");
  const [preferredServerId, setPreferredServerId] = useState("");
  const [selectedServerIds, setSelectedServerIds] = useState<string[] | null>(null);
  const [preview, setPreview] = useState<Preview | null>(null);
  const [frameLoaded, setFrameLoaded] = useState(false);
  const [frameSlow, setFrameSlow] = useState(false);
  const [frameError, setFrameError] = useState(false);
  const [verifiedUrls, setVerifiedUrls] = useState<string[]>([]);
  const [startedUrls, setStartedUrls] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const [searchType, setSearchType] = useState<EmbedInput["mediaType"]>("tv");
  const [results, setResults] = useState<TmdbResult[]>([]);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const mountedRef = useRef(true);
  const requestsRef = useRef(new Set<AbortController>());
  const attemptRef = useRef(0);
  const seasonRequestRef = useRef(0);
  const seasonControllerRef = useRef<AbortController | null>(null);
  const titleRequestRef = useRef(0);
  const liveFormRef = useRef(form);
  liveFormRef.current = form;
  const touchedMetadataRef = useRef(new Set<MetadataField>());
  const busy = loading || action !== null;
  const dirtySettings = JSON.stringify(settings) !== JSON.stringify(savedSettings);
  const savedSettingsKey = JSON.stringify(savedSettings);
  const input = useMemo(() => mediaInput(form), [form]);
  const inputKey = JSON.stringify(input);
  const bulkMode = !editingId && wholeSeason && form.mediaType === "tv" && form.idSource === "tmdb";
  const seasonInputKey = JSON.stringify([form.mediaType, form.idSource, form.mediaId.trim(), Number(form.season)]);
  const titleInputKey = titleIdentity(form);
  const automaticTitle = isAutomaticTitle(form);
  const activeMetadata = loadedMetadata?.inputKey === titleInputKey ? loadedMetadata.data : null;
  const activeSeason = bulkMode && loadedSeason?.inputKey === seasonInputKey ? loadedSeason.data : null;
  const { links, linkError } = useMemo(() => {
    if (!input.mediaId) return { links: [] as PlaybackLink[], linkError: "أدخل معرّف العمل لتوليد رابط المشغل." };
    if (bulkMode && !activeSeason) return { links: [] as PlaybackLink[], linkError: "تظهر روابط المعاينة بعد جلب حلقات الموسم تلقائيًا." };
    if (input.mediaType === "tv" && (!form.season.trim() || !form.episode.trim())) {
      return { links: [] as PlaybackLink[], linkError: "أدخل رقم الموسم ورقم الحلقة." };
    }
    try {
      const generated = getPlaybackLinks(savedSettings, input);
      return { links: generated, linkError: generated.length ? "" : input.idSource === "imdb" ? "لا توجد سيرفرات مفعّلة تدعم IMDb. فعّل سيرفرًا متوافقًا أو استخدم معرّف TMDb." : "لا توجد سيرفرات مفعّلة. فعّل سيرفرًا واحفظ الإعدادات." };
    } catch (error) {
      return { links: [] as PlaybackLink[], linkError: errorText(error) };
    }
  }, [input, savedSettings, form.season, form.episode, bulkMode, activeSeason]);
  const selectedLink = links.find((link) => link.id === selectedServer) ?? links[0];
  const allowedServerIds = selectedServerIds === null ? links.map((link) => link.id) : selectedServerIds.filter((id) => links.some((link) => link.id === id));
  const preferredLink = links.find((link) => link.id === preferredServerId) ?? links.find((link) => allowedServerIds.includes(link.id));
  const activePreview = preview && preview.inputKey === inputKey && links.some((link) => link.url === preview.url) ? preview : null;
  const primaryVerified = Boolean(preferredLink && allowedServerIds.includes(preferredLink.id) && verifiedUrls.includes(preferredLink.url));
  const previewVerified = Boolean(activePreview && verifiedUrls.includes(activePreview.url));
  const seasonReady = Boolean(activeSeason?.episodes.length && links.length);
  const canPublish = primaryVerified && (!bulkMode || seasonReady);

  async function requestJson(url: string, init?: RequestInit): Promise<Record<string, unknown>> {
    const controller = new AbortController();
    const externalSignal = init?.signal;
    const abort = () => controller.abort();
    if (externalSignal?.aborted) controller.abort();
    externalSignal?.addEventListener("abort", abort, { once: true });
    requestsRef.current.add(controller);
    try {
      const response = await fetch(url, { ...init, cache: "no-store", credentials: "same-origin", signal: controller.signal });
      const data = await response.json().catch(() => null) as Record<string, unknown> | null;
      if (!response.ok) {
        if (response.status === 401 || response.status === 403) throw new Error("انتهت جلسة الإدارة. سجّل الدخول مجددًا.");
        throw new Error(typeof data?.error === "string" ? data.error : "تعذر الاتصال بخدمة الإدارة.");
      }
      if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error("تعذر قراءة استجابة خدمة الإدارة.");
      if (typeof data.error === "string") throw new Error(data.error);
      if (init?.method && init.method !== "GET" && mountedRef.current) setAuditWarning(typeof data.auditWarning === "string" ? data.auditWarning : "");
      return data;
    } finally {
      requestsRef.current.delete(controller);
      externalSignal?.removeEventListener("abort", abort);
    }
  }

  async function reload() {
    setLoading(true);
    setNotice(null);
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    invalidateSeason();
    try {
      const snapshot = parseSnapshot(await requestJson("/api/admin/playback"));
      if (!mountedRef.current) return;
      setSavedSettings(snapshot.settings);
      setSettings(snapshot.settings);
      setItems(snapshot.items);
    } catch (error) {
      if (mountedRef.current) setNotice({ text: errorText(error), error: true });
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }

  useEffect(() => {
    mountedRef.current = true;
    const requests = requestsRef.current;
    async function initialize() {
      try {
        const snapshot = parseSnapshot(await requestJson("/api/admin/playback"));
        if (!mountedRef.current) return;
        setSavedSettings(snapshot.settings);
        setSettings(snapshot.settings);
        setItems(snapshot.items);
      } catch (error) {
        if (mountedRef.current) setNotice({ text: errorText(error), error: true });
      } finally {
        if (mountedRef.current) setLoading(false);
      }
    }
    void initialize();
    return () => {
      mountedRef.current = false;
      seasonRequestRef.current++;
      titleRequestRef.current++;
      requests.forEach((controller) => controller.abort());
      // React removes the iframe when the admin section closes, stopping playback.
    };
    // Load once when this protected admin section opens.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const requestId = ++titleRequestRef.current;
    setMetadataError("");
    setMetadataLoading(false);
    if (loading || !automaticTitle) return;
    const controller = new AbortController();
    const requestedKey = titleInputKey;
    const requestedId = form.mediaId.trim();
    const timeout = window.setTimeout(async () => {
      setMetadataLoading(true);
      try {
        const data = await requestJson(`/api/admin/playback/title?id=${encodeURIComponent(requestedId)}`, { signal: controller.signal }) as unknown as SeriesMetadata;
        if (!mountedRef.current || controller.signal.aborted || requestId !== titleRequestRef.current || titleIdentity(liveFormRef.current) !== requestedKey) return;
        if (data.mediaType !== "tv" || Number(data.id) !== Number(requestedId) || typeof data.title !== "string" || typeof data.poster !== "string") throw new Error("وصلت بيانات لا تطابق معرّف المسلسل.");
        setLoadedMetadata({ inputKey: requestedKey, data });
        applyMetadata(data, requestedKey);
      } catch (error) {
        if (mountedRef.current && !controller.signal.aborted && requestId === titleRequestRef.current) setMetadataError(errorText(error));
      } finally {
        if (mountedRef.current && requestId === titleRequestRef.current) setMetadataLoading(false);
      }
    }, 500);
    return () => { window.clearTimeout(timeout); controller.abort(); };
    // Only a change of title identity or an explicit retry starts a lookup.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [titleInputKey, editingId, automaticTitle, loading, metadataReload]);

  useEffect(() => {
    if (loading || action !== null || !bulkMode || !automaticTitle || !form.season.trim() || !Number.isInteger(Number(form.season)) || Number(form.season) < 0 || Number(form.season) > 999) return;
    const controller = new AbortController();
    const timeout = window.setTimeout(() => { void fetchSeason(controller.signal); }, 550);
    return () => {
      window.clearTimeout(timeout);
      controller.abort();
      seasonRequestRef.current++;
      setSeasonLoading(false);
    };
    // Metadata updates and episode selection do not restart the season lookup.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [seasonInputKey, bulkMode, automaticTitle, loading, savedSettingsKey, action]);

  useEffect(() => {
    if (!activePreview || frameLoaded) return;
    const timeout = window.setTimeout(() => setFrameSlow(true), 20000);
    return () => window.clearTimeout(timeout);
  }, [activePreview, frameLoaded]);

  useEffect(() => {
    if (!activePreview) return;
    const current = activePreview;
    const expectedOrigin = new URL(current.baseUrl).origin;
    function receivePlayback(event: MessageEvent) {
      if (current.attempt !== attemptRef.current) return;
      if (event.source !== iframeRef.current?.contentWindow) return;
      if (event.origin !== expectedOrigin && !(current.serverId === "vidsrc" && event.origin === "https://to.vidsrc.party")) return;
      let message: unknown = event.data;
      if (typeof message === "string") {
        try { message = JSON.parse(message); } catch { return; }
      }
      if (!message || typeof message !== "object") return;
      const envelope = message as { type?: unknown; data?: unknown };
      if (envelope.type !== "PLAYER_EVENT" || !envelope.data || typeof envelope.data !== "object") return;
      const detail = envelope.data as Record<string, unknown>;
      if (!matchesPlaybackDetails(detail, input)) return;
      if (detail.event !== "play" && !(detail.event === "timeupdate" && typeof detail.currentTime === "number" && detail.currentTime > 0)) return;
      // Only VidSrc.party documents this message contract. Playback alone does
      // not prove that the provider returned the requested series or episode.
      if (current.serverId !== "vidsrc") return;
      setStartedUrls((previous) => previous.includes(current.url) ? previous : [...previous, current.url]);
    }
    window.addEventListener("message", receivePlayback);
    return () => window.removeEventListener("message", receivePlayback);
  }, [activePreview, input]);

  function stopPreview() {
    attemptRef.current++;
    setPreview(null);
    setFrameLoaded(false);
    setFrameSlow(false);
    setFrameError(false);
  }

  function changeInput(update: Partial<Pick<MediaForm, "mediaType" | "idSource" | "mediaId" | "season" | "episode">>) {
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    if (["mediaType", "idSource", "mediaId", "season"].some((key) => key in update)) invalidateSeason();
    if (!editingId && ("mediaType" in update || "idSource" in update)) setWholeSeason(true);
    const next = { ...liveFormRef.current, ...update };
    if (titleIdentity(next) !== titleIdentity(liveFormRef.current)) {
      titleRequestRef.current++;
      setLoadedMetadata(null);
      setMetadataLoading(false);
      setMetadataError("");
      for (const field of metadataFields) if (!touchedMetadataRef.current.has(field)) next[field] = "";
    }
    liveFormRef.current = next;
    setForm(next);
  }

  function changeMetadata(field: MetadataField, value: string) {
    touchedMetadataRef.current.add(field);
    setForm((previous) => ({ ...previous, [field]: value }));
  }

  function applyMetadata(data: Partial<Pick<MediaForm, MetadataField>>, requestedKey: string) {
    setForm((previous) => {
      if (titleIdentity(previous) !== requestedKey) return previous;
      const next = { ...previous };
      const limits = { title: 120, poster: 1000, description: 1000, year: 4, genre: 80 };
      for (const field of metadataFields) {
        if (touchedMetadataRef.current.has(field) || typeof data[field] !== "string") continue;
        // An absent optional field must not erase metadata returned by the other lookup.
        if (data[field] || !next[field]) next[field] = data[field].slice(0, limits[field]);
      }
      return next;
    });
  }

  function invalidateSeason() {
    seasonControllerRef.current?.abort();
    seasonRequestRef.current++;
    setLoadedSeason(null);
    setSeasonLoading(false);
    setSeasonError("");
  }

  function changePublicationMode(nextWholeSeason: boolean) {
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    invalidateSeason();
    setWholeSeason(nextWholeSeason);
  }

  async function fetchSeason(signal?: AbortSignal) {
    if (busy || !bulkMode) return;
    if (!/^[1-9]\d*$/.test(form.mediaId.trim()) || Number(form.mediaId) > 2147483647 || !form.season.trim() || !Number.isInteger(Number(form.season)) || Number(form.season) < 0 || Number(form.season) > 999) {
      setSeasonError("أدخل معرّف TMDb صحيحًا ورقم الموسم المطلوب.");
      return;
    }
    const controller = new AbortController();
    const abort = () => controller.abort();
    if (signal?.aborted) controller.abort();
    signal?.addEventListener("abort", abort, { once: true });
    seasonControllerRef.current?.abort();
    seasonControllerRef.current = controller;
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    setLoadedSeason(null);
    const requestId = ++seasonRequestRef.current;
    const requestedKey = seasonInputKey;
    setSeasonLoading(true);
    setSeasonError("");
    try {
      const data = await requestJson(`/api/admin/playback/season?id=${encodeURIComponent(form.mediaId.trim())}&season=${encodeURIComponent(form.season)}`, { signal: controller.signal }) as unknown as LoadedSeason["data"];
      if (!mountedRef.current || controller.signal.aborted || requestId !== seasonRequestRef.current || JSON.stringify([liveFormRef.current.mediaType, liveFormRef.current.idSource, liveFormRef.current.mediaId.trim(), Number(liveFormRef.current.season)]) !== requestedKey) return;
      if (data.mediaType !== "tv" || Number(data.id) !== Number(form.mediaId) || data.season !== Number(form.season) || !Array.isArray(data.episodes)) throw new Error("وصلت بيانات لا تطابق المسلسل والموسم المطلوبين.");
      if (!data.episodes.length) throw new Error("لا توجد حلقات صدرت بالفعل في هذا الموسم لإضافتها.");
      setLoadedSeason({ inputKey: requestedKey, data });
      applyMetadata(data, titleIdentity(form));
      setForm((previous) => ({ ...previous, episode: String(data.episodes[0].episode) }));
    } catch (error) {
      if (mountedRef.current && !controller.signal.aborted && requestId === seasonRequestRef.current) setSeasonError(errorText(error));
    } finally {
      signal?.removeEventListener("abort", abort);
      if (seasonControllerRef.current === controller) seasonControllerRef.current = null;
      if (mountedRef.current && requestId === seasonRequestRef.current) setSeasonLoading(false);
    }
  }

  function startPreview(link = selectedLink) {
    if (busy || dirtySettings || !link) return;
    setFrameLoaded(false);
    setFrameSlow(false);
    setFrameError(false);
    setPreview({ serverId: link.id, url: link.url, baseUrl: link.baseUrl, inputKey, attempt: ++attemptRef.current });
  }

  function choosePreviewServer(id: string) {
    const link = links.find((entry) => entry.id === id);
    setSelectedServer(id);
    if (activePreview && link) startPreview(link);
    else stopPreview();
  }

  function changeProviders(next: PlaybackProviderConfig[]) {
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    setSettings((previous) => ({ ...previous, servers: next }));
  }

  function changeProvider(id: string, update: Partial<PlaybackProviderConfig>) {
    changeProviders((settings.servers ?? []).map((server) => server.id === id ? { ...server, ...update } : server));
  }

  function addProvider() {
    if ((settings.servers?.length ?? 0) >= 9) return;
    changeProviders([...(settings.servers ?? []), {
      id: `custom-${crypto.randomUUID()}`,
      name: "سيرفر مخصص", enabled: false,
      priority: Math.min(10000, Math.max(0, ...(settings.servers ?? []).map((server) => server.priority)) + 1),
      movieTemplate: "", tvTemplate: "", supportsImdb: false,
    }]);
  }

  function choosePrimaryServer(id: string) {
    setPreferredServerId(id);
    setSelectedServerIds((previous) => [...new Set([...(previous ?? links.map((link) => link.id)), id])]);
    choosePreviewServer(id);
  }

  function chooseAllowedServer(id: string, allowed: boolean) {
    const next = allowed ? [...new Set([...allowedServerIds, id])] : allowedServerIds.filter((serverId) => serverId !== id);
    setSelectedServerIds(next);
    if (!allowed && preferredLink?.id === id) setPreferredServerId(next[0] ?? "");
  }

  async function refreshAfterChange(success: string) {
    window.dispatchEvent(new Event("mk2-catalog-refresh"));
    try {
      const snapshot = parseSnapshot(await requestJson("/api/admin/playback"));
      if (!mountedRef.current) return;
      setSavedSettings(snapshot.settings);
      setSettings(snapshot.settings);
      setItems(snapshot.items);
      setNotice({ text: success, error: false });
    } catch (error) {
      if (mountedRef.current) setNotice({ text: `${success} تعذر تحديث القائمة: ${errorText(error)}`, error: true });
    }
  }

  async function saveSettings(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    setAction("settings");
    setNotice(null);
    try {
      const data = await requestJson("/api/admin/playback", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "settings", settings }),
      });
      if (!mountedRef.current) return;
      const next = normalizePlaybackSettings(data.settings && typeof data.settings === "object" ? data.settings : settings);
      setSavedSettings(next);
      setSettings(next);
      stopPreview();
      setVerifiedUrls([]);
      setStartedUrls([]);
      invalidateSeason();
      await refreshAfterChange("تم حفظ إعدادات السيرفرات.");
    } catch (error) {
      if (mountedRef.current) setNotice({ text: errorText(error), error: true });
    } finally {
      if (mountedRef.current) setAction(null);
    }
  }

  async function publish(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || dirtySettings || !canPublish || !preferredLink) return;
    setAction("publish");
    setNotice(null);
    try {
      const data = await requestJson("/api/admin/playback", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(bulkMode ? {
          action: "publish-season", item: { mediaType: "tv", idSource: "tmdb", mediaId: input.mediaId, season: input.season, title: form.title.trim(), poster: form.poster.trim(), description: form.description.trim(), year: form.year.trim(), genre: form.genre.trim(), serverIds: allowedServerIds, preferredServerId: preferredLink.id, previewEpisode: input.episode }, verifiedUrls,
        } : { action: "publish", item: { ...input, ...(editingId ? { id: editingId } : {}), title: form.title.trim(), poster: form.poster.trim(), description: form.description.trim(), year: form.year.trim(), genre: form.genre.trim(), serverIds: allowedServerIds, preferredServerId: preferredLink.id }, verifiedUrls }),
      });
      if (!mountedRef.current) return;
      resetForm();
      await refreshAfterChange(bulkMode ? `تم نشر الموسم ${input.season} كاملًا: ${Number(data.episodeCount)} حلقة متاحة للمشاهدين.` : editingId ? "تم تحديث العمل وإتاحته للمشاهدة." : "تم نشر العمل في المكتبة.");
    } catch (error) {
      if (mountedRef.current) setNotice({ text: errorText(error), error: true });
    } finally {
      if (mountedRef.current) setAction(null);
    }
  }

  async function removeItem(item: ManagedItem) {
    if (busy) return;
    setAction("delete");
    setNotice(null);
    try {
      await requestJson("/api/admin/playback", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id }) });
      if (!mountedRef.current) return;
      setItems((previous) => previous.filter((entry) => entry.id !== item.id));
      setDeleteId(null);
      if (editingId === item.id) resetForm();
      await refreshAfterChange(`تم حذف «${item.title}» من المكتبة.`);
    } catch (error) {
      if (mountedRef.current) setNotice({ text: errorText(error), error: true });
    } finally {
      if (mountedRef.current) setAction(null);
    }
  }

  function resetForm() {
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    invalidateSeason();
    titleRequestRef.current++;
    touchedMetadataRef.current.clear();
    setLoadedMetadata(null);
    setMetadataLoading(false);
    setMetadataError("");
    setEditingId(null);
    setSelectedServerIds(null);
    setPreferredServerId("");
    setWholeSeason(true);
    liveFormRef.current = { ...emptyMedia };
    setForm(liveFormRef.current);
    setResults([]);
  }

  function editItem(item: ManagedItem) {
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    invalidateSeason();
    titleRequestRef.current++;
    touchedMetadataRef.current = new Set(metadataFields.filter((field) => Boolean(item[field])));
    setLoadedMetadata(null);
    setMetadataLoading(false);
    setMetadataError("");
    setWholeSeason(false);
    setEditingId(item.id);
    const currentLinks = getPlaybackLinks(savedSettings, item);
    const approvedIds = currentLinks.filter((link) => item.verifiedUrls.includes(link.url)).map((link) => link.id);
    setSelectedServerIds(item.serverIds?.length ? item.serverIds : approvedIds.length ? approvedIds : null);
    setPreferredServerId(item.preferredServerId ?? approvedIds[0] ?? currentLinks[0]?.id ?? "");
    setSelectedServer(item.preferredServerId ?? approvedIds[0] ?? currentLinks[0]?.id ?? "vidsrc");
    liveFormRef.current = { mediaType: item.mediaType, idSource: item.idSource, mediaId: item.mediaId, season: String(item.season), episode: String(item.episode), title: item.title, poster: item.poster, description: item.description, year: item.year, genre: item.genre };
    setForm(liveFormRef.current);
    setNotice({ text: "تم تحميل بيانات العمل. اختر السيرفر الرئيسي والبدائل، ثم عاين الحلقة وأكّد مطابقتها قبل حفظ التعديلات.", error: false });
    setResults([]);
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    formRef.current?.querySelector<HTMLInputElement>("[data-media-id]")?.focus({ preventScroll: true });
  }

  async function searchTmdb(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    setAction("search");
    setNotice(null);
    setResults([]);
    try {
      const data = await requestJson(`/api/admin/tmdb/search?q=${encodeURIComponent(query.trim())}&type=${searchType}`);
      if (!Array.isArray(data.results)) throw new Error("تعذر قراءة نتائج TMDB.");
      if (!mountedRef.current) return;
      setResults(data.results as TmdbResult[]);
      if (!data.results.length) setNotice({ text: "لم نعثر على نتائج بهذا الاسم في TMDB.", error: false });
    } catch (error) {
      if (mountedRef.current) setNotice({ text: errorText(error), error: true });
    } finally {
      if (mountedRef.current) setAction(null);
    }
  }

  function selectResult(result: TmdbResult) {
    stopPreview();
    setVerifiedUrls([]);
    setStartedUrls([]);
    invalidateSeason();
    titleRequestRef.current++;
    touchedMetadataRef.current.clear();
    setLoadedMetadata(null);
    setMetadataError("");
    if (!editingId) setWholeSeason(true);
    liveFormRef.current = { ...liveFormRef.current, mediaType: searchType, idSource: "tmdb", mediaId: String(result.id), title: result.name, poster: result.posterUrl, description: result.description, year: result.year, genre: "" };
    setForm(liveFormRef.current);
    setResults([]);
    setNotice({ text: searchType === "tv" && !editingId ? `تم تعبئة بيانات «${result.name}». يجري جلب حلقات الموسم تلقائيًا ويمكنك تغيير رقم الموسم.` : `تم تعبئة بيانات «${result.name}». أدخل الموسم والحلقة عند الحاجة ثم عاين المشغل.`, error: false });
  }

  return <div className="playback-admin" dir="rtl" aria-busy={busy}>
    <form className="admin-form playback-panel" onSubmit={saveSettings}>
      <h3>إعدادات سيرفرات المشاهدة</h3>
      <p className="admin-help">فعّل السيرفرات التي تريد إتاحتها. الأولوية الأصغر تبدأ أولًا، ويمكنك اختيار سيرفر رئيسي مختلف لكل موسم عند نشره.</p>
      {settings.legacyFallbackNeedsRepair && <aside className="playback-legacy-repair" role="status">
        <strong>رابط السيرفر الاحتياطي القديم يحتاج تصحيحًا</strong>
        <p>تعطّل هذا الرابط وحده، وبقيت السيرفرات الأخرى متاحة. أضف الاحتياطي كسيرفر مخصص بروابط صحيحة، ثم عاين الحلقة قبل النشر.</p>
        <details><summary>عرض الرابط القديم</summary><code dir="ltr">{settings.legacyFallbackOriginalUrl}</code></details>
        <button type="button" className="playback-text-button" disabled={busy} onClick={() => setSettings((previous) => ({ ...previous, fallbackBaseUrl: "", legacyFallbackNeedsRepair: undefined, legacyFallbackOriginalUrl: undefined }))}>تجاهل الرابط القديم</button>
      </aside>}
      <fieldset disabled={busy}>
        <div className="playback-provider-grid">
          {(settings.servers ?? []).map((server) => {
            const custom = server.id.startsWith("custom-") || server.id === "fallback";
            return <article className={`playback-provider-card${server.enabled ? " is-enabled" : ""}`} key={server.id} data-server-id={server.id}>
              <div className="playback-server-heading">
                <div><strong dir="auto">{server.name}</strong><small>{custom ? "سيرفر مخصص" : "سيرفر مشاهدة"} · {server.supportsImdb ? "TMDb وIMDb" : "TMDb"}</small></div>
                <label className="playback-toggle"><input type="checkbox" role="switch" aria-label={`تشغيل ${server.name}`} checked={server.enabled} onChange={(event) => changeProvider(server.id, { enabled: event.target.checked })}/><span className="playback-toggle-track" aria-hidden="true"/><span>{server.enabled ? "مفعّل" : "متوقف"}</span></label>
              </div>
              <div className="playback-provider-controls">
                <label>الأولوية<input aria-label={`أولوية ${server.name}`} type="number" min="1" max="10000" step="1" value={server.priority} onChange={(event) => changeProvider(server.id, { priority: Number(event.target.value) })} required/></label>
                {server.docsUrl && <a className="playback-provider-docs" href={server.docsUrl} target="_blank" rel="noopener noreferrer">توثيق السيرفر ↗</a>}
                {custom && <button type="button" className="playback-delete" onClick={() => changeProviders((settings.servers ?? []).filter((entry) => entry.id !== server.id))}>حذف السيرفر</button>}
              </div>
              <details className="playback-provider-templates" open={custom || undefined}>
                <summary>{custom ? "اسم السيرفر وقوالب الروابط" : "عرض قوالب الروابط"}</summary>
                {custom && <label>اسم السيرفر<input value={server.name} maxLength={60} onChange={(event) => changeProvider(server.id, { name: event.target.value })} required/></label>}
                <label>قالب الفيلم<input type="url" dir="ltr" value={server.movieTemplate} placeholder="https://example.com/embed/movie/{id}" maxLength={2048} readOnly={!custom} onChange={(event) => changeProvider(server.id, { movieTemplate: event.target.value })} required/></label>
                <label>قالب المسلسل<input type="url" dir="ltr" value={server.tvTemplate} placeholder="https://example.com/embed/tv/{id}/{season}/{episode}" maxLength={2048} readOnly={!custom} onChange={(event) => changeProvider(server.id, { tvTemplate: event.target.value })} required/></label>
                {custom && <label className="playback-checkbox"><input type="checkbox" checked={server.supportsImdb} onChange={(event) => changeProvider(server.id, { supportsImdb: event.target.checked })}/><span>يدعم معرف IMDb أيضًا</span></label>}
                <p className="admin-help">استخدم HTTPS و<code dir="ltr">{'{id}'}</code> للمعرّف، و<code dir="ltr">{'{season}'}</code> و<code dir="ltr">{'{episode}'}</code> للمسلسل.</p>
              </details>
            </article>;
          })}
        </div>
        <div className="playback-provider-footer"><button type="button" className="feature-button quiet" disabled={busy || (settings.servers?.length ?? 0) >= 9} onClick={addProvider}>+ إضافة سيرفر مخصص</button><span>{settings.servers?.length ?? 0} / 9 سيرفرات</span></div>
        <p className="playback-note">وجود مسلسل في TMDb لا يضمن توفره على أي سيرفر. عاين المسلسل والحلقة الفعلية قبل النشر، خاصة الأعمال العربية والخليجية.</p>
        <button className="feature-button primary" disabled={busy}>{action === "settings" ? "جارٍ الحفظ…" : "حفظ إعدادات السيرفرات"}</button>
      </fieldset>
      {dirtySettings && <p className="playback-note" role="status">احفظ إعدادات السيرفرات قبل المعاينة أو نشر العمل.</p>}
    </form>

    <details className="playback-panel playback-lookup">
      <summary>جلب بيانات العمل من TMDB</summary>
      <form className="admin-form" onSubmit={searchTmdb}>
        <fieldset disabled={busy}>
          <div className="design-row"><label>نوع البحث<select value={searchType} onChange={(event) => { setSearchType(event.target.value as EmbedInput["mediaType"]); setResults([]); }}><option value="tv">مسلسل</option><option value="movie">فيلم</option></select></label><label>اسم العمل<input type="search" value={query} minLength={2} maxLength={100} onChange={(event) => { setQuery(event.target.value); setResults([]); }} placeholder="ابحث باسم العمل" required/></label></div>
          <button className="feature-button quiet" disabled={busy}>{action === "search" ? "جارٍ البحث…" : "بحث في TMDB"}</button>
        </fieldset>
        {results.length > 0 && <div className="tmdb-results" aria-label="نتائج بحث TMDB">{results.map((result) => <button type="button" className="tmdb-result" key={result.id} disabled={busy} onClick={() => selectResult(result)}>{result.posterUrl ? <img src={result.posterUrl} alt="" loading="lazy"/> : <span className="tmdb-no-poster">TMDB</span>}<span><strong>{result.name}</strong><small>{[result.year, result.rating ? `★ ${result.rating}` : ""].filter(Boolean).join(" · ")}</small></span></button>)}</div>}
        <div className="tmdb-credit"><a href="https://www.themoviedb.org" target="_blank" rel="noopener noreferrer"><img src="/tmdb-logo.svg" alt="TMDB" loading="lazy"/></a><span>هذا المنتج يستخدم TMDB API لكنه غير معتمد أو مصدّق من TMDB.</span></div>
      </form>
    </details>

    <form ref={formRef} className="admin-form playback-panel" onSubmit={publish}>
      <div className="playback-panel-heading"><h3>{editingId ? "تعديل عمل منشور" : bulkMode ? "نشر موسم كامل" : "معاينة ونشر عمل"}</h3>{editingId && <button type="button" className="playback-text-button" disabled={busy} onClick={resetForm}>إلغاء التعديل</button>}</div>
      {bulkMode && <p className="admin-help">أدخل معرّف المسلسل ورقم الموسم. يظهر الملصق والبيانات والحلقات تلقائيًا، ثم اختر السيرفر الرئيسي وعاين الحلقة للتأكد من مطابقتها قبل نشر الموسم كاملًا.</p>}
      <fieldset disabled={busy}>
        <div className="design-row"><label>نوع العمل<select value={form.mediaType} onChange={(event) => changeInput({ mediaType: event.target.value as EmbedInput["mediaType"] })}><option value="tv">مسلسل</option><option value="movie">فيلم</option></select></label><label>مصدر المعرّف<select value={form.idSource} onChange={(event) => changeInput({ idSource: event.target.value as EmbedInput["idSource"] })}><option value="tmdb">TMDb</option><option value="imdb">IMDb</option></select></label></div>
        {!editingId && form.mediaType === "tv" && form.idSource === "tmdb" && <label>طريقة الإضافة<select value={wholeSeason ? "season" : "episode"} onChange={(event) => changePublicationMode(event.target.value === "season")}><option value="season">الموسم كاملًا</option><option value="episode">حلقة واحدة</option></select></label>}
        <label>معرّف {form.idSource === "tmdb" ? "TMDb" : "IMDb"}<input data-media-id dir="ltr" inputMode={form.idSource === "tmdb" ? "numeric" : "text"} value={form.mediaId} maxLength={30} placeholder={form.idSource === "tmdb" ? "مثال: 1399" : "مثال: tt0944947"} pattern={form.idSource === "tmdb" ? "[0-9]+" : "tt[0-9]+"} onChange={(event) => changeInput({ mediaId: event.target.value })} required/></label>
        {(automaticTitle || form.poster) && <div className="playback-metadata-card" aria-busy={metadataLoading}>
          {form.poster ? <img src={form.poster} alt={`ملصق ${form.title || "المسلسل"}`}/> : <span className="playback-poster-placeholder" aria-hidden="true">TMDb</span>}
          <div>
            <strong>{form.title || "بيانات المسلسل"}</strong>
            {(form.year || form.genre) && <span>{[form.year, form.genre].filter(Boolean).join(" · ")}</span>}
            {automaticTitle && <p className={metadataError ? "playback-metadata-error" : "admin-help"} role={metadataError ? "alert" : "status"}>{metadataLoading ? "جارٍ جلب الملصق وبيانات المسلسل…" : metadataError ? metadataError : activeMetadata ? form.poster ? "تم جلب ملصق المسلسل وبياناته تلقائيًا." : "تم جلب البيانات؛ لا يوجد ملصق لهذا المسلسل في المصدر." : "سيظهر الملصق والبيانات تلقائيًا بعد إدخال المعرّف."}</p>}
            {automaticTitle && <button type="button" className="playback-text-button" disabled={busy || metadataLoading} onClick={() => setMetadataReload((value) => value + 1)}>{metadataError ? "إعادة جلب بيانات المسلسل" : "تحديث بيانات المسلسل"}</button>}
          </div>
        </div>}
        {form.mediaType === "tv" && <div className={bulkMode ? "" : "design-row"}><label>رقم الموسم<input type="number" min="0" max="999" step="1" value={form.season} onChange={(event) => changeInput({ season: event.target.value })} required/></label>{!bulkMode && <label>رقم الحلقة<input type="number" min="1" max="9999" step="1" value={form.episode} onChange={(event) => changeInput({ episode: event.target.value })} required/></label>}</div>}
        {bulkMode && <>
          <button type="button" className="feature-button quiet" disabled={busy || seasonLoading || !automaticTitle || !form.season.trim()} onClick={() => void fetchSeason()}>{seasonLoading ? "جارٍ جلب الحلقات…" : activeSeason ? "تحديث حلقات الموسم" : "جلب حلقات الموسم"}</button>
          {seasonLoading && <p className="admin-help" role="status">جارٍ جلب حلقات الموسم {form.season}… يمكنك تغيير المعرّف أو الموسم أثناء التحميل.</p>}
          {seasonError && <p className="playback-metadata-error" role="alert">{seasonError}</p>}
          {activeSeason && <div className="playback-season-summary">
            <div><strong>{activeSeason.title}</strong><span>الموسم {activeSeason.season} · {activeSeason.episodes.length} حلقة صدرت بالفعل</span><details><summary>عرض حلقات الموسم</summary><ol>{activeSeason.episodes.map((episode) => <li key={episode.id}><span>الحلقة {episode.episode}</span><strong>{episode.title}</strong></li>)}</ol></details></div>
          </div>}
          {activeSeason && <div className="playback-preview-episode">
            <label>الحلقة التي تريد معاينتها<select value={form.episode} onChange={(event) => changeInput({ episode: event.target.value })}>{activeSeason.episodes.map((episode) => <option key={episode.id} value={episode.episode}>الحلقة {episode.episode} · {episode.title}</option>)}</select></label>
            <div className="playback-episode-shortcuts">{[0, 1, activeSeason.episodes.length - 1].filter((index, position, values) => index >= 0 && index < activeSeason.episodes.length && values.indexOf(index) === position).map((index) => <button type="button" className="playback-text-button" key={index} onClick={() => changeInput({ episode: String(activeSeason.episodes[index].episode) })}>{index === 0 ? "أول حلقة" : index === 1 ? "ثاني حلقة" : "آخر حلقة"}</button>)}</div>
          </div>}
        </>}
        {linkError ? <p className="admin-help playback-link-help" aria-live="polite">{linkError}</p> : <>
          <div className="playback-server-policy">
            <label>السيرفر الرئيسي {bulkMode ? "لهذا الموسم" : form.mediaType === "tv" ? "لهذه الحلقة" : "لهذا الفيلم"}<select value={preferredLink?.id ?? ""} onChange={(event) => choosePrimaryServer(event.target.value)} disabled={dirtySettings}>{!preferredLink && <option value="">اختر سيرفرًا</option>}{links.map((link) => <option key={link.id} value={link.id}>{link.name} · أولوية {link.priority}</option>)}</select></label>
            <div className="playback-allowed-servers"><strong>السيرفرات المتاحة للمشاهد</strong>{links.map((link) => <label className="playback-checkbox" key={link.id}><input type="checkbox" checked={allowedServerIds.includes(link.id)} disabled={dirtySettings || preferredLink?.id === link.id} onChange={(event) => chooseAllowedServer(link.id, event.target.checked)}/><span>{link.name}{preferredLink?.id === link.id ? " · رئيسي" : " · بديل"}{verifiedUrls.includes(link.url) ? " · أكدت المطابقة" : ""}</span></label>)}</div>
            <p className="admin-help">استبعد أي سيرفر يعرض مسلسلًا أو حلقة مختلفة. هذا الاختيار يخص {bulkMode ? "الموسم" : "هذا العمل"} ولا يوقف السيرفر لبقية المسلسلات.</p>
          </div>
          <label>سيرفر المعاينة<select value={selectedLink?.id ?? ""} onChange={(event) => choosePreviewServer(event.target.value)} disabled={dirtySettings}>{links.map((link) => <option key={link.id} value={link.id}>{link.name} · أولوية {link.priority}{verifiedUrls.includes(link.url) ? " · أكدت المطابقة" : ""}</option>)}</select></label>
          <a className="playback-generated-url" href={selectedLink?.url} target="_blank" rel="noopener noreferrer" dir="ltr">{selectedLink?.url}</a>
        </>}
        <div className="button-row"><button type="button" className="feature-button quiet" disabled={busy || dirtySettings || !selectedLink} onClick={() => startPreview()}>{activePreview ? "إعادة المعاينة" : "معاينة"}</button><button type="button" className="feature-button quiet" disabled={!activePreview} onClick={stopPreview}>إيقاف المعاينة</button></div>
      </fieldset>

      <div className="playback-preview" aria-label="المعاينة الحية للمشغل">
        {activePreview ? <iframe key={`${activePreview.url}:${activePreview.attempt}`} ref={iframeRef} sandbox={PLAYER_FRAME_SANDBOX} src={activePreview.url} title={`معاينة ${form.mediaType === "tv" ? `الموسم ${input.season} الحلقة ${input.episode}` : "الفيلم"} عبر ${links.find((link) => link.id === activePreview.serverId)?.name ?? "السيرفر"}`} allow="autoplay; encrypted-media; fullscreen; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" onLoad={(event) => { if (event.currentTarget !== iframeRef.current || activePreview.attempt !== attemptRef.current) return; setFrameLoaded(true); setFrameSlow(false); }} onError={(event) => { if (event.currentTarget === iframeRef.current && activePreview.attempt === attemptRef.current) setFrameError(true); }}/> : <div className="playback-preview-empty"><span aria-hidden="true">▷</span><strong>معاينة المشغل</strong><p>أدخل المعرّف ثم اضغط «معاينة» لفتح الفيديو هنا.</p></div>}
      </div>
      {activePreview && <div className="playback-preview-feedback" aria-live="polite">
        <p className={previewVerified ? "playback-verified" : "admin-help"}>{previewVerified ? "✓ أكدت أن الفيديو يعمل ويطابق المسلسل والحلقة المطلوبة." : frameError ? "تعذر تحميل المشغل. اختر سيرفرًا آخر للمعاينة." : frameSlow ? "المشغل يستغرق وقتًا أطول. جرّب إعادة المعاينة أو تغيير السيرفر." : startedUrls.includes(activePreview.url) ? "بدأ التشغيل. تأكد بنفسك من اسم المسلسل ومحتوى الحلقة قبل التأكيد." : frameLoaded ? "تم تحميل الإطار. شغّل الفيديو وتأكد من أنه المسلسل والحلقة المطلوبان." : "جارٍ تحميل المشغل…"}</p>
        <button type="button" className="feature-button quiet" disabled={busy || !frameLoaded || frameError || previewVerified || dirtySettings} onClick={() => { if (activePreview) setVerifiedUrls((previous) => previous.includes(activePreview.url) ? previous : [...previous, activePreview.url]); }}>{form.mediaType === "tv" ? "أكدت مطابقة المسلسل والحلقة ونجاح التشغيل" : "أكدت مطابقة الفيلم ونجاح التشغيل"}</button>
      </div>}
      <p className="admin-help">{bulkMode ? "يجب تأكيد مطابقة حلقة المعاينة على السيرفر الرئيسي قبل نشر الموسم. البدائل المحددة ستتاح للمشاهد؛ يُنصح بتجربتها ومعاينة أكثر من حلقة، فتوفر حلقة واحدة لا يضمن توفر الموسم كاملًا." : "تحميل الإطار وحده لا يثبت توفر الفيديو أو صحة العمل. يجب تأكيد مطابقة السيرفر الرئيسي بعد المشاهدة. البدائل المحددة ستتاح للمشاهد؛ يُنصح بتجربتها قبل النشر."}</p>
      <fieldset disabled={busy}>
        <label>اسم العمل<input value={form.title} onChange={(event) => changeMetadata("title", event.target.value)} maxLength={120} required/></label>
        <label>وصف مختصر<textarea value={form.description} onChange={(event) => changeMetadata("description", event.target.value)} maxLength={1000} rows={2}/></label>
        <details className="playback-poster-override"><summary>تغيير رابط الملصق يدويًا (اختياري)</summary><label>رابط الملصق<input type="url" dir="ltr" value={form.poster} onChange={(event) => changeMetadata("poster", event.target.value)} placeholder="https://.../poster.jpg" maxLength={1000}/></label><p className="admin-help">يُجلب ملصق مسلسلات TMDb تلقائيًا. استخدم هذا الحقل فقط إذا أردت ملصقًا مختلفًا.</p></details>
        <div className="design-row"><label>التصنيف<input value={form.genre} onChange={(event) => changeMetadata("genre", event.target.value)} maxLength={80}/></label><label>السنة<input inputMode="numeric" pattern="[0-9]{4}" value={form.year} onChange={(event) => changeMetadata("year", event.target.value)} placeholder="2026" maxLength={4}/></label></div>
        <p className={canPublish ? "playback-verified" : "playback-note"} role="status">{canPublish ? bulkMode ? `✓ أكدت الحلقة ${input.episode} عبر ${preferredLink?.name}. ${activeSeason?.episodes.length} حلقة جاهزة للنشر مع السيرفرات المحددة.` : `✓ أكدت مطابقة التشغيل عبر السيرفر الرئيسي: ${preferredLink?.name}.` : bulkMode && !seasonReady ? seasonLoading ? "يجري جلب حلقات الموسم تلقائيًا…" : "أدخل معرف المسلسل والموسم، ثم فعّل سيرفرًا مناسبًا واحفظه." : preferredLink ? `عاين ${preferredLink.name} وأكّد أن الفيديو يطابق ${form.mediaType === "tv" ? `الموسم ${input.season} والحلقة ${input.episode}` : "الفيلم المطلوب"} قبل النشر.` : "اختر سيرفرًا رئيسيًا قبل النشر."}</p>
        <button className="feature-button primary" disabled={busy || dirtySettings || !canPublish}>{action === "publish" ? "جارٍ الحفظ…" : bulkMode ? "نشر الموسم كاملًا بالسيرفرات المحددة" : editingId ? "حفظ التعديلات ونشرها" : "نشر العمل للمشاهدين"}</button>
      </fieldset>
    </form>

    <section className="playback-panel playback-published" aria-label="الأعمال المنشورة">
      <div className="playback-panel-heading"><h3>الأعمال المنشورة <span className="playback-count">{items.length}</span></h3><button type="button" className="playback-text-button" disabled={busy} onClick={() => void reload()}>تحديث</button></div>
      {loading ? <p className="admin-help" role="status">جارٍ تحميل الإعدادات والمكتبة…</p> : items.length ? <ul>{items.map((item) => {
        let ready = false;
        let primaryName = "";
        try {
          const itemLinks = getPlaybackLinks(savedSettings, item).filter((link) => !item.serverIds || item.serverIds.includes(link.id));
          ready = itemLinks.some((link) => item.verifiedUrls.includes(link.url));
          primaryName = itemLinks.find((link) => link.id === item.preferredServerId)?.name ?? "";
        } catch { /* Display invalidated entries for the administrator to repair. */ }
        return <li key={item.id}><div className="playback-item-details"><strong>{item.title}</strong><span>{item.mediaType === "tv" ? `مسلسل · الموسم ${item.season} · الحلقة ${item.episode}` : "فيلم"} · <bdi>{item.idSource.toUpperCase()} {item.mediaId}</bdi></span>{primaryName && <span>السيرفر الرئيسي: <bdi>{primaryName}</bdi></span>}<small className={ready ? "playback-verified" : "playback-note"}>{ready ? "جاهز للمشاهدة" : "يحتاج معاينة مع إعدادات السيرفر الحالية"}</small></div><div className="playback-item-actions">{deleteId === item.id ? <><button type="button" className="playback-delete" disabled={busy} onClick={() => void removeItem(item)}>{action === "delete" ? "جارٍ الحذف…" : "تأكيد الحذف"}</button><button type="button" className="playback-text-button" disabled={busy} onClick={() => setDeleteId(null)}>إلغاء</button></> : <><button type="button" className="playback-text-button" disabled={busy} onClick={() => editItem(item)}>تعديل ومعاينة</button><button type="button" className="playback-delete" disabled={busy} onClick={() => setDeleteId(item.id)}>حذف</button></>}</div></li>;
      })}</ul> : <p className="admin-help">لم تنشر أعمالًا بعد. أضف معرّف المسلسل ورقم الموسم لجلب حلقاته ونشرها معًا.</p>}
    </section>
    {auditWarning && <p className="admin-warning" role="status">{auditWarning}</p>}
    {notice && <p className={`admin-status playback-status${notice.error ? " playback-status-error" : ""}`} role={notice.error ? "alert" : "status"}>{notice.text}</p>}
  </div>;
}
