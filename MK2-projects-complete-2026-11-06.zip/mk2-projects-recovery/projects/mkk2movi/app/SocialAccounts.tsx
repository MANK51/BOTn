"use client";

import {
  normalizeSocialLinks,
  SOCIAL_PLATFORMS,
  SOCIAL_PLATFORM_LABELS,
  type SocialLinks,
  type SocialPlatform,
} from "../lib/social-links";

const profilePlaceholders: Record<SocialPlatform, string> = {
  tiktok: "https://www.tiktok.com/@username",
  snapchat: "https://www.snapchat.com/add/username",
  instagram: "https://www.instagram.com/username",
};

function SocialIcon({ platform }: { platform: SocialPlatform }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {platform === "instagram" ? <><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".7" fill="currentColor" stroke="none"/></> : platform === "tiktok" ? <path d="M14 3v12.5a4.5 4.5 0 1 1-4.5-4.5h1M14 3c.6 3.4 2.7 5.5 6 5.5V12a9 9 0 0 1-6-2.5"/> : <path d="M12 3c-3.2 0-5 2.3-5 5.2v2.1c-.7.4-1.3-.6-2-.1-.7.6.5 1.4 2 1.8-.3 2.4-1.9 4.3-4 4.8.4.8 1.7 1.1 2.7 1.3l.4 1.7c2-.4 2.6 1.2 5.9 1.2s3.9-1.6 5.9-1.2l.4-1.7c1-.2 2.3-.5 2.7-1.3-2.1-.5-3.7-2.4-4-4.8 1.5-.4 2.7-1.2 2-1.8-.7-.5-1.3.5-2 .1V8.2C17 5.3 15.2 3 12 3Z"/>}
  </svg>;
}

export function PublicSocialLinks({ links, placement }: { links: SocialLinks; placement: "header" | "footer" }) {
  const safeLinks = normalizeSocialLinks(links);
  const visiblePlatforms = SOCIAL_PLATFORMS.filter((platform) => safeLinks[platform].enabled && safeLinks[platform].url);
  if (!visiblePlatforms.length) return null;
  return <div className={`social-links social-links-${placement}`} role="group" aria-label="حسابات التواصل">
    {visiblePlatforms.map((platform) => <a
      key={platform}
      className="social-link"
      data-social-platform={platform}
      href={safeLinks[platform].url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`تابعنا على ${SOCIAL_PLATFORM_LABELS[platform]} (يفتح في نافذة جديدة)`}
      title={SOCIAL_PLATFORM_LABELS[platform]}
    ><SocialIcon platform={platform}/>{placement === "footer" && <span>{SOCIAL_PLATFORM_LABELS[platform]}</span>}</a>)}
  </div>;
}

export function SocialAccountsFields({ value, onChange, busy }: { value: SocialLinks; onChange: (links: SocialLinks) => void; busy: boolean }) {
  function updatePlatform(platform: SocialPlatform, change: Partial<SocialLinks[SocialPlatform]>) {
    onChange({ ...value, [platform]: { ...value[platform], ...change } });
  }

  return <>
    <div className="social-admin-intro"><h3>حسابات التواصل</h3><p className="admin-help">أضف روابط حساباتك، واختر ما يظهر منها في الموقع. تقدر توقف أي حساب أو تحذفه بشكل مستقل.</p></div>
    <div className="social-account-cards">
      {SOCIAL_PLATFORMS.map((platform) => {
        const account = value[platform];
        const label = SOCIAL_PLATFORM_LABELS[platform];
        const inputId = `social-account-${platform}`;
        return <section className={`social-account-card${account.enabled ? " is-enabled" : ""}`} data-social-platform={platform} key={platform} aria-labelledby={`${inputId}-title`}>
          <div className="social-account-heading"><div className="social-account-name"><span className="social-account-icon"><SocialIcon platform={platform}/></span><h4 id={`${inputId}-title`}>{label}</h4></div>
            <button type="button" className="social-account-switch" role="switch" aria-checked={account.enabled} aria-label={`إظهار حساب ${label} في الموقع`} disabled={busy} onClick={() => updatePlatform(platform, { enabled: !account.enabled })}><span className="social-account-switch-track" aria-hidden="true"/><span>{account.enabled ? "ظاهر" : "مخفي"}</span></button>
          </div>
          <label htmlFor={inputId}>رابط حساب {label}<input id={inputId} type="url" inputMode="url" autoComplete="off" dir="ltr" placeholder={profilePlaceholders[platform]} value={account.url} maxLength={2048} required={account.enabled} disabled={busy} aria-describedby={`${inputId}-help`} onChange={(event) => updatePlatform(platform, { url: event.target.value })}/></label>
          <div className="social-account-bottom"><p className="admin-help" id={`${inputId}-help`}>{account.enabled ? "سيظهر بعد حفظ الحسابات." : "إيقاف الظهور يحتفظ بالرابط لإعادة تشغيله لاحقًا."}</p><button type="button" className="social-account-remove" disabled={busy || (!account.url && !account.enabled)} onClick={() => updatePlatform(platform, { url: "", enabled: false })} aria-label={`حذف حساب ${label}`}>حذف الحساب</button></div>
        </section>;
      })}
    </div>
    <p className="admin-help">استخدم رابط HTTPS من موقع المنصة نفسها. اضغط حفظ لتطبيق التغييرات.</p>
  </>;
}
