"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Cloud, CloudOff, RefreshCw } from "lucide-react";
import { mergeViewerLibraries, normalizeViewerLibrary, readViewerLibrary, saveViewerLibrary, VIEWER_LIBRARY_EVENT, VIEWER_LIBRARY_KEY } from "../lib/viewer-library";
import "./personal-library.css";

type SyncState = "idle" | "syncing" | "saved" | "error";

/** Account upload begins only after the visitor explicitly enables it. */
export function ViewerSync({ signedIn }: { signedIn: boolean }) {
  const [enabled, setEnabled] = useState(false);
  const [state, setState] = useState<SyncState>("idle");
  const [message, setMessage] = useState("");
  const active = useRef(false);
  const dirty = useRef(false);
  const writingResponse = useRef(false);
  const controller = useRef<AbortController | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const enabledRef = useRef(false);

  async function sync() {
    if (!signedIn || !enabledRef.current) return;
    if (active.current) { dirty.current = true; return; }
    active.current = true;
    dirty.current = false;
    setState("syncing");
    const requestController = new AbortController();
    controller.current = requestController;
    const deadline = setTimeout(() => requestController.abort(), 15_000);
    try {
      const response = await fetch("/api/viewer/library", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ library: readViewerLibrary() }), cache: "no-store", signal: requestController.signal });
      const body = await response.json() as { library?: unknown; error?: string };
      if (!response.ok || !body.library) throw new Error(body.error || "تعذّرت المزامنة. اختياراتك محفوظة على هذا المتصفح.");
      if (!enabledRef.current) return;
      // Local changes made while the request was in flight are never overwritten.
      const merged = mergeViewerLibraries(normalizeViewerLibrary(body.library), readViewerLibrary());
      writingResponse.current = true;
      saveViewerLibrary(merged);
      writingResponse.current = false;
      setState("saved"); setMessage("تمت المزامنة مع حسابك");
    } catch (error) {
      if (!enabledRef.current) return;
      setState("error"); setMessage(error instanceof Error && error.name !== "AbortError" ? error.message : "تعذّرت المزامنة الآن. اختياراتك محفوظة على هذا المتصفح.");
    } finally {
      clearTimeout(deadline);
      active.current = false;
      if (dirty.current && enabledRef.current) timer.current = setTimeout(() => void sync(), 1500);
    }
  }

  useEffect(() => {
    if (!enabled || !signedIn) return;
    const changed = () => {
      if (writingResponse.current) return;
      if (active.current) { dirty.current = true; return; }
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => void sync(), 1500);
    };
    const storage = (event: StorageEvent) => { if (event.key === VIEWER_LIBRARY_KEY || event.key === null) changed(); };
    window.addEventListener(VIEWER_LIBRARY_EVENT, changed);
    window.addEventListener("storage", storage);
    window.addEventListener("online", changed);
    return () => { window.removeEventListener(VIEWER_LIBRARY_EVENT, changed); window.removeEventListener("storage", storage); window.removeEventListener("online", changed); if (timer.current) clearTimeout(timer.current); };
  }, [enabled, signedIn]);

  useEffect(() => () => { enabledRef.current = false; controller.current?.abort(); if (timer.current) clearTimeout(timer.current); }, []);
  useEffect(() => { if (!signedIn) { enabledRef.current = false; setEnabled(false); controller.current?.abort(); } }, [signedIn]);

  if (!signedIn) return <div className="viewer-sync" dir="rtl"><div><p>مكتبتك محفوظة محليًا على هذا الجهاز.</p><small>تتوفر المزامنة بين الأجهزة بعد تسجيل الدخول بحساب الموقع وتفعيلها من هنا.</small></div><CloudOff size={18} aria-hidden="true" /></div>;
  return <div className="viewer-sync" dir="rtl"><div><p className={state === "error" ? "viewer-sync-error" : ""} role="status">{enabled ? message || "جارٍ مزامنة مكتبتك…" : "احتفظ بمكتبتك مع حسابك على أجهزتك."}</p><small>{enabled ? "تُدمج المفضلة وقائمة لاحقًا وسجل التقدم. يمكنك إيقاف المزامنة في أي وقت." : "التفعيل يدمج اختيارات هذا المتصفح مع مكتبة حسابك؛ لا يُنشر سجل مشاهدتك للآخرين."}</small></div><div className="viewer-sync-state">{enabled ? <><button type="button" disabled={state === "syncing"} onClick={() => void sync()}>{state === "saved" ? <Check size={15} /> : <RefreshCw size={15} />}{state === "syncing" ? "جارٍ الحفظ…" : "مزامنة الآن"}</button><button type="button" onClick={() => { enabledRef.current = false; setEnabled(false); setState("idle"); setMessage(""); controller.current?.abort(); }}>إيقاف</button></> : <button type="button" onClick={() => { enabledRef.current = true; setEnabled(true); void sync(); }}><Cloud size={16} />تفعيل المزامنة</button>}</div></div>;
}
