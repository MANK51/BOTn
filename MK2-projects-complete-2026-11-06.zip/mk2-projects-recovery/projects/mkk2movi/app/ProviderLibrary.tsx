"use client";

import { useEffect, useId, useRef, useState } from "react";
import type { FormEvent } from "react";
import type { CinemaItem, CinemaMediaType } from "../lib/cinema-types";
import { PROVIDER_MAINTENANCE, PROVIDER_MAINTENANCE_TITLE, PROVIDER_MAINTENANCE_MESSAGE } from "../lib/provider-status";
import { CinemaCard } from "./CinemaLibrary";
import "./provider-library.css";

type ProviderCategory = { id: string; name: string };
type ProviderCatalog = {
  configured: boolean;
  maintenance?: boolean;
  expiresAt?: string | null;
  categories: ProviderCategory[];
  items: CinemaItem[];
  page: number;
  pages: number;
  total: number;
  warning?: string;
  truncated?: boolean;
  discovery?: boolean;
};
type Filters = { type: CinemaMediaType; category: string; query: string; page: number };
const number = new Intl.NumberFormat("ar");

function LibraryIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><rect x="3" y="6" width="18" height="15" rx="3" /><path d="m8 2 4 4 4-4M10 11l5 3-5 3z" /></svg>;
}

function SearchIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4.5 4.5" /></svg>;
}

function parseCatalog(value: unknown, type: CinemaMediaType): ProviderCatalog {
  if (!value || typeof value !== "object") throw new Error("تعذّر قراءة بيانات مكتبة الاشتراك. أعد المحاولة.");
  const data = value as Partial<ProviderCatalog>;
  if (typeof data.configured !== "boolean" || !Array.isArray(data.categories) || !Array.isArray(data.items)
    || !Number.isInteger(data.page) || Number(data.page) < 1 || !Number.isInteger(data.pages) || Number(data.pages) < 0
    || !Number.isInteger(data.total) || Number(data.total) < 0) throw new Error("تعذّر قراءة بيانات مكتبة الاشتراك. أعد المحاولة.");
  const seenCategories = new Set<string>();
  const categories: ProviderCategory[] = [];
  for (const entry of data.categories) {
    if (!entry || typeof entry.id !== "string" || typeof entry.name !== "string" || !entry.id || !entry.name) throw new Error("تعذّر قراءة أقسام مكتبة الاشتراك. أعد المحاولة.");
    if (!seenCategories.has(entry.id)) { seenCategories.add(entry.id); categories.push(entry); }
  }
  const seenItems = new Set<string>();
  const items: CinemaItem[] = [];
  for (const entry of data.items) {
    if (!entry || entry.source !== "provider" || entry.mediaType !== type || typeof entry.id !== "string" || !entry.id
      || typeof entry.title !== "string" || !entry.title || typeof entry.poster !== "string" || typeof entry.year !== "string") throw new Error("تعذّر قراءة أعمال مكتبة الاشتراك. أعد المحاولة.");
    if (!seenItems.has(entry.id)) { seenItems.add(entry.id); items.push(entry); }
  }
  return { configured: data.configured, maintenance: data.maintenance === true, expiresAt: typeof data.expiresAt === "string" && Number.isFinite(Date.parse(data.expiresAt)) ? data.expiresAt : null, categories, items, page: Number(data.page), pages: Number(data.pages), total: Number(data.total), warning: typeof data.warning === "string" ? data.warning : undefined, truncated: data.truncated === true, discovery: data.discovery === true };
}

function ProviderMaintenance() {
  const id = useId();
  const headingId = `${id}-heading`;
  return <section className="cinema-library provider-library provider-library-maintenance" dir="rtl" aria-labelledby={headingId} data-provider-maintenance="true">
    <header className="provider-library-heading">
      <div><span className="cinema-library-eyebrow">مكتبة MK~2</span><h2 id={headingId}>مسلسلات MK~2</h2></div>
      <span className="provider-library-mark"><LibraryIcon /></span>
    </header>
    <div className="provider-maintenance-panel" role="status">
      <span className="provider-maintenance-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M14.5 6.5a5 5 0 0 0-6.7 6.7l-4.5 4.5a2.1 2.1 0 0 0 3 3l4.5-4.5a5 5 0 0 0 6.7-6.7L14 13l-3-3z"/><path d="m17 3 4 4M18 6l-2 2"/></svg></span>
      <h3>{PROVIDER_MAINTENANCE_TITLE}</h3>
      <p>{PROVIDER_MAINTENANCE_MESSAGE}</p>
    </div>
  </section>;
}

export default function ProviderLibrary(props: { onOpen: (item: CinemaItem) => void }) {
  return PROVIDER_MAINTENANCE ? <ProviderMaintenance /> : <ActiveProviderLibrary {...props} />;
}

/** Browse provider categories or search the TV library without sending its full catalog to the browser. */
function ActiveProviderLibrary({ onOpen }: { onOpen: (item: CinemaItem) => void }) {
  const [filters, setFilters] = useState<Filters>({ type: "tv", category: "", query: "", page: 1 });
  const [draftQuery, setDraftQuery] = useState("");
  const [catalog, setCatalog] = useState<ProviderCatalog | null>(null);
  const [categories, setCategories] = useState<ProviderCategory[]>([]);
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);
  const controller = useRef<AbortController | null>(null);
  const sequence = useRef(0);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);
  const hasLoaded = useRef(false);
  const expiryRefreshed = useRef<string | null>(null);
  const id = useId();
  const headingId = `${id}-heading`;
  const resultsId = `${id}-results`;
  const searchHintId = `${id}-search-hint`;

  const cancelPending = () => {
    controller.current?.abort();
    sequence.current += 1;
    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = null;
  };

  useEffect(() => {
    const request = new AbortController();
    controller.current = request;
    const current = ++sequence.current;
    if (!hasLoaded.current) setLoading(true);
    setError("");
    const parameters = new URLSearchParams({ type: filters.type });
    if (filters.category || (filters.type === "tv" && filters.query)) {
      if (filters.category) parameters.set("category", filters.category);
      parameters.set("page", String(filters.page));
      if (filters.query) parameters.set("q", filters.query);
    }
    void (async () => {
      try {
        const response = await fetch(`/api/provider/catalog?${parameters}`, { signal: request.signal, cache: "no-store" });
        let data: unknown;
        try { data = await response.json(); }
        catch { throw new Error("تعذّر الاتصال بمكتبة الاشتراك. أعد المحاولة بعد قليل."); }
        if (request.signal.aborted || current !== sequence.current) return;
        if (!response.ok) {
          const message = data && typeof data === "object" && "error" in data && typeof data.error === "string" ? data.error : "تعذّر تحميل مكتبة الاشتراك. أعد المحاولة بعد قليل.";
          throw new Error(message);
        }
        const next = parseCatalog(data, filters.type);
        hasLoaded.current = true;
        setCatalog(next);
        setCategories(next.categories);
        setConfigured(next.configured);
      } catch (failure) {
        if (!request.signal.aborted && current === sequence.current) setError(failure instanceof Error ? failure.message : "تعذّر تحميل مكتبة الاشتراك. أعد المحاولة.");
      } finally {
        if (!request.signal.aborted && current === sequence.current) setLoading(false);
      }
    })();
    return () => { request.abort(); sequence.current += 1; };
  }, [filters, refresh]);

  useEffect(() => () => { if (debounce.current) clearTimeout(debounce.current); }, []);

  useEffect(() => {
    const reload = () => {
      cancelPending();
      setError("");
      setRefresh((value) => value + 1);
    };
    const onReturn = () => { if (!document.hidden) reload(); };
    const interval = window.setInterval(() => { if (!document.hidden) reload(); }, 60_000);
    window.addEventListener("mk2-catalog-refresh", reload);
    document.addEventListener("visibilitychange", onReturn);
    return () => { window.clearInterval(interval); window.removeEventListener("mk2-catalog-refresh", reload); document.removeEventListener("visibilitychange", onReturn); };
  }, []);

  useEffect(() => {
    const expiresAt = catalog?.expiresAt;
    if (!catalog?.configured || !expiresAt || expiryRefreshed.current === expiresAt) return;
    let timer: ReturnType<typeof setTimeout>;
    const check = () => {
      const remaining = Date.parse(expiresAt) - Date.now();
      if (remaining > 0) { timer = setTimeout(check, Math.min(remaining + 20, 60_000)); return; }
      expiryRefreshed.current = expiresAt;
      cancelPending();
      setCatalog((previous) => previous ? { ...previous, configured: false, maintenance: true, categories: [], items: [] } : previous);
      setConfigured(false); setCategories([]); setError(""); setLoading(false);
      window.dispatchEvent(new Event("mk2-catalog-refresh"));
    };
    check();
    return () => clearTimeout(timer);
  }, [catalog?.configured, catalog?.expiresAt]);

  const changeType = (type: CinemaMediaType) => {
    if (type === filters.type) return;
    cancelPending();
    setDraftQuery("");
    setCategories([]);
    setCatalog(null);
    setConfigured(null);
    setLoading(true);
    setError("");
    setFilters({ type, category: "", query: "", page: 1 });
  };

  const changeCategory = (category: string) => {
    cancelPending();
    setDraftQuery("");
    setCatalog(null);
    setError("");
    setLoading(true);
    setFilters((previous) => ({ ...previous, category, query: "", page: 1 }));
  };

  const search = (text: string, immediate = false) => {
    cancelPending();
    setDraftQuery(text);
    setError("");
    setLoading(true);
    const apply = () => {
      debounce.current = null;
      setFilters((previous) => ({ ...previous, query: text.trim(), page: 1 }));
    };
    if (immediate) apply();
    else debounce.current = setTimeout(apply, 350);
  };

  const submitSearch = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); if (filters.type === "tv" || filters.category) search(draftQuery, true); };
  const changePage = (page: number) => {
    if (!catalog || loading || page < 1 || page > catalog.pages) return;
    cancelPending();
    setLoading(true);
    setFilters((previous) => ({ ...previous, page }));
    document.getElementById(headingId)?.scrollIntoView({ block: "start", behavior: "instant" });
  };
  const selectedCategory = categories.find((entry) => entry.id === filters.category);
  const kind = filters.type === "tv" ? "المسلسلات" : "الأفلام";
  const globalSearch = filters.type === "tv" && !filters.category && Boolean(filters.query);
  const discoverSeries = filters.type === "tv" && !filters.category && !filters.query;
  const searchEnabled = filters.type === "tv" || Boolean(filters.category);

  if (catalog?.maintenance || configured === false) return <ProviderMaintenance />;

  return <section className="cinema-library provider-library" dir="rtl" aria-labelledby={headingId}>
    <header className="provider-library-heading">
      <div><span className="cinema-library-eyebrow">مكتبة MK~2</span><h2 id={headingId}>مسلسلات MK~2</h2><p>اكتشف مسلسلات من مكتبتك، أو ابحث بالعربية والإنجليزية واختر العمل لعرض مواسمه وحلقاته.</p></div>
      <span className="provider-library-mark"><LibraryIcon /></span>
    </header>

    <div className="provider-library-controls">
      <div className="cinema-type-tabs" role="group" aria-label="نوع مكتبة الاشتراك">
        <button type="button" aria-pressed={filters.type === "tv"} aria-controls={resultsId} onClick={() => changeType("tv")}>مسلسلات</button>
        <button type="button" aria-pressed={filters.type === "movie"} aria-controls={resultsId} onClick={() => changeType("movie")}>أفلام</button>
      </div>
      <label className="provider-library-category"><span>تصنيف {kind}</span><select value={filters.category} disabled={!categories.length} onChange={(event) => changeCategory(event.target.value)} aria-controls={resultsId}>
        <option value="">{loading && !categories.length ? "جارٍ تحميل التصنيفات…" : filters.type === "tv" ? "كل المسلسلات" : "اختر تصنيفًا لعرض أفلامه"}</option>
        {categories.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}
      </select></label>
      <form className="cinema-search provider-library-search" role="search" aria-label={filters.category ? "البحث داخل التصنيف" : "البحث في جميع مسلسلات MK~2"} onSubmit={submitSearch}>
        <label className="cinema-search-field"><span className="cinema-sr-only">{filters.category ? "اسم العمل داخل التصنيف المحدد" : "اسم المسلسل في مسلسلات MK~2"}</span><SearchIcon /><input type="search" value={draftQuery} onChange={(event) => search(event.target.value)} maxLength={120} disabled={!searchEnabled} placeholder={filters.category ? "ابحث داخل هذا التصنيف…" : filters.type === "tv" ? "ابحث في كل مسلسلات MK~2…" : "اختر تصنيفًا أولًا"} aria-describedby={searchHintId} aria-controls={resultsId} autoComplete="off" spellCheck={false} />
          {draftQuery && <button className="cinema-search-clear" type="button" onClick={() => search("", true)} aria-label="مسح البحث">×</button>}
        </label>
        <button className="cinema-search-submit" type="submit" disabled={!searchEnabled} aria-label={filters.category ? "البحث داخل التصنيف" : "البحث في جميع المسلسلات"}><SearchIcon /><span>بحث</span></button>
      </form>
    </div>
    <p id={searchHintId} className="provider-library-search-hint">{filters.category ? <>البحث داخل التصنيف المختار فقط.{filters.type === "tv" ? " اختر «كل المسلسلات» للبحث في جميع مسلسلات MK~2." : " غيّر التصنيف للبحث في تصنيف آخر."}</> : filters.type === "tv" ? "البحث في جميع مسلسلات MK~2 بالعربية أو الإنجليزية." : "اختر تصنيفًا للبحث في أفلامه بالعربية أو الإنجليزية."}</p>

    <div className="provider-library-status" role="status" aria-live="polite" aria-atomic="true">
      {loading ? <p><span className="cinema-loading-spinner" aria-hidden="true" /> {globalSearch ? "جارٍ البحث في جميع المسلسلات…" : discoverSeries ? "جارٍ تحميل مسلسلات من مكتبتك…" : filters.category ? "جارٍ تحميل الأعمال…" : "جارٍ تحميل التصنيفات…"}</p>
        : error ? <p>تعذّر تحميل المكتبة.</p>
          : catalog?.discovery ? <p><strong>أعمال من مكتبتك</strong><span aria-hidden="true"> · </span>{number.format(catalog.total)} مسلسل<span aria-hidden="true"> · </span>ابحث أو اختر تصنيفًا للمزيد</p>
            : (selectedCategory || globalSearch) && catalog ? <p><strong>{selectedCategory?.name || "جميع مسلسلات MK~2"}</strong><span aria-hidden="true"> · </span>{catalog.truncated ? "ضمن النتائج المتاحة: " : ""}{number.format(catalog.total)} {filters.type === "tv" ? "مسلسل" : "فيلم"}{filters.query && <> لبحث «{filters.query}»</>}</p>
            : configured ? <p>{number.format(categories.length)} تصنيف متاح في {kind}</p> : <p>مكتبة MK~2</p>}
    </div>

    <div id={resultsId} className="provider-library-results" aria-busy={loading}>
      {loading ? <div className="cinema-grid cinema-skeleton-grid" aria-hidden="true">{Array.from({ length: filters.category || globalSearch || discoverSeries ? 8 : 4 }, (_, index) => <div className="cinema-skeleton" key={index}><span /><span /><span /></div>)}</div>
        : error ? <div className="cinema-empty cinema-error" role="alert"><LibraryIcon /><h3>تعذّر الوصول إلى المكتبة</h3><p>{error}</p><button className="cinema-library-button" type="button" onClick={() => { setLoading(true); setRefresh((value) => value + 1); }}>إعادة المحاولة</button></div>
            : !categories.length && !globalSearch ? <div className="cinema-empty"><LibraryIcon /><h3>لا توجد أقسام متاحة حاليًا</h3><p>لم يُرجع اشتراك الموقع أقسامًا لـ{kind}. جرّب النوع الآخر أو أعد المحاولة لاحقًا.</p><button className="cinema-library-button is-secondary" type="button" onClick={() => { setLoading(true); setRefresh((value) => value + 1); }}>تحديث الأقسام</button></div>
              : !filters.category && !globalSearch && !discoverSeries ? <div className="cinema-empty provider-library-select-empty"><LibraryIcon /><h3>ابدأ باختيار تصنيف</h3><p>اختر أحد تصنيفات الأفلام من القائمة لعرض أعماله.</p></div>
                : <>
                  {(catalog?.warning || catalog?.truncated) && <div className="cinema-notice" role="note"><p>{catalog.warning || "هذا القسم كبير؛ تظهر النتائج المتاحة حاليًا من المزوّد."}</p></div>}
                  {catalog?.items.length ? <div className="cinema-grid">{catalog.items.map((item) => <CinemaCard key={`${item.mediaType}:${item.id}`} item={item} onOpen={onOpen} />)}</div>
                    : <div className="cinema-empty"><SearchIcon /><h3>{globalSearch ? "لم نعثر على مسلسلات بهذا الاسم" : filters.query ? "لم نعثر على نتائج في هذا القسم" : discoverSeries ? "لا توجد مسلسلات للعرض الآن" : "لا توجد أعمال في هذا القسم حاليًا"}</h3><p>{globalSearch ? "جرّب الاسم بالعربية أو الإنجليزية، أو تصفّح أحد التصنيفات." : filters.query ? "جرّب اسمًا آخر، أو اختر قسمًا مختلفًا من القائمة." : discoverSeries ? "جرّب البحث باسم مسلسل أو اختر أحد التصنيفات لعرض أعماله." : "جرّب قسمًا آخر أو أعد تحميل النتائج لاحقًا."}</p>{filters.query && <button className="cinema-library-button is-secondary" type="button" onClick={() => search("", true)}>{globalSearch ? "مسح البحث" : "عرض كل أعمال القسم"}</button>}</div>}
                  {catalog && catalog.pages > 1 && <nav className="provider-library-pagination" aria-label="صفحات مكتبة الاشتراك">
                    <button type="button" className="cinema-library-button is-secondary" disabled={catalog.page <= 1} onClick={() => changePage(catalog.page - 1)}>السابقة</button>
                    <span aria-current="page">صفحة {number.format(catalog.page)} من {number.format(catalog.pages)}</span>
                    <button type="button" className="cinema-library-button is-secondary" disabled={catalog.page >= catalog.pages} onClick={() => changePage(catalog.page + 1)}>التالية</button>
                  </nav>}
                </>}
    </div>
  </section>;
}
