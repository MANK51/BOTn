"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { Clapperboard, Download, Share2, X } from "lucide-react";
import "./pwa-install.css";

type InstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

export default function PwaInstall() {
  const pathname = usePathname();
  const privatePage = /^\/(?:admin|api|auth|offline)(?:\/|$)/.test(pathname ?? "");
  const [prompt, setPrompt] = useState<InstallPrompt | null>(null);
  const [ios, setIos] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [instructions, setInstructions] = useState(false);
  const [busy, setBusy] = useState(false);
  const [installError, setInstallError] = useState(false);
  const [update, setUpdate] = useState<ServiceWorker | null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const heading = useRef<HTMLHeadingElement>(null);
  const installButton = useRef<HTMLButtonElement>(null);
  const updateRequested = useRef(false);

  useEffect(() => {
    if (privatePage) return;
    const standalone = window.matchMedia("(display-mode: standalone)");
    const checkInstalled = () => setInstalled(standalone.matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone));
    const onPrompt = (event: Event) => { event.preventDefault(); setPrompt(event as InstallPrompt); };
    const onInstalled = () => { setInstalled(true); setPrompt(null); };
    checkInstalled();
    setIos(/iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));
    standalone.addEventListener("change", checkInstalled);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    let disposed = false;
    let registration: ServiceWorkerRegistration | undefined;
    let installingWorker: ServiceWorker | null = null;
    let refreshing = false;
    const onControllerChange = () => {
      if (refreshing) return;
      // Only an explicit click on the update action requests a reload.
      if (!updateRequested.current) return;
      refreshing = true;
      window.location.reload();
    };
    const onStateChange = () => {
      if (!disposed && installingWorker?.state === "installed" && navigator.serviceWorker.controller) setUpdate(registration?.waiting ?? installingWorker);
    };
    const onUpdateFound = () => {
      installingWorker?.removeEventListener("statechange", onStateChange);
      installingWorker = registration?.installing ?? null;
      installingWorker?.addEventListener("statechange", onStateChange);
    };
    if ("serviceWorker" in navigator && window.isSecureContext) {
      navigator.serviceWorker.addEventListener("controllerchange", onControllerChange);
      void navigator.serviceWorker.register("/sw.js", { scope: "/", updateViaCache: "none" }).then((value) => {
        if (disposed) return;
        registration = value;
        if (value.waiting && navigator.serviceWorker.controller) setUpdate(value.waiting);
        value.addEventListener("updatefound", onUpdateFound);
      }).catch(() => { /* Online browsing remains fully available without offline support. */ });
    }
    return () => {
      disposed = true;
      standalone.removeEventListener("change", checkInstalled);
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
      installingWorker?.removeEventListener("statechange", onStateChange);
      registration?.removeEventListener("updatefound", onUpdateFound);
      if ("serviceWorker" in navigator) navigator.serviceWorker.removeEventListener("controllerchange", onControllerChange);
    };
  }, [privatePage]);

  useEffect(() => {
    const element = dialog.current;
    if (!instructions || installed || privatePage) {
      if (element?.open) element.close();
      return;
    }
    if (!element?.open) element?.showModal();
    heading.current?.focus({ preventScroll: true });
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previousOverflow; };
  }, [instructions, installed, privatePage]);

  async function install() {
    if (!prompt || busy) return;
    setBusy(true);
    setInstallError(false);
    try {
      await prompt.prompt();
      const choice = await prompt.userChoice;
      if (choice.outcome === "accepted") { setInstalled(true); setInstructions(false); }
    } catch { setInstallError(true); }
    finally { setBusy(false); setPrompt(null); }
  }

  function applyUpdate() {
    if (!update) return;
    updateRequested.current = true;
    update.postMessage({ type: "ACTIVATE_UPDATE" });
    setUpdate(null);
  }

  if (privatePage) return null;
  return <>
    {!installed && <button className="pwa-install-button" type="button" onClick={() => { setInstallError(false); setInstructions(true); }} aria-haspopup="dialog" ref={installButton}><span className="pwa-install-button-logo"><Clapperboard size={19} aria-hidden="true" /></span><span>تثبيت التطبيق</span><Download size={15} aria-hidden="true" /></button>}
    {update && <aside className="pwa-update" aria-label="تحديث الموقع"><span>إصدار جديد جاهز</span><button type="button" onClick={applyUpdate}>تحديث الموقع</button><button type="button" aria-label="إخفاء تنبيه التحديث" onClick={() => setUpdate(null)}>×</button></aside>}
    <dialog className="pwa-install-dialog" ref={dialog} dir="rtl" aria-labelledby="pwa-install-title" aria-describedby="pwa-install-description" onCancel={() => setInstructions(false)} onClose={() => { setInstructions(false); installButton.current?.focus({ preventScroll: true }); }} onClick={(event) => { if (event.target === event.currentTarget) { const bounds = event.currentTarget.getBoundingClientRect(); if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) setInstructions(false); } }}>
      <div className="pwa-install-content">
      <button className="pwa-install-close" type="button" aria-label="إغلاق نافذة تثبيت التطبيق" onClick={() => setInstructions(false)}><X size={22} aria-hidden="true" /></button>
      <span className="pwa-install-brand"><Clapperboard size={30} aria-hidden="true" /></span>
      <span className="pwa-install-eyebrow">حكاياتك أقرب إليك</span>
      <h2 id="pwa-install-title" tabIndex={-1} ref={heading}>{ios ? "MK2Movie على الآيفون" : "MK2Movie على جهازك"}</h2>
      <p id="pwa-install-description">أضف الموقع إلى الشاشة الرئيسية للوصول إليه كتطبيق.</p>
      {prompt ? <div className="pwa-install-native"><p>ثبّت التطبيق وافتح مكتبتك مباشرة من جهازك.</p><button type="button" className="pwa-install-done" onClick={() => void install()} disabled={busy}><Download size={18} aria-hidden="true" />{busy ? "فتح التثبيت…" : "تثبيت MK2Movie"}</button></div> : ios ? <ol><li>افتح هذه الصفحة في <b>Safari</b>.</li><li>اضغط زر <b>المشاركة <Share2 size={15} aria-hidden="true" /></b> في المتصفح.</li><li>اختر <b>إضافة إلى الشاشة الرئيسية</b> ثم <b>إضافة</b>.</li></ol> : <div className="pwa-install-manual"><p>من قائمة المتصفح اختر <b>تثبيت التطبيق</b> أو <b>إضافة إلى الشاشة الرئيسية</b> إذا كان الخيار متاحًا.</p><p>إذا لم يظهر خيار التثبيت، يمكنك إضافة الموقع إلى المفضلة والوصول إليه من المتصفح.</p></div>}
      {installError && <p className="pwa-install-error" role="status">تعذّر فتح نافذة التثبيت. جرّب التثبيت من قائمة المتصفح.</p>}
      <p className="pwa-install-hint">المكتبة والمشاهدة تحتاجان اتصالًا بالإنترنت.</p>
      {!prompt && <button type="button" className="pwa-install-done" onClick={() => setInstructions(false)}>حسنًا</button>}
      </div>
    </dialog>
  </>;
}
