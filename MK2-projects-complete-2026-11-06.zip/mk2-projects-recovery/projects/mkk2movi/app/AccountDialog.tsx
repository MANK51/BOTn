"use client";

import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { Clapperboard, Eye, EyeOff, LoaderCircle, LockKeyhole, UserRound, X } from "lucide-react";
import "./account-dialog.css";

export type PublicSiteAccount = { id: string; username: string; name: string };
type Props = { onClose: () => void; onAuthenticated: (account: PublicSiteAccount) => void; siteName: string };
type Mode = "signin" | "signup";
const focusable = "button:not([disabled]), input:not([disabled]), a[href], [tabindex]:not([tabindex='-1'])";

export default function AccountDialog({ onClose, onAuthenticated, siteName }: Props) {
  const [mode, setMode] = useState<Mode>("signin");
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [viewport, setViewport] = useState<{ top: number; height: number } | null>(null);
  const dialog = useRef<HTMLElement>(null);
  const usernameField = useRef<HTMLInputElement>(null);
  const nameField = useRef<HTMLInputElement>(null);
  const request = useRef<AbortController | null>(null);
  const mounted = useRef(true);
  const closeCallback = useRef(onClose);
  const authenticatedCallback = useRef(onAuthenticated);
  closeCallback.current = onClose;
  authenticatedCallback.current = onAuthenticated;
  const id = useId();

  function close() { request.current?.abort(); setPassword(""); closeCallback.current(); }

  useEffect(() => {
    mounted.current = true;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const frame = requestAnimationFrame(() => usernameField.current?.focus({ preventScroll: true }));
    const updateViewport = () => {
      const current = window.visualViewport;
      if (current) setViewport({ top: current.offsetTop, height: current.height });
    };
    updateViewport();
    window.visualViewport?.addEventListener("resize", updateViewport);
    window.visualViewport?.addEventListener("scroll", updateViewport);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); request.current?.abort(); closeCallback.current(); return; }
      if (event.key !== "Tab" || !dialog.current) return;
      const controls = Array.from(dialog.current.querySelectorAll<HTMLElement>(focusable)).filter((element) => element.getClientRects().length > 0);
      if (!controls.length) { event.preventDefault(); dialog.current.focus(); return; }
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && (document.activeElement === first || !dialog.current.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !dialog.current.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      mounted.current = false;
      request.current?.abort();
      cancelAnimationFrame(frame);
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKey);
      window.visualViewport?.removeEventListener("resize", updateViewport);
      window.visualViewport?.removeEventListener("scroll", updateViewport);
      if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    };
  }, []);

  function changeMode(next: Mode) {
    if (pending || next === mode) return;
    setMode(next); setError(""); setPassword(""); setShowPassword(false);
    requestAnimationFrame(() => (next === "signup" ? nameField.current : usernameField.current)?.focus({ preventScroll: true }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    setError("");
    const normalizedUsername = username.normalize("NFKC").trim().toLowerCase();
    if (!/^[\p{L}\p{N}._-]{3,32}$/u.test(normalizedUsername)) { setError("اسم المستخدم من 3 إلى 32 حرفًا؛ استخدم حروفًا أو أرقامًا أو . _ - بدون مسافات."); usernameField.current?.focus(); return; }
    if (mode === "signup" && (name.trim().length < 2 || name.trim().length > 60)) { setError("اكتب اسمًا من حرفين إلى 60 حرفًا."); nameField.current?.focus(); return; }
    if (password.length < 8 || password.length > 128) { setError("كلمة المرور من 8 إلى 128 حرفًا."); return; }
    const controller = new AbortController();
    request.current = controller;
    const deadline = setTimeout(() => controller.abort(), 20_000);
    setPending(true);
    try {
      const response = await fetch(`/api/account/${mode}`, {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: normalizedUsername, password, ...(mode === "signup" ? { name: name.trim() } : {}) }), signal: controller.signal,
      });
      const body = await response.json().catch(() => null) as { account?: PublicSiteAccount; error?: string } | null;
      if (!response.ok || !body?.account || typeof body.account.id !== "string" || typeof body.account.username !== "string" || typeof body.account.name !== "string") throw new Error(body?.error || "تعذّر تسجيل الدخول الآن. حاول مرة أخرى.");
      if (!mounted.current) return;
      setPassword("");
      authenticatedCallback.current(body.account);
    } catch (failure) {
      if (!mounted.current) return;
      setError(failure instanceof TypeError ? "تعذّر الاتصال بالموقع. تحقق من الإنترنت وحاول مرة أخرى." : failure instanceof Error && failure.name !== "AbortError" ? failure.message : "استغرق الاتصال وقتًا طويلًا. تحقق من الإنترنت وحاول مرة أخرى.");
    } finally { clearTimeout(deadline); if (mounted.current) setPending(false); }
  }

  return <div className="mk2-account-dialog-scrim" style={viewport ? { top: viewport.top, height: viewport.height } : undefined} onMouseDown={(event) => { if (event.target === event.currentTarget) close(); }}>
    <section className="mk2-account-dialog" ref={dialog} role="dialog" aria-modal="true" aria-labelledby={`${id}-title`} aria-describedby={`${id}-description`} dir="rtl" tabIndex={-1}>
      <button type="button" className="mk2-account-dialog-close" aria-label="إغلاق تسجيل الدخول" onClick={close}><X size={23} /></button>
      <span className="mk2-account-dialog-logo" aria-hidden="true"><Clapperboard size={31} strokeWidth={1.8} /></span>
      <p className="mk2-account-dialog-eyebrow">أهلًا بك في <bdi>{siteName}</bdi></p>
      <h2 id={`${id}-title`}>حكاياتك، على راحتك.</h2>
      <p id={`${id}-description`} className="mk2-account-dialog-description">{mode === "signup" ? "أنشئ حسابك باسم واسم مستخدم وكلمة مرور، واحتفظ بقوائمك معك." : "ادخل إلى حسابك باسم المستخدم وكلمة المرور."}</p>
      <div className="mk2-account-dialog-tabs" aria-label="خيارات الحساب"><button type="button" aria-pressed={mode === "signin"} disabled={pending} onClick={() => changeMode("signin")}>تسجيل الدخول</button><button type="button" aria-pressed={mode === "signup"} disabled={pending} onClick={() => changeMode("signup")}>إنشاء حساب</button></div>
      <form className="mk2-account-dialog-form" onSubmit={submit} aria-busy={pending}>
        {mode === "signup" && <label htmlFor={`${id}-name`}>الاسم<div className="mk2-account-dialog-input"><UserRound size={18} aria-hidden="true" /><input ref={nameField} id={`${id}-name`} name="name" autoComplete="name" value={name} onChange={(event) => setName(event.target.value)} minLength={2} maxLength={60} required disabled={pending} placeholder="اسمك" /></div></label>}
        <label htmlFor={`${id}-username`}>اسم المستخدم<div className="mk2-account-dialog-input"><UserRound size={18} aria-hidden="true" /><input ref={usernameField} id={`${id}-username`} name="username" autoComplete="username" autoCapitalize="none" spellCheck={false} dir="auto" value={username} onChange={(event) => setUsername(event.target.value)} minLength={3} maxLength={32} required disabled={pending} aria-describedby={mode === "signup" ? `${id}-username-hint` : undefined} placeholder="اسم المستخدم" /></div>{mode === "signup" && <small id={`${id}-username-hint`}>حروف وأرقام، ويمكن استخدام . _ - بدون مسافات.</small>}</label>
        <label htmlFor={`${id}-password`}>كلمة المرور<div className="mk2-account-dialog-input"><LockKeyhole size={18} aria-hidden="true" /><input id={`${id}-password`} name="password" type={showPassword ? "text" : "password"} autoComplete={mode === "signup" ? "new-password" : "current-password"} value={password} onChange={(event) => setPassword(event.target.value)} minLength={8} maxLength={128} required disabled={pending} placeholder={mode === "signup" ? "8 أحرف على الأقل" : "كلمة المرور"} dir="auto" /><button type="button" className="mk2-account-dialog-password" aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"} aria-pressed={showPassword} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div></label>
        {error && <p className="mk2-account-dialog-error" role="alert">{error}</p>}
        <button type="submit" className="mk2-account-dialog-submit" disabled={pending}>{pending ? <><LoaderCircle size={18} aria-hidden="true" />{mode === "signup" ? "جارٍ إنشاء حسابك…" : "جارٍ تسجيل الدخول…"}</> : mode === "signup" ? "إنشاء حسابي" : "تسجيل الدخول"}</button>
      </form>
      <button type="button" className="mk2-account-dialog-guest" onClick={close}>المتابعة كضيف</button>
      <p className="mk2-account-dialog-note">يمكنك تصفح الموقع وحفظ قوائمك على هذا الجهاز دون حساب.</p>
    </section>
  </div>;
}
