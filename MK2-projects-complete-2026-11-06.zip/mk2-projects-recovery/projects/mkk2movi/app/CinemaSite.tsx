"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowUpLeft, Bell, Bookmark, Check, ChevronLeft, ChevronRight, Clapperboard, Film, Home, Library, Menu, Moon, Pause, Play, Search, Settings, Sparkles, Star, Sun, Tv, X } from "lucide-react";
import CinemaLibrary, { CinemaCard } from "./CinemaLibrary";
import ProviderLibrary from "./ProviderLibrary";
import { PROVIDER_MAINTENANCE, PROVIDER_MAINTENANCE_TITLE, PROVIDER_MAINTENANCE_MESSAGE } from "../lib/provider-status";
import AdminPanel from "./AdminPanel";
import SeriesDetails from "./SeriesDetails";
import MovieDetails from "./MovieDetails";
import { PersonalLibrary } from "./PersonalLibrary";
import { UserActions, useViewerLibrary } from "./UserActions";
import { ViewerSync } from "./ViewerSync";
import PwaInstall from "./PwaInstall";
import AccountDialog from "./AccountDialog";
import InstallPresence from "./InstallPresence";
import type { PublicSiteAccount } from "../lib/site-accounts";
import { PublicSocialLinks } from "./SocialAccounts";
import { createDefaultSocialLinks, normalizeSocialLinks } from "../lib/social-links";
import { continueViewerEntries, viewerInterestGenreIds } from "../lib/viewer-library";
import { buildMediaShareUrl, parseMediaShareParams } from "../lib/media-links";
import { normalizePublishedCinema, sameCinemaTitle, uniqueCinemaItems, type PublishedCinemaItem } from "../lib/cinema-published";
import type { CinemaCatalogResponse, CinemaItem, CinemaTitleResponse } from "../lib/cinema-types";
import type { SiteSettings } from "../lib/site-settings";
import { MK2_PERSONAL_SITE, SITE_RELEASE } from "../lib/site-release";
import "./cinema-site.css";

type Props = { initialAccount?: PublicSiteAccount | null; adminInitiallyOpen?: boolean };
type MainView = "home" | "movies" | "series" | "discover" | "library" | "provider";
type Position = { season?: number; episode?: number };
type Selection = { item: CinemaItem; position?: Position };
type SectionId = "recent" | "rated" | "popular" | "recommended";
type Presentation = { featured: { id: string; mediaType: "tv" | "movie" }[]; sections: { id: SectionId; enabled: boolean }[] };
const defaultPresentation: Presentation = { featured: [], sections: ["recent", "rated", "popular", "recommended"].map((id) => ({ id: id as SectionId, enabled: true })) };
const defaults: SiteSettings = { siteName: "MK2Movie", logoUrl: "", heroTitle: "حكايات تستحق المشاهدة.", heroText: "تصفّح المسلسلات، اختر الموسم والحلقة، وابدأ المشاهدة مباشرة.", heroImage: "", accentColor: "#e6b85c", defaultTheme: "dark", socialLinks: createDefaultSocialLinks() };
const views = new Set<MainView>(["home", "movies", "series", "discover", "library", "provider"]);
const navigation: { id: MainView; label: string; icon: typeof Home }[] = [{ id: "home", label: "الرئيسية", icon: Home }, { id: "series", label: "المسلسلات", icon: Tv }, { id: "provider", label: "مسلسلات MK~2", icon: Clapperboard }, { id: "movies", label: "الأفلام", icon: Film }, { id: "library", label: "مكتبتي", icon: Library }];
const labels: Record<SectionId, { title: string; kicker: string; description: string }> = {
  recent: { title: "أحدث الإضافات", kicker: "الجديد في MK2", description: "أعمال مكتبة الموقع، مرتبة بحسب تاريخ إضافتها." },
  rated: { title: "حكايات حازت إعجاب الجمهور", kicker: "الأعلى تقييمًا", description: "تقييمات حقيقية من مجتمع TMDb، تساعدك على اختيار حكايتك القادمة." },
  popular: { title: "الأكثر مشاهدة على MK2", kicker: "اختيارات المشاهدين", description: "من مرات التشغيل الفعلية التي رصدتها المشغلات الداعمة داخل الموقع." },
  recommended: { title: "قد تكون حكايتك القادمة", kicker: "مقترحات لك", description: "أعمال من الأنواع التي تتابعها أو تضيفها إلى قوائمك." },
};
const safeImage = (value: string) => { try { const u = new URL(value); return u.protocol === "https:" && !u.username && !u.password ? u.href : ""; } catch { return ""; } };
const canonicalItem = (item: PublishedCinemaItem): PublishedCinemaItem => item.tmdbId && item.source === "embed" ? { ...item, id: item.tmdbId, source: "automatic" } : item;

function Shelf({ id, items, loading, children, onOpen, onBrowse }: { id: string; items: CinemaItem[]; loading?: boolean; children?: React.ReactNode; onOpen: (item: CinemaItem) => void; onBrowse: () => void }) {
  const row = useRef<HTMLDivElement>(null);
  const [scrollable, setScrollable] = useState(false);
  useEffect(() => { const el = row.current; if (!el) return; const measure = () => setScrollable(el.scrollWidth > el.clientWidth + 5); measure(); const observer = new ResizeObserver(measure); observer.observe(el); return () => observer.disconnect(); }, [items.length]);
  return <div className="mk2-shelf-body">{loading ? <div className="mk2-shelf-skeleton" aria-label="جارٍ تحميل الأعمال">{Array.from({ length: 6 }, (_, i) => <span key={i} />)}</div> : items.length ? <div className="mk2-card-row" ref={row} id={`row-${id}`}>{items.map((item) => <CinemaCard key={`${item.source}:${item.mediaType}:${item.id}`} item={item} onOpen={onOpen} compact />)}</div> : children}{items.length > 0 && <div className="mk2-shelf-foot"><button className="mk2-text-button" onClick={onBrowse}>اكتشف المزيد <ArrowUpLeft size={16} /></button>{scrollable && <div className="mk2-row-arrows"><button aria-label="الأعمال السابقة" aria-controls={`row-${id}`} onClick={() => row.current?.scrollBy({ left: (row.current?.clientWidth || 600) * .8, behavior: "smooth" })}><ChevronRight size={18} /></button><button aria-label="الأعمال التالية" aria-controls={`row-${id}`} onClick={() => row.current?.scrollBy({ left: -(row.current?.clientWidth || 600) * .8, behavior: "smooth" })}><ChevronLeft size={18} /></button></div>}</div>}</div>;
}

export default function CinemaSite({ initialAccount = null, adminInitiallyOpen = false }: Props) {
  const [account, setAccount] = useState<PublicSiteAccount | null>(initialAccount);
  const [signingOut, setSigningOut] = useState(false);
  const [accountError, setAccountError] = useState("");
  const accountRevision = useRef(0);
  const signedInName = account?.name || null;
  const [settings, setSettings] = useState<SiteSettings>(defaults);
  const [mode, setMode] = useState<"dark" | "light">("dark");
  const [view, setView] = useState<MainView>("home");
  const [libraryMounted, setLibraryMounted] = useState(false);
  const [discoveryType, setDiscoveryType] = useState<"all" | "tv" | "movie">("all");
  const [navigationKey, setNavigationKey] = useState(0);
  const [query, setQuery] = useState("");
  const [headerQuery, setHeaderQuery] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [welcome, setWelcome] = useState(false);
  const [adminOpen, setAdminOpen] = useState(adminInitiallyOpen);
  const [selection, setSelection] = useState<Selection | null>(null);
  const [published, setPublished] = useState<PublishedCinemaItem[]>([]);
  const [trending, setTrending] = useState<CinemaItem[]>([]);
  const [recentArabic, setRecentArabic] = useState<CinemaItem[]>([]);
  const [rated, setRated] = useState<CinemaItem[]>([]);
  const [mostWatched, setMostWatched] = useState<CinemaItem[]>([]);
  const [presentation, setPresentation] = useState<Presentation>(defaultPresentation);
  const [features, setFeatures] = useState<CinemaItem[]>([]);
  const [featureIndex, setFeatureIndex] = useState(0);
  const [rotationPaused, setRotationPaused] = useState(false);
  const [heroHovered, setHeroHovered] = useState(false);
  const [heroFocused, setHeroFocused] = useState(false);
  const [pageVisible, setPageVisible] = useState(true);
  const [homeLoading, setHomeLoading] = useState(true);
  const [homeError, setHomeError] = useState("");
  const [providerMaintenance, setProviderMaintenance] = useState(true);
  const [providerExpiresAt, setProviderExpiresAt] = useState<string | null>(null);
  const [refresh, setRefresh] = useState(0);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [notifications, setNotifications] = useState<CinemaItem[]>([]);
  const returnLocation = useRef("/#home");
  const selectionRef = useRef(selection); selectionRef.current = selection;
  const viewer = useViewerLibrary();
  const acceptSettings = useCallback((value: SiteSettings) => { const next = { ...defaults, ...value, socialLinks: normalizeSocialLinks(value.socialLinks) }; setSettings(next); if (/^#[0-9a-fA-F]{6}$/.test(next.accentColor)) { document.documentElement.style.setProperty("--gold", next.accentColor); document.documentElement.style.setProperty("--gold2", next.accentColor); } }, []);
  const openItem = useCallback((item: CinemaItem, position?: Position) => { if (!selectionRef.current) returnLocation.current = window.location.pathname === "/admin" ? "/#home" : window.location.pathname + window.location.search + window.location.hash; setSelection({ item, position }); setMobileMenu(false); window.history.pushState({}, "", buildMediaShareUrl(item, position)); }, []);
  const closeDetails = useCallback(() => { setSelection(null); window.history.replaceState({}, "", returnLocation.current); }, []);
  const navigate = useCallback((next: MainView) => { setView(next); setMobileMenu(false); setNotificationsOpen(false); setSelection(null); if (["movies", "series", "discover"].includes(next)) { setDiscoveryType(next === "movies" ? "movie" : next === "series" ? "tv" : "all"); setLibraryMounted(true); setNavigationKey((key) => key + 1); } window.history.pushState({}, "", `/#${next}`); window.scrollTo({ top: 0, behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); }, []);

  useEffect(() => {
    const readLocation = () => { const hash = window.location.hash.slice(1) as MainView; if (views.has(hash)) { setView(hash); if (["movies", "series", "discover"].includes(hash)) { setDiscoveryType(hash === "movies" ? "movie" : hash === "series" ? "tv" : "all"); setLibraryMounted(true); } } const parsed = parseMediaShareParams(new URLSearchParams(window.location.search)); if (parsed) { returnLocation.current = "/#home"; setSelection({ item: { id: parsed.id, source: parsed.source, mediaType: parsed.mediaType, title: "", description: "", poster: "", year: "", rating: "", genre: "" }, position: { season: parsed.season, episode: parsed.episode } }); } else setSelection(null); };
    readLocation(); window.addEventListener("popstate", readLocation); window.addEventListener("hashchange", readLocation);
    const controller = new AbortController();
    void fetch("/api/settings", { signal: controller.signal, cache: "no-store" }).then(async (response) => { if (response.ok) { const value = await response.json() as SiteSettings; acceptSettings(value); try { if (!localStorage.getItem("mk2-theme")) setMode(value.defaultTheme === "light" ? "light" : "dark"); } catch {} } }).catch(() => undefined);
    try { const stored = localStorage.getItem("mk2-theme"); if (stored === "dark" || stored === "light") setMode(stored); if (!sessionStorage.getItem("mk2-visit-sent")) { sessionStorage.setItem("mk2-visit-sent", "1"); void fetch("/api/visit", { method: "POST" }).catch(() => undefined); } } catch {}
    return () => { controller.abort(); window.removeEventListener("popstate", readLocation); window.removeEventListener("hashchange", readLocation); };
  }, [acceptSettings]);
  useEffect(() => { document.body.classList.toggle("light-mode", mode === "light"); }, [mode]);
  useEffect(() => { document.title = selection?.item.title ? `${selection.item.title} | ${settings.siteName}` : `${settings.siteName} | أفلام ومسلسلات`; }, [selection?.item.title, settings.siteName]);
  useEffect(() => {
    let lastRefresh = Date.now();
    const update = () => { lastRefresh = Date.now(); setRefresh((value) => value + 1); };
    const onReturn = () => { if (!document.hidden && Date.now() - lastRefresh > 60_000) update(); };
    const playback = (event: Event) => { const item = (event as CustomEvent<{ item: CinemaItem }>).detail?.item; if (item) void fetch("/api/content-insights", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: item.id, mediaType: item.mediaType, source: item.source }), keepalive: true }).catch(() => undefined); };
    window.addEventListener("mk2-catalog-refresh", update); document.addEventListener("visibilitychange", onReturn); window.addEventListener("mk2-playback-started", playback);
    return () => { window.removeEventListener("mk2-catalog-refresh", update); document.removeEventListener("visibilitychange", onReturn); window.removeEventListener("mk2-playback-started", playback); };
  }, []);
  useEffect(() => {
    if (providerMaintenance || !providerExpiresAt) return;
    let timer: ReturnType<typeof setTimeout>;
    const check = () => {
      const remaining = Date.parse(providerExpiresAt) - Date.now();
      if (remaining > 0) { timer = setTimeout(check, Math.min(remaining + 20, 60_000)); return; }
      setProviderMaintenance(true);
      setPublished((items) => items.filter((item) => item.source !== "provider"));
      setRefresh((value) => value + 1);
    };
    check();
    return () => clearTimeout(timer);
  }, [providerExpiresAt, providerMaintenance]);
  useEffect(() => {
    const controller = new AbortController(); let active = true; setHomeLoading(true); setHomeError("");
    const json = async <T,>(url: string): Promise<T> => { const response = await fetch(url, { signal: controller.signal }); if (!response.ok) throw new Error(String(response.status)); return response.json(); };
    void (async () => {
      const r = await Promise.allSettled([json<unknown>("/api/catalog").then((value) => { if (active) { setPublished(normalizePublishedCinema(value).map(canonicalItem)); const metadata = value && typeof value === "object" ? value as { configured?: boolean; maintenance?: boolean; expiresAt?: string | null } : {}; setProviderMaintenance(PROVIDER_MAINTENANCE || metadata.maintenance === true || metadata.configured !== true); setProviderExpiresAt(typeof metadata.expiresAt === "string" && Number.isFinite(Date.parse(metadata.expiresAt)) ? metadata.expiresAt : null); } return value; }), json<CinemaCatalogResponse>("/api/cinema/catalog?type=tv&scope=arabic&sort=popular"), json<CinemaCatalogResponse>("/api/cinema/catalog?type=all&scope=all&sort=rating"), json<Presentation>("/api/presentation"), json<{ items: Array<Pick<CinemaItem, "id" | "source" | "mediaType"> & { count: number }> }>("/api/content-insights"), json<CinemaCatalogResponse>("/api/cinema/catalog?type=tv&scope=arabic&sort=newest")]);
      if (!active) return;
      const current = r[0].status === "fulfilled" ? normalizePublishedCinema(r[0].value).map(canonicalItem) : [];
      const popular = r[1].status === "fulfilled" ? r[1].value.items : [];
      const highRated = r[2].status === "fulfilled" ? r[2].value.items : [];
      const config = r[3].status === "fulfilled" && Array.isArray(r[3].value.sections) ? r[3].value : defaultPresentation;
      setPublished(current); setTrending(popular); setRated(highRated); setPresentation(config);
      setRecentArabic(r[5].status === "fulfilled" ? r[5].value.items : []);
      if (r[0].status === "rejected" || (r[1].status === "rejected" && r[2].status === "rejected")) setHomeError("تعذّر تحميل جزء من المكتبة. الأعمال المتاحة ظاهرة، ويمكنك إعادة المحاولة.");
      try {
        const known = JSON.parse(localStorage.getItem("mk2-published-seen-v1") || "null") as string[] | null;
        const ids = current.map((item) => `${item.source}:${item.mediaType}:${item.id}:${item.addedAt || ""}:${item.episodeCount || ""}`);
        if (Array.isArray(known)) setNotifications(current.filter((item, index) => !known.includes(ids[index])).slice(0, 8));
        // A temporary partial catalog must not make old content look newly added.
        if (r[0].status === "fulfilled" && current.length) localStorage.setItem("mk2-published-seen-v1", JSON.stringify([...new Set([...ids, ...(Array.isArray(known) ? known : [])])].slice(0, 500)));
      } catch {}
      setHomeLoading(false);
      const chosenFeatures = config.featured.length ? config.featured : current.filter((item) => item.source === "automatic").slice(0, 5).map((item) => ({ id: item.id, mediaType: item.mediaType }));
      const featured = await Promise.allSettled(chosenFeatures.slice(0, 8).map((item) => json<CinemaTitleResponse>(`/api/cinema/title?type=${item.mediaType}&id=${encodeURIComponent(item.id)}`)));
      if (!active) return;
      setFeatures(featured.flatMap((result) => result.status === "fulfilled" ? [result.value.item] : []));
      const identities = r[4].status === "fulfilled" ? r[4].value.items.slice(0, 8) : [];
      const watched = await Promise.allSettled(identities.map(async (identity) => { const found = current.find((item) => sameCinemaTitle(item, { ...identity, title: "", poster: "", description: "", year: "", rating: "", genre: "" })); if (found) return found; if (identity.source === "automatic") return (await json<CinemaTitleResponse>(`/api/cinema/title?type=${identity.mediaType}&id=${encodeURIComponent(identity.id)}`)).item; return null; }));
      if (active) setMostWatched(uniqueCinemaItems(watched.flatMap((result) => result.status === "fulfilled" && result.value ? [result.value] : [])));
    })().catch(() => { if (active) { setHomeLoading(false); setHomeError("تعذّر تحميل المكتبة. حاول مرة أخرى."); } });
    return () => { active = false; controller.abort(); };
  }, [refresh]);

  useEffect(() => {
    const controller = new AbortController();
    const refreshAccount = () => {
      if (document.hidden) return;
      const revision = accountRevision.current;
      void fetch("/api/account/session", { cache: "no-store", signal: controller.signal })
        .then(async (response) => { if (response.ok) { const result = await response.json() as { account: PublicSiteAccount | null }; if (!controller.signal.aborted && accountRevision.current === revision) setAccount(result.account); } })
        .catch(() => undefined);
    };
    refreshAccount();
    document.addEventListener("visibilitychange", refreshAccount);
    return () => { controller.abort(); document.removeEventListener("visibilitychange", refreshAccount); };
  }, []);

  const signOut = async () => {
    if (signingOut) return;
    setSigningOut(true); setAccountError("");
    try {
      const response = await fetch("/api/account/signout", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}", cache: "no-store" });
      if (!response.ok) throw new Error("تعذر تسجيل الخروج. حاول مرة أخرى.");
      accountRevision.current += 1; setAccount(null);
    } catch (error) { setAccountError(error instanceof Error ? error.message : "تعذر تسجيل الخروج."); }
    finally { setSigningOut(false); }
  };

  const banners = useMemo(() => {
    const latest = [...published].filter((item) => item.mediaType === "tv" && (item.poster || item.backdrop))
      .sort((a, b) => (b.addedAt || "").localeCompare(a.addedAt || ""));
    const candidates = [...latest.slice(0, 4), ...recentArabic, ...trending, ...features];
    return uniqueCinemaItems(candidates.filter((item) => item.mediaType === "tv" && (item.poster || item.backdrop)))
      .slice(0, 8).map((item) => {
        const metadata = features.find((entry) => sameCinemaTitle(item, entry));
        return metadata ? { ...item, backdrop: item.backdrop || metadata.backdrop, poster: item.poster || metadata.poster, description: item.description || metadata.description } : item;
      });
  }, [features, published, recentArabic, trending]);
  const featured = banners[featureIndex % Math.max(banners.length, 1)];
  const seriesBackdrop = safeImage(featured?.backdrop || "");
  const seriesPoster = safeImage(featured?.poster || "");
  const backdrop = seriesBackdrop || seriesPoster || safeImage(settings.heroImage.includes("i.ytimg.com") ? "" : settings.heroImage);
  const artworkKind = seriesBackdrop ? "backdrop" : seriesPoster ? "poster" : backdrop ? "backdrop" : "none";
  const artworkUrl = backdrop.includes("image.tmdb.org/t/p/") ? backdrop.replace(/\/w\d+\//, artworkKind === "poster" ? "/w780/" : "/w1280/") : backdrop;
  const mobileArtworkUrl = seriesPoster.includes("image.tmdb.org/t/p/") ? seriesPoster.replace(/\/w\d+\//, "/w780/") : seriesPoster || artworkUrl;
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const motion = () => setRotationPaused(media.matches);
    const visibility = () => setPageVisible(!document.hidden);
    motion(); visibility();
    media.addEventListener("change", motion); document.addEventListener("visibilitychange", visibility);
    return () => { media.removeEventListener("change", motion); document.removeEventListener("visibilitychange", visibility); };
  }, []);
  useEffect(() => {
    if (banners.length < 2 || view !== "home" || rotationPaused || heroHovered || heroFocused || !pageVisible || selection || adminOpen || welcome) return;
    const timer = window.setTimeout(() => setFeatureIndex((index) => (index + 1) % banners.length), 6500);
    return () => window.clearTimeout(timer);
  }, [banners.length, featureIndex, view, rotationPaused, heroHovered, heroFocused, pageVisible, selection, adminOpen, welcome]);
  const recent = useMemo(() => [...published].sort((a, b) => (b.addedAt || "").localeCompare(a.addedAt || "")).slice(0, 12), [published]);
  const recommended = useMemo(() => { const interest = viewerInterestGenreIds(viewer); const unseen = uniqueCinemaItems([...trending, ...rated]).filter((item) => !viewer.history.some((entry) => sameCinemaTitle(entry.item, item))); return (interest.length ? unseen.map((item) => ({ item, weight: (item.genreIds || []).filter((id) => interest.includes(id)).length })).sort((a, b) => b.weight - a.weight).map((entry) => entry.item) : unseen).slice(0, 12); }, [viewer, trending, rated]);
  const resume = continueViewerEntries(viewer).slice(0, 6);
  const shelfItems: Record<SectionId, CinemaItem[]> = { recent, rated: rated.slice(0, 12), popular: mostWatched, recommended };
  const showDiscovery = ["series", "movies", "discover"].includes(view);
  const search = (event: React.FormEvent) => { event.preventDefault(); setQuery(headerQuery.trim()); navigate("discover"); };
  const toggleMode = () => { const next = mode === "dark" ? "light" : "dark"; setMode(next); try { localStorage.setItem("mk2-theme", next); } catch {} };

  return <>
    <div className="mk2-cinema" inert={Boolean(selection || adminOpen || welcome)}>
      <a className="mk2-skip" href="#main-content">انتقل إلى المحتوى</a>
      <header className="mk2-header"><a className="mk2-brand" href="/#home" onClick={(e) => { e.preventDefault(); navigate("home"); }} aria-label={`${settings.siteName} · الرئيسية`}><span className="mk2-brand-mark">{safeImage(settings.logoUrl) ? <img src={safeImage(settings.logoUrl)} alt="" /> : <Clapperboard size={25} />}</span><span dir="ltr">{settings.siteName}<small>حكايتك تبدأ هنا</small></span></a><nav className="mk2-desktop-nav" aria-label="التنقل الرئيسي">{navigation.map(({ id, label }) => <a key={id} className={view === id ? "active" : ""} href={`/#${id}`} aria-current={view === id ? "page" : undefined} onClick={(e) => { e.preventDefault(); navigate(id); }}>{label}{id === "library" && <Bookmark size={14} />}</a>)}</nav><div className="mk2-header-tools"><form className="mk2-header-search" onSubmit={search}><Search size={16} /><input aria-label="البحث في الأفلام والمسلسلات" placeholder="ابحث عن حكايتك…" value={headerQuery} onChange={(e) => setHeaderQuery(e.target.value)} maxLength={100} /><button aria-label="بحث" type="submit"><ArrowUpLeft size={15} /></button></form><button className="mk2-icon-button mk2-mobile-search" aria-label="البحث" onClick={() => navigate("discover")}><Search size={21} /></button><button className="mk2-icon-button" aria-label={mode === "dark" ? "الوضع الفاتح" : "الوضع الليلي"} onClick={toggleMode}>{mode === "dark" ? <Sun size={19} /> : <Moon size={19} />}</button><button className="mk2-icon-button mk2-notification-button" aria-label={`التحديثات${notifications.length ? `، ${notifications.length} أعمال جديدة` : ""}`} aria-expanded={notificationsOpen} onClick={() => setNotificationsOpen(!notificationsOpen)}><Bell size={19} />{notifications.length > 0 && <i />}</button><button className="mk2-account" onClick={() => signedInName ? navigate("library") : setWelcome(true)}>{signedInName ? signedInName.slice(0, 18) : "دخول"}<span>{signedInName ? signedInName[0] : "M"}</span></button><button className="mk2-icon-button mk2-menu-button" aria-label="القائمة" aria-expanded={mobileMenu} onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X size={21} /> : <Menu size={21} />}</button></div></header>
      {mobileMenu && <nav className="mk2-mobile-menu" aria-label="القائمة الإضافية">{navigation.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => navigate(id)}><Icon size={18} />{label}</button>)}<a href="/admin"><Settings size={18} />لوحة الإدارة</a></nav>}
      {notificationsOpen && <section className="mk2-notifications" aria-label="تحديثات المحتوى"><div><strong>الجديد في مكتبتك</strong><button className="mk2-icon-button" aria-label="إغلاق التحديثات" onClick={() => setNotificationsOpen(false)}><X size={17} /></button></div>{notifications.length ? notifications.map((item) => <button key={`${item.source}:${item.id}`} onClick={() => { setNotificationsOpen(false); openItem(item); }}><Check size={16} /><span>{item.title}<small>إضافة أو تحديث في مكتبة الموقع منذ زيارتك السابقة</small></span></button>) : <p>لا توجد إضافات جديدة منذ آخر زيارة. ستظهر هنا تحديثات مكتبة الموقع عند إضافتها.</p>}</section>}
      <main id="main-content" tabIndex={-1}>
        <section className="mk2-home-view" hidden={view !== "home"}>
          <section className={`mk2-hero ${!featured ? "mk2-hero-empty" : ""}`} data-artwork={artworkKind} aria-label="أحدث الإضافات والمسلسلات العربية" aria-roledescription="عارض شرائح"
            onMouseEnter={() => setHeroHovered(true)} onMouseLeave={() => setHeroHovered(false)}
            onFocusCapture={() => setHeroFocused(true)} onBlurCapture={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setHeroFocused(false); }}>
            <picture key={`${artworkUrl}:${mobileArtworkUrl}`} className="mk2-hero-art">{mobileArtworkUrl && <source media="(max-width: 700px)" srcSet={mobileArtworkUrl} />}{artworkUrl && <img className="mk2-hero-backdrop" src={artworkUrl} alt="" decoding="async" fetchPriority="high" />}</picture>
            <div className="mk2-hero-shade" /><div className="mk2-hero-orb" />
            <div className="mk2-hero-content" aria-live={rotationPaused ? "polite" : "off"} aria-atomic="true">
              <span className="mk2-eyebrow"><i /><span>أحدث الإضافات والمسلسلات العربية</span><span className="mk2-hero-tag">مسلسلات</span></span>
              <p className="mk2-hero-intro">{settings.heroTitle}</p>
              <h1>{featured?.title || (homeLoading ? "لحظة، حكايتك في الطريق…" : "لكل مزاج حكاية.")}</h1>
              {featured && <div className="mk2-hero-meta">{Number(featured.rating) > 0 && <span className="mk2-rating"><Star size={15} fill="currentColor" />{featured.rating}<small>/10</small></span>}{featured.year && <span>{featured.year}</span>}<span>مسلسل</span>{featured.genre && <span>{featured.genre.split(/[،,]/).slice(0, 2).join(" · ")}</span>}</div>}
              <p className="mk2-hero-description">{featured?.description || settings.heroText}</p>
              <div className="mk2-hero-actions"><button className="mk2-primary" onClick={() => featured ? openItem(featured) : navigate("series")}><Play size={18} fill="currentColor" />{featured ? "اضغط للمشاهدة" : "استكشف المكتبة"}</button><button className="mk2-secondary" onClick={() => navigate("discover")}><Search size={17} />اكتشف المزيد</button></div>
              {featured && <UserActions item={featured} compact />}
            </div>
            <div className="mk2-hero-bottom"><span><i />حكايات قريبة، وتجربة أجمل.</span>{banners.length > 1 && <div className="mk2-hero-controls">
              <div className="mk2-banner-pagination" aria-label="المسلسلات المميزة">{banners.map((item, index) => <button type="button" key={`${item.source}:${item.mediaType}:${item.id}`} className={featureIndex % banners.length === index ? "active" : ""} onClick={() => setFeatureIndex(index)} aria-label={`عرض ${item.title}`} aria-pressed={featureIndex % banners.length === index} />)}<span dir="ltr">{String(featureIndex % banners.length + 1).padStart(2, "0")} / {String(banners.length).padStart(2, "0")}</span></div>
              <button type="button" className="mk2-hero-rotation" onClick={() => setRotationPaused((paused) => !paused)} aria-label={rotationPaused ? "تشغيل التنقل التلقائي بين المسلسلات" : "إيقاف التنقل التلقائي بين المسلسلات"} aria-pressed={!rotationPaused}>{rotationPaused ? <Play size={17} /> : <Pause size={17} />}<span>{rotationPaused ? "تشغيل" : "إيقاف"}</span></button>
            </div>}</div>
          </section>
          <div className="mk2-content-wrap"><div className="mk2-quick-genres"><span>على مزاجك</span><button onClick={() => navigate("series")}><Tv size={16} />مسلسلات عربية وخليجية</button><button onClick={() => navigate("movies")}><Film size={16} />عالم الأفلام</button><button onClick={() => navigate("library")}><Bookmark size={16} />قائمتي الخاصة</button><button onClick={() => navigate("provider")}><Play size={16} />مسلسلات MK~2</button><span className="mk2-live-status"><i />مكتبة متجددة</span></div>{homeError && <div className="mk2-inline-error" role="status"><p>{homeError}</p><button onClick={() => setRefresh((v) => v + 1)}>إعادة المحاولة</button></div>}
            {resume.length > 0 && <section className="mk2-section mk2-continue"><div className="mk2-section-heading"><div><span className="mk2-eyebrow">نكمل الحكاية؟</span><h2>أكمل المشاهدة</h2></div><button className="mk2-text-button" onClick={() => navigate("library")}>سجل المشاهدة <ArrowUpLeft size={17} /></button></div><div className="mk2-continue-row">{resume.map((entry) => <button className="mk2-continue-card" key={entry.key} onClick={() => openItem(entry.item, { season: entry.progress?.season, episode: entry.progress?.episode })}>{entry.item.poster && <img src={entry.item.poster} alt="" loading="lazy" decoding="async" />}<span className="mk2-continue-play"><Play size={17} fill="currentColor" /></span><span><strong>{entry.item.title}</strong><small>{entry.progress?.episode ? `الموسم ${entry.progress.season} · الحلقة ${entry.progress.episode}` : "متابعة العمل"}</small><i><b style={{ width: `${Math.min(100, (entry.progress?.currentTime || 0) / (entry.progress?.duration || 1) * 100)}%` }} /></i></span></button>)}</div></section>}
            {presentation.sections.filter((s) => s.enabled && labels[s.id]).map(({ id }) => <section className="mk2-section" key={id} aria-labelledby={`shelf-title-${id}`}><div className="mk2-section-heading"><div><span className="mk2-eyebrow">{labels[id].kicker}</span><h2 id={`shelf-title-${id}`}>{labels[id].title}<span className="mk2-title-dot">.</span></h2><p>{id === "recommended" && !viewer.history.length && !viewer.favorites.length ? "مجموعة مختارة لتبدأ منها. تتطور اقتراحاتك مع الأعمال التي تحبها." : labels[id].description}</p></div><span className="mk2-section-symbol">{id === "recommended" ? <Sparkles size={23} /> : id === "rated" ? <Star size={23} /> : id === "recent" ? <Clapperboard size={23} /> : <Play size={23} />}</span></div><Shelf id={id} items={shelfItems[id]} loading={homeLoading && id !== "popular"} onOpen={openItem} onBrowse={() => navigate(id === "recent" ? "series" : "discover")}><div className="mk2-empty-shelf">{id === "popular" ? <><Play size={25} /><p>تبدأ القائمة من المشاهدات الفعلية.</p><small>ستظهر الأعمال هنا عندما يسجّل المشغل بدء تشغيلها؛ لا نعرض ترتيبًا افتراضيًا.</small></> : <><Clapperboard size={25} /><p>{id === "recent" ? "لم تُضف أعمال إلى مكتبة الموقع بعد." : "تعذّر تحميل هذا القسم حاليًا."}</p><button className="mk2-text-button" onClick={() => navigate("discover")}>استكشف المكتبة</button></>}</div></Shelf></section>)}
            <section className="mk2-provider-callout"><span className="mk2-explore-icon"><Tv size={30} /></span><div><span className="mk2-eyebrow">مسلسلات MK~2</span><h2>{providerMaintenance ? PROVIDER_MAINTENANCE_TITLE : "مسلسلاتك، من مصدر المشاهدة المتصل."}</h2><p>{providerMaintenance ? PROVIDER_MAINTENANCE_MESSAGE : "ابحث باسم المسلسل أو تصفح التصنيفات، ثم اختر الموسم والحلقة من العمل نفسه."}</p></div><button className="mk2-primary" onClick={() => navigate("provider")}>{providerMaintenance ? "مسلسلات MK~2" : "تصفح مسلسلات MK~2"} <ArrowUpLeft size={17} /></button></section><section className="mk2-explore-banner"><span className="mk2-explore-icon"><Clapperboard size={34} /></span><div><span className="mk2-eyebrow">كل حكاية لها وقتها</span><h2>اختر ما تحب. واترك الباقي لقائمتك.</h2><p>احفظ أعمالك المفضلة، وارجع لحلقاتك وقوائمك متى شئت.</p></div><button className="mk2-secondary" onClick={() => navigate("library")}>افتح مكتبتي <ArrowUpLeft size={17} /></button></section>
          </div>
        </section>
        {libraryMounted && <div className="mk2-content-wrap mk2-discover-view" hidden={!showDiscovery}><CinemaLibrary onOpen={openItem} initialType={discoveryType} initialQuery={query} navigationKey={navigationKey} /></div>}
        {view === "provider" && <div className="mk2-content-wrap mk2-provider-view"><ProviderLibrary onOpen={openItem} /></div>}
        <div className="mk2-content-wrap mk2-personal-view" hidden={view !== "library"}><div className="mk2-library-account"><div><strong>{account ? `أهلًا ${account.name}` : "حسابك على MK2Movie"}</strong><p>{account ? `@${account.username}` : "أنشئ حسابًا باسمك واسم مستخدم وكلمة مرور لمزامنة مكتبتك بين أجهزتك."}</p></div>{account ? <button className="mk2-secondary" disabled={signingOut} onClick={() => void signOut()}>{signingOut ? "جارٍ الخروج…" : "تسجيل الخروج"}</button> : <button className="mk2-primary" onClick={() => setWelcome(true)}>دخول أو إنشاء حساب</button>}</div>{accountError && <p className="mk2-account-error" role="alert">{accountError}</p>}<ViewerSync key={account?.id || "guest"} signedIn={Boolean(account)} /><PersonalLibrary onOpen={openItem} signedIn={Boolean(account)} /></div>
      </main>
      <footer className="mk2-footer"><div className="mk2-footer-top"><div><a className="mk2-brand" href="/#home" onClick={(e) => { e.preventDefault(); navigate("home"); }}><span className="mk2-brand-mark"><Clapperboard size={23} /></span><span dir="ltr">{settings.siteName}<small>حكايتك تبدأ هنا</small></span></a><p>مكانك لاكتشاف الأفلام والمسلسلات ومتابعة حكاياتك المفضلة.</p><PublicSocialLinks links={settings.socialLinks} placement="footer" /></div><nav aria-label="روابط التذييل"><a href="/#movies" onClick={(e) => { e.preventDefault(); navigate("movies"); }}>الأفلام</a><a href="/#series" onClick={(e) => { e.preventDefault(); navigate("series"); }}>المسلسلات</a><a href="/#library" onClick={(e) => { e.preventDefault(); navigate("library"); }}>مكتبتي</a><a href="/#provider" onClick={(e) => { e.preventDefault(); navigate("provider"); }}>مسلسلات MK~2</a><a href="/admin">لوحة الإدارة</a></nav><div className="mk2-footer-app"><PwaInstall />{account && <button className="mk2-footer-signout" disabled={signingOut} onClick={() => void signOut()}>{signingOut ? "جارٍ الخروج…" : "تسجيل الخروج"}</button>}</div></div><div className="mk2-footer-bottom"><span dir="ltr">© {new Date().getFullYear()} {settings.siteName}</span><span className="mk2-tmdb-attribution"><img src="/tmdb-logo.svg" width="68" height="20" alt="TMDb" />بيانات وصور الأعمال من TMDb؛ لا يوفر خدمة تشغيل الفيديو.</span></div><p className="mk2-attribution-note">This product uses the TMDB API but is not endorsed or certified by TMDB.</p><div className="mk2-release-footer"><span className="mk2-release-chip">الإصدار <bdi>{SITE_RELEASE}</bdi></span>{MK2_PERSONAL_SITE && <a className="mk2-personal-credit" href={MK2_PERSONAL_SITE} target="_blank" rel="noopener noreferrer" aria-label="MK~2 · الموقع الشخصي (يفتح في نافذة جديدة)"><span dir="ltr">MK~2</span><ArrowUpLeft size={13} /></a>}</div></footer>
      <nav className="mk2-bottom-nav" aria-label="التنقل على الجوال">{navigation.map(({ id, label, icon: Icon }) => <button key={id} className={view === id ? "active" : ""} aria-current={view === id ? "page" : undefined} onClick={() => navigate(id)}><Icon size={20} /><span>{id === "provider" ? "MK~2" : label}</span></button>)}<button className={view === "discover" ? "active" : ""} onClick={() => navigate("discover")}><Search size={20} /><span>البحث</span></button></nav>
    </div>
    {selection?.item.mediaType === "tv" && <SeriesDetails key={`${selection.item.source}:${selection.item.id}`} selection={{ ...selection.item, mediaType: "tv", ...selection.position }} siteName={settings.siteName} onClose={closeDetails} onOpenSimilar={openItem} />}
    {selection?.item.mediaType === "movie" && <MovieDetails key={`${selection.item.source}:${selection.item.id}`} item={selection.item} siteName={settings.siteName} onClose={closeDetails} onOpenSimilar={openItem} />}
    {adminOpen && <AdminPanel onClose={() => { setAdminOpen(false); if (window.location.pathname === "/admin") window.history.replaceState({}, "", "/#home"); }} onSettingsChange={acceptSettings} />}
    <InstallPresence account={account} />
    {welcome && <AccountDialog siteName={settings.siteName} onClose={() => setWelcome(false)} onAuthenticated={(next) => { accountRevision.current += 1; setAccount(next); setAccountError(""); setWelcome(false); }} />}
  </>;
}
