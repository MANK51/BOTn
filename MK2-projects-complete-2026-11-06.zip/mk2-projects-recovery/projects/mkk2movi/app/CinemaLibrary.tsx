"use client";

import { useCallback, useEffect, useId, useRef, useState } from "react";
import type { FormEvent, KeyboardEvent } from "react";
import type { CinemaCatalogResponse, CinemaItem, CinemaMediaType, CinemaScope, CinemaSort } from "../lib/cinema-types";
import { UserActions } from "./UserActions";
import "./cinema-library.css";

type LibraryType = CinemaMediaType | "all";
export type CinemaLibraryProps = {
  onOpen: (item: CinemaItem) => void;
  initialType?: LibraryType;
  initialQuery?: string;
  navigationKey?: number;
  onItems?: (items: CinemaItem[]) => void;
  compact?: boolean;
};

const scopeOptions: { id: CinemaScope; label: string }[] = [
  { id: "arabic", label: "عربي" },
  { id: "gulf", label: "خليجي" },
  { id: "shahid", label: "أعمال شاهد" },
  { id: "all", label: "كل الأعمال" },
];
const typeOptions: { id: LibraryType; label: string }[] = [
  { id: "all", label: "الكل" }, { id: "tv", label: "مسلسلات" }, { id: "movie", label: "أفلام" },
];
const currentYear = new Date().getUTCFullYear();
const years = Array.from({ length: currentYear - 1899 }, (_, index) => String(currentYear - index));
const number = new Intl.NumberFormat("ar");
const itemKey = (item: CinemaItem) => `${item.mediaType}:${item.id}`;
const effectiveQuery = (text: string) => text.trim().length >= 2 ? text.trim() : "";

function SearchIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4.5 4.5" /></svg>;
}

function FilmIcon() {
  return <svg viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true"><rect x="8" y="7" width="32" height="34" rx="5" /><path d="M8 17h32M8 31h32M17 7v34M31 7v34" /></svg>;
}

function DetailIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m14 6-6 6 6 6M8 12h12" /></svg>;
}

function optimizedPoster(poster: string) {
  if (!poster) return { src: "", srcSet: undefined };
  try {
    const url = new URL(poster);
    if (url.hostname === "image.tmdb.org" && /^\/t\/p\/(w\d+|original)\/.+/.test(url.pathname)) {
      const imagePath = url.pathname.replace(/^\/t\/p\/(w\d+|original)\//, "");
      return { src: `https://image.tmdb.org/t/p/w342/${imagePath}`, srcSet: `https://image.tmdb.org/t/p/w185/${imagePath} 185w, https://image.tmdb.org/t/p/w342/${imagePath} 342w, https://image.tmdb.org/t/p/w500/${imagePath} 500w` };
    }
  } catch { /* Local poster URLs remain usable. */ }
  return { src: poster, srcSet: undefined };
}

export function CinemaPoster({ item, small = false }: { item: CinemaItem; small?: boolean }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [item.poster]);
  const poster = optimizedPoster(item.poster);
  return poster.src && !failed ? <img className="cinema-poster-image" src={poster.src} srcSet={poster.srcSet} sizes={small ? "54px" : "(max-width: 520px) 43vw, (max-width: 850px) 29vw, (max-width: 1180px) 21vw, 190px"} alt={small ? "" : `ملصق ${item.title}`} loading="lazy" decoding="async" onError={() => setFailed(true)} /> : <span className="cinema-poster-fallback"><FilmIcon />{!small && <span>{item.title}</span>}</span>;
}

export function CinemaCard({ item, onOpen, compact = false }: { item: CinemaItem; onOpen: (item: CinemaItem) => void; compact?: boolean }) {
  const rating = Number(item.rating);
  const label = [item.title, item.year, item.mediaType === "movie" ? "فيلم" : "مسلسل", item.originalTitle && item.originalTitle !== item.title ? item.originalTitle : ""].filter(Boolean).join("، ");
  return <article className={`cinema-card${compact ? " cinema-card-compact" : ""}`}>
    <button className="cinema-card-open" type="button" onClick={() => onOpen(item)} aria-label={`تفاصيل ${label}`}>
      <span className="cinema-card-art">
        <CinemaPoster item={item} />
        <span className="cinema-card-scrim" />
        <span className="cinema-card-type">{item.mediaType === "movie" ? "فيلم" : "مسلسل"}</span>
        {Number.isFinite(rating) && rating > 0 && <span className="cinema-card-rating" aria-label={`التقييم ${rating.toFixed(1)} من 10`}><span aria-hidden="true">★</span> {rating.toFixed(1)}</span>}
        <span className="cinema-card-detail"><DetailIcon /><span>اكتشف العمل</span></span>
      </span>
      <span className="cinema-card-info"><span className="cinema-card-title-row"><strong className="cinema-card-title">{item.title}</strong>{item.year && <span className="cinema-card-year">{item.year}</span>}</span>
        {item.originalTitle && item.originalTitle !== item.title && <span className="cinema-card-original" dir="auto">{item.originalTitle}</span>}
        {item.genre && <span className="cinema-card-genre">{item.genre}</span>}
      </span>
    </button>
    <div className="cinema-card-actions"><UserActions item={item} compact /></div>
  </article>;
}

function SkeletonGrid() {
  return <div className="cinema-grid cinema-skeleton-grid" aria-hidden="true">{Array.from({ length: 8 }, (_, index) => <div className="cinema-skeleton" key={index}><span /><span /><span /></div>)}</div>;
}

export default function CinemaLibrary({ onOpen, initialType = "all", initialQuery = "", navigationKey = 0, onItems, compact = false }: CinemaLibraryProps) {
  const [type, setType] = useState<LibraryType>(initialType);
  const [scope, setScope] = useState<CinemaScope>("arabic");
  const [draftQuery, setDraftQuery] = useState(initialQuery);
  const [query, setQuery] = useState(effectiveQuery(initialQuery));
  const [genre, setGenre] = useState("");
  const [rating, setRating] = useState("");
  const [sort, setSort] = useState<CinemaSort>("popular");
  const [yearMemory, setYearMemory] = useState<Record<string, string>>({});
  const yearKey = `${type}:${scope}`;
  const year = yearMemory[yearKey] || "";
  const [items, setItems] = useState<CinemaItem[]>([]);
  const [catalog, setCatalog] = useState<CinemaCatalogResponse | null>(null);
  const [knownGenres, setKnownGenres] = useState<CinemaCatalogResponse["genres"]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0);
  const [suggestionsOpen, setSuggestionsOpen] = useState(false);
  const [activeSuggestion, setActiveSuggestion] = useState(-1);
  const requestId = useRef(0);
  const controllerRef = useRef<AbortController | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const queryRef = useRef(query);
  const itemsRef = useRef<CinemaItem[]>([]);
  const onItemsRef = useRef(onItems);
  const failedRequest = useRef<{ page: number; replace: boolean } | null>(null);
  const previousInitialType = useRef(initialType);
  const previousNavigationKey = useRef(navigationKey);
  const previousInitialQuery = useRef(initialQuery);
  const searchRoot = useRef<HTMLFormElement | null>(null);
  const id = useId();
  const headingId = `${id}-heading`;
  const listId = `${id}-suggestions`;
  const queryHintId = `${id}-query-hint`;
  useEffect(() => { onItemsRef.current = onItems; }, [onItems]);
  useEffect(() => { queryRef.current = query; }, [query]);

  const cancelPending = useCallback(() => {
    controllerRef.current?.abort();
    requestId.current += 1;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = null;
  }, []);

  const loadCatalog = useCallback(async (page: number, replace: boolean) => {
    controllerRef.current?.abort();
    const controller = new AbortController();
    controllerRef.current = controller;
    const sequence = ++requestId.current;
    setError("");
    setActiveSuggestion(-1);
    if (replace) {
      setLoading(true);
      setLoadingMore(false);
      itemsRef.current = [];
      setItems([]);
      setCatalog(null);
    } else setLoadingMore(true);
    try {
      const parameters = new URLSearchParams({ type, scope, sort, page: String(page) });
      if (query) parameters.set("q", query);
      if (year) parameters.set("year", year);
      if (genre) parameters.set("genre", genre);
      if (rating) parameters.set("rating", rating);
      const response = await fetch(`/api/cinema/catalog?${parameters}`, { signal: controller.signal, cache: "no-store" });
      let data: CinemaCatalogResponse & { error?: string };
      try { data = await response.json() as CinemaCatalogResponse & { error?: string }; }
      catch { throw new Error("تعذّر الاتصال بالمكتبة. أعد المحاولة بعد قليل."); }
      if (controller.signal.aborted || sequence !== requestId.current) return;
      if (!response.ok) throw new Error(data.error || "تعذّر تحميل المكتبة. حاول مرة أخرى.");
      if (!Array.isArray(data.items) || !Array.isArray(data.genres) || typeof data.hasMore !== "boolean") throw new Error("تعذّر تحميل نتائج المكتبة. حاول مرة أخرى.");
      failedRequest.current = null;
      const existing = new Set((replace ? [] : itemsRef.current).map(itemKey));
      const nextItems = [...(replace ? [] : itemsRef.current), ...data.items.filter((item) => {
        const key = itemKey(item);
        if (existing.has(key)) return false;
        existing.add(key);
        return true;
      })];
      itemsRef.current = nextItems;
      setItems(nextItems);
      setCatalog(data);
      setKnownGenres((previous) => {
        const seen = new Set(data.genres.map((entry) => entry.id));
        return [...data.genres, ...previous.filter((entry) => !seen.has(entry.id))];
      });
      onItemsRef.current?.(nextItems);
    } catch (failure) {
      if (controller.signal.aborted || sequence !== requestId.current) return;
      failedRequest.current = { page, replace };
      setError(failure instanceof Error ? failure.message : "تعذّر تحميل المكتبة. حاول مرة أخرى.");
    } finally {
      if (!controller.signal.aborted && sequence === requestId.current) {
        setLoading(false);
        setLoadingMore(false);
      }
    }
  }, [type, scope, query, year, genre, rating, sort]);

  useEffect(() => {
    void loadCatalog(1, true);
    return () => { controllerRef.current?.abort(); requestId.current += 1; };
  }, [loadCatalog, refresh]);

  useEffect(() => {
    if (previousInitialType.current === initialType && previousNavigationKey.current === navigationKey) return;
    previousInitialType.current = initialType;
    previousNavigationKey.current = navigationKey;
    cancelPending();
    setType(initialType);
    const nextQuery = effectiveQuery(draftQuery);
    setQuery(nextQuery);
    queryRef.current = nextQuery;
    setSuggestionsOpen(false);
    setRefresh((value) => value + 1);
  }, [initialType, navigationKey, cancelPending]);

  useEffect(() => {
    if (previousInitialQuery.current === initialQuery) return;
    previousInitialQuery.current = initialQuery;
    cancelPending();
    const nextQuery = effectiveQuery(initialQuery);
    setDraftQuery(initialQuery);
    setQuery(nextQuery);
    queryRef.current = nextQuery;
    setSuggestionsOpen(Boolean(nextQuery));
    setRefresh((value) => value + 1);
  }, [initialQuery, cancelPending]);

  useEffect(() => {
    const reload = () => { cancelPending(); setRefresh((value) => value + 1); };
    window.addEventListener("mk2-catalog-refresh", reload);
    return () => { window.removeEventListener("mk2-catalog-refresh", reload); cancelPending(); };
  }, [cancelPending]);

  const beginSearch = (text: string, immediate: boolean) => {
    cancelPending();
    setError("");
    setActiveSuggestion(-1);
    setLoading(true);
    setLoadingMore(false);
    const apply = () => {
      debounceRef.current = null;
      const next = effectiveQuery(text);
      if (next === queryRef.current) setRefresh((value) => value + 1);
      else { queryRef.current = next; setQuery(next); }
    };
    if (immediate) apply();
    else debounceRef.current = setTimeout(apply, 350);
  };

  const changeFilter = (change: () => void) => {
    cancelPending();
    setSuggestionsOpen(false);
    const nextQuery = effectiveQuery(draftQuery);
    setQuery(nextQuery);
    queryRef.current = nextQuery;
    change();
  };

  const resetFilters = () => {
    cancelPending();
    setDraftQuery("");
    setQuery("");
    queryRef.current = "";
    setGenre("");
    setRating("");
    setSort("popular");
    setYearMemory((previous) => ({ ...previous, [yearKey]: "" }));
    setSuggestionsOpen(false);
    setRefresh((value) => value + 1);
  };

  const suggestionItems = (items.length ? items : catalog?.suggestions || []).slice(0, 6);
  const showSuggestions = suggestionsOpen && !loading && !loadingMore && !error && draftQuery.trim() === query && query.length >= 2 && suggestionItems.length > 0;
  const openSuggestion = (item: CinemaItem) => { setSuggestionsOpen(false); setActiveSuggestion(-1); onOpen(item); };
  const searchKeys = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Escape") { setSuggestionsOpen(false); setActiveSuggestion(-1); return; }
    if ((event.key === "ArrowDown" || event.key === "ArrowUp") && suggestionItems.length && query.length >= 2 && !loading) {
      event.preventDefault();
      setSuggestionsOpen(true);
      setActiveSuggestion((previous) => event.key === "ArrowDown" ? (previous + 1) % suggestionItems.length : (previous <= 0 ? suggestionItems.length : previous) - 1);
    }
    if (event.key === "Enter" && showSuggestions && activeSuggestion >= 0) {
      event.preventDefault();
      openSuggestion(suggestionItems[activeSuggestion]);
    }
  };
  const submitSearch = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); setSuggestionsOpen(false); beginSearch(draftQuery, true); };
  const hasFilters = Boolean(query || draftQuery || genre || year || rating || sort !== "popular");
  const mediaGroups = type === "all" ? (["tv", "movie"] as const).map((mediaType) => ({ mediaType, items: items.filter((item) => item.mediaType === mediaType) })) : [{ mediaType: type, items }];
  const matchedCount = catalog?.totalResultsExact ? catalog.totalResults : items.length;
  const scopeLabel = scopeOptions.find((option) => option.id === scope)?.label || "المكتبة";

  return <section className={`cinema-library${compact ? " cinema-library-compact" : ""}`} dir="rtl" aria-labelledby={headingId} data-cinema-library>
    <div className="cinema-library-heading">
      <div><span className="cinema-library-eyebrow">كل حكاية تبدأ من هنا</span><h2 id={headingId}>{type === "tv" ? "عالم المسلسلات" : type === "movie" ? "ليلتك السينمائية" : "اكتشف حكايتك القادمة"}</h2><p>أعمال تعرفها، وحكايات تستحق أن تكتشفها.</p></div>
      <form className="cinema-search" role="search" onSubmit={submitSearch} ref={searchRoot} onBlur={(event) => { if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setSuggestionsOpen(false); }}>
        <div className="cinema-search-field"><SearchIcon /><label className="cinema-sr-only" htmlFor={`${id}-search`}>ابحث في {scopeLabel}</label><input id={`${id}-search`} value={draftQuery} type="search" autoComplete="off" placeholder={`ابحث في ${scopeLabel} بالعربي أو الإنجليزي`} onChange={(event) => { const text = event.target.value; setDraftQuery(text); setSuggestionsOpen(true); beginSearch(text, false); }} onFocus={() => setSuggestionsOpen(true)} onKeyDown={searchKeys} role="combobox" aria-autocomplete="list" aria-expanded={showSuggestions} aria-controls={showSuggestions ? listId : undefined} aria-activedescendant={showSuggestions && activeSuggestion >= 0 ? `${id}-suggestion-${activeSuggestion}` : undefined} aria-describedby={queryHintId} enterKeyHint="search" />{draftQuery && <button className="cinema-search-clear" type="button" aria-label="مسح البحث" onClick={() => { setDraftQuery(""); beginSearch("", true); }}>×</button>}</div>
        <button className="cinema-search-submit" type="submit" aria-label="تنفيذ البحث"><SearchIcon /><span>بحث</span></button>
        {showSuggestions && <div className="cinema-suggestions"><p>{!items.length ? "هل تقصد أحد هذه الأعمال؟" : "انتقل إلى العمل"}</p><ul id={listId} role="listbox" aria-label="اقتراحات البحث">{suggestionItems.map((item, index) => <li key={itemKey(item)} role="option" id={`${id}-suggestion-${index}`} aria-selected={activeSuggestion === index}><button type="button" onMouseDown={(event) => event.preventDefault()} onClick={() => openSuggestion(item)} tabIndex={-1} className={activeSuggestion === index ? "is-active" : ""}><span className="cinema-suggestion-poster"><CinemaPoster item={item} small /></span><span><strong>{item.title}</strong><small>{[item.originalTitle !== item.title ? item.originalTitle : "", item.year, item.mediaType === "movie" ? "فيلم" : "مسلسل"].filter(Boolean).join(" · ")}</small></span><DetailIcon /></button></li>)}</ul></div>}
      </form>
    </div>

    <div className="cinema-discovery-bar"><div className="cinema-type-tabs" role="group" aria-label="نوع العمل">{typeOptions.map((option) => <button type="button" key={option.id} aria-pressed={type === option.id} onClick={() => { if (type !== option.id) changeFilter(() => setType(option.id)); }}>{option.label}</button>)}</div><span className="cinema-bar-divider" /><div className="cinema-scope-tabs" role="group" aria-label="المكتبة">{scopeOptions.map((option) => <button type="button" key={option.id} aria-pressed={scope === option.id} onClick={() => { if (scope !== option.id) changeFilter(() => setScope(option.id)); }}>{option.label}</button>)}</div></div>

    <div className="cinema-filters">
      <label><span>التصنيف</span><select value={genre} onChange={(event) => changeFilter(() => setGenre(event.target.value))}><option value="">كل الأنواع</option>{knownGenres.map((option) => <option value={String(option.id)} key={option.id}>{option.label}</option>)}</select></label>
      <label><span>سنة الإنتاج</span><select value={year} onChange={(event) => { const nextYear = event.target.value; changeFilter(() => setYearMemory((previous) => ({ ...previous, [yearKey]: nextYear }))); }}><option value="">كل السنوات</option>{years.map((value) => <option value={value} key={value}>{value}</option>)}</select></label>
      <label><span>التقييم</span><select value={rating} onChange={(event) => changeFilter(() => setRating(event.target.value))}><option value="">كل التقييمات</option>{[9, 8, 7, 6, 5].map((value) => <option value={String(value)} key={value}>{value}+ من 10</option>)}</select></label>
      <label><span>الترتيب</span><select value={sort} onChange={(event) => changeFilter(() => setSort(event.target.value as CinemaSort))}><option value="popular">الرائجة</option><option value="rating">الأعلى تقييمًا</option><option value="newest">الأحدث إنتاجًا</option></select></label>
      {hasFilters && <button className="cinema-reset" type="button" onClick={resetFilters}>مسح الفلاتر <span aria-hidden="true">↺</span></button>}
    </div>
    <div className="cinema-library-status"><p id={queryHintId}>{draftQuery.trim().length === 1 ? "اكتب حرفين على الأقل للبحث. تظل الفلاتر ضمن القسم الذي اخترته." : query ? <>نتائج «<b>{query}</b>» في {scopeLabel}</> : "اختر حكايتك. السنة بحسب بداية عرض العمل."}</p><span aria-live="polite" aria-atomic="true">{loading ? "جارٍ البحث…" : !error ? `${number.format(matchedCount || 0)} ${catalog?.totalResultsExact ? "عمل" : "عمل ظاهر"}` : ""}</span></div>

    {catalog?.warning && !loading && <div className="cinema-notice" role="status"><p>{catalog.warning}</p>{catalog.metadataIncomplete && <button type="button" onClick={() => void loadCatalog(1, true)}>إعادة التحقق</button>}</div>}
    {catalog?.metadataIncomplete && !catalog.warning && !loading && <div className="cinema-notice" role="status"><p>تعذّر التحقق من بعض البيانات. قد لا تكون كل النتائج ظاهرة بعد.</p><button type="button" onClick={() => void loadCatalog(1, true)}>إعادة التحقق</button></div>}
    <div className="cinema-results" aria-busy={loading || loadingMore}>
      {loading ? <SkeletonGrid /> : mediaGroups.map((group) => group.items.length > 0 && <div className="cinema-media-group" key={group.mediaType}>{type === "all" && <h3>{group.mediaType === "tv" ? "مسلسلات" : "أفلام"}<span>{number.format(group.items.length)}</span></h3>}<div className="cinema-grid">{group.items.map((item) => <CinemaCard key={itemKey(item)} item={item} onOpen={onOpen} compact={compact} />)}</div></div>)}
      {!loading && error && <div className="cinema-empty cinema-error" role="alert"><SearchIcon /><h3>لم يكتمل تحميل المكتبة</h3><p>{error}</p><button className="cinema-library-button" type="button" onClick={() => { const retry = failedRequest.current || { page: 1, replace: true }; void loadCatalog(retry.page, retry.replace); }}>إعادة المحاولة</button></div>}
      {!loading && !error && items.length === 0 && <div className="cinema-empty"><SearchIcon /><h3>{query ? "لم نعثر على نتيجة مطابقة هنا" : "لا توجد أعمال تطابق هذه الفلاتر"}</h3><p>{catalog?.hasMore ? "قد توجد نتائج في الصفحات التالية. تابع البحث داخل القسم نفسه." : query ? "جرّب اسم العمل بالعربية أو الإنجليزية، أو خفف أحد الفلاتر." : "جرّب سنة أو تصنيفًا آخر لاستكشاف المزيد."}</p>{catalog?.suggestions && catalog.suggestions.length > 0 && <div className="cinema-typo-suggestions"><span>أعمال قريبة من بحثك</span>{catalog.suggestions.slice(0, 4).map((item) => <button type="button" key={itemKey(item)} onClick={() => onOpen(item)}>{item.title}{item.year ? ` · ${item.year}` : ""}</button>)}</div>}{hasFilters && <button className="cinema-library-button is-secondary" type="button" onClick={resetFilters}>عرض المكتبة</button>}</div>}
      {!loading && catalog?.hasMore && !error && <div className="cinema-load-more"><button className="cinema-library-button" type="button" disabled={loadingMore} onClick={() => void loadCatalog(catalog.page + 1, false)}>{loadingMore ? <><span className="cinema-loading-spinner" aria-hidden="true" />جارٍ التحميل…</> : items.length === 0 ? "متابعة البحث في القسم" : "اكتشف المزيد"}<DetailIcon /></button></div>}
    </div>
  </section>;
}
