"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { CinemaItem } from "../lib/cinema-types";
import type { PlaybackLink } from "../lib/playback";
import { PLAYER_FRAME_SANDBOX } from "../lib/playback-frame-policy";
import { providerMovieWatchUrl } from "../lib/provider-playback";
import { hasPlaybackProgress, nextUnfailedPlayerServer, readPlayerProgress, readPlayerSignal } from "../lib/player-signal";
import { getViewerResume, recordViewerProgress, recordViewerVisit } from "../lib/viewer-library";
import { nativePlaybackError } from "../lib/native-player";
import { PlayerFullscreen } from "./PlayerFullscreen";
import { UserActions } from "./UserActions";
import { CinemaDetailExtras, playbackStarted, playbackTime, reliableTmdbId, useTitleMetadata } from "./CinemaDetailExtras";
import "./series-details.css";

function safeServer(server: PlaybackLink) {
  try { const url = new URL(server.url); return url.protocol === "https:" && !url.username && !url.password ? url.href : ""; } catch { return ""; }
}

function MovieArt({ src, className, title = "" }: { src?: string; className: string; title?: string }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  return <span className={className}>{src && !failed ? <img src={src} alt={title} decoding="async" onError={() => setFailed(true)} /> : <span className="series-detail-art-fallback" aria-hidden="true">▶</span>}</span>;
}

export default function MovieDetails({ item, onClose, onOpenSimilar, siteName = "MK2Movie" }: { item: CinemaItem; onClose: () => void; onOpenSimilar?: (item: CinemaItem) => void; siteName?: string }) {
  const tmdbId = reliableTmdbId(item.tmdbId || (item.source === "automatic" ? item.id : ""));
  const { metadata, failed: metadataFailed, retryMetadata } = useTitleMetadata("movie", tmdbId);
  const detail = useMemo<CinemaItem>(() => ({ ...item, ...(metadata?.item ?? {}), id: item.id, source: item.source, mediaType: "movie", title: metadata?.item.title || item.title, ...(item.source === "provider" && item.containerExtension ? { containerExtension: item.containerExtension } : {}) }), [item, metadata]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [servers, setServers] = useState<PlaybackLink[]>([]);
  const [serverId, setServerId] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [watching, setWatching] = useState(false);
  const [revision, setRevision] = useState(0);
  const [sourceRevision, setSourceRevision] = useState(0);
  const [playerLoading, setPlayerLoading] = useState(false);
  const [playerError, setPlayerError] = useState(false);
  const [slow, setSlow] = useState(false);
  const [started, setStarted] = useState(false);
  const [notice, setNotice] = useState("");
  const [resumeTime, setResumeTime] = useState(0);
  const [nativePaused, setNativePaused] = useState(true);
  const [nativeErrorMessage, setNativeErrorMessage] = useState("");
  const [expanded, setExpanded] = useState(false);
  const shellRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);
  const playerRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerContainerRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLIFrameElement>(null);
  const frameProgressRef = useRef<{ currentTime: number; duration: number } | null>(null);
  const attemptRef = useRef("");
  const failuresRef = useRef(new Set<string>());
  const countedRef = useRef(false);
  const closeCallback = useRef(onClose);
  closeCallback.current = onClose;
  const current = servers.find((server) => server.id === serverId) || servers[0];
  const frameUrl = current ? safeServer(current) : "";
  const attempt = `${item.source}:${item.id}:${videoUrl || frameUrl}:${revision}`;
  attemptRef.current = attempt;
  const officialWatchUrl = metadata?.officialWatchUrl || (tmdbId ? `https://www.themoviedb.org/movie/${tmdbId}/watch` : "");

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true); setError(""); setServers([]); setVideoUrl(""); setWatching(false); failuresRef.current.clear();
    void (async () => {
      try {
        if (item.source === "provider") {
          if (!controller.signal.aborted) setVideoUrl(providerMovieWatchUrl(item.id, item.containerExtension));
          return;
        }
        let publishedId = item.source === "embed" && /^[0-9a-f-]{36}$/i.test(item.id) ? item.id : "";
        if (item.source === "automatic" && tmdbId) {
          const response = await fetch("/api/catalog", { cache: "no-store", signal: controller.signal });
          if (!response.ok) throw new Error("تعذّر التحقق من مكتبة الأفلام المنشورة. أعد المحاولة.");
          const catalog = await response.json() as { movies?: Array<{ id: string; type: string; source?: string; tmdbId?: string }> };
          const matching = Array.isArray(catalog.movies) ? catalog.movies.find((movie) => movie.type === "movie" && movie.source === "embed" && movie.tmdbId === tmdbId && /^[0-9a-f-]{36}$/i.test(movie.id)) : undefined;
          publishedId = matching?.id || "";
        }
        if (!publishedId) return;
        const response = await fetch(`/api/playback?id=${encodeURIComponent(publishedId)}`, { cache: "no-store", signal: controller.signal });
        const result = await response.json() as { mediaType?: string; episodes?: Array<{ servers?: PlaybackLink[] }>; error?: string };
        if (!response.ok) throw new Error(result.error || "الفيلم غير متاح للمشاهدة حاليًا.");
        if (result.mediaType !== "movie" || !Array.isArray(result.episodes) || result.episodes.length !== 1 || !Array.isArray(result.episodes[0]?.servers)) throw new Error("تعذّر التأكد من ارتباط المشغل بالفيلم المحدد.");
        const allowed = result.episodes[0].servers.filter((server) => server && typeof server.id === "string" && typeof server.name === "string" && Boolean(safeServer(server)));
        if (!controller.signal.aborted) { setServers(allowed); setServerId(allowed[0]?.id || ""); }
      } catch (failure) { if (!controller.signal.aborted) setError(failure instanceof Error ? failure.message : "تعذّر تحميل خيارات المشاهدة."); }
      finally { if (!controller.signal.aborted) setLoading(false); }
    })();
    return () => controller.abort();
  }, [item.id, item.source, item.containerExtension, tmdbId, sourceRevision]);

  useEffect(() => {
    countedRef.current = false;
    frameProgressRef.current = null;
  }, [item.id, item.source]);

  useEffect(() => {
    if (detail.title.trim()) recordViewerVisit(detail);
    // Opening the title is history; only actual progress below counts as a view.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detail.id, detail.source, detail.title]);

  useEffect(() => {
    if (!detail.title.trim()) return;
    const previousTitle = document.title;
    const pageTitle = `${detail.title} | ${siteName}`;
    document.title = pageTitle;
    return () => { if (document.title === pageTitle) document.title = previousTitle; };
  }, [detail.title, siteName]);

  useEffect(() => {
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus({ preventScroll: true });
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") { event.preventDefault(); closeCallback.current(); return; }
      if (event.key !== "Tab" || !shellRef.current) return;
      const focusable = Array.from(shellRef.current.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], select:not([disabled]), video[controls], iframe, [tabindex="0"]')).filter((element) => element.offsetParent !== null);
      const first = focusable[0]; const last = focusable.at(-1);
      if (!first || !last) return;
      if (event.shiftKey && (document.activeElement === first || !shellRef.current.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !shellRef.current.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = overflow; document.removeEventListener("keydown", keydown); if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true }); };
  }, []);

  useEffect(() => {
    setStarted(false); setSlow(false); setResumeTime(0); setNativePaused(true); setNativeErrorMessage(""); setPlayerError(false);
    if (!watching) return;
    setPlayerLoading(true);
    const timeout = window.setTimeout(() => { setSlow(true); setPlayerLoading(false); }, 15000);
    return () => window.clearTimeout(timeout);
  }, [attempt, watching]);

  useEffect(() => {
    if (!videoUrl || !watching || !playerLoading) return;
    const timeout = window.setTimeout(() => {
      setPlayerLoading(false); setSlow(true); setNativePaused(videoRef.current?.paused ?? true);
      setNotice("لم يبدأ الفيديو بعد. اضغط تشغيل الفيديو، أو أعد المحاولة إذا استمر التوقف.");
    }, 15000);
    return () => window.clearTimeout(timeout);
  }, [videoUrl, watching, playerLoading, attempt]);

  function reportProgress(currentTime: number, duration: number, force = false, countAsPlaying = true) {
    if (!hasPlaybackProgress(currentTime, duration)) return;
    setStarted(true); setPlayerLoading(false); setSlow(false);
    recordViewerProgress(detail, { currentTime, duration, force });
    if (countAsPlaying && !countedRef.current) { countedRef.current = true; playbackStarted(detail); }
  }

  useEffect(() => {
    const save = () => {
      const video = videoRef.current;
      if (video && hasPlaybackProgress(video.currentTime, video.duration)) recordViewerProgress(detail, { currentTime: video.currentTime, duration: video.duration, force: true });
      else if (frameProgressRef.current) recordViewerProgress(detail, { ...frameProgressRef.current, force: true });
    };
    const visibility = () => { if (document.visibilityState === "hidden") save(); };
    window.addEventListener("pagehide", save); document.addEventListener("visibilitychange", visibility);
    return () => { save(); window.removeEventListener("pagehide", save); document.removeEventListener("visibilitychange", visibility); };
  }, [detail]);

  function failServer(id: string, failedAttempt: string) {
    if (attemptRef.current !== failedAttempt || current?.id !== id || failuresRef.current.has(id)) return;
    failuresRef.current.add(id);
    const next = nextUnfailedPlayerServer(servers.map((server) => server.id), id, failuresRef.current);
    if (next) { setServerId(next); setPlayerError(false); setNotice("تعذّر تشغيل السيرفر الحالي؛ نجرّب خيارًا آخر للفيلم نفسه."); }
    else { setPlayerError(true); setPlayerLoading(false); setNotice("تعذّر التشغيل على السيرفرات التي جُرّبت. يمكنك إعادة المحاولة أو مراجعة المصادر الرسمية."); }
  }

  useEffect(() => {
    if (!watching || !frameUrl || !current || videoUrl || !tmdbId) return;
    const message = (event: MessageEvent) => {
      if (attemptRef.current !== attempt || failuresRef.current.has(current.id)) return;
      const target = { providerId: current.id, frameUrl, mediaId: tmdbId, idSource: "tmdb" as const, mediaType: "movie" as const, season: 0, episode: 1 };
      const received = { origin: event.origin, sourceMatches: Boolean(frameRef.current?.contentWindow) && event.source === frameRef.current?.contentWindow, data: event.data };
      if (readPlayerSignal(target, received) === "error") failServer(current.id, attempt);
      else { const progress = readPlayerProgress(target, received); if (progress) { frameProgressRef.current = progress; reportProgress(progress.currentTime, progress.duration); } }
    };
    window.addEventListener("message", message);
    return () => window.removeEventListener("message", message);
  }, [watching, frameUrl, current, videoUrl, tmdbId, attempt, detail, servers]);

  function retry() { setPlayerError(false); setNotice(""); failuresRef.current.clear(); setRevision((value) => value + 1); }
  function chooseServer(id: string) { if (!servers.some((server) => server.id === id)) return; failuresRef.current.delete(id); setServerId(id); setPlayerError(false); setNotice(""); if (id === current?.id) retry(); }
  function start() { setWatching(true); requestAnimationFrame(() => playerRef.current?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" })); }

  function requestNativePlay(video: HTMLVideoElement) {
    const activeAttempt = attemptRef.current;
    setNotice(""); setPlayerError(false); setNativeErrorMessage("");
    setPlayerLoading(video.readyState < HTMLMediaElement.HAVE_FUTURE_DATA);
    const failure = (error: unknown) => {
      if (attemptRef.current !== activeAttempt || videoRef.current !== video || !video.isConnected) return;
      const name = error && typeof error === "object" && "name" in error ? error.name : "";
      if (name === "AbortError") return;
      setPlayerLoading(false); setNativePaused(true);
      if (name === "NotAllowedError") setNotice("المتصفح يحتاج ضغطة منك. اضغط تشغيل الفيديو للمتابعة.");
      else { setNativeErrorMessage(nativePlaybackError(4)); setPlayerError(true); }
    };
    try {
      void Promise.resolve(video.play()).then(() => {
        if (attemptRef.current !== activeAttempt || videoRef.current !== video) return;
        setNativePaused(video.paused);
        if (!video.paused) { setPlayerLoading(false); setSlow(false); }
      }).catch(failure);
    } catch (error) { failure(error); }
  }

  function nativeReady(video: HTMLVideoElement) { setPlayerLoading(false); setNativePaused(video.paused); }

  function nativeFailure(video: HTMLVideoElement) {
    setPlayerLoading(false); setNativePaused(true);
    setNativeErrorMessage(nativePlaybackError(video.error?.code)); setPlayerError(true);
  }

  return <div className={`series-detail-shell movie-detail-shell${watching ? " series-detail-watching" : ""}`} ref={shellRef} role="dialog" aria-modal="true" aria-labelledby="movie-detail-title" dir="rtl" data-movie-details-id={item.id}>
    <header className="series-detail-topbar"><button ref={closeRef} type="button" className="series-detail-back" onClick={onClose}><span aria-hidden="true">→</span> العودة للمكتبة</button><span className="series-detail-top-title">{detail.title}</span><span className="series-detail-top-label">فيلم</span></header>
    <section className="series-detail-hero" aria-label="عن الفيلم"><MovieArt src={detail.backdrop || detail.poster} className="series-detail-backdrop" /><div className="series-detail-hero-shade" /><div className="series-detail-hero-content"><div className="series-detail-intro"><span className="series-detail-eyebrow"><span />فيلم</span><h1 id="movie-detail-title">{detail.title}</h1>{detail.originalTitle && detail.originalTitle !== detail.title && <p className="series-detail-original" dir="auto">{detail.originalTitle}</p>}<div className="series-detail-facts">{detail.year && <span>{detail.year}</span>}{detail.genre && <span>{detail.genre}</span>}{detail.rating && <span className="series-detail-rating">★ {detail.rating}</span>}</div>{detail.description && <div className="series-detail-synopsis-wrap"><p className={`series-detail-synopsis${expanded ? " is-expanded" : ""}`}>{detail.description}</p>{detail.description.length > 320 && <button type="button" className="series-detail-synopsis-toggle" aria-expanded={expanded} onClick={() => setExpanded((value) => !value)}>{expanded ? "عرض أقل" : "القصة كاملة"}</button>}</div>}<div className="series-detail-hero-actions">{!loading && Boolean(videoUrl || servers.length) && <button type="button" className="series-detail-button series-detail-primary" onClick={start}><span aria-hidden="true">▶</span> شاهد الفيلم</button>}{officialWatchUrl && <a className="series-detail-button series-detail-secondary" href={officialWatchUrl} target="_blank" rel="noopener noreferrer">مصادر المشاهدة الرسمية <span aria-hidden="true">↗</span></a>}</div><UserActions item={detail} /></div><MovieArt src={detail.poster} className="series-detail-main-poster" title={`ملصق ${detail.title}`} /></div></section>
    {loading && <div className="series-detail-status-line" role="status"><span className="series-detail-spinner" /> جارٍ التحقق من خيارات المشاهدة المنشورة…</div>}
    {error && <p className="series-detail-metadata-notice" role="alert">{error} <button type="button" onClick={() => setSourceRevision((value) => value + 1)}>إعادة المحاولة</button></p>}
    {!loading && !error && !videoUrl && !servers.length && <div className="series-detail-availability"><span aria-hidden="true">◉</span><div><h2>تفاصيل الفيلم متاحة</h2><p>لم يُضف مدير الموقع مصدر مشاهدة لهذا الفيلم بعد. بيانات TMDb تعرض معلومات العمل، ويمكنك مراجعة مصادر المشاهدة الرسمية.</p></div></div>}
    {watching && Boolean(videoUrl || frameUrl) && <section ref={playerRef} className="series-detail-cinema" aria-labelledby="movie-player-title"><div className="series-detail-cinema-heading"><div><span className="series-detail-kicker">مشاهدة الفيلم</span><h2 id="movie-player-title">{detail.title}</h2></div></div><div ref={playerContainerRef} className="series-detail-player" data-movie-server-id={videoUrl ? "provider" : current?.id}>{videoUrl ? <video ref={videoRef} key={`${videoUrl}:${revision}`} src={videoUrl} controls autoPlay playsInline preload="metadata" poster={detail.backdrop || detail.poster || undefined} aria-label={detail.title} onLoadedMetadata={(event) => { const video = event.currentTarget; nativeReady(video); const saved = getViewerResume(detail); const time = saved && saved.currentTime >= 5 && saved.currentTime < video.duration * .95 ? saved.currentTime : 0; setResumeTime(time); if (time > 0) { video.pause(); setNativePaused(true); } else if (video.paused) requestNativePlay(video); }} onCanPlay={(event) => nativeReady(event.currentTarget)} onLoadedData={(event) => nativeReady(event.currentTarget)} onPlay={() => setNativePaused(false)} onPlaying={(event) => { nativeReady(event.currentTarget); setSlow(false); }} onWaiting={(event) => { if (!event.currentTarget.paused) setPlayerLoading(true); }} onTimeUpdate={(event) => { setNativePaused(event.currentTarget.paused); reportProgress(event.currentTarget.currentTime, event.currentTarget.duration, false, !event.currentTarget.paused && !event.currentTarget.seeking); }} onPause={(event) => { setNativePaused(true); setPlayerLoading(false); reportProgress(event.currentTarget.currentTime, event.currentTarget.duration, true, false); }} onEnded={(event) => { setNativePaused(true); setPlayerLoading(false); reportProgress(event.currentTarget.currentTime, event.currentTarget.duration, true, false); }} onError={(event) => nativeFailure(event.currentTarget)} /> : <iframe ref={frameRef} key={`${frameUrl}:${revision}`} src={frameUrl} title={`${detail.title} · ${current?.name}`} sandbox={PLAYER_FRAME_SANDBOX} allow="autoplay; fullscreen; encrypted-media; picture-in-picture" referrerPolicy="strict-origin-when-cross-origin" allowFullScreen onLoad={() => { if (attemptRef.current === attempt) setPlayerLoading(false); }} onError={() => current && failServer(current.id, attempt)} />}{videoUrl && nativePaused && resumeTime === 0 && !playerError && <button type="button" className="series-detail-native-play" onClick={() => { const video = videoRef.current; if (video) requestNativePlay(video); }} aria-label="تشغيل الفيلم"><span aria-hidden="true">▶</span><span>تشغيل الفيديو</span></button>}<PlayerFullscreen containerRef={playerContainerRef} videoRef={videoRef} resetKey={attempt} />{playerLoading && <span className="series-detail-player-loading" role="status"><span className="series-detail-spinner" /> جارٍ تجهيز المشغل…</span>}</div>{videoUrl && resumeTime > 0 && <div className="series-detail-resume"><span>لديك موضع مشاهدة محفوظ.</span><button type="button" onClick={() => { const video = videoRef.current; if (!video || !Number.isFinite(video.duration) || resumeTime >= video.duration) return; video.currentTime = resumeTime; setResumeTime(0); requestNativePlay(video); }}>تابع من <bdi>{playbackTime(resumeTime)}</bdi></button><button type="button" onClick={() => { setResumeTime(0); const video = videoRef.current; if (video) { video.currentTime = 0; requestNativePlay(video); } }}>من البداية</button></div>}{!videoUrl && <div className="series-detail-server-picker"><div className="series-detail-server-heading"><h3>سيرفرات المشاهدة</h3><span>خيارات المشاهدة: {new Intl.NumberFormat("ar").format(servers.length)}</span></div><label className="series-detail-server-select"><span>سيرفر المشاهدة</span><select aria-label="اختر سيرفر المشاهدة" value={current?.id || ""} onChange={(event) => chooseServer(event.target.value)}>{servers.map((server) => <option key={server.id} value={server.id}>{server.name}</option>)}</select></label><div className="series-detail-servers" role="group" aria-label="سيرفرات المشاهدة">{servers.map((server) => <button type="button" key={server.id} aria-pressed={current?.id === server.id} onClick={() => chooseServer(server.id)}>{server.name}</button>)}</div></div>}<div className="series-detail-watch-controls"><button type="button" className="series-detail-text-button" onClick={retry}>إعادة تشغيل المشغل</button></div>{notice && <p className="series-detail-server-notice" role="status">{notice}</p>}{slow && !started && !playerError && <p className="series-detail-server-notice" role="status">إذا لم يبدأ الفيديو، أعد المحاولة{servers.length > 1 ? " أو اختر سيرفرًا آخر" : ""}. ظهور المشغل وحده لا يؤكد توفر الفيلم.</p>}{playerError && <p className="series-detail-inline-error" role="alert">{videoUrl ? nativeErrorMessage || nativePlaybackError() : "تعذّر تشغيل الفيلم."} <button type="button" onClick={retry}>إعادة المحاولة</button>{officialWatchUrl && <> أو <a href={officialWatchUrl} target="_blank" rel="noopener noreferrer">راجع مصادر المشاهدة الرسمية</a></>}.</p>}</section>}
    <CinemaDetailExtras metadata={metadata} onOpenSimilar={onOpenSimilar} failed={metadataFailed} onRetry={retryMetadata} />
    <div className="series-detail-bottom-space" />
  </div>;
}
