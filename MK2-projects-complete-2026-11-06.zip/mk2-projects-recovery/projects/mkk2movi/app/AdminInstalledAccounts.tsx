"use client";
import { useEffect, useRef, useState } from "react";
import { validInstalledAccount, type InstalledAccount, type InstalledAccountsPage } from "../lib/app-installation-types";
import "./admin-installed-accounts.css";
const MAX_DISPLAYED_ACCOUNTS = 1000;
const platformLabels = { ios: "آيفون / آيباد", android: "أندرويد", desktop: "كمبيوتر", unknown: "غير محدد" };

export default function AdminInstalledAccounts({ onSessionExpired }: { onSessionExpired?: () => void }) {
  const [accounts, setAccounts] = useState<InstalledAccount[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [partial, setPartial] = useState(false);
  const controller = useRef<AbortController | null>(null);
  const expired = useRef(onSessionExpired);
  expired.current = onSessionExpired;

  async function load(nextCursor?: string) {
    controller.current?.abort();
    const current = new AbortController();
    controller.current = current;
    setLoading(true); setError("");
    try {
      const response = await fetch(`/api/admin/installations${nextCursor ? `?${new URLSearchParams({ cursor: nextCursor })}` : ""}`, { cache: "no-store", credentials: "same-origin", signal: current.signal });
      if (response.status === 401) { expired.current?.(); throw new Error("انتهت جلسة الإدارة. سجّل الدخول مجددًا."); }
      const data = await response.json() as Partial<InstalledAccountsPage> & { error?: string };
      if (!response.ok) throw new Error(data.error ?? "تعذر تحميل حسابات التطبيق.");
      if (!Array.isArray(data.accounts) || data.accounts.length > 50 || !data.accounts.every(item => validInstalledAccount(item)) || (data.nextCursor !== null && (typeof data.nextCursor !== "string" || data.nextCursor.length > 2048)) || typeof data.partial !== "boolean") throw new Error("استجابة حسابات التطبيق غير مكتملة.");
      if (current.signal.aborted) return;
      setAccounts(previous => [...new Map([...(nextCursor ? previous : []), ...data.accounts!].map(account => [account.id, account])).values()].sort((a, b) => Date.parse(b.lastOpenedAt) - Date.parse(a.lastOpenedAt)).slice(0, MAX_DISPLAYED_ACCOUNTS));
      setCursor(data.nextCursor ?? null);
      setPartial(previous => nextCursor ? previous || Boolean(data.partial) : Boolean(data.partial));
      setLoaded(true);
    } catch (failure) { if (!current.signal.aborted) setError(failure instanceof Error ? failure.message : "تعذر تحميل حسابات التطبيق."); }
    finally { if (!current.signal.aborted) setLoading(false); }
  }
  useEffect(() => { void load(); return () => controller.current?.abort(); }, []);

  const limited = accounts.length >= MAX_DISPLAYED_ACCOUNTS && Boolean(cursor);
  return <section className="installed-accounts" aria-busy={loading}>
    <div className="admin-section-heading"><div><h3>حسابات فتحت التطبيق المثبّت</h3><p className="admin-help">تظهر الحسابات بعد تسجيل الدخول وفتح الموقع كتطبيق مستقل من الشاشة الرئيسية. الضغط على زر التثبيت وحده لا يُحتسب. يبدأ التسجيل من هذا الإصدار، ويُحدّث آخر فتح مرة يوميًا.</p></div><button type="button" className="feature-button quiet" disabled={loading} onClick={() => void load()}>تحديث القائمة</button></div>
    <p className="installed-accounts-note">هذا سجل فتح للتطبيق؛ المتصفح لا يتيح التأكد من بقاء التطبيق مثبّتًا أو معرفة وقت حذفه.</p>
    <div className="installed-accounts-count"><strong>{loaded ? accounts.length.toLocaleString("ar-SA") : "—"}</strong><span>حسابات معروضة{cursor ? " · توجد صفحات إضافية" : ""}</span></div>
    {error && <div className="admin-warning" role="alert"><p>{error}{loaded ? " القائمة المعروضة من آخر تحميل ناجح." : ""}</p><button type="button" className="feature-button quiet" disabled={loading} onClick={() => void load(cursor && accounts.length ? cursor : undefined)}>إعادة المحاولة</button></div>}
    {partial && <p className="admin-warning" role="status">تعذر قراءة بعض السجلات؛ العدد المعروض قد لا يشمل جميع الحسابات. حدّث القائمة للمحاولة مجددًا.</p>}
    {loading && !loaded && <p className="admin-help" role="status">جارٍ تحميل حسابات التطبيق…</p>}
    {loaded && !accounts.length && !partial && !error && <p className="installed-accounts-empty">لا توجد حسابات مسجّلة فتحت التطبيق المثبّت بعد.</p>}
    {accounts.length > 0 && <div className="installed-accounts-table-wrap"><table className="installed-accounts-table"><caption className="sr-only">الحسابات التي سجّلت فتح التطبيق المثبّت</caption><thead><tr><th scope="col">الحساب</th><th scope="col">الجهاز عند آخر تسجيل</th><th scope="col">أول فتح مسجّل</th><th scope="col">آخر فتح مسجّل</th></tr></thead><tbody>{accounts.map(account => <tr key={account.id}><th scope="row"><strong>{account.name}</strong><span dir="auto">@{account.username}</span></th><td>{platformLabels[account.platform]}</td><td><time dateTime={account.firstOpenedAt}>{new Date(account.firstOpenedAt).toLocaleString("ar-SA")}</time></td><td><time dateTime={account.lastOpenedAt}>{new Date(account.lastOpenedAt).toLocaleString("ar-SA")}</time></td></tr>)}</tbody></table></div>}
    {cursor && !limited && <button type="button" className="feature-button quiet installed-accounts-more" disabled={loading} onClick={() => void load(cursor)}>{loading ? "جارٍ التحميل…" : "تحميل حسابات إضافية"}</button>}
    {limited && <p className="admin-help">وصل العرض إلى حد ألف حساب لتقليل استهلاك الذاكرة. السجلات الأخرى محفوظة؛ لا تُحذف عند الوصول إلى الحد.</p>}
  </section>;
}
