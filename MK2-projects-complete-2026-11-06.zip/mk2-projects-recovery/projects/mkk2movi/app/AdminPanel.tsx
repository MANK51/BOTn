"use client";

import { useEffect, useRef, useState } from "react";
import PlaybackAdmin from "./PlaybackAdmin";
import AdminInstalledAccounts from "./AdminInstalledAccounts";
import SeriesDetails from "./SeriesDetails";
import type { SeriesDetailsSelection } from "../lib/series-details-types";
import { createDefaultSocialLinks, normalizeSocialLinks, validateSocialLinks } from "../lib/social-links";
import type { SiteSettings as Settings } from "../lib/site-settings";
import { SocialAccountsFields } from "./SocialAccounts";
import { defaultPresentation, validatePresentation, type SitePresentation, type ShelfId } from "../lib/presentation";
import { PROVIDER_MAINTENANCE, PROVIDER_MAINTENANCE_TITLE, PROVIDER_MAINTENANCE_MESSAGE } from "../lib/provider-status";
import "./admin-panel.css";

type AdminTab = "dashboard" | "servers" | "iptv" | "uploads" | "presentation" | "design" | "social" | "stats" | "audit" | "installations";
type UploadedEpisode = { id: string; series_id: string; season: number; episode_number: number; title: string; file_name: string; size_bytes: number };
type UploadedSeries = { id: string; title: string; description: string; poster_url: string; genre: string; year: string; is_published: number; episodes: UploadedEpisode[] };
type TmdbResult = { id: number; name: string; description: string; posterUrl: string; year: string; rating: string };
type VisitStats = { views: number; uniqueVisitors: number; todayViews: number; todayUnique: number };
type Dashboard = { movies: number | null; series: number | null; seasons: number | null; episodes: number | null; uploadedDrafts: number | null; metadataRecords: number | null; partial: boolean };
type AuditEvent = { id: string; timestamp: string; action: string; target: string; metadata?: Record<string, number | boolean | string> };
type IptvMetadata = { configured?: boolean; maintenance?: boolean; expiresAt?: string | null; server?: string; username?: string; settings?: Settings };
const shelfLabels: Record<ShelfId, string> = { recent: "أحدث الإضافات", rated: "الأعلى تقييمًا", popular: "الأكثر شعبية", recommended: "أعمال مقترحة" };
const defaultSettings: Settings = { siteName: "MK2Movie", logoUrl: "", heroTitle: "حكايات تستحق المشاهدة.", heroText: "تصفّح المسلسلات، اختر الموسم والحلقة، وابدأ المشاهدة مباشرة.", heroImage: "", accentColor: "#e6b85c", defaultTheme: "dark", socialLinks: createDefaultSocialLinks() };
const emptyCredentials = { server: "", username: "", password: "" };

export default function AdminPanel({ onClose, onSettingsChange }: { onClose: () => void; onSettingsChange?: (settings: Settings) => void }) {
  const episodeInputRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const [seriesSelection, setSeriesSelection] = useState<SeriesDetailsSelection | null>(null);
  const selectionRef = useRef(seriesSelection);
  selectionRef.current = seriesSelection;
  const [adminTab, setAdminTab] = useState<AdminTab>("dashboard");
  const [loggedIn, setLoggedIn] = useState(false);
  const [login, setLogin] = useState({ username: "", password: "" });
  const [credentials, setCredentials] = useState(emptyCredentials);
  const [configured, setConfigured] = useState(false);
  const [providerMaintenance, setProviderMaintenance] = useState(false);
  const [providerExpiresAt, setProviderExpiresAt] = useState<string | null>(null);
  const [siteForm, setSiteForm] = useState<Settings>(defaultSettings);
  const [stats, setStats] = useState<VisitStats | null>(null);
  const [managedSeries, setManagedSeries] = useState<UploadedSeries[]>([]);
  const [seriesForm, setSeriesForm] = useState({ title: "", description: "", posterUrl: "", genre: "", year: "" });
  const [editingUploadId, setEditingUploadId] = useState<string | null>(null);
  const [uploadEdit, setUploadEdit] = useState({ title: "", description: "", posterUrl: "", genre: "", year: "" });
  const [selectedSeriesId, setSelectedSeriesId] = useState("");
  const [seasonNumber, setSeasonNumber] = useState("1");
  const [firstEpisodeNumber, setFirstEpisodeNumber] = useState("1");
  const [episodeFiles, setEpisodeFiles] = useState<File[]>([]);
  const [tmdbQuery, setTmdbQuery] = useState("");
  const [tmdbResults, setTmdbResults] = useState<TmdbResult[]>([]);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [presentation, setPresentation] = useState<SitePresentation>(defaultPresentation);
  const [featuredDetails, setFeaturedDetails] = useState<Record<string, { title: string; poster: string }>>({});
  const [featuredDraft, setFeaturedDraft] = useState({ id: "", mediaType: "tv" as "tv" | "movie" });
  const [audit, setAudit] = useState<AuditEvent[]>([]);
  const [auditFailed, setAuditFailed] = useState(false);
  const [auditNotice, setAuditNotice] = useState("");
  const [presentationLoaded, setPresentationLoaded] = useState(false);
  const [dashboardFailed, setDashboardFailed] = useState(false);
  const [restoring, setRestoring] = useState(true);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    void loadAdmin(controller.signal).catch(() => undefined).finally(() => { if (!controller.signal.aborted) setRestoring(false); });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panelRef.current?.focus();
    function keydown(event: KeyboardEvent) {
      if (selectionRef.current) return;
      if (event.key === "Escape") { event.preventDefault(); onCloseRef.current(); }
      if (event.key !== "Tab") return;
      const focusables = Array.from(panelRef.current?.querySelectorAll<HTMLElement>('button:not(:disabled),a[href],input:not(:disabled),textarea:not(:disabled),select:not(:disabled),[tabindex="0"]') ?? []).filter((node) => node.offsetParent !== null);
      const first = focusables[0], last = focusables.at(-1);
      if (!first) { event.preventDefault(); return; }
      if (event.shiftKey && (document.activeElement === first || document.activeElement === panelRef.current)) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    document.addEventListener("keydown", keydown);
    return () => { document.body.style.overflow = originalOverflow; document.removeEventListener("keydown", keydown); previous?.focus(); };
  }, []);
  async function loadAdmin(signal?: AbortSignal) {
    const configResponse = await adminFetch("/api/admin/config", { cache: "no-store", signal });
    if (!configResponse.ok || signal?.aborted) return false;
    const configData = await configResponse.json() as IptvMetadata;
    if (signal?.aborted) return false;
    setLoggedIn(true); setConfigured(Boolean(configData.configured));
    setProviderMaintenance(configData.maintenance === true);
    setProviderExpiresAt(typeof configData.expiresAt === "string" && Number.isFinite(Date.parse(configData.expiresAt)) ? configData.expiresAt : null);
    setCredentials({ server: configData.server ?? "", username: configData.username ?? "", password: "" });
    setSiteForm(configData.settings ? { ...configData.settings, socialLinks: normalizeSocialLinks(configData.settings.socialLinks) } : { ...defaultSettings, socialLinks: createDefaultSocialLinks() });
    const results = await Promise.allSettled([loadDashboard(), loadUploads(), loadPresentation()]);
    if (results.some((result) => result.status === "rejected")) setStatus("تم الدخول. تعذر تحميل بعض أقسام الإدارة؛ أعد فتح القسم للمحاولة.");
    return true;
  }

  async function adminFetch(url: string, init?: RequestInit) {
    const response = await fetch(url, init);
    if (response.status === 401 && url !== "/api/admin/login" && loggedIn) { setLoggedIn(false); setStatus("انتهت جلسة الإدارة. سجّل الدخول مجددًا."); }
    if (response.ok && init?.method && init.method !== "GET") {
      const data = await response.clone().json().catch(() => null) as { auditWarning?: string } | null;
      if (data?.auditWarning) setAuditNotice(data.auditWarning);
    }
    return response;
  }

  async function loadDashboard() {
    setDashboardFailed(false);
    const results = await Promise.allSettled([
      adminFetch("/api/admin/dashboard", { cache: "no-store" }).then(async (response) => { if (!response.ok) throw new Error("تعذر قراءة أعداد المحتوى."); setDashboard(await response.json() as Dashboard); }),
      adminFetch("/api/admin/analytics", { cache: "no-store" }).then(async (response) => { if (!response.ok) throw new Error("تعذر قراءة الزيارات."); const data = await response.json() as { stats: VisitStats }; if (!data.stats || Object.values(data.stats).some((value) => typeof value !== "number" || !Number.isFinite(value))) throw new Error("إحصاءات غير مكتملة."); setStats(data.stats); }),
    ]);
    if (results.some((result) => result.status === "rejected")) setDashboardFailed(true);
  }

  async function loadPresentation() {
    try { const response = await adminFetch("/api/admin/presentation", { cache: "no-store" }); if (!response.ok) throw new Error("تعذر قراءة إعدادات الرئيسية."); const next = validatePresentation(await response.json()); setPresentation(next); setPresentationLoaded(true); void loadFeaturedDetails(next); }
    catch (error) { setPresentationLoaded(false); setStatus(error instanceof Error ? error.message : "تعذر قراءة إعدادات الرئيسية."); }
  }

  async function loadAudit() {
    setAuditFailed(false);
    try { const response = await adminFetch("/api/admin/audit", { cache: "no-store" }); if (!response.ok) throw new Error("تعذر قراءة السجل."); const data = await response.json() as { events: AuditEvent[]; partial?: boolean }; setAudit(data.events); setAuditFailed(Boolean(data.partial)); }
    catch { setAuditFailed(true); }
  }

  function moveFeatured(index: number, offset: number) {
    setPresentation((current) => { const items = [...current.featured]; const next = index + offset; if (next < 0 || next >= items.length) return current; [items[index], items[next]] = [items[next], items[index]]; return { ...current, featured: items }; });
  }

  function moveSection(index: number, offset: number) {
    setPresentation((current) => { const sections = [...current.sections]; const next = index + offset; if (next < 0 || next >= sections.length) return current; [sections[index], sections[next]] = [sections[next], sections[index]]; return { ...current, sections }; });
  }

  async function verifiedFeatured(identity: { id: string; mediaType: "tv" | "movie" }) {
    const response = await adminFetch(`/api/cinema/title?${new URLSearchParams({ id: identity.id, type: identity.mediaType })}`, { cache: "no-store" });
    const data = await response.json() as { item?: { tmdbId?: string; mediaType?: string; title?: string; poster?: string }; error?: string };
    if (!response.ok || data.item?.tmdbId !== identity.id || data.item.mediaType !== identity.mediaType || !data.item.title) throw new Error(data.error ?? "تعذر التحقق من العمل في TMDb.");
    return { title: data.item.title, poster: data.item.poster ?? "" };
  }

  async function loadFeaturedDetails(next: SitePresentation) {
    const verified: Record<string, { title: string; poster: string }> = {};
    for (let offset = 0; offset < next.featured.length; offset += 4) {
      const results = await Promise.allSettled(next.featured.slice(offset, offset + 4).map(async (identity) => ({ key: `${identity.mediaType}:${identity.id}`, details: await verifiedFeatured(identity) })));
      for (const result of results) if (result.status === "fulfilled") verified[result.value.key] = result.value.details;
    }
    setFeaturedDetails((current) => ({ ...current, ...verified }));
  }

  async function addFeatured() {
    setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const identity = { ...featuredDraft, id: featuredDraft.id.trim() };
      const next = validatePresentation({ ...presentation, featured: [...presentation.featured, identity] });
      const details = await verifiedFeatured(identity);
      setFeaturedDetails((current) => ({ ...current, [`${identity.mediaType}:${identity.id}`]: details })); setPresentation(next); setFeaturedDraft({ id: "", mediaType: "tv" }); setStatus(`أُضيف «${details.title}» إلى القائمة. احفظ الرئيسية لتطبيق التغيير.`);
    } catch (error) { setStatus(error instanceof Error ? error.message : "معرف غير صالح."); }
    finally { setBusy(false); }
  }

  async function savePresentation(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const next = validatePresentation(presentation);
      const response = await adminFetch("/api/admin/presentation", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(next) });
      const result = await response.json() as { presentation?: SitePresentation; error?: string };
      if (!response.ok || !result.presentation) throw new Error(result.error ?? "تعذر حفظ الرئيسية.");
      setPresentation(validatePresentation(result.presentation)); refreshPublicCatalog(); setStatus("حُفظ ترتيب الرئيسية والبنرات، وسيظهر للزوار بعد تحديث المحتوى.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر حفظ الرئيسية."); }
    finally { setBusy(false); }
  }

  function refreshPublicCatalog() { window.dispatchEvent(new Event("mk2-catalog-refresh")); }

  async function loadUploads() {
    try {
    const response = await adminFetch("/api/admin/uploads", { cache: "no-store" });
    if (!response.ok) return;
    const data = await response.json() as { series: UploadedSeries[] };
    if (!Array.isArray(data.series)) throw new Error("استجابة المكتبة غير مكتملة.");
    setManagedSeries(data.series);
    setSelectedSeriesId((current) => current || data.series[0]?.id || "");
    } catch { setStatus("تعذر تحميل مسلسلات الملفات. أعد فتح القسم للمحاولة."); }
  }

  async function searchTmdb(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setAuditNotice(""); setStatus(""); setTmdbResults([]);
    try {
      const response = await adminFetch(`/api/admin/tmdb/search?q=${encodeURIComponent(tmdbQuery)}`, { cache: "no-store" });
      const data = await response.json() as { error?: string; results?: TmdbResult[] };
      if (!response.ok) throw new Error(data.error ?? "تعذر البحث في TMDB");
      setTmdbResults(data.results ?? []);
      if (!data.results?.length) setStatus("ما لقينا مسلسل بهذا الاسم في TMDB.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر البحث في TMDB"); }
    finally { setBusy(false); }
  }

  function selectTmdbResult(result: TmdbResult) {
    setSeriesForm((current) => ({ ...current, title: result.name, description: result.description, posterUrl: result.posterUrl, year: result.year }));
    setTmdbResults([]); setTmdbQuery(result.name); setStatus(`تم تعبئة بيانات «${result.name}» من TMDB. أنشئ المسلسل ثم أضف ملفات الحلقات.`);
  }

  async function createUploadedSeries(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const response = await adminFetch("/api/admin/uploads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(seriesForm) });
      const result = await response.json() as { error?: string; id?: string }; if (!response.ok || !result.id) throw new Error(result.error ?? "تعذر إنشاء المسلسل");
      setSeriesForm({ title: "", description: "", posterUrl: "", genre: "", year: "" }); setSelectedSeriesId(result.id); await loadUploads(); refreshPublicCatalog(); setStatus("حُفظ المسلسل كمسودة. ارفع الحلقات وأضف الملصق ثم انشره من القائمة.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر إنشاء المسلسل"); }
    finally { setBusy(false); }
  }

  async function uploadEpisodes(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!episodeFiles.length || !selectedSeriesId) return;
    setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const season = Number(seasonNumber); const startEpisode = Number(firstEpisodeNumber);
      for (const [index, file] of episodeFiles.entries()) {
        setStatus(`رفع الحلقة ${index + 1} من ${episodeFiles.length}: ${file.name}`);
        const title = file.name.replace(/\.[^.]+$/, "").replace(/[._-]+/g, " ").trim().slice(0, 160) || `الحلقة ${startEpisode + index}`;
        const initResponse = await adminFetch("/api/admin/uploads/init", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ seriesId: selectedSeriesId, fileName: file.name, size: file.size, season, episodeNumber: startEpisode + index, title }) });
        const init = await initResponse.json() as { error?: string; sessionId?: string; chunkSize?: number; totalParts?: number };
        if (!initResponse.ok || !init.sessionId || !init.chunkSize) throw new Error(init.error ?? `تعذر بدء رفع ${file.name}`);
        try {
          for (let part = 0; part < (init.totalParts ?? Math.ceil(file.size / init.chunkSize)); part++) {
            const chunk = file.slice(part * init.chunkSize, Math.min(file.size, (part + 1) * init.chunkSize));
            const partResponse = await adminFetch("/api/admin/uploads/part", { method: "POST", headers: { "Content-Type": "application/octet-stream", "x-upload-session": init.sessionId, "x-part-number": String(part + 1) }, body: chunk });
            if (!partResponse.ok) { const error = await partResponse.json() as { error?: string }; throw new Error(error.error ?? `تعذر رفع جزء من ${file.name}`); }
          }
          const completeResponse = await adminFetch("/api/admin/uploads/complete", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sessionId: init.sessionId }) });
          const complete = await completeResponse.json() as { error?: string };
          if (!completeResponse.ok) throw new Error(complete.error ?? `تعذر إكمال ${file.name}`);
        } catch (error) {
          await adminFetch("/api/admin/uploads/abort", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ sessionId: init.sessionId }) }).catch(() => undefined);
          throw error;
        }
      }
      setEpisodeFiles([]); if (episodeInputRef.current) episodeInputRef.current.value = ""; await loadUploads(); refreshPublicCatalog(); setStatus(`اكتمل رفع ${episodeFiles.length} حلقة.`);
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر رفع الحلقات"); }
    finally { setBusy(false); }
  }

  async function deleteUploadedEpisode(episodeId: string) {
    if (!window.confirm("حذف ملف الحلقة؟")) return;
    setBusy(true); setAuditNotice("");
    try { const response = await adminFetch(`/api/admin/uploads/episode/${encodeURIComponent(episodeId)}`, { method: "DELETE" }); const data = await response.json() as { error?: string }; if (!response.ok) throw new Error(data.error ?? "تعذر الحذف"); await loadUploads(); refreshPublicCatalog(); setStatus("تم حذف الحلقة."); }
    catch (error) { setStatus(error instanceof Error ? error.message : "تعذر حذف الحلقة"); }
    finally { setBusy(false); }
  }

  async function deleteUploadedSeries(seriesId: string) {
    if (!window.confirm("حذف المسلسل وكل حلقاته نهائيًا؟")) return;
    setBusy(true); setAuditNotice("");
    try { const response = await adminFetch(`/api/admin/uploads/series/${encodeURIComponent(seriesId)}`, { method: "DELETE" }); const data = await response.json() as { error?: string }; if (!response.ok) throw new Error(data.error ?? "تعذر الحذف"); setSelectedSeriesId(""); await loadUploads(); refreshPublicCatalog(); setStatus("تم حذف المسلسل وحلقاته."); }
    catch (error) { setStatus(error instanceof Error ? error.message : "تعذر الحذف"); }
    finally { setBusy(false); }
  }

  async function updateUploadedSeries(seriesId: string, update: { published?: boolean; title?: string; description?: string; posterUrl?: string; genre?: string; year?: string }) {
    setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const response = await adminFetch(`/api/admin/uploads/series/${encodeURIComponent(seriesId)}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(update) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "تعذر تحديث المسلسل");
      await loadUploads(); refreshPublicCatalog(); setEditingUploadId(null);
      setStatus(update.published === true ? "نُشر المسلسل وأصبح متاحًا للمستخدمين." : update.published === false ? "حُفظ المسلسل كمسودة مخفية عن الجمهور." : "تم تحديث بيانات المسلسل.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر تحديث المسلسل"); }
    finally { setBusy(false); }
  }

  function editUploadedSeries(series: UploadedSeries) {
    setEditingUploadId(series.id);
    setUploadEdit({ title: series.title, description: series.description, posterUrl: series.poster_url, genre: series.genre, year: series.year });
  }

  async function signIn(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const response = await adminFetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(login) });
      const result = await response.json() as { error?: string }; if (!response.ok) throw new Error(result.error ?? "تعذر تسجيل الدخول");
      if (!await loadAdmin()) throw new Error("تم التحقق، لكن تعذر تحميل جلسة الإدارة. أعد المحاولة."); setLogin({ username: "", password: "" }); setStatus("تم تسجيل الدخول.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر تسجيل الدخول"); }
    finally { setBusy(false); setLogin((current) => ({ ...current, password: "" })); }
  }

  async function saveIptv(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const response = await adminFetch("/api/admin/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(credentials) });
      const result = await response.json() as { error?: string; server?: string }; if (!response.ok) throw new Error(result.error ?? "تعذر الحفظ");
      setCredentials((value) => ({ ...value, server: result.server ?? value.server, password: "" }));
      await loadProviderStatus();
      window.dispatchEvent(new Event("mk2-catalog-refresh"));
      setStatus(`تم حفظ الاشتراك. عنوان API المستخدم: ${result.server}`);
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر الحفظ"); }
    finally { setBusy(false); }
  }

  async function loadProviderStatus() {
    const response = await adminFetch("/api/admin/config", { cache: "no-store" });
    const result = await response.json() as IptvMetadata & { error?: string };
    if (!response.ok) throw new Error(result.error ?? "تعذر قراءة حالة مكتبة MK~2.");
    setConfigured(result.configured === true);
    setProviderMaintenance(result.maintenance === true);
    setProviderExpiresAt(typeof result.expiresAt === "string" && Number.isFinite(Date.parse(result.expiresAt)) ? result.expiresAt : null);
  }

  async function saveProviderMaintenance(maintenance: boolean) {
    setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const response = await adminFetch("/api/admin/provider-maintenance", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ maintenance }) });
      const result = await response.json() as { maintenance?: boolean; error?: string };
      if (!response.ok || typeof result.maintenance !== "boolean") throw new Error(result.error ?? "تعذر حفظ وضع الصيانة.");
      setProviderMaintenance(result.maintenance);
      window.dispatchEvent(new Event("mk2-catalog-refresh"));
      setStatus(result.maintenance ? "تم إغلاق مكتبة MK~2 للصيانة. نعمل من أجلكم." : "تم إلغاء وضع الصيانة. تُتاح المكتبة عندما يكون اشتراك المشاهدة صالحًا.");
      await loadProviderStatus();
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر حفظ وضع الصيانة."); }
    finally { setBusy(false); }
  }

  async function testIptv() {
    setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const response = await adminFetch("/api/admin/test-iptv", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(credentials) });
      const result = await response.json() as { error?: string; server?: string }; if (!response.ok) throw new Error(result.error ?? "فشل الاتصال");
      setCredentials((value) => ({ ...value, server: result.server ?? value.server })); setStatus(`نجح الاتصال بالسيرفر: ${result.server}`);
    } catch (error) { setStatus(error instanceof Error ? error.message : "فشل اختبار الاتصال"); }
    finally { setBusy(false); }
  }

  async function saveSiteSettings(event: React.FormEvent<HTMLFormElement>, section: "design" | "social") {
    event.preventDefault(); setBusy(true); setAuditNotice(""); setStatus("");
    try {
      const { socialLinks, ...designSettings } = siteForm;
      const payload = section === "social" ? { socialLinks: validateSocialLinks(socialLinks) } : designSettings;
      const endpoint = section === "social" ? "/api/admin/social-links" : "/api/admin/settings";
      const response = await adminFetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const result = await response.json().catch(() => null) as { error?: string; settings: Settings } | null;
      if (!response.ok || !result?.settings) throw new Error(result?.error ?? "تعذر حفظ إعدادات الموقع. حاول مجددًا.");
      const next = { ...result.settings, socialLinks: normalizeSocialLinks(result.settings.socialLinks) };
      setSiteForm(next); onSettingsChange?.(next);
      if (section === "design") { document.body.classList.toggle("light-mode", next.defaultTheme === "light"); localStorage.removeItem("mk2-theme"); }
      setStatus(section === "social" ? "تم حفظ حسابات التواصل وتحديث ظهورها في الموقع." : "تم حفظ هوية الموقع والألوان والصور.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "تعذر حفظ إعدادات الموقع"); }
    finally { setBusy(false); }
  }

  async function signOutAdmin() {
    setBusy(true); setAuditNotice("");
    try { const response = await adminFetch("/api/admin/logout", { method: "POST" }); if (!response.ok) throw new Error("تعذر تسجيل الخروج."); setLoggedIn(false); setCredentials(emptyCredentials); setLogin({ username: "", password: "" }); setStatus(""); setAuditNotice(""); }
    catch (error) { setStatus(error instanceof Error ? error.message : "تعذر تسجيل الخروج."); }
    finally { setBusy(false); }
  }


  return <>
    <div className="feature-backdrop admin-backdrop" inert={Boolean(seriesSelection)} aria-hidden={Boolean(seriesSelection)} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section ref={panelRef} tabIndex={-1} className="admin-box" role="dialog" aria-modal="true" aria-labelledby="mk2-admin-title"><button aria-label="إغلاق لوحة الإدارة" className="feature-close" onClick={onClose}>×</button><span className="section-kicker">MK2 · منطقة محمية</span><h2 id="mk2-admin-title">مركز تحكم MK2Movie</h2><p className="admin-intro">المحتوى والمشاهدة والهوية في مساحة واحدة.</p>{restoring ? <p role="status">جارٍ التحقق من الجلسة الآمنة…</p> : !loggedIn ? <form className="admin-form" onSubmit={signIn}><label>اسم المستخدم<input value={login.username} autoComplete="username" maxLength={100} onChange={(e) => setLogin({ ...login, username: e.target.value })} required/></label><label>كلمة المرور<input type="password" value={login.password} autoComplete="current-password" maxLength={500} onChange={(e) => setLogin({ ...login, password: e.target.value })} required/></label><button className="feature-button primary" disabled={busy}>{busy ? "جارٍ التحقق…" : "دخول آمن"}</button></form> : <>
      <div className="admin-tabs" role="group" aria-label="أقسام لوحة الإدارة">{([ ["dashboard", "نظرة عامة"], ["servers", "سيرفرات المشاهدة"], ["iptv", "مكتبة IPTV"], ["uploads", "مسلسلاتي"], ["presentation", "الرئيسية والبنرات"], ["design", "هوية الموقع"], ["social", "حسابات التواصل"], ["installations", "حسابات التطبيق"], ["stats", "الزيارات"], ["audit", "سجل التعديلات"] ] as Array<[AdminTab, string]>).map(([key, label]) => <button type="button" aria-pressed={adminTab === key} className={adminTab === key ? "selected" : ""} key={key} onClick={() => { setAdminTab(key); setStatus(""); if (key === "stats" || key === "dashboard") void loadDashboard(); if (key === "audit") void loadAudit(); if (key === "presentation") void loadPresentation(); if (key === "uploads") void loadUploads(); if (key === "iptv") void loadProviderStatus().catch((error: unknown) => setStatus(error instanceof Error ? error.message : "تعذر قراءة حالة المكتبة.")); }}>{label}</button>)}</div>
      {adminTab === "dashboard" && <div className="admin-dashboard">
        <div className="admin-section-heading"><div><span className="section-kicker">حالة المنصة</span><h3>مكتبتك بالأرقام</h3></div><button type="button" className="feature-button quiet" onClick={() => void loadDashboard()}>تحديث الأعداد</button></div>
        {dashboardFailed && <p className="admin-warning" role="status">تعذر تحديث بعض الإحصاءات. جرّب التحديث مجددًا.</p>}
        <div className="admin-metrics">{([["الأفلام", dashboard?.movies], ["المسلسلات", dashboard?.series], ["المواسم", dashboard?.seasons], ["الحلقات", dashboard?.episodes]] as const).map(([label, count]) => <div key={label}><span>{label}</span><strong>{count === null || count === undefined ? "—" : count.toLocaleString("ar-SA")}</strong><small>سجلات محفوظة بالموقع</small></div>)}</div>
        <p className="admin-help">الأعداد للأعمال المضافة في قاعدة بيانات الموقع، وتشمل المسودات. مكتبة TMDb الخارجية تتغير ولا تعني توفر فيديو للمشاهدة. قد يتكرر العمل إذا أُضيف من أكثر من مصدر.</p>
        {dashboard?.partial && <p className="admin-warning">بعض جداول الإحصاءات غير متاحة؛ تظهر قيمتها بشرطة بدل أعداد تقديرية.</p>}
        <div className="admin-summary"><span>مسودات الملفات: <strong>{dashboard?.uploadedDrafts ?? "—"}</strong></span><span>سجلات بيانات مخبّأة: <strong>{dashboard?.metadataRecords ?? "—"}</strong></span></div>
        <div className="admin-quick-actions"><button type="button" onClick={() => setAdminTab("servers")}><strong>إدارة المشاهدة</strong><span>استيراد TMDb، معاينة ونشر المواسم</span></button><button type="button" onClick={() => setAdminTab("uploads")}><strong>ملفاتك ومسلسلاتك</strong><span>رفع الحلقات وتعديل بيانات المحتوى</span></button><button type="button" onClick={() => setAdminTab("presentation")}><strong>رتّب الصفحة الرئيسية</strong><span>الأعمال المميزة والأقسام الظاهرة</span></button></div>
      </div>}
      {adminTab === "presentation" && <form className="admin-form" onSubmit={savePresentation}>
        <div className="admin-section-heading"><div><h3>الرئيسية والبنرات</h3><p className="admin-help">اختيار أعمال فعلية بمعرف TMDb. يُجلب الاسم والملصق من بيانات العمل. هذه الإعدادات لا تنشر ملف فيديو.</p></div><button type="button" className="feature-button quiet" disabled={busy} onClick={() => void loadPresentation()}>إعادة التحميل</button></div>
        {!presentationLoaded ? <p className="admin-warning">لم تُحمّل الإعدادات المحفوظة. أعد المحاولة قبل تعديلها.</p> : <>
          <h4>الأعمال المميزة ({presentation.featured.length}/8)</h4>
          <div className="admin-curation-add"><label>معرف TMDb<input inputMode="numeric" maxLength={10} value={featuredDraft.id} onChange={(event) => setFeaturedDraft({ ...featuredDraft, id: event.target.value })} placeholder="المعرف الرقمي"/></label><label>النوع<select value={featuredDraft.mediaType} onChange={(event) => setFeaturedDraft({ ...featuredDraft, mediaType: event.target.value as "tv" | "movie" })}><option value="tv">مسلسل</option><option value="movie">فيلم</option></select></label><button type="button" className="feature-button quiet" disabled={busy || presentation.featured.length >= 8 || !featuredDraft.id.trim()} onClick={() => void addFeatured()}>إضافة للمميزة</button></div>
          {presentation.featured.length ? <ol className="admin-curation-list">{presentation.featured.map((item, index) => <li key={`${item.mediaType}:${item.id}`}><span className="admin-featured-title">{featuredDetails[`${item.mediaType}:${item.id}`]?.poster && <img loading="lazy" src={featuredDetails[`${item.mediaType}:${item.id}`].poster} alt=""/>}<span><strong>{featuredDetails[`${item.mediaType}:${item.id}`]?.title ?? "بيانات العمل غير محمّلة"}</strong><small>{item.mediaType === "tv" ? "مسلسل" : "فيلم"} · TMDb <bdi>{item.id}</bdi></small></span></span><div><button type="button" disabled={index === 0 || busy} onClick={() => moveFeatured(index, -1)} aria-label={`تقديم العمل ${item.id}`}>↑</button><button type="button" disabled={index === presentation.featured.length - 1 || busy} onClick={() => moveFeatured(index, 1)} aria-label={`تأخير العمل ${item.id}`}>↓</button><button type="button" disabled={busy} onClick={() => setPresentation({ ...presentation, featured: presentation.featured.filter((_, itemIndex) => itemIndex !== index) })}>إزالة</button></div></li>)}</ol> : <p className="admin-help">عند تركها فارغة يختار الموقع عملًا من المكتبة المتاحة.</p>}
          <h4>أقسام الصفحة الرئيسية</h4><ol className="admin-curation-list">{presentation.sections.map((item, index) => <li key={item.id}><label className="admin-toggle"><input type="checkbox" checked={item.enabled} onChange={(event) => setPresentation({ ...presentation, sections: presentation.sections.map((section) => section.id === item.id ? { ...section, enabled: event.target.checked } : section) })}/><span>{shelfLabels[item.id]}</span></label><div><button type="button" disabled={index === 0 || busy} onClick={() => moveSection(index, -1)} aria-label={`تقديم ${shelfLabels[item.id]}`}>↑</button><button type="button" disabled={index === presentation.sections.length - 1 || busy} onClick={() => moveSection(index, 1)} aria-label={`تأخير ${shelfLabels[item.id]}`}>↓</button></div></li>)}</ol>
          <button className="feature-button primary" disabled={busy}>{busy ? "جارٍ الحفظ…" : "حفظ الرئيسية والبنرات"}</button>
        </>}
      </form>}
      {adminTab === "audit" && <section className="admin-audit"><div className="admin-section-heading"><div><h3>سجل التعديلات المهمة</h3><p className="admin-help">آخر ٥٠ عملية من سجل يحتفظ بآخر ٢٠٠ تغيير. لا تُسجّل كلمات المرور أو روابط التشغيل أو بيانات الزوار. يبدأ التسجيل من هذا التحديث.</p></div><button type="button" className="feature-button quiet" onClick={() => void loadAudit()}>تحديث السجل</button></div>{auditFailed && <p className="admin-warning" role="status">تعذر تحميل بعض السجل أو كله. أعد المحاولة.</p>}{audit.length ? <ol className="admin-audit-list">{audit.map((event) => <li key={event.id}><div><strong>{({ "settings.update": "تحديث هوية الموقع", "social.update": "تعديل حسابات التواصل", "iptv.update": "تحديث اشتراك IPTV", "iptv.maintenance": "تغيير صيانة مكتبة MK~2", "playback.settings": "تعديل سيرفرات المشاهدة", "playback.publish": "نشر أو تعديل عمل", "playback.publish-season": "نشر موسم", "playback.delete": "حذف عمل", "upload.series.create": "إنشاء مسلسل ملفات", "upload.series.update": "تعديل مسلسل ملفات", "upload.series.delete": "حذف مسلسل ملفات", "upload.episode.complete": "إكمال رفع حلقة", "upload.episode.delete": "حذف حلقة", "presentation.update": "تعديل أقسام الرئيسية" } as Record<string, string>)[event.action] ?? "تعديل إداري"}</strong><time dateTime={event.timestamp}>{new Date(event.timestamp).toLocaleString("ar-SA")}</time></div><small><bdi>{event.target}</bdi>{event.metadata?.season !== undefined ? ` · الموسم ${event.metadata.season}` : ""}{event.metadata?.episode !== undefined ? ` · الحلقة ${event.metadata.episode}` : ""}{event.metadata?.count !== undefined ? ` · العدد ${event.metadata.count}` : ""}</small></li>)}</ol> : <p className="admin-help">لا توجد تغييرات مسجّلة بعد.</p>}</section>}
      {adminTab === "installations" && <AdminInstalledAccounts onSessionExpired={() => { setLoggedIn(false); setStatus("انتهت جلسة الإدارة. سجّل الدخول مجددًا."); }}/>}
      {adminTab === "servers" && <><p className="admin-help">TMDb يوفّر بيانات الأعمال والصور، وليس ملفات فيديو. أضف مصادر تملك حق عرضها أو يُسمح بتضمينها؛ ظهور الرابط لا يثبت توفر الحلقة أو تطابقها.</p><PlaybackAdmin/></>}
      {adminTab === "iptv" && <section className="admin-form admin-provider-maintenance" aria-label="حالة مكتبة MK~2"><label className="admin-toggle"><input type="checkbox" role="switch" checked={providerMaintenance} disabled={busy || PROVIDER_MAINTENANCE} aria-describedby="mk2-provider-maintenance-help" onChange={(event) => void saveProviderMaintenance(event.target.checked)} /><span>وضع صيانة مكتبة MK~2</span></label><p id="mk2-provider-maintenance-help" className="admin-help">يُحفظ التغيير مباشرة. عند التشغيل تظهر للزوار رسالة «{PROVIDER_MAINTENANCE_TITLE}، {PROVIDER_MAINTENANCE_MESSAGE}» ويتوقف الوصول إلى مكتبة الاشتراك، مع الاحتفاظ بإعدادات الاتصال.</p><p className="admin-help" role="status">{providerMaintenance || PROVIDER_MAINTENANCE ? "الصيانة مفعّلة." : configured ? "مكتبة الاشتراك متاحة." : "المكتبة غير متاحة؛ تحقق من صلاحية الاشتراك وإعداداته."}</p>{providerExpiresAt && <p className="admin-help">انتهاء الاشتراك التجريبي: <time dateTime={providerExpiresAt}>{new Date(providerExpiresAt).toLocaleString("ar-SA")}</time>. يقبل الاشتراك اتصال مشاهدة واحدًا؛ انتهاء صلاحيته يغلق المكتبة تلقائيًا.</p>}</section>}
      {adminTab === "iptv" && !PROVIDER_MAINTENANCE && <form className="admin-form" onSubmit={saveIptv}><p className="admin-help">أدخل عنوان Xtream API الذي يوفّره مزوّد اشتراكك. رابط تحميل التطبيق أو رقم سيرفر APEX ليسا عنوان API مباشرًا. تُحفظ بيانات الاشتراك في إعدادات الخادم.</p><label>عنوان Xtream API المباشر<input type="url" placeholder="https://عنوان-السيرفر-من-المزود" value={credentials.server} onChange={(e) => setCredentials({ ...credentials, server: e.target.value })} required/></label><label>اسم مستخدم الاشتراك<input value={credentials.username} autoComplete="off" onChange={(e) => setCredentials({ ...credentials, username: e.target.value })} required/></label><label>كلمة مرور الاشتراك<input type="password" autoComplete="new-password" placeholder={configured ? "أدخلها مجددًا لتحديث الاتصال" : "كلمة مرور مزود IPTV"} value={credentials.password} onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} required/></label><div className="button-row"><button type="button" className="feature-button quiet" disabled={busy} onClick={() => void testIptv()}>{busy ? "جارٍ الاختبار…" : "اختبار الاتصال"}</button><button className="feature-button primary" disabled={busy}>{busy ? "جارٍ الحفظ…" : "حفظ الاشتراك"}</button></div></form>}
      {adminTab === "uploads" && <div className="uploads-admin">
        <form className="admin-form upload-form tmdb-search-form" onSubmit={searchTmdb}>
          <h3>جلب بيانات مسلسل من TMDB</h3>
          <label>ابحث باسم المسلسل<input value={tmdbQuery} onChange={(e) => setTmdbQuery(e.target.value)} minLength={2} maxLength={100} placeholder="مثال: اسم المسلسل بالعربي أو الإنجليزي" required/></label>
          <button className="feature-button quiet" disabled={busy}>{busy ? "جارٍ البحث…" : "بحث في TMDB"}</button>
          {tmdbResults.length > 0 && <div className="tmdb-results" aria-label="نتائج بحث TMDB">{tmdbResults.map((result) => <button type="button" className="tmdb-result" key={result.id} onClick={() => selectTmdbResult(result)}>{result.posterUrl ? <img src={result.posterUrl} alt="" loading="lazy"/> : <span className="tmdb-no-poster">TMDB</span>}<span><strong>{result.name}</strong><small>{[result.year, result.rating ? `★ ${result.rating}` : ""].filter(Boolean).join(" · ")}</small></span></button>)}</div>}
          <p className="admin-help">يعبي الاسم والوصف والملصق تلقائيًا. TMDB يوفر بيانات وصورًا فقط؛ أضف ملفات فيديو تملك حق نشرها كي تعمل المشاهدة.</p>
        </form>
        <form className="admin-form upload-form" onSubmit={createUploadedSeries}>
          <h3>إضافة مسلسل</h3>
          <label>اسم المسلسل<input value={seriesForm.title} onChange={(e) => setSeriesForm({ ...seriesForm, title: e.target.value })} maxLength={120} required/></label>
          <label>وصف مختصر<textarea value={seriesForm.description} onChange={(e) => setSeriesForm({ ...seriesForm, description: e.target.value })} maxLength={1000} rows={2}/></label>
          <label>رابط الملصق (اختياري)<input type="url" placeholder="https://.../poster.jpg" value={seriesForm.posterUrl} onChange={(e) => setSeriesForm({ ...seriesForm, posterUrl: e.target.value })}/></label>
          <div className="design-row"><label>التصنيف<input value={seriesForm.genre} onChange={(e) => setSeriesForm({ ...seriesForm, genre: e.target.value })} maxLength={80}/></label><label>السنة<input inputMode="numeric" value={seriesForm.year} onChange={(e) => setSeriesForm({ ...seriesForm, year: e.target.value })} placeholder="2026" maxLength={4}/></label></div>
          <button className="feature-button primary" disabled={busy}>{busy ? "جارٍ الحفظ…" : "إنشاء المسلسل"}</button>
        </form>
        <form className="admin-form upload-form" onSubmit={uploadEpisodes}>
          <h3>رفع حلقات من الجهاز</h3>
          <label>المسلسل<select value={selectedSeriesId} onChange={(e) => setSelectedSeriesId(e.target.value)} required><option value="">اختر مسلسلًا</option>{managedSeries.map((series) => <option key={series.id} value={series.id}>{series.title}</option>)}</select></label>
          <div className="design-row"><label>رقم الموسم<input type="number" min="1" max="999" value={seasonNumber} onChange={(e) => setSeasonNumber(e.target.value)} required/></label><label>رقم أول حلقة<input type="number" min="1" max="9999" value={firstEpisodeNumber} onChange={(e) => setFirstEpisodeNumber(e.target.value)} required/></label></div>
          <label>ملفات الفيديو (يمكن اختيار أكثر من حلقة)<input ref={episodeInputRef} type="file" accept=".mp4,.m4v,.mov,.webm,video/mp4,video/quicktime,video/webm" multiple onChange={(e) => setEpisodeFiles(Array.from(e.currentTarget.files ?? []))} required/></label>
          {episodeFiles.length > 0 && <p className="admin-help">{episodeFiles.length} ملف · {(episodeFiles.reduce((total, file) => total + file.size, 0) / (1024 * 1024)).toFixed(1)} ميجابايت إجمالًا. الحد الأقصى لكل ملف 1 جيجابايت. تُرفع الملفات بالترتيب الذي اخترته.</p>}
          <button className="feature-button primary" disabled={busy || !managedSeries.length || !episodeFiles.length}>{busy ? "جارٍ رفع الملفات…" : "رفع الحلقات"}</button>
        </form>
        <div className="managed-series-list"><h3>مسلسلاتك وحلقاتها</h3><p className="admin-help">المسودة لا تظهر للجمهور. أضف ملصقًا وحلقات، ثم انشر المسلسل عندما يصبح جاهزًا.</p>{managedSeries.length ? managedSeries.map((series) => <section className="managed-series" key={series.id}>
          <div className="managed-series-heading"><div><strong>{series.title}</strong><span>{series.episodes.length} حلقة · {series.is_published ? "منشور" : "مسودة"}</span></div><span className={`upload-publish-state ${series.is_published ? "is-public" : ""}`}>{series.is_published ? "متاح للجمهور" : "مخفي"}</span></div>
          <div className="managed-series-actions">
            <button type="button" className="feature-button primary" disabled={busy || (!series.is_published && (!series.poster_url || !series.episodes.length))} onClick={() => void updateUploadedSeries(series.id, { published: !series.is_published })}>{series.is_published ? "إخفاء من الموقع" : "نشر المسلسل"}</button>
            <button type="button" className="feature-button quiet" disabled={busy} onClick={() => editUploadedSeries(series)}>تعديل البيانات</button>
            {series.episodes.length > 0 && <button type="button" className="feature-button quiet" disabled={busy} onClick={() => setSeriesSelection({ id: series.id, source: "upload", title: series.title, poster: series.poster_url })}>معاينة الحلقات</button>}
            <button type="button" className="delete-upload" disabled={busy} onClick={() => void deleteUploadedSeries(series.id)}>حذف المسلسل</button>
          </div>
          {!series.is_published && (!series.poster_url || !series.episodes.length) && <p className="admin-help">قبل النشر: {!series.poster_url ? "أضف ملصق المسلسل" : ""}{!series.poster_url && !series.episodes.length ? " و" : ""}{!series.episodes.length ? "ارفع حلقة واحدة على الأقل" : ""}.</p>}
          {editingUploadId === series.id && <form className="admin-form managed-series-edit" onSubmit={(event) => { event.preventDefault(); void updateUploadedSeries(series.id, uploadEdit); }}>
            <label>اسم المسلسل<input value={uploadEdit.title} maxLength={120} required onChange={(event) => setUploadEdit({ ...uploadEdit, title: event.target.value })}/></label>
            <label>رابط الملصق<input type="url" value={uploadEdit.posterUrl} maxLength={2048} onChange={(event) => setUploadEdit({ ...uploadEdit, posterUrl: event.target.value })}/></label>
            <label>الوصف<textarea rows={2} maxLength={1000} value={uploadEdit.description} onChange={(event) => setUploadEdit({ ...uploadEdit, description: event.target.value })}/></label>
            <div className="design-row"><label>سنة العرض<input value={uploadEdit.year} maxLength={4} inputMode="numeric" onChange={(event) => setUploadEdit({ ...uploadEdit, year: event.target.value })}/></label><label>التصنيف<input value={uploadEdit.genre} maxLength={80} onChange={(event) => setUploadEdit({ ...uploadEdit, genre: event.target.value })}/></label></div>
            <div className="button-row"><button className="feature-button primary" disabled={busy}>حفظ البيانات</button><button type="button" className="feature-button quiet" disabled={busy} onClick={() => setEditingUploadId(null)}>إلغاء</button></div>
          </form>}
          {series.episodes.length ? <details className="managed-series-episodes"><summary>عرض الحلقات ({series.episodes.length})</summary><ul>{series.episodes.map((episode) => <li key={episode.id}><span>م{episode.season} · ح{episode.episode_number} — {episode.title} <small>({(episode.size_bytes / (1024 * 1024)).toFixed(0)} م.ب)</small></span><button type="button" className="delete-upload" disabled={busy} onClick={() => void deleteUploadedEpisode(episode.id)}>حذف</button></li>)}</ul></details> : <p className="admin-help">لم تُرفع حلقات بعد.</p>}
        </section>) : <p className="admin-help">لا توجد مسلسلات مضافة.</p>}</div>
      </div>}
      {adminTab === "design" && <form className="admin-form" onSubmit={(event) => void saveSiteSettings(event, "design")}><label>اسم الموقع<input value={siteForm.siteName} onChange={(e) => setSiteForm({ ...siteForm, siteName: e.target.value })} maxLength={60} required/></label><label>رابط صورة الشعار<input type="url" placeholder="https://.../logo.png" value={siteForm.logoUrl} onChange={(e) => setSiteForm({ ...siteForm, logoUrl: e.target.value })}/></label><label>عنوان الواجهة<input value={siteForm.heroTitle} onChange={(e) => setSiteForm({ ...siteForm, heroTitle: e.target.value })} maxLength={100} required/></label><label>وصف الواجهة<textarea value={siteForm.heroText} onChange={(e) => setSiteForm({ ...siteForm, heroText: e.target.value })} maxLength={300} rows={3}/></label><label>رابط صورة الواجهة<input type="url" value={siteForm.heroImage} onChange={(e) => setSiteForm({ ...siteForm, heroImage: e.target.value })}/></label><div className="design-row"><label>لون الواجهة<input type="color" value={siteForm.accentColor} onChange={(e) => setSiteForm({ ...siteForm, accentColor: e.target.value })}/></label><label>الوضع الافتراضي<select value={siteForm.defaultTheme} onChange={(e) => setSiteForm({ ...siteForm, defaultTheme: e.target.value as "dark" | "light" })}><option value="dark">ليلي</option><option value="light">فاتح</option></select></label></div><button className="feature-button primary" disabled={busy}>{busy ? "جارٍ الحفظ…" : "حفظ الهوية"}</button></form>}
      {adminTab === "social" && <form className="admin-form social-admin-form" onSubmit={(event) => void saveSiteSettings(event, "social")}><SocialAccountsFields value={siteForm.socialLinks} onChange={(socialLinks) => setSiteForm((current) => ({ ...current, socialLinks }))} busy={busy}/><button className="feature-button primary" disabled={busy}>{busy ? "جارٍ الحفظ…" : "حفظ حسابات التواصل"}</button></form>}
      {adminTab === "stats" && <><div className="admin-section-heading"><h3>إحصاءات الزيارات</h3><button type="button" className="feature-button quiet" onClick={() => void loadDashboard()}>تحديث الزيارات</button></div>{dashboardFailed && <p className="admin-warning" role="status">تعذر تحديث بعض الإحصاءات؛ الأرقام السابقة إن وجدت قد لا تكون حديثة.</p>}<div className="stats-grid"><div><strong>{stats?.views ?? "—"}</strong><span>مشاهدة صفحة إجمالًا</span></div><div><strong>{stats?.todayViews ?? "—"}</strong><span>زيارة اليوم</span></div><div><strong>{stats?.uniqueVisitors ?? "—"}</strong><span>زوار مميزون حسب اليوم</span></div><div><strong>{stats?.todayUnique ?? "—"}</strong><span>زوار اليوم</span></div><p>الإحصاءات مجمّعة ومجهولة؛ لا يعرض الموقع أسماء الزوار أو عناوين IP.</p></div></>}
      <button className="admin-logout" disabled={busy} onClick={() => void signOutAdmin()}>تسجيل الخروج من الإدارة</button>
    </>}{status && <p className="admin-status" role="status">{status}</p>}{auditNotice && <p className="admin-warning" role="status">{auditNotice}</p>}<div className="admin-security">جلسة محمية بملف ارتباط آمن · لا تُخزّن كلمات المرور في المتصفح.</div></section></div>
    {seriesSelection && <div className="admin-preview-layer"><SeriesDetails key={`${seriesSelection.source}:${seriesSelection.id}`} selection={seriesSelection} onClose={() => setSeriesSelection(null)}/></div>}
  </>;
}
