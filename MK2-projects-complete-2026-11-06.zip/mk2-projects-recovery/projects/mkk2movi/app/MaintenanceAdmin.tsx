"use client";

import AdminPanel from "./AdminPanel";

/** Keep administration available without mounting the public library. */
export default function MaintenanceAdmin() {
  return <AdminPanel onClose={() => window.location.assign("/")} />;
}
