"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import "./published-series-library.css";

export type PublishedSeriesItem = {
  id: string;
  type: "series";
  name: string;
  poster: string;
  genre: string;
  rating: string;
  year: string;
  originalTitle?: string;
  source?: "upload" | "embed";
  description?: string;
  episodeCount?: number;
  seasons?: number[];
};

type CatalogResponse = {
  series?: unknown;
  playbackUnavailable?: boolean;
  uploadsUnavailable?: boolean;
  uploadUnavailable?: boolean;
  error?: string;
};

const countFormat = new Intl.NumberFormat("ar");
const loadError = "تعذّر تحميل مسلسلات الموقع. حاول مرة أخرى.";

function publishedItems(value: unknown): PublishedSeriesItem[] {
  if (!Array.isArray(value)) throw new Error(loadError);
  const items: PublishedSeriesItem[] = [];
  const seen = new Set<string>();
  for (const valueItem of value) {
    if (!valueItem || typeof valueItem !== "object") continue;
    const item = valueItem as Record<string, unknown>;
    if (item.type !== "series" || typeof item.id !== "string" || !item.id || typeof item.name !== "string" || !item.name.trim()) continue;
    if (item.published === false || item.isPublished === false || item.status === "draft") continue;
    const source = item.source === "upload" || item.source === "embed" ? item.source : undefined;
    const episodeCount = typeof item.episodeCount === "number" && Number.isInteger(item.episodeCount) && item.episodeCount >= 0 ? item.episodeCount : undefined;
    const seasons = Array.isArray(item.seasons) ? [...new Set(item.seasons.filter((season): season is number => typeof season === "number" && Number.isInteger(season) && season >= 0))].sort((a, b) => a - b) : undefined;
    if (source === "upload" && episodeCount === 0) continue;
    const key = `${source ?? "provider"}:${item.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    items.push({
      id: item.id,
      type: "series",
      name: item.name,
      poster: typeof item.poster === "string" ? item.poster : "",
      genre: typeof item.genre === "string" && item.genre.trim().toLocaleLowerCase() !== item.name.trim().toLocaleLowerCase() ? item.genre : "",
      rating: typeof item.rating === "string" ? item.rating : "",
      year: typeof item.year === "string" ? item.year : "",
      originalTitle: typeof item.originalTitle === "string" ? item.originalTitle : undefined,
      source,
      description: typeof item.description === "string" ? item.description : undefined,
      episodeCount,
      seasons,
    });
  }
  return items.sort((a, b) => Number(!a.source) - Number(!b.source));
}

function PlayIcon() {
  return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.7c0-.8.9-1.3 1.6-.9l10 6.3c.7.4.7 1.4 0 1.8l-10 6.3c-.7.4-1.6-.1-1.6-.9V5.7Z" /></svg>;
}

function watchLabel(item: PublishedSeriesItem) {
  if (item.seasons?.length === 1) return item.seasons[0] === 0 ? "الحلقات الخاصة" : `الموسم ${item.seasons[0]}`;
  if (item.seasons?.length) {
    const regularSeasons = item.seasons.filter((season) => season > 0);
    return [regularSeasons.length ? `المواسم ${regularSeasons.join("، ")}` : "", item.seasons.includes(0) ? "حلقات خاصة" : ""].filter(Boolean).join(" · ");
  }
  if (item.episodeCount !== undefined) return `${countFormat.format(item.episodeCount)} حلقة مضافة`;
  return "المواسم والحلقات";
}

function SeriesPoster({ item }: { item: PublishedSeriesItem }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [item.poster]);
  return <span className="published-series-poster">
    {item.poster && !failed ? <img src={item.poster} alt={`ملصق ${item.name}`} loading="lazy" decoding="async" onError={() => setFailed(true)} /> : <span className="published-series-no-poster"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><rect x="7" y="12" width="34" height="25" rx="5" /><path d="m17 6 7 6 7-6M18 42h12m-6-5v5m-3-17 9 5-9 5z" /></svg><span>{item.name}</span></span>}
    <span className="published-series-badge">مسلسل</span>
    {Number(item.rating) > 0 && <span className="published-series-poster-rating"><span aria-hidden="true">★</span><span aria-label={`التقييم ${item.rating} من 10`}>{item.rating}</span></span>}
    <span className="published-series-play"><PlayIcon /></span>
  </span>;
}

export default function PublishedSeriesLibrary({ onOpen }: { onOpen: (item: PublishedSeriesItem) => void }) {
  const [items, setItems] = useState<PublishedSeriesItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [unavailable, setUnavailable] = useState(false);
  const activeRequest = useRef<AbortController | null>(null);
  const requestId = useRef(0);
  const lastRequest = useRef(0);

  const load = useCallback(async () => {
    activeRequest.current?.abort();
    const controller = new AbortController();
    activeRequest.current = controller;
    const currentRequest = ++requestId.current;
    lastRequest.current = Date.now();
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/catalog", { cache: "no-store", signal: controller.signal });
      const data = await response.json() as CatalogResponse;
      if (controller.signal.aborted || currentRequest !== requestId.current) return;
      if (!response.ok) throw new Error(data.error || loadError);
      const nextItems = publishedItems(data.series);
      const uploadsUnavailable = data.uploadsUnavailable === true || data.uploadUnavailable === true;
      const playbackUnavailable = data.playbackUnavailable === true;
      setItems((previous) => {
        const availableIds = new Set(nextItems.map((item) => `${item.source ?? "provider"}:${item.id}`));
        const retainedItems = previous.filter((item) => (item.source === "embed" && playbackUnavailable || item.source === "upload" && uploadsUnavailable) && !availableIds.has(`${item.source}:${item.id}`));
        return [...nextItems, ...retainedItems].sort((a, b) => Number(!a.source) - Number(!b.source));
      });
      setUnavailable(uploadsUnavailable || playbackUnavailable);
      setLoaded(true);
    } catch (failure) {
      if (controller.signal.aborted || currentRequest !== requestId.current) return;
      setError(failure instanceof Error ? failure.message : loadError);
    } finally {
      if (!controller.signal.aborted && currentRequest === requestId.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const refresh = () => { void load(); };
    const refreshVisible = () => {
      if (document.visibilityState === "visible" && Date.now() - lastRequest.current > 1000) void load();
    };
    window.addEventListener("mk2-catalog-refresh", refresh);
    window.addEventListener("focus", refreshVisible);
    document.addEventListener("visibilitychange", refreshVisible);
    const interval = window.setInterval(refreshVisible, 30000);
    return () => {
      window.removeEventListener("mk2-catalog-refresh", refresh);
      window.removeEventListener("focus", refreshVisible);
      document.removeEventListener("visibilitychange", refreshVisible);
      window.clearInterval(interval);
      activeRequest.current?.abort();
      requestId.current += 1;
    };
  }, [load]);

  if (loaded && !items.length && !error && !unavailable) return null;

  return <section className="published-series-library" dir="rtl" aria-labelledby="published-series-heading" aria-busy={loading}>
    <div className="published-series-heading">
      <div><span className="section-kicker">اختيارات MK2</span><h2 id="published-series-heading">مسلسلات الموقع</h2><p>كل مسلسل في مكان واحد، مع مواسمه وحلقاته.</p></div>
      {items.length > 0 && <span className="published-series-count"><span aria-hidden="true" />{countFormat.format(items.length)} مسلسل</span>}
    </div>
    {!loaded && loading ? <div className="published-series-loading" role="status"><span className="published-series-spinner" aria-hidden="true" /><span>نجهّز اختيارات الموقع…</span></div> : items.length > 0 && <div className="published-series-grid" aria-label="مسلسلات الموقع المنشورة">
      {items.map((item) => <button type="button" className="published-series-card" key={`${item.source ?? "provider"}:${item.id}`} data-published-series-id={item.id} onClick={() => onOpen(item)} aria-label={`عرض مسلسل ${[item.name, item.year, item.originalTitle !== item.name ? item.originalTitle : ""].filter(Boolean).join(" · ")} · ${watchLabel(item)}`}>
        <SeriesPoster item={item} />
        <span className="published-series-card-info">
          <span className="published-series-title-row"><span className="published-series-title">{item.name}</span>{item.year && <span className="published-series-year" aria-label={`سنة الإصدار ${item.year}`}>{item.year}</span>}</span>
          {item.originalTitle && item.originalTitle !== item.name && <span className="published-series-original-title" dir="auto">{item.originalTitle}</span>}
          {item.genre && <span className="published-series-genre">{item.genre}</span>}
          <span className="published-series-watch"><span>{watchLabel(item)}</span><span className="published-series-arrow" aria-hidden="true">←</span></span>
        </span>
      </button>)}
    </div>}
    {(error || unavailable) && <div className="published-series-notice" role="alert"><p>{error || "تعذّر تحديث بعض المسلسلات حاليًا. حاول مرة أخرى."}</p><button type="button" disabled={loading} onClick={() => void load()}>{loading ? "جارٍ التحديث…" : "إعادة المحاولة"}</button></div>}
  </section>;
}
