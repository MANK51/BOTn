"use client";

import { type FormEvent, useEffect, useRef, useState } from "react";
import ShareButton from './share-button';

function HeartIcon({ className = "", filled = false }: { className?: string; filled?: boolean }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill={filled ? "currentColor" : "none"} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" />
    </svg>
  );
}

function ArrowIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M19 12H5m6-6-6 6 6 6" />
    </svg>
  );
}

function HeartCanvas({ replay }: { replay: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;

    const logicalSize = 620;
    const stamps: Array<{ x: number; y: number }> = [];
    for (let scale = 11; scale <= 16; scale += 1) {
      for (let point = 0; point < 120; point += 1) {
        const angle = (point / 120) * Math.PI * 2;
        const x = 16 * Math.pow(Math.sin(angle), 3);
        const y = 13 * Math.cos(angle) - 5 * Math.cos(2 * angle) - 2 * Math.cos(3 * angle) - Math.cos(4 * angle);
        stamps.push({ x: logicalSize / 2 + x * scale, y: 268 - y * scale });
      }
    }

    let frame = 0;
    let drawn = 0;
    let startTime: number | null = null;
    let disposed = false;
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");

    const configure = () => {
      const pixelRatio = Math.min(window.devicePixelRatio || 1, 3);
      const displaySize = canvas.getBoundingClientRect().width || logicalSize;
      const resolution = Math.round(displaySize * pixelRatio);
      canvas.width = resolution;
      canvas.height = resolution;
      context.setTransform(resolution / logicalSize, 0, 0, resolution / logicalSize, 0, 0);
      context.clearRect(0, 0, logicalSize, logicalSize);
      context.font = '7px Arial, sans-serif';
      context.textAlign = "center";
      context.textBaseline = "middle";
      context.fillStyle = "#ffb6c1";
      context.shadowColor = "rgba(255, 182, 193, 0.32)";
      context.shadowBlur = 2;
      for (let index = 0; index < drawn; index += 1) {
        context.fillText("I love you", stamps[index].x, stamps[index].y);
      }
    };

    const drawTo = (count: number) => {
      while (drawn < count) {
        const stamp = stamps[drawn];
        context.fillText("I love you", stamp.x, stamp.y);
        drawn += 1;
      }
    };

    const animate = (timestamp: number) => {
      if (disposed) return;
      if (startTime === null) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / 35000, 1);
      drawTo(Math.floor(progress * stamps.length));
      if (progress < 1) frame = window.requestAnimationFrame(animate);
    };

    const onPreferenceChange = () => {
      if (preference.matches) {
        window.cancelAnimationFrame(frame);
        drawTo(stamps.length);
      }
    };

    configure();
    if (preference.matches) drawTo(stamps.length);
    else frame = window.requestAnimationFrame(animate);

    const observer = new ResizeObserver(configure);
    observer.observe(canvas);
    preference.addEventListener("change", onPreferenceChange);

    return () => {
      disposed = true;
      window.cancelAnimationFrame(frame);
      observer.disconnect();
      preference.removeEventListener("change", onPreferenceChange);
    };
  }, [replay]);

  return <canvas ref={canvasRef} className="heart-canvas" role="img" aria-label="قلب وردي مرسوم بكلمات I love you" />;
}

export default function HomePage() {
  const [name, setName] = useState("");
  const [visitorName, setVisitorName] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [replay, setReplay] = useState(0);
  const [incomingShare, setIncomingShare] = useState<{ id: string; kind: "general" | "named"; recipientName: string | null } | null>(null);
  const [loadingShare, setLoadingShare] = useState(true);
  const [shareLinkError, setShareLinkError] = useState("");
  const registeredVisitors = useRef(new Map<string, { id: string; name: string }>());
  const registeringVisitors = useRef(new Map<string, Promise<{ id: string; name: string }>>());
  const visitRequestIds = useRef(new Map<string, string>());
  const nameInputRef = useRef<HTMLInputElement>(null);
  const heartHeadingRef = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    let controller: AbortController | null = null;
    async function loadIncomingShare() {
      controller?.abort();
      controller = new AbortController();
      const signal = controller.signal;
      setLoadingShare(true);
      setIncomingShare(null);
      setShareLinkError("");
      setVisitorName(null);
      setName("");
      setError("");
      const params = new URLSearchParams(window.location.search);
      if (!params.has("s")) { setLoadingShare(false); return; }
      try {
        const response = await fetch(`/api/shares?shareId=${encodeURIComponent(params.get("s") || "")}`, { signal });
        const result = await response.json().catch(() => null) as { share?: { id: string; kind: "general" | "named"; recipientName: string | null } } | null;
        if (signal.aborted) return;
        if (!response.ok || !result?.share?.id) throw new Error("هذا الرابط ما عاد يفتح، بس تقدر تكتب اسمك وتفتح قلبك ❤️");
        setIncomingShare(result.share);
        if (result.share.kind === "named") setName(result.share.recipientName || "");
      } catch (problem) {
        if (!signal.aborted) setShareLinkError(problem instanceof Error && problem.message.includes("هذا الرابط") ? problem.message : "تعذّر فتح المشاركة. تقدر تدخل باسمك وتفتح قلبك ❤️");
      } finally { if (!signal.aborted) setLoadingShare(false); }
    }
    void loadIncomingShare();
    window.addEventListener("popstate", loadIncomingShare);
    return () => { controller?.abort(); window.removeEventListener("popstate", loadIncomingShare); };
  }, []);

  async function ensureVisitor(candidate: string): Promise<{ id: string; name: string }> {
    if (loadingShare) throw new Error("لحظة، نفتح المشاركة…");
    const cleanName = (incomingShare?.kind === "named" ? incomingShare.recipientName || "" : candidate).trim().replace(/\s+/g, " ");
    if (!cleanName || cleanName.length > 40) throw new Error("اكتب اسمك، بحد أقصى ٤٠ حرفًا.");
    // A visit belongs to this name and this incoming link for this page session.
    const key = JSON.stringify([incomingShare?.id || null, cleanName]);
    const existing = registeredVisitors.current.get(key);
    if (existing) { setName(existing.name); return existing; }
    const pending = registeringVisitors.current.get(key);
    if (pending) return pending;
    if (!visitRequestIds.current.has(key)) visitRequestIds.current.set(key, crypto.randomUUID());
    const registration = (async () => {
      const response = await fetch("/api/visits", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: cleanName, requestId: visitRequestIds.current.get(key), ...(incomingShare ? { sourceShareId: incomingShare.id } : {}) }),
      });
      const result = await response.json().catch(() => null) as { id?: string; name?: string; error?: string } | null;
      if (!response.ok || !result?.id || !result?.name) throw new Error(result?.error || "ما قدرنا نحفظ اسمك. جرّب مرة ثانية.");
      const record = { id: result.id, name: result.name };
      registeredVisitors.current.set(key, record);
      registeredVisitors.current.set(JSON.stringify([incomingShare?.id || null, result.name]), record);
      setName(record.name);
      return record;
    })();
    registeringVisitors.current.set(key, registration);
    try { return await registration; }
    finally { registeringVisitors.current.delete(key); }
  }

  useEffect(() => {
    if (!visitorName) return;
    heartHeadingRef.current?.focus({ preventScroll: true });
    const resetPosition = () => window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
    const frame = window.requestAnimationFrame(resetPosition);
    const timer = window.setTimeout(resetPosition, 350);
    return () => { window.cancelAnimationFrame(frame); window.clearTimeout(timer); };
  }, [visitorName]);

  async function enterSite(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting || loadingShare) return;
    const cleanName = name.trim().replace(/\s+/g, " ");
    if (!cleanName || cleanName.length > 40) {
      setError("اكتب اسمك، بحد أقصى ٤٠ حرفًا.");
      nameInputRef.current?.focus();
      return;
    }

    setSubmitting(true);
    setError("");
    try {
      const record = await ensureVisitor(cleanName);
      nameInputRef.current?.blur();
      setVisitorName(record.name);
      setReplay(0);
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : "تعذّر الاتصال. جرّب مرة ثانية.");
    } finally {
      setSubmitting(false);
    }
  }

  function startAgain() {
    setVisitorName(null);
    setName(incomingShare?.kind === "named" ? incomingShare.recipientName || "" : "");
    setError("");
    if (incomingShare?.kind !== "named") window.requestAnimationFrame(() => nameInputRef.current?.focus());
  }

  return (
    <div className={`site-shell ${visitorName ? "is-open" : ""}`} dir="rtl">
      <header className="site-header">
        <a className="brand" href="/" aria-label="لك قلب، الصفحة الرئيسية">
          <HeartIcon className="brand-heart" />
          <span>لك قلب</span>
        </a>
        <div className="header-actions">
          <ShareButton senderName={visitorName || name} onEnsureVisitor={ensureVisitor} disabled={loadingShare || submitting} fixedSenderName={Boolean(visitorName) || incomingShare?.kind === "named"} />
          <a className="admin-link" href="/admin" aria-label="لوحة الإدارة" title="لوحة الإدارة">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <rect x="5" y="10" width="14" height="11" rx="3" />
            <path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2" />
          </svg>
          </a>
        </div>
      </header>

      <main className="visitor-main">
        {visitorName ? (
          <section className="heart-scene" aria-labelledby="heart-heading">
            <div className="scene-heading">
              <p className="eyebrow"><span /> من القلب، لك <span /></p>
              <h1 id="heart-heading" ref={heartHeadingRef} tabIndex={-1}>يا <bdi>{visitorName}</bdi>، هذا القلب لك.</h1>
            </div>
            <div className="heart-art"><HeartCanvas replay={replay} /></div>
            <div className="scene-bottom">
              <p className="scene-caption">بعض المشاعر ما تحتاج كلام كثير.</p>
              <div className="scene-actions">
                <button className="text-button replay-button" onClick={() => setReplay((value) => value + 1)}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M4 10a8 8 0 1 1 1.7 7M4 4v6h6" />
                  </svg>
                  ارسم القلب من جديد
                </button>
                <span className="action-divider" aria-hidden="true" />
                <button className="text-button" onClick={startAgain}>{incomingShare?.kind === "named" ? "من البداية" : "اسم آخر"} <ArrowIcon /></button>
              </div>
              <ShareButton variant="panel" senderName={visitorName} onEnsureVisitor={ensureVisitor} fixedSenderName={true} />
            </div>
          </section>
        ) : (
          <section className="entry-scene" aria-labelledby="entry-heading">
            <div className="entry-emblem" aria-hidden="true">
              <span className="emblem-orbit" />
              <HeartIcon />
              <span className="emblem-star star-one">✦</span>
              <span className="emblem-star star-two">✦</span>
            </div>
            <p className="eyebrow"><span /> شيء صغير، وشعور كبير <span /></p>
            <h1 id="entry-heading">{incomingShare?.kind === "named" ? <>هذا القلب لك يا <bdi>{incomingShare.recipientName}</bdi>.</> : "كل قلب يبدأ باسم."}</h1>
            <p className="entry-description">{incomingShare?.kind === "named" ? "اسمك جاهز، اضغط وافتح قلبك." : "اكتب اسمك، وخَلّ الباقي على القلب."}</p>
            {shareLinkError && <p className="incoming-share-note" role="status">{shareLinkError}</p>}

            <form className="name-form" onSubmit={enterSite} aria-busy={submitting}>
              <label htmlFor="visitor-name">اسمك الجميل</label>
              <div className={`name-field ${error ? "has-error" : ""}`}>
                <input
                  ref={nameInputRef}
                  id="visitor-name"
                  name="name"
                  type="text"
                  placeholder="اكتب اسمك هنا…"
                  value={name}
                  maxLength={40}
                  autoComplete="given-name"
                  enterKeyHint="go"
                  readOnly={incomingShare?.kind === "named"}
                  disabled={submitting || loadingShare}
                  aria-invalid={Boolean(error)}
                  aria-describedby={error ? "name-error name-notice" : "name-notice"}
                  onChange={(event) => {
                    setName(event.target.value);
                    if (error) setError("");
                  }}
                />
                <HeartIcon />
              </div>
              {error && <p className="form-error" id="name-error" role="alert">{error}</p>}
              <button className="primary-button" type="submit" disabled={submitting || loadingShare}>
                {submitting || loadingShare ? <span className="button-spinner" aria-hidden="true" /> : <HeartIcon filled />}
                <span>{loadingShare ? "لحظة، نفتح المشاركة…" : submitting ? "لحظة، نجهّز قلبك…" : "افتح قلبك"}</span>
              </button>
              <p className="privacy-note" id="name-notice">
                <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.25" aria-hidden="true"><circle cx="10" cy="10" r="7" /><path d="M10 9v5m0-8v1" /></svg>
                {incomingShare ? "يُحفظ اسمك لصاحب الموقع مع المشاركة اللي دخلت منها." : "يُحفظ اسمك لصاحب الموقع عند الدخول."}
              </p>
            </form>
            <ShareButton variant="panel" senderName={name} onEnsureVisitor={ensureVisitor} disabled={loadingShare || submitting} fixedSenderName={incomingShare?.kind === "named"} />
          </section>
        )}
      </main>

      <footer className="site-footer">
        <div className="footer-love"><span>صُنع بمحبّة</span><HeartIcon filled /></div>
        <div className="footer-credit"><span>من</span><a href="https://mk2-digital.m2000m1400.chatgpt.site" target="_blank" rel="noopener noreferrer"><bdi dir="ltr">MK~2</bdi></a></div>
      </footer>
    </div>
  );
}
