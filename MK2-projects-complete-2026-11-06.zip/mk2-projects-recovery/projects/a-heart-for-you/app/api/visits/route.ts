import { database, json, readBody, sameOrigin } from '../../../lib/api';
import { normalizeName, validId, validName } from '../../../lib/sharing';

export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({ error: 'طلب غير مسموح.' }, 403);
  let body;
  try { body = await readBody(request); } catch { return json({ error: 'اكتب اسمك وحاول مرة ثانية.' }, 400); }
  if (!validId(body?.requestId)) return json({ error: 'حاول الدخول مرة ثانية.' }, 400);
  const sourceShareId = body.sourceShareId ?? null;
  if (sourceShareId !== null && !validId(sourceShareId)) return json({ error: 'رابط المشاركة غير صحيح.' }, 400);
  try {
    const db = database();
    let name = normalizeName(body.name);
    if (sourceShareId) {
      const share = await db.prepare('SELECT kind, recipient_name AS recipientName FROM share_links WHERE id = ?').bind(sourceShareId).first<{ kind: string; recipientName: string | null }>();
      if (!share) return json({ error: 'ما لقينا رابط المشاركة. افتح الموقع من الرابط الأصلي.' }, 404);
      if (share.kind === 'named') name = share.recipientName || '';
    }
    if (!validName(name)) return json({ error: 'اكتب اسمًا من حرف إلى ٤٠ حرفًا.' }, 400);
    await db.prepare('INSERT INTO visits (id, name, created_at, source_share_id) VALUES (?, ?, ?, ?) ON CONFLICT(id) DO NOTHING').bind(body.requestId, name, new Date().toISOString(), sourceShareId).run();
    const visit = await db.prepare('SELECT id, name, source_share_id AS sourceShareId FROM visits WHERE id = ?').bind(body.requestId).first<{ id: string; name: string; sourceShareId: string | null }>();
    if (!visit || visit.name !== name || visit.sourceShareId !== sourceShareId) return json({ error: 'تغيّر الاسم أو رابط المشاركة. حدّث الصفحة وحاول مرة ثانية.' }, 409);
    return json({ ok: true, id: visit.id, name: visit.name });
  } catch {
    return json({ error: 'ما قدرنا نحفظ اسمك الآن. حاول مرة ثانية.' }, 503);
  }
}
