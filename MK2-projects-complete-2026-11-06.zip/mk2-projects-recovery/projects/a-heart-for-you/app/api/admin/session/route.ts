import { json, sameOrigin } from '../../../../lib/api';
import { createSession, getSessionExpiry, sessionCookie } from '../../../../lib/admin-auth';

export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({ error: 'طلب غير مسموح.' }, 403);
  try {
    if (!await getSessionExpiry(request)) return json({ error: 'انتهت جلستك. سجّل دخولك من جديد.' }, 401, { 'Set-Cookie': sessionCookie('', 0) });
    const token = await createSession();
    return json({ ok: true, expiresAt: Number(token.split('.')[0]) * 1000 }, 200, { 'Set-Cookie': sessionCookie(token) });
  } catch { return json({ error: 'تعذّر تجديد الجلسة. حاول بعد قليل.' }, 503); }
}
