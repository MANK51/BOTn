import { json, sameOrigin } from '../../../../lib/api';
import { sessionCookie } from '../../../../lib/admin-auth';

export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({ error: 'طلب غير مسموح.' }, 403);
  return json({ ok: true }, 200, { 'Set-Cookie': sessionCookie('', 0) });
}
