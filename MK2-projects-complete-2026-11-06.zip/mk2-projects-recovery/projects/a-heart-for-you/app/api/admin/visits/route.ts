import { database, json } from '../../../../lib/api';
import { getSessionExpiry } from '../../../../lib/admin-auth';

export async function GET(request: Request) {
  try {
    const expiresAt = await getSessionExpiry(request);
    if (!expiresAt) return json({ error: 'سجّل دخولك أولًا.' }, 401);
    const db = database();
    const startOfDay = new Date();
    startOfDay.setUTCHours(0, 0, 0, 0);
    const [entries, totals, owners, referrals] = await db.batch<Record<string, unknown>>([
      db.prepare('SELECT v.id, v.name, v.created_at AS createdAt, v.source_share_id AS sourceShareId, sender.id AS sourceSenderVisitId, sender.name AS sourceSenderName FROM visits v LEFT JOIN share_links s ON s.id = v.source_share_id LEFT JOIN visits sender ON sender.id = s.owner_visit_id ORDER BY v.created_at DESC LIMIT 300'),
      db.prepare('SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN created_at >= ? THEN 1 ELSE 0 END), 0) AS today, (SELECT COUNT(DISTINCT owner_visit_id) FROM share_links) AS sharerTotal FROM visits').bind(startOfDay.toISOString()),
      db.prepare('SELECT sender.id, sender.name, COUNT(DISTINCT s.id) AS shareCount, COUNT(v.id) AS visitorCount FROM share_links s INNER JOIN visits sender ON sender.id = s.owner_visit_id LEFT JOIN visits v ON v.source_share_id = s.id GROUP BY sender.id ORDER BY MAX(s.created_at) DESC LIMIT 100'),
      db.prepare('SELECT v.id, v.name, v.created_at AS createdAt, s.id AS shareId, s.kind, s.recipient_name AS recipientName, s.owner_visit_id AS senderVisitId FROM visits v INNER JOIN share_links s ON s.id = v.source_share_id ORDER BY v.created_at DESC LIMIT 1000'),
    ]);
    const sharers = owners.results.map(owner => ({
      id: String(owner.id), name: String(owner.name),
      shareCount: Number(owner.shareCount), visitorCount: Number(owner.visitorCount),
      visitors: referrals.results.filter(visit => visit.senderVisitId === owner.id).map(({ senderVisitId, ...visit }) => visit),
    }));
    return json({ visits: entries.results, ...totals.results[0], sharers, referralListLimit: 1000, sharerListLimit: 100, expiresAt });
  } catch {
    return json({ error: 'ما قدرنا نحمّل الأسماء. حاول مرة ثانية.' }, 503);
  }
}
