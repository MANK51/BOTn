import { database, json, readBody, sameOrigin } from '../../../../lib/api';
import { attemptKey, checkPassword, createSession, sessionCookie } from '../../../../lib/admin-auth';

export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({ error: 'طلب غير مسموح.' }, 403);
  let body;
  try { body = await readBody(request); } catch { return json({ error: 'أدخل كلمة المرور.' }, 400); }
  if (typeof body?.password !== 'string' || body.password.length > 128) return json({ error: 'أدخل كلمة المرور.' }, 400);
  try {
    const db = database();
    const key = await attemptKey(request);
    const now = Date.now();
    const windowStart = now - 15 * 60 * 1000;
    const attempt = await db.prepare('INSERT INTO login_attempts (key, count, started_at) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN started_at < ? THEN 1 ELSE count + 1 END, started_at = CASE WHEN started_at < ? THEN ? ELSE started_at END RETURNING count').bind(key, now, windowStart, windowStart, now).first<{ count: number }>();
    if (!attempt || attempt.count > 8) return json({ error: 'محاولات كثيرة. جرّب بعد ١٥ دقيقة.' }, 429, { 'Retry-After': '900' });
    if (!await checkPassword(body.password)) return json({ error: 'كلمة المرور غير صحيحة.' }, 401);
    await db.prepare('DELETE FROM login_attempts WHERE key = ?').bind(key).run();
    const token = await createSession();
    return json({ ok: true, expiresAt: Number(token.split('.')[0]) * 1000 }, 200, { 'Set-Cookie': sessionCookie(token) });
  } catch {
    return json({ error: 'لوحة الإدارة غير متاحة الآن. حاول بعد قليل.' }, 503);
  }
}
