import { database, json, readBody, sameOrigin } from '../../../lib/api';
import { normalizeName, validId, validName } from '../../../lib/sharing';

type Share = { id: string; kind: 'general' | 'named'; recipientName: string | null };

export async function GET(request: Request) {
  const id = new URL(request.url).searchParams.get('shareId');
  if (!validId(id)) return json({ error: 'رابط المشاركة غير صحيح.' }, 400);
  try {
    // Only the share target is public; owner visit IDs authorize writes and stay private.
    const share = await database().prepare('SELECT id, kind, recipient_name AS recipientName FROM share_links WHERE id = ?').bind(id).first<Share>();
    return share ? json({ share }) : json({ error: 'ما لقينا رابط المشاركة.' }, 404);
  } catch { return json({ error: 'تعذّر فتح المشاركة الآن. حاول بعد قليل.' }, 503); }
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return json({ error: 'طلب غير مسموح.' }, 403);
  let body;
  try { body = await readBody(request); } catch { return json({ error: 'أكمل بيانات المشاركة وحاول مرة ثانية.' }, 400); }
  if (!validId(body?.ownerVisitId) || !validId(body?.requestId)) return json({ error: 'اكتب اسمك أولًا لتجهيز المشاركة.' }, 400);
  if (body.kind !== 'general' && body.kind !== 'named') return json({ error: 'اختر مشاركة عامة أو مشاركة باسم شخص.' }, 400);
  const recipientName = body.kind === 'named' ? normalizeName(body.recipientName) : null;
  if (body.kind === 'named' && !validName(recipientName!)) return json({ error: 'اكتب اسم الشخص من حرف إلى ٤٠ حرفًا.' }, 400);
  try {
    const db = database();
    // The unguessable owner visit ID is a capability returned only on registration.
    const owner = await db.prepare('SELECT id FROM visits WHERE id = ?').bind(body.ownerVisitId).first<{ id: string }>();
    if (!owner) return json({ error: 'اكتب اسمك أولًا لتجهيز المشاركة.' }, 403);
    await db.prepare('INSERT INTO share_links (id, owner_visit_id, kind, recipient_name, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO NOTHING').bind(body.requestId, owner.id, body.kind, recipientName, new Date().toISOString()).run();
    const saved = await db.prepare('SELECT id, kind, recipient_name AS recipientName, owner_visit_id AS ownerVisitId FROM share_links WHERE id = ?').bind(body.requestId).first<Share & { ownerVisitId: string }>();
    if (!saved || saved.ownerVisitId !== owner.id || saved.kind !== body.kind || saved.recipientName !== recipientName) return json({ error: 'تغيّرت بيانات المشاركة. جهّز رابطًا جديدًا.' }, 409);
    const url = new URL('/', request.url);
    url.searchParams.set('s', saved.id);
    const share: Share = { id: saved.id, kind: saved.kind, recipientName: saved.recipientName };
    return json({ share, url: url.href });
  } catch { return json({ error: 'ما قدرنا نجهّز الرابط الآن. حاول مرة ثانية.' }, 503); }
}
