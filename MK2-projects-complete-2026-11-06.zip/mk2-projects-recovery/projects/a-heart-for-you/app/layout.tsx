import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'لك قلب — كل قلب يبدأ باسم',
  description: 'اكتب اسمك، ودع كلمات الحب ترسم لك قلبًا ورديًا.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
