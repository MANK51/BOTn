"use client";

import { type FormEvent, useEffect, useId, useRef, useState } from "react";
import "./share.css";

const siteUrl = "https://a-heart-for-you.m2000m1400.chatgpt.site";
type ShareKind = "general" | "named";
type Visitor = { id: string; name: string };
type PreparedShare = { id: string; kind: ShareKind; recipientName: string | null; url: string };
type Props = {
  variant?: "header" | "panel";
  senderName: string;
  onEnsureVisitor: (name: string) => Promise<Visitor>;
  disabled?: boolean;
  fixedSenderName?: boolean;
};

function cleanName(value: string) { return value.trim().replace(/\s+/g, " "); }
function escapeHtml(value: string) { return value.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!); }

function ShareIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="m8.6 10.5 6.8-4m-6.8 7 6.8 4" /></svg>;
}

export default function ShareButton({ variant = "header", senderName, onEnsureVisitor, disabled = false, fixedSenderName = false }: Props) {
  const dialog = useRef<HTMLDialogElement>(null);
  const requestRef = useRef<{ key: string; id: string } | null>(null);
  const id = useId();
  const [canShare, setCanShare] = useState(false);
  const [kind, setKind] = useState<ShareKind>("general");
  const [ownName, setOwnName] = useState("");
  const [recipient, setRecipient] = useState("");
  const [prepared, setPrepared] = useState<PreparedShare | null>(null);
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { setCanShare(typeof navigator.share === "function"); }, []);

  function invalidateLink() {
    setPrepared(null);
    setStatus("");
    setError("");
    requestRef.current = null;
  }

  function showDialog(selectedKind?: ShareKind) {
    if (disabled || busy) return;
    const nextKind = selectedKind ?? kind;
    if (nextKind !== kind || cleanName(senderName) !== cleanName(ownName)) invalidateLink();
    setKind(nextKind);
    setOwnName(senderName);
    setError("");
    setStatus("");
    dialog.current?.showModal();
  }

  async function prepareLink(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const sender = cleanName(fixedSenderName ? senderName : ownName);
    const target = cleanName(recipient);
    if (!sender || sender.length > 40) { setError("اكتب اسمك، بحد أقصى ٤٠ حرفًا."); return; }
    if (kind === "named" && (!target || target.length > 40)) { setError("اكتب اسم الشخص، بحد أقصى ٤٠ حرفًا."); return; }
    setBusy(true);
    setError("");
    setStatus("");
    try {
      const visitor = await onEnsureVisitor(sender);
      setOwnName(visitor.name);
      const key = JSON.stringify([visitor.id, kind, kind === "named" ? target : null]);
      if (requestRef.current?.key !== key) requestRef.current = { key, id: crypto.randomUUID() };
      const response = await fetch("/api/shares", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ownerVisitId: visitor.id, kind, ...(kind === "named" ? { recipientName: target } : {}), requestId: requestRef.current.id }),
      });
      const result = await response.json().catch(() => null) as { error?: string; share?: { id: string; kind: ShareKind; recipientName: string | null } } | null;
      if (!response.ok || !result?.share?.id) throw new Error(result?.error || "ما قدرنا نجهّز الرابط. جرّب مرة ثانية.");
      setPrepared({ ...result.share, url: `${siteUrl}/?s=${encodeURIComponent(result.share.id)}` });
      setStatus("رابطك جاهز. انسخه أو شاركه عبر التطبيقات ❤️");
    } catch (problem) {
      setError(problem instanceof Error ? problem.message : "تعذّر الاتصال. جرّب مرة ثانية.");
    } finally { setBusy(false); }
  }

  const loveText = prepared?.kind === "named"
    ? `يا ${prepared.recipientName}، فيه قلب ينتظرك ❤️\nهذا القلب مكتوب لك أنت…`
    : "فيه قلب ينتظرك، ومكتوب لك أنت ❤️\nاكتب اسمك وشوفه…";
  const plainMessage = `${loveText}\nاضغط على I love you 💗\n${prepared?.url || ""}`;
  const htmlMessage = `<div dir="rtl">${loveText.split("\n").map((line) => `<p>${escapeHtml(line)}</p>`).join("")}<p>اضغط على <a href="${escapeHtml(prepared?.url || "")}">I love you</a> 💗</p></div>`;

  async function copyMessage(linkOnly = false) {
    if (!prepared || busy) return;
    setBusy(true);
    setStatus("");
    setError("");
    let copied = false;
    try {
      if (!linkOnly && typeof ClipboardItem !== "undefined" && navigator.clipboard?.write) {
        await navigator.clipboard.write([new ClipboardItem({
          "text/html": new Blob([htmlMessage], { type: "text/html" }),
          "text/plain": new Blob([plainMessage], { type: "text/plain" }),
        })]);
        copied = true;
      }
    } catch { /* Some apps accept plain text only. */ }
    if (!copied) {
      try {
        await navigator.clipboard.writeText(linkOnly ? prepared.url : plainMessage);
        copied = true;
      } catch {
        const field = document.createElement("textarea");
        field.value = linkOnly ? prepared.url : plainMessage;
        field.setAttribute("readonly", "");
        field.style.position = "fixed";
        field.style.opacity = "0";
        dialog.current?.appendChild(field);
        field.select();
        try { copied = document.execCommand("copy"); } catch { copied = false; }
        field.remove();
      }
    }
    setStatus(copied ? (linkOnly ? "تم نسخ الرابط ❤️" : "تم نسخ الرسالة، أرسلها بحب ❤️") : "تعذّر النسخ. تقدر تنسخ الرابط من الخانة أدناه.");
    setBusy(false);
  }

  async function shareMessage() {
    if (!prepared || busy) return;
    setStatus("");
    setError("");
    setBusy(true);
    try {
      // Called directly by a second click, keeping iPhone's share permission active.
      await navigator.share({ title: "لك قلب", text: `${loveText}\nاضغط على I love you 💗`, url: prepared.url });
    } catch (problem) {
      if (!(problem instanceof Error && problem.name === "AbortError")) setStatus("قائمة المشاركة غير متاحة هنا. تقدر تنسخ الرسالة وترسلها.");
    } finally { setBusy(false); }
  }

  return <>
    {variant === "header" ? (
      <button className="share-trigger" type="button" disabled={disabled || busy} aria-haspopup="dialog" onClick={() => showDialog()}><ShareIcon /><span>شارك</span></button>
    ) : (
      <div className="share-panel" aria-label="خيارات المشاركة">
        <p>شارك قلبًا مع اللي تحب</p>
        <div className="share-panel-buttons">
          <button type="button" disabled={disabled || busy} onClick={() => showDialog("general")}><ShareIcon />مشاركة عامة</button>
          <button type="button" disabled={disabled || busy} onClick={() => showDialog("named")}><span aria-hidden="true">♡</span>مشاركة باسم شخص</button>
        </div>
      </div>
    )}
    <dialog className="share-dialog" ref={dialog} dir="rtl" aria-labelledby={`${id}-title`} onCancel={(event) => { if (busy) event.preventDefault(); }} onClick={(event) => { if (!busy && event.target === event.currentTarget) dialog.current?.close(); }}>
      <div className="share-content">
        <button className="share-close" type="button" disabled={busy} aria-label="إغلاق المشاركة" onClick={() => dialog.current?.close()}>×</button>
        <div className="share-emblem" aria-hidden="true">♡</div>
        <h2 id={`${id}-title`}>شارك الحب</h2>
        <p className="share-description">رسالة صغيرة، لشخص له مكان بقلبك.</p>
        <div className="share-kind" aria-label="نوع المشاركة">
          <button type="button" aria-pressed={kind === "general"} disabled={busy} onClick={() => { if (kind !== "general") { setKind("general"); invalidateLink(); } }}>مشاركة عامة</button>
          <button type="button" aria-pressed={kind === "named"} disabled={busy} onClick={() => { if (kind !== "named") { setKind("named"); invalidateLink(); } }}>مشاركة باسم شخص</button>
        </div>
        <form className="share-form" onSubmit={prepareLink} aria-busy={busy}>
          <label htmlFor={`${id}-sender`}>اسمك</label>
          <input id={`${id}-sender`} value={fixedSenderName ? senderName : ownName} maxLength={40} autoComplete="given-name" placeholder="اكتب اسمك هنا…" readOnly={fixedSenderName} disabled={busy} onChange={(event) => { setOwnName(event.target.value); invalidateLink(); }} required />
          {kind === "named" && <>
            <label htmlFor={`${id}-recipient`}>اسم الشخص</label>
            <input id={`${id}-recipient`} value={recipient} maxLength={40} autoComplete="off" placeholder="مثلاً: العتيبي" disabled={busy} onChange={(event) => { setRecipient(event.target.value); invalidateLink(); }} required />
            <p className="share-form-note">يفتح الرابط واسمه جاهز؛ يضغط «افتح قلبك» وبس.</p>
          </>}
          <p className="share-privacy">يُحفظ اسمك واسم من يدخل رابطك لصاحب الموقع.</p>
          {!prepared && <button className="share-copy" type="submit" disabled={busy || disabled}>{busy ? "لحظة، نجهّز رابطك…" : "جهّز الرابط"}</button>}
        </form>
        {error && <p className="share-error" role="alert">{error}</p>}
        {prepared && <div className="share-ready">
          <div className="share-message" dir="rtl">
            {loveText.split("\n").map((line, index) => <p key={index}>{line}</p>)}
            <p>اضغط على <a href={prepared.url} target="_blank" rel="noopener noreferrer"><bdi>I love you</bdi></a> 💗</p>
          </div>
          <button className="share-copy" type="button" disabled={busy} onClick={() => void copyMessage()}>نسخ الرسالة</button>
          <button className="share-native" type="button" disabled={busy} onClick={() => void copyMessage(true)}>نسخ الرابط</button>
          {canShare && <button className="share-native" type="button" disabled={busy} onClick={() => void shareMessage()}><ShareIcon />مشاركة عبر التطبيقات</button>}
          <input className="share-url" value={prepared.url} dir="ltr" readOnly aria-label="رابط المشاركة" onFocus={(event) => event.currentTarget.select()} />
          <p className="share-note">قد يظهر الرابط كاملًا حسب التطبيق اللي ترسل منه.</p>
          <details className="share-instagram">
            <summary>رابط مخفي لستوري إنستغرام</summary>
            <p>انسخ الرابط، وأضف ملصق «الرابط» في الستوري، ثم غيّر نص الملصق إلى <bdi>I love you</bdi>.</p>
          </details>
        </div>}
        <p className="share-status" role="status" aria-live="polite">{status}</p>
      </div>
    </dialog>
  </>;
}
