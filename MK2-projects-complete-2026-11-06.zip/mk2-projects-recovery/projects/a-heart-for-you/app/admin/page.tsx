"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import Link from "next/link";
import { useAdminIdle } from "./use-admin-idle";
import "./admin.css";

type Visit = { id: string | number; name: string; createdAt: string; sourceSenderName?: string | null; sourceShareId?: string | null; sourceSenderVisitId?: string | null };
type SharedVisit = { id: string; name: string; createdAt: string; shareId: string; kind: "general" | "named"; recipientName: string | null };
type Sharer = { id: string; name: string; shareCount: number; visitorCount: number; visitors: SharedVisit[] };
type VisitData = { visits: Visit[]; total: number; today: number; sharers?: Sharer[]; referralListLimit?: number; expiresAt?: number };
type Session = "checking" | "locked" | "authenticated";

const numberFormat = new Intl.NumberFormat("ar-SA");
const dateFormat = new Intl.DateTimeFormat("ar-SA-u-ca-gregory", {
  dateStyle: "medium",
  timeStyle: "short",
});

function Icon({ kind }: { kind: "heart" | "lock" | "refresh" | "search" | "arrow" }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {kind === "heart" && <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" />}
      {kind === "lock" && <><rect x="5" y="10" width="14" height="11" rx="3" /><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3" /></>}
      {kind === "refresh" && <><path d="M20 7v5h-5M4 17v-5h5" /><path d="M6.1 6.1A8 8 0 0 1 20 12M4 12a8 8 0 0 0 13.9 5.9" /></>}
      {kind === "search" && <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 4 4" /></>}
      {kind === "arrow" && <path d="m9 5 7 7-7 7M16 12H4" />}
    </svg>
  );
}

function visitDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "—" : dateFormat.format(date);
}

export default function AdminPage() {
  const [session, setSession] = useState<Session>("checking");
  const [data, setData] = useState<VisitData>({ visits: [], total: 0, today: 0 });
  const [password, setPassword] = useState("");
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const generationRef = useRef(0);
  const visitsRequestRef = useRef<AbortController | null>(null);
  const loginRequestRef = useRef<AbortController | null>(null);

  const lockProtectedState = useCallback((message: string) => {
    generationRef.current += 1;
    visitsRequestRef.current?.abort();
    loginRequestRef.current?.abort();
    setSession("locked");
    setData({ visits: [], total: 0, today: 0 });
    setSearch("");
    setPassword("");
    setError(message);
    setBusy(false);
    setRefreshing(false);
  }, []);

  const { activate, logout: closeSession, waitForLogout } = useAdminIdle(lockProtectedState);

  const loadVisits = useCallback(async () => {
    visitsRequestRef.current?.abort();
    const controller = new AbortController();
    visitsRequestRef.current = controller;
    const generation = generationRef.current;
    const isCurrent = () => generation === generationRef.current && visitsRequestRef.current === controller && !controller.signal.aborted;
    setRefreshing(true);
    setError("");
    try {
      const response = await fetch("/api/admin/visits", { cache: "no-store", credentials: "same-origin", signal: controller.signal });
      if (!isCurrent()) return;
      if (response.status === 401) {
        void closeSession().catch(() => {});
        return;
      }
      if (!response.ok) throw new Error("تعذّر تحميل الأسماء. حاول مرة ثانية.");
      const nextData: VisitData = await response.json();
      if (!isCurrent()) return;
      if (!activate(nextData.expiresAt ?? Number.NaN)) return;
      setData(nextData);
      setSession("authenticated");
    } catch (cause) {
      if (!isCurrent()) return;
      setError(cause instanceof Error ? cause.message : "تعذّر الاتصال. حاول مرة ثانية.");
      setSession((current) => current === "checking" ? "locked" : current);
    } finally {
      if (isCurrent()) setRefreshing(false);
      if (visitsRequestRef.current === controller) visitsRequestRef.current = null;
    }
  }, [activate, closeSession]);

  useEffect(() => {
    void loadVisits();
    return () => {
      generationRef.current += 1;
      visitsRequestRef.current?.abort();
      loginRequestRef.current?.abort();
    };
  }, [loadVisits]);

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const generation = generationRef.current;
    const controller = new AbortController();
    loginRequestRef.current?.abort();
    loginRequestRef.current = controller;
    const isCurrent = () => generation === generationRef.current && loginRequestRef.current === controller && !controller.signal.aborted;
    setBusy(true);
    setError("");
    try {
      // Finish clearing the previous cookie before setting a new session.
      await waitForLogout();
      if (!isCurrent()) return;
      const response = await fetch("/api/admin/login", {
        method: "POST",
        cache: "no-store",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
        signal: controller.signal,
      });
      const result: unknown = await response.json().catch(() => ({}));
      if (!isCurrent()) return;
      const message = result && typeof result === "object" && "error" in result && typeof result.error === "string" ? result.error : "تعذّر تسجيل الدخول. حاول مرة ثانية.";
      if (!response.ok) throw new Error(message);
      const expiresAt = result && typeof result === "object" && "expiresAt" in result && typeof result.expiresAt === "number" ? result.expiresAt : Number.NaN;
      if (!activate(expiresAt, true)) return;
      setPassword("");
      setSession("authenticated");
      await loadVisits();
    } catch (cause) {
      if (!isCurrent()) return;
      setError(cause instanceof Error ? cause.message : "تعذّر الاتصال. حاول مرة ثانية.");
    } finally {
      if (isCurrent()) setBusy(false);
      if (loginRequestRef.current === controller) loginRequestRef.current = null;
    }
  }

  async function logout() {
    const request = closeSession();
    const generation = generationRef.current;
    setBusy(true);
    try {
      await request;
    } catch (cause) {
      if (generation !== generationRef.current) return;
      setError(cause instanceof Error ? cause.message : "تعذّر الاتصال. حاول مرة ثانية.");
    } finally {
      if (generation === generationRef.current) setBusy(false);
    }
  }

  const filtered = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("ar");
    return query ? data.visits.filter((visit) => visit.name.toLocaleLowerCase("ar").includes(query) || visit.sourceSenderName?.toLocaleLowerCase("ar").includes(query)) : data.visits;
  }, [data.visits, search]);

  const filteredSharers = useMemo(() => {
    const query = search.trim().toLocaleLowerCase("ar");
    const sharers = data.sharers ?? [];
    if (!query) return sharers;
    return sharers.flatMap((sharer) => {
      if (sharer.name.toLocaleLowerCase("ar").includes(query)) return [sharer];
      const visitors = sharer.visitors.filter((visitor) => visitor.name.toLocaleLowerCase("ar").includes(query));
      return visitors.length ? [{ ...sharer, visitors }] : [];
    });
  }, [data.sharers, search]);

  const partialReferrals = (data.sharers ?? []).some((sharer) => sharer.visitorCount > sharer.visitors.length);

  return (
    <main className="admin-page" dir="rtl">
      <div className="admin-frame">
        <header className="admin-topbar">
          <Link className="admin-brand" href="/" aria-label="العودة إلى الموقع"><Icon kind="heart" /><span>لك قلب</span></Link>
          <Link className="admin-home" href="/">العودة للموقع <Icon kind="arrow" /></Link>
        </header>

        {session === "checking" ? (
          <div className="admin-loading" role="status"><span className="admin-spinner" />جاري فتح لوحة الإدارة…</div>
        ) : session === "locked" ? (
          <section className="admin-login" aria-labelledby="admin-login-title">
            <div className="admin-lock"><Icon kind="lock" /></div>
            <p className="admin-eyebrow">مساحتك الخاصة</p>
            <h1 id="admin-login-title">لوحة الإدارة</h1>
            <p className="admin-description">كل الأسماء اللي مرّت من هنا، في مكان واحد.</p>
            <form onSubmit={login} className="admin-login-form">
              <label htmlFor="admin-password">كلمة المرور</label>
              <input id="admin-password" name="password" type="password" autoComplete="current-password" placeholder="أدخل كلمة المرور" value={password} onChange={(event) => setPassword(event.target.value)} required disabled={busy} />
              {error && <p className="admin-error" role="alert">{error}</p>}
              <button className="admin-primary" type="submit" disabled={busy || !password.trim()}>{busy ? "جاري الدخول…" : "دخول لوحة الإدارة"}<Icon kind="arrow" /></button>
            </form>
            <p className="admin-private"><Icon kind="lock" />الدخول متاح لصاحب الموقع فقط</p>
            <p className="admin-description">تسجيل الخروج تلقائيًا بعد ١٥ دقيقة بدون نشاط.</p>
          </section>
        ) : (
          <section className="admin-dashboard" aria-labelledby="admin-dashboard-title">
            <div className="admin-heading">
              <div><p className="admin-eyebrow">أثر صغير، وذكرى حلوة</p><h1 id="admin-dashboard-title">أسماء مرّت من هنا<span>.</span></h1><p className="admin-description">شوف مين دخل، ومين شارك الموقع مع غيره.</p><p className="admin-description">تسجيل الخروج تلقائيًا بعد ١٥ دقيقة بدون نشاط.</p></div>
              <button type="button" className="admin-text-button" onClick={logout} disabled={busy}>{busy ? "جاري الخروج…" : "تسجيل الخروج"}</button>
            </div>

            <div className="admin-stats">
              <article className="admin-stat"><span>كل الزيارات</span><strong>{numberFormat.format(data.total)}</strong><p>اسم ترك لنا ذكرى</p></article>
              <article className="admin-stat"><span>زيارات اليوم</span><strong>{numberFormat.format(data.today)}</strong><p>زيارة جديدة اليوم</p></article>
            </div>

            <div className="admin-visitors">
              <div className="admin-table-tools">
                <h2>قائمة الأسماء <span>{numberFormat.format(data.visits.length)}</span></h2>
                <div className="admin-tool-actions">
                  <label className="admin-search"><Icon kind="search" /><span className="admin-sr-only">البحث في أسماء الزوار واللي شاركوا</span><input type="search" placeholder="ابحث عن اسم…" value={search} onChange={(event) => setSearch(event.target.value)} /></label>
                  <button type="button" className="admin-refresh" onClick={() => void loadVisits()} disabled={refreshing || busy}><span className={refreshing ? "admin-refreshing" : undefined}><Icon kind="refresh" /></span>{refreshing ? "جاري التحديث" : "تحديث"}</button>
                </div>
              </div>
              {error && <p className="admin-error admin-table-error" role="alert">{error}</p>}
              {filtered.length > 0 ? (
                <div className="admin-table-scroll"><table><thead><tr><th scope="col">الاسم</th><th scope="col">دخل عن طريق</th><th scope="col">وقت الزيارة</th></tr></thead><tbody>{filtered.map((visit) => <tr key={visit.id}><td><span className="admin-name-heart"><Icon kind="heart" /></span>{visit.name}</td><td className="admin-visit-source">{visit.sourceSenderName || "زيارة مباشرة"}</td><td><time dateTime={visit.createdAt}>{visitDate(visit.createdAt)}</time></td></tr>)}</tbody></table></div>
              ) : (
                <div className="admin-empty"><Icon kind={search ? "search" : "heart"} /><h3>{search ? "ما لقينا هذا الاسم" : "الحكاية تبدأ بأول اسم"}</h3><p>{search ? "جرّب كتابة اسم ثاني أو امسح البحث." : "الأسماء بتظهر هنا أول ما أحد يدخل الموقع."}</p></div>
              )}
              <div className="admin-table-footer"><span>{search ? `نتائج البحث: ${numberFormat.format(filtered.length)}` : data.total > data.visits.length ? `تظهر أحدث ${numberFormat.format(data.visits.length)} زيارة` : "الأحدث يظهر أولًا"}</span><span className="admin-footer-heart"><Icon kind="heart" />كل اسم له مكان</span></div>
            </div>

            <section className="admin-sharers" aria-labelledby="admin-sharers-title">
              <div className="admin-sharers-heading"><h2 id="admin-sharers-title">اللي شاركوا الموقع <span>{numberFormat.format((data.sharers ?? []).length)}</span></h2><p>افتح الاسم وشوف مين دخل من روابطه.</p></div>
              {filteredSharers.length > 0 ? (
                <div className="admin-sharer-list">{filteredSharers.map((sharer) => (
                  <details className="admin-sharer" key={`${sharer.id}-${search.trim()}`} open={search.trim() ? true : undefined}>
                    <summary><span className="admin-sharer-name"><span className="admin-sharer-arrow" aria-hidden="true">‹</span>{sharer.name}</span><span className="admin-sharer-counts"><span>{numberFormat.format(sharer.shareCount)} مشاركة</span><span>{numberFormat.format(sharer.visitorCount)} دخلوا من روابطه</span></span></summary>
                    {sharer.visitors.length ? (
                      <ul className="admin-referrals">{sharer.visitors.map((visitor) => <li key={visitor.id}><span className="admin-referral-name"><Icon kind="heart" />{visitor.name}</span><time dateTime={visitor.createdAt}>{visitDate(visitor.createdAt)}</time></li>)}</ul>
                    ) : <p className="admin-no-referrals">ما دخل أحد من روابطه للحين.</p>}
                  </details>
                ))}</div>
              ) : <div className="admin-empty admin-sharers-empty"><h3>{search ? "ما لقينا مشاركات لهذا الاسم" : "المشاركات بتظهر هنا"}</h3><p>{search ? "جرّب اسم المرسل أو الشخص اللي دخل من رابطه." : "أول ما أحد يشارك رابطًا، بيظهر اسمه حتى لو ما دخل أحد منه."}</p></div>}
              {partialReferrals && <p className="admin-referral-limit">تظهر حتى {numberFormat.format(data.referralListLimit ?? 1000)} من أحدث الزيارات عبر المشاركات؛ بعض الأسماء الأقدم غير ظاهرة.</p>}
            </section>
          </section>
        )}
        <footer className="admin-footer">تفاصيل صغيرة، حب كبير.</footer>
      </div>
    </main>
  );
}
