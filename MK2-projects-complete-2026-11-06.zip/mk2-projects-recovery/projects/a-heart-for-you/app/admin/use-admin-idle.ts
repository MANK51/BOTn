"use client";

import { useCallback, useEffect, useRef } from "react";
import { ADMIN_IDLE_TIMEOUT_MS } from "../../lib/admin-session-config";

export const ADMIN_IDLE_MESSAGE = "تم تسجيل خروجك تلقائيًا بعد ١٥ دقيقة بدون نشاط.";
const RENEW_INTERVAL_MS = 30_000;
const ACTIVITY_THROTTLE_MS = 1_000;

export function useAdminIdle(onLock: (message: string) => void) {
  const onLockRef = useRef(onLock);
  const activeRef = useRef(false);
  const generationRef = useRef(0);
  const lastActivityRef = useRef(0);
  const serverExpiresAtRef = useRef(0);
  const lastProcessedActivityRef = useRef(0);
  const lastRenewStartedRef = useRef(0);
  const pendingActivityRef = useRef(false);
  const idleTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const renewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const renewRequestRef = useRef<Promise<void> | null>(null);
  const renewControllerRef = useRef<AbortController | null>(null);
  const logoutRequestRef = useRef<Promise<void> | null>(null);
  const logoutControllerRef = useRef<AbortController | null>(null);
  const expireRef = useRef<() => void>(() => {});
  const queueRenewRef = useRef<() => void>(() => {});

  useEffect(() => { onLockRef.current = onLock; }, [onLock]);

  const clearTimers = useCallback(() => {
    if (idleTimerRef.current !== null) clearTimeout(idleTimerRef.current);
    if (renewTimerRef.current !== null) clearTimeout(renewTimerRef.current);
    idleTimerRef.current = null;
    renewTimerRef.current = null;
    pendingActivityRef.current = false;
  }, []);

  const deadline = useCallback(() => Math.min(
    lastActivityRef.current + ADMIN_IDLE_TIMEOUT_MS,
    serverExpiresAtRef.current,
  ), []);

  const scheduleIdle = useCallback(() => {
    if (idleTimerRef.current !== null) clearTimeout(idleTimerRef.current);
    if (!activeRef.current) return;
    idleTimerRef.current = setTimeout(() => {
      idleTimerRef.current = null;
      if (!activeRef.current) return;
      if (Date.now() >= deadline()) expireRef.current();
      else scheduleIdle();
    }, Math.max(0, deadline() - Date.now()));
  }, [deadline]);

  const logout = useCallback((message = "") => {
    activeRef.current = false;
    generationRef.current += 1;
    clearTimers();
    onLockRef.current(message);
    if (logoutRequestRef.current) return logoutRequestRef.current;

    // A renewal response can set a cookie, so its response must settle before
    // the logout response clears that cookie.
    const renewal = renewRequestRef.current;
    const request = (async () => {
      await renewal?.catch(() => {});
      const controller = new AbortController();
      logoutControllerRef.current = controller;
      try {
        const response = await fetch("/api/admin/logout", {
          method: "POST", cache: "no-store", credentials: "same-origin", signal: controller.signal, keepalive: true,
        });
        if (!response.ok) throw new Error("تعذّر تسجيل الخروج. حاول مرة ثانية.");
      } finally {
        if (logoutControllerRef.current === controller) logoutControllerRef.current = null;
      }
    })();
    logoutRequestRef.current = request;
    void request.finally(() => {
      if (logoutRequestRef.current === request) logoutRequestRef.current = null;
    }).catch(() => {});
    return request;
  }, [clearTimers]);

  useEffect(() => {
    expireRef.current = () => { void logout(ADMIN_IDLE_MESSAGE).catch(() => {}); };
  }, [logout]);

  const renew = useCallback(() => {
    if (!activeRef.current || renewRequestRef.current) return;
    if (Date.now() >= deadline()) {
      expireRef.current();
      return;
    }
    const generation = generationRef.current;
    const controller = new AbortController();
    renewControllerRef.current = controller;
    lastRenewStartedRef.current = Date.now();
    pendingActivityRef.current = false;
    const request = (async () => {
      try {
        const response = await fetch("/api/admin/session", {
          method: "POST", cache: "no-store", credentials: "same-origin", signal: controller.signal,
        });
        if (!activeRef.current || generation !== generationRef.current) return;
        if (response.status === 401) {
          expireRef.current();
          return;
        }
        if (!response.ok) return;
        const result: unknown = await response.json();
        if (!activeRef.current || generation !== generationRef.current) return;
        if (result && typeof result === "object" && "expiresAt" in result && typeof result.expiresAt === "number" && Number.isFinite(result.expiresAt)) {
          serverExpiresAtRef.current = result.expiresAt;
          scheduleIdle();
        }
      } catch {
        // Network failures do not extend the existing session deadline.
      } finally {
        if (renewControllerRef.current === controller) renewControllerRef.current = null;
      }
    })();
    renewRequestRef.current = request;
    void request.finally(() => {
      if (renewRequestRef.current === request) renewRequestRef.current = null;
      if (activeRef.current && generation === generationRef.current && pendingActivityRef.current) queueRenewRef.current();
    }).catch(() => {});
  }, [deadline, scheduleIdle]);

  const queueRenew = useCallback(() => {
    if (!activeRef.current || renewTimerRef.current !== null) return;
    const delay = Math.max(0, lastRenewStartedRef.current + RENEW_INTERVAL_MS - Date.now());
    if (delay === 0 && !renewRequestRef.current) {
      renew();
      return;
    }
    if (renewRequestRef.current && delay === 0) return;
    renewTimerRef.current = setTimeout(() => {
      renewTimerRef.current = null;
      if (activeRef.current && pendingActivityRef.current) renew();
    }, delay);
  }, [renew]);

  useEffect(() => { queueRenewRef.current = queueRenew; }, [queueRenew]);

  const activate = useCallback((expiresAt: number, freshLogin = false) => {
    if (!Number.isFinite(expiresAt)) {
      expireRef.current();
      return false;
    }
    const now = Date.now();
    if (!activeRef.current) {
      generationRef.current += 1;
      lastActivityRef.current = freshLogin ? now : expiresAt - ADMIN_IDLE_TIMEOUT_MS;
      lastProcessedActivityRef.current = 0;
      lastRenewStartedRef.current = freshLogin ? now : 0;
    }
    // A visits request sent before renewal can arrive after the renewal response.
    // Keep the newer cookie deadline rather than regressing to that older read.
    serverExpiresAtRef.current = activeRef.current ? Math.max(serverExpiresAtRef.current, expiresAt) : expiresAt;
    activeRef.current = true;
    if (now >= deadline()) {
      expireRef.current();
      return false;
    }
    scheduleIdle();
    return true;
  }, [deadline, scheduleIdle]);

  const waitForLogout = useCallback(async () => {
    await logoutRequestRef.current?.catch(() => {});
  }, []);

  useEffect(() => {
    const checkExpiration = () => {
      if (activeRef.current && Date.now() >= deadline()) expireRef.current();
    };
    const activity = () => {
      if (!activeRef.current) return;
      const now = Date.now();
      // A suspended tab must expire before an arriving event can renew it.
      if (now >= deadline()) {
        expireRef.current();
        return;
      }
      lastActivityRef.current = now;
      pendingActivityRef.current = true;
      if (now - lastProcessedActivityRef.current < ACTIVITY_THROTTLE_MS) return;
      lastProcessedActivityRef.current = now;
      scheduleIdle();
      queueRenew();
    };
    const visibility = () => { if (document.visibilityState === "visible") checkExpiration(); };
    const events = ["pointerdown", "keydown", "wheel", "touchstart", "input"] as const;
    events.forEach((name) => window.addEventListener(name, activity, { passive: true }));
    window.addEventListener("focus", checkExpiration);
    document.addEventListener("visibilitychange", visibility);
    return () => {
      activeRef.current = false;
      generationRef.current += 1;
      clearTimers();
      renewControllerRef.current?.abort();
      // Let the cookie-clearing POST finish if the user navigates away.
      events.forEach((name) => window.removeEventListener(name, activity));
      window.removeEventListener("focus", checkExpiration);
      document.removeEventListener("visibilitychange", visibility);
    };
  }, [clearTimers, deadline, queueRenew, scheduleIdle]);

  return { activate, logout, waitForLogout };
}
