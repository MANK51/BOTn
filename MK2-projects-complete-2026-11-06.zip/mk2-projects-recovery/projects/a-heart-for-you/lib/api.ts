import { env } from 'cloudflare:workers';

export const database = () => {
  if (!env.DB) throw new Error('Database is unavailable');
  return env.DB;
};

export function json(data: unknown, status = 200, headers: HeadersInit = {}) {
  return Response.json(data, { status, headers: { 'Cache-Control': 'private, no-store', ...headers } });
}

export function sameOrigin(request: Request) {
  const origin = request.headers.get('origin');
  return origin === new URL(request.url).origin;
}

export async function readBody(request: Request) {
  if (!request.headers.get('content-type')?.includes('application/json')) throw new Error('Invalid body');
  if (Number(request.headers.get('content-length') || 0) > 2048) throw new Error('Invalid body');
  const raw = await request.text();
  if (raw.length > 2048) throw new Error('Invalid body');
  return JSON.parse(raw);
}
