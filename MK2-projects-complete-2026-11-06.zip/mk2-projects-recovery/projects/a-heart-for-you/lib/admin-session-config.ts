export const ADMIN_IDLE_TIMEOUT_MS = 15 * 60 * 1000;
