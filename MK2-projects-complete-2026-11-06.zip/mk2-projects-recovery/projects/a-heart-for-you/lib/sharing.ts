export function normalizeName(value: unknown): string {
  return typeof value === 'string' ? value.trim().normalize('NFC').replace(/\s+/g, ' ') : '';
}

export function validName(value: string): boolean {
  return Boolean(value) && [...value].length <= 40 && !/[\u0000-\u001f\u007f-\u009f]/.test(value);
}

export function validId(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}
