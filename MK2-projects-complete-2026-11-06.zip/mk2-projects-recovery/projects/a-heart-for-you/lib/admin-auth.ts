import { env } from 'cloudflare:workers';
import { ADMIN_IDLE_TIMEOUT_MS } from './admin-session-config';

const encoder = new TextEncoder();
export const COOKIE_NAME = '__Host-heart-admin';
export const SESSION_SECONDS = ADMIN_IDLE_TIMEOUT_MS / 1000;

function password() {
  if (!env.ADMIN_PASSWORD) throw new Error('Admin password is unavailable');
  return env.ADMIN_PASSWORD;
}

async function hmac(value: string) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(password()), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
  return { key, signature: await crypto.subtle.sign('HMAC', key, encoder.encode(value)) };
}

function hex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map(x => x.toString(16).padStart(2, '0')).join('');
}

export async function checkPassword(input: string) {
  const actual = new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(password())));
  const supplied = new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(input)));
  let difference = 0;
  for (let i = 0; i < actual.length; i++) difference |= actual[i] ^ supplied[i];
  return difference === 0;
}

export async function createSession() {
  const expires = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const payload = `${expires}.${crypto.randomUUID()}`;
  const { signature } = await hmac(`session:${payload}`);
  return `${payload}.${hex(signature)}`;
}

export async function getSessionExpiry(request: Request): Promise<number | null> {
  const cookies = (request.headers.get('cookie') || '').split(';').map(v => v.trim());
  const matches = cookies.filter(v => v.startsWith(`${COOKIE_NAME}=`));
  if (matches.length !== 1) return null;
  const token = matches[0].slice(COOKIE_NAME.length + 1);
  const [expires, nonce, signature, extra] = token.split('.');
  if (extra || !/^\d{10}$/.test(expires || '') || !/^[a-f0-9-]{36}$/.test(nonce || '') || !/^[a-f0-9]{64}$/.test(signature || '')) return null;
  const now = Math.floor(Date.now() / 1000);
  if (+expires <= now || +expires > now + SESSION_SECONDS) return null;
  const { key } = await hmac(`session:${expires}.${nonce}`);
  const bytes = Uint8Array.from(signature.match(/../g)!, b => parseInt(b, 16));
  const valid = await crypto.subtle.verify('HMAC', key, bytes, encoder.encode(`session:${expires}.${nonce}`));
  return valid ? Number(expires) * 1000 : null;
}

export async function isAdmin(request: Request) {
  return (await getSessionExpiry(request)) !== null;
}

export async function attemptKey(request: Request) {
  const address = request.headers.get('cf-connecting-ip') || 'unknown';
  return hex((await hmac(`login-ip:${address}`)).signature);
}

export function sessionCookie(value: string, maxAge = SESSION_SECONDS) {
  return `${COOKIE_NAME}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
}
