import { sqliteTable, text, integer, index, type AnySQLiteColumn } from 'drizzle-orm/sqlite-core';

export const visits = sqliteTable('visits', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  createdAt: text('created_at').notNull(),
  sourceShareId: text('source_share_id').references((): AnySQLiteColumn => shareLinks.id),
}, (table) => [index('visits_created_at_idx').on(table.createdAt), index('visits_source_share_idx').on(table.sourceShareId)]);

export const shareLinks = sqliteTable('share_links', {
  id: text('id').primaryKey(),
  ownerVisitId: text('owner_visit_id').notNull().references((): AnySQLiteColumn => visits.id),
  kind: text('kind', { enum: ['general', 'named'] }).notNull(),
  recipientName: text('recipient_name'),
  createdAt: text('created_at').notNull(),
}, (table) => [index('share_links_owner_idx').on(table.ownerVisitId)]);

export const loginAttempts = sqliteTable('login_attempts', {
  key: text('key').primaryKey(),
  count: integer('count').notNull(),
  startedAt: integer('started_at').notNull(),
});
