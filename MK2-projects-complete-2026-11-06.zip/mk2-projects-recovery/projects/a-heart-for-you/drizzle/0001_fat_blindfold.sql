CREATE TABLE `share_links` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_visit_id` text NOT NULL,
	`kind` text NOT NULL,
	`recipient_name` text,
	`created_at` text NOT NULL,
	FOREIGN KEY (`owner_visit_id`) REFERENCES `visits`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `share_links_owner_idx` ON `share_links` (`owner_visit_id`);--> statement-breakpoint
ALTER TABLE `visits` ADD `source_share_id` text REFERENCES share_links(id);--> statement-breakpoint
CREATE INDEX `visits_source_share_idx` ON `visits` (`source_share_id`);