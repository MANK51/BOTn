import { sqliteTable, text, integer, index, uniqueIndex, primaryKey } from 'drizzle-orm/sqlite-core';

export const users = sqliteTable('users', {
  id: text('id').primaryKey(), telegramId: text('telegram_id').notNull().unique(),
  name: text('name').notNull(), username: text('username'), avatar: text('avatar'),
  xp: integer('xp').notNull().default(0), points: integer('points').notNull().default(0),
  level: integer('level').notNull().default(1), role: text('role').notNull().default('user'),
  status: text('status').notNull().default('active'), notifyAllowed: integer('notify_allowed').notNull().default(0),
  streak: integer('streak').notNull().default(0), lastDaily: text('last_daily'),
  createdAt: integer('created_at').notNull(), lastSeen: integer('last_seen').notNull(),
}, t => [index('users_status_idx').on(t.status), index('users_xp_idx').on(t.xp)]);

export const worlds = sqliteTable('worlds', {
  id: text('id').primaryKey(), ownerId: text('owner_id').notNull().references(() => users.id),
  name: text('name').notNull(), description: text('description').notNull().default(''),
  kind: text('kind').notNull().default('games'), visibility: text('visibility').notNull().default('public'),
  rules: text('rules').notNull().default(''), image: text('image').notNull().default('/assets/castle.webp'),
  background: text('background').notNull().default('/assets/castle.webp'), color: text('color').notNull().default('#7C3AED'),
  joinMode: text('join_mode').notNull().default('open'), telegramChatId: text('telegram_chat_id'),
  status: text('status').notNull().default('active'), createdAt: integer('created_at').notNull(), updatedAt: integer('updated_at').notNull(),
}, t => [index('worlds_visibility_idx').on(t.visibility, t.status), index('worlds_owner_idx').on(t.ownerId)]);

export const worldMembers = sqliteTable('world_members', {
  worldId: text('world_id').notNull().references(() => worlds.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: text('role').notNull().default('member'), status: text('status').notNull().default('active'),
  joinedAt: integer('joined_at').notNull(),
}, t => [primaryKey({ columns: [t.worldId, t.userId] }), index('world_members_user_idx').on(t.userId, t.status)]);

export const worldInvites = sqliteTable('world_invites', {
  token: text('token').primaryKey(), worldId: text('world_id').notNull().references(() => worlds.id, { onDelete: 'cascade' }),
  createdBy: text('created_by').notNull().references(() => users.id), expiresAt: integer('expires_at').notNull(), createdAt: integer('created_at').notNull(),
});

export const worldPosts = sqliteTable('world_posts', {
  id: text('id').primaryKey(), worldId: text('world_id').notNull().references(() => worlds.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id), title: text('title').notNull(), body: text('body').notNull(), createdAt: integer('created_at').notNull(),
}, t => [index('world_posts_world_idx').on(t.worldId, t.createdAt)]);

export const teams = sqliteTable('teams', {
  id: text('id').primaryKey(), worldId: text('world_id').notNull().references(() => worlds.id, { onDelete: 'cascade' }),
  leaderId: text('leader_id').notNull().references(() => users.id), name: text('name').notNull(), description: text('description').notNull().default(''),
  logo: text('logo').notNull().default('/assets/quest-team.svg'), points: integer('points').notNull().default(0), createdAt: integer('created_at').notNull(),
}, t => [uniqueIndex('teams_world_name_idx').on(t.worldId, t.name)]);

export const teamMembers = sqliteTable('team_members', {
  teamId: text('team_id').notNull().references(() => teams.id, { onDelete: 'cascade' }),
  worldId: text('world_id').notNull().references(() => worlds.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: text('role').notNull().default('member'), joinedAt: integer('joined_at').notNull(),
}, t => [primaryKey({ columns: [t.teamId, t.userId] }), uniqueIndex('team_members_one_world_idx').on(t.worldId, t.userId)]);

export const teamInvites = sqliteTable('team_invites', {
  id: text('id').primaryKey(), teamId: text('team_id').notNull().references(() => teams.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id), invitedBy: text('invited_by').notNull().references(() => users.id),
  status: text('status').notNull().default('pending'), createdAt: integer('created_at').notNull(),
}, t => [uniqueIndex('team_invites_unique_idx').on(t.teamId, t.userId)]);

export const challenges = sqliteTable('challenges', {
  id: text('id').primaryKey(), worldId: text('world_id').notNull().references(() => worlds.id, { onDelete: 'cascade' }),
  createdBy: text('created_by').notNull().references(() => users.id), title: text('title').notNull(), description: text('description').notNull().default(''),
  type: text('type').notNull().default('quiz'), difficulty: text('difficulty').notNull().default('normal'),
  xpReward: integer('xp_reward').notNull().default(50), pointsReward: integer('points_reward').notNull().default(20),
  attemptLimit: integer('attempt_limit').notNull().default(3), timeLimit: integer('time_limit').notNull().default(300),
  status: text('status').notNull().default('draft'), scheduledAt: integer('scheduled_at'),
  createdAt: integer('created_at').notNull(), updatedAt: integer('updated_at').notNull(),
}, t => [index('challenges_world_idx').on(t.worldId, t.status), index('challenges_scheduled_idx').on(t.status, t.scheduledAt)]);

export const challengeStages = sqliteTable('challenge_stages', {
  id: text('id').primaryKey(), challengeId: text('challenge_id').notNull().references(() => challenges.id, { onDelete: 'cascade' }),
  position: integer('position').notNull(), kind: text('kind').notNull().default('quiz'), prompt: text('prompt').notNull(),
  options: text('options').notNull().default('[]'), answer: text('answer').notNull(),
  seconds: integer('seconds').notNull().default(60), branch: text('branch').notNull().default('{}'),
}, t => [uniqueIndex('challenge_stages_position_idx').on(t.challengeId, t.position)]);

export const attempts = sqliteTable('attempts', {
  id: text('id').primaryKey(), challengeId: text('challenge_id').notNull().references(() => challenges.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id), attemptNo: integer('attempt_no').notNull(),
  status: text('status').notNull().default('active'), stageIndex: integer('stage_index').notNull().default(0),
  score: integer('score').notNull().default(0), answers: text('answers').notNull().default('[]'),
  startedAt: integer('started_at').notNull(), stageStartedAt: integer('stage_started_at').notNull(),
  completedAt: integer('completed_at'), updatedAt: integer('updated_at').notNull(), version: integer('version').notNull().default(0),
}, t => [uniqueIndex('attempts_number_idx').on(t.challengeId, t.userId, t.attemptNo), index('attempts_user_idx').on(t.userId, t.status)]);

export const events = sqliteTable('events', {
  id: text('id').primaryKey(), worldId: text('world_id').references(() => worlds.id, { onDelete: 'cascade' }), creatorId: text('creator_id').notNull().references(() => users.id),
  title: text('title').notNull(), description: text('description').notNull().default(''),
  status: text('status').notNull().default('scheduled'), stage: text('stage').notNull().default('puzzle'), revision: integer('revision').notNull().default(0),
  puzzlePrompt: text('puzzle_prompt').notNull(), puzzleAnswer: text('puzzle_answer').notNull(), puzzleGoal: integer('puzzle_goal').notNull().default(1),
  voteGoal: integer('vote_goal').notNull().default(1), contributionGoal: integer('contribution_goal').notNull().default(1),
  chosenDoor: text('chosen_door'), effectiveGoal: integer('effective_goal').notNull().default(1),
  rewardXp: integer('reward_xp').notNull().default(100), rewardPoints: integer('reward_points').notNull().default(50),
  startsAt: integer('starts_at').notNull(), endsAt: integer('ends_at').notNull(), createdAt: integer('created_at').notNull(), updatedAt: integer('updated_at').notNull(),
}, t => [index('events_live_idx').on(t.status, t.startsAt, t.endsAt), index('events_world_idx').on(t.worldId)]);

export const eventParticipants = sqliteTable('event_participants', {
  eventId: text('event_id').notNull().references(() => events.id, { onDelete: 'cascade' }), userId: text('user_id').notNull().references(() => users.id),
  puzzleSolved: integer('puzzle_solved').notNull().default(0), puzzleGuesses: integer('puzzle_guesses').notNull().default(0),
  contributed: integer('contributed').notNull().default(0), rewardClaimed: integer('reward_claimed').notNull().default(0), createdAt: integer('created_at').notNull(),
}, t => [primaryKey({ columns: [t.eventId, t.userId] })]);

export const eventActions = sqliteTable('event_actions', {
  id: text('id').primaryKey(), eventId: text('event_id').notNull().references(() => events.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id), actionKey: text('action_key').notNull(), kind: text('kind').notNull(), data: text('data').notNull().default('{}'), createdAt: integer('created_at').notNull(),
}, t => [uniqueIndex('event_actions_once_idx').on(t.eventId, t.userId, t.actionKey)]);

export const votes = sqliteTable('votes', {
  eventId: text('event_id').notNull().references(() => events.id, { onDelete: 'cascade' }), userId: text('user_id').notNull().references(() => users.id),
  option: text('option').notNull(), createdAt: integer('created_at').notNull(),
}, t => [primaryKey({ columns: [t.eventId, t.userId] })]);

export const eventContributions = sqliteTable('event_contributions', {
  eventId: text('event_id').notNull().references(() => events.id, { onDelete: 'cascade' }), userId: text('user_id').notNull().references(() => users.id),
  attemptId: text('attempt_id').notNull().references(() => attempts.id), createdAt: integer('created_at').notNull(),
}, t => [primaryKey({ columns: [t.eventId, t.userId] }), uniqueIndex('event_contributions_attempt_idx').on(t.attemptId)]);

export const eventLogs = sqliteTable('event_logs', {
  id: text('id').primaryKey(), eventId: text('event_id').notNull().references(() => events.id, { onDelete: 'cascade' }),
  kind: text('kind').notNull(), payload: text('payload').notNull().default('{}'), createdAt: integer('created_at').notNull(),
}, t => [index('event_logs_event_idx').on(t.eventId, t.createdAt)]);

export const rewards = sqliteTable('rewards', {
  id: text('id').primaryKey(), name: text('name').notNull(), description: text('description').notNull().default(''),
  kind: text('kind').notNull().default('badge'), rarity: text('rarity').notNull().default('common'),
  image: text('image').notNull().default('/assets/badge-gold.svg'), price: integer('price').notNull().default(0),
  enabled: integer('enabled').notNull().default(1), conditions: text('conditions').notNull().default('{}'), createdAt: integer('created_at').notNull(),
});

export const inventory = sqliteTable('inventory', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().references(() => users.id), rewardId: text('reward_id').notNull().references(() => rewards.id),
  equipped: integer('equipped').notNull().default(0), acquiredAt: integer('acquired_at').notNull(), source: text('source').notNull(),
}, t => [uniqueIndex('inventory_owned_idx').on(t.userId, t.rewardId)]);

export const xpTransactions = sqliteTable('xp_transactions', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().references(() => users.id),
  worldId: text('world_id').references(() => worlds.id), sourceKey: text('source_key').notNull(),
  xp: integer('xp').notNull().default(0), points: integer('points').notNull().default(0), reason: text('reason').notNull(), createdAt: integer('created_at').notNull(),
}, t => [uniqueIndex('xp_transactions_once_idx').on(t.userId, t.sourceKey), index('xp_transactions_period_idx').on(t.createdAt, t.worldId)]);

export const dailyClaims = sqliteTable('daily_claims', {
  userId: text('user_id').notNull().references(() => users.id), day: text('day').notNull(), streak: integer('streak').notNull(), createdAt: integer('created_at').notNull(),
}, t => [primaryKey({ columns: [t.userId, t.day] })]);

export const notifications = sqliteTable('notifications', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().references(() => users.id), title: text('title').notNull(),
  body: text('body').notNull(), href: text('href'), readAt: integer('read_at'), createdAt: integer('created_at').notNull(),
}, t => [index('notifications_user_idx').on(t.userId, t.createdAt)]);

export const supportTickets = sqliteTable('support_tickets', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().references(() => users.id), subject: text('subject').notNull(), message: text('message').notNull(),
  priority: text('priority').notNull().default('normal'), status: text('status').notNull().default('open'), assignedTo: text('assigned_to').references(() => users.id),
  createdAt: integer('created_at').notNull(), updatedAt: integer('updated_at').notNull(),
}, t => [index('support_tickets_user_idx').on(t.userId, t.status)]);

export const ticketReplies = sqliteTable('ticket_replies', {
  id: text('id').primaryKey(), ticketId: text('ticket_id').notNull().references(() => supportTickets.id, { onDelete: 'cascade' }),
  userId: text('user_id').notNull().references(() => users.id), message: text('message').notNull(), createdAt: integer('created_at').notNull(),
});

export const adminRoles = sqliteTable('admin_roles', {
  userId: text('user_id').primaryKey().references(() => users.id), role: text('role').notNull(), grantedBy: text('granted_by').references(() => users.id), createdAt: integer('created_at').notNull(),
});

export const auditLogs = sqliteTable('audit_logs', {
  id: text('id').primaryKey(), actorId: text('actor_id').references(() => users.id), action: text('action').notNull(),
  entityType: text('entity_type').notNull(), entityId: text('entity_id'), beforeData: text('before_data'), afterData: text('after_data'), createdAt: integer('created_at').notNull(),
}, t => [index('audit_logs_created_idx').on(t.createdAt)]);

export const settings = sqliteTable('settings', {
  key: text('key').primaryKey(), value: text('value').notNull(), updatedBy: text('updated_by').references(() => users.id), updatedAt: integer('updated_at').notNull(),
});

export const reports = sqliteTable('reports', {
  id: text('id').primaryKey(), userId: text('user_id').notNull().references(() => users.id), worldId: text('world_id').references(() => worlds.id),
  reason: text('reason').notNull(), status: text('status').notNull().default('open'), createdAt: integer('created_at').notNull(),
});

export const sessions = sqliteTable('sessions', {
  tokenHash: text('token_hash').primaryKey(), userId: text('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expiresAt: integer('expires_at').notNull(), createdAt: integer('created_at').notNull(),
}, t => [index('sessions_expires_idx').on(t.expiresAt)]);

export const webhookUpdates = sqliteTable('webhook_updates', {
  updateId: integer('update_id').primaryKey(), status: text('status').notNull().default('processing'),
  createdAt: integer('created_at').notNull(), updatedAt: integer('updated_at').notNull(), errorCode: text('error_code'),
});

export const rateLimits = sqliteTable('rate_limits', {
  key: text('key').primaryKey(), bucket: integer('bucket').notNull(), hits: integer('hits').notNull().default(0), updatedAt: integer('updated_at').notNull(),
});
