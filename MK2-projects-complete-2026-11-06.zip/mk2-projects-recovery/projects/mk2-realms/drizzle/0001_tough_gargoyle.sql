PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_rewards` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`kind` text DEFAULT 'badge' NOT NULL,
	`rarity` text DEFAULT 'common' NOT NULL,
	`image` text DEFAULT '/assets/badge-gold.svg' NOT NULL,
	`price` integer DEFAULT 0 NOT NULL,
	`enabled` integer DEFAULT 1 NOT NULL,
	`conditions` text DEFAULT '{}' NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_rewards`("id", "name", "description", "kind", "rarity", "image", "price", "enabled", "conditions", "created_at") SELECT "id", "name", "description", "kind", "rarity", "image", "price", "enabled", "conditions", "created_at" FROM `rewards`;--> statement-breakpoint
DROP TABLE `rewards`;--> statement-breakpoint
ALTER TABLE `__new_rewards` RENAME TO `rewards`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE TABLE `__new_teams` (
	`id` text PRIMARY KEY NOT NULL,
	`world_id` text NOT NULL,
	`leader_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`logo` text DEFAULT '/assets/quest-team.svg' NOT NULL,
	`points` integer DEFAULT 0 NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`world_id`) REFERENCES `worlds`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`leader_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
INSERT INTO `__new_teams`("id", "world_id", "leader_id", "name", "description", "logo", "points", "created_at") SELECT "id", "world_id", "leader_id", "name", "description", "logo", "points", "created_at" FROM `teams`;--> statement-breakpoint
DROP TABLE `teams`;--> statement-breakpoint
ALTER TABLE `__new_teams` RENAME TO `teams`;--> statement-breakpoint
CREATE UNIQUE INDEX `teams_world_name_idx` ON `teams` (`world_id`,`name`);--> statement-breakpoint
CREATE TABLE `__new_worlds` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`name` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`kind` text DEFAULT 'games' NOT NULL,
	`visibility` text DEFAULT 'public' NOT NULL,
	`rules` text DEFAULT '' NOT NULL,
	`image` text DEFAULT '/assets/castle.webp' NOT NULL,
	`background` text DEFAULT '/assets/castle.webp' NOT NULL,
	`color` text DEFAULT '#7C3AED' NOT NULL,
	`join_mode` text DEFAULT 'open' NOT NULL,
	`telegram_chat_id` text,
	`status` text DEFAULT 'active' NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL,
	FOREIGN KEY (`owner_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
INSERT INTO `__new_worlds`("id", "owner_id", "name", "description", "kind", "visibility", "rules", "image", "background", "color", "join_mode", "telegram_chat_id", "status", "created_at", "updated_at") SELECT "id", "owner_id", "name", "description", "kind", "visibility", "rules", "image", "background", "color", "join_mode", "telegram_chat_id", "status", "created_at", "updated_at" FROM `worlds`;--> statement-breakpoint
DROP TABLE `worlds`;--> statement-breakpoint
ALTER TABLE `__new_worlds` RENAME TO `worlds`;--> statement-breakpoint
CREATE INDEX `worlds_visibility_idx` ON `worlds` (`visibility`,`status`);--> statement-breakpoint
CREATE INDEX `worlds_owner_idx` ON `worlds` (`owner_id`);