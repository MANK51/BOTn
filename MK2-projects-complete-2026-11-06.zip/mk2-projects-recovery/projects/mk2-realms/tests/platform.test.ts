import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { ensureUser, platformApi, grantRewardStatements, mapUser } from '../lib/platform';

class Statement {
  values: any[] = [];
  constructor(private db: DatabaseSync, private sql: string) {}
  bind(...values: any[]) { this.values = values; return this; }
  async first() { return this.db.prepare(this.sql).get(...this.values) ?? null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.values) }; }
  execute() { const result = this.db.prepare(this.sql).run(...this.values); return { success: true, meta: { changes: Number(result.changes) } }; }
  async run() { return this.execute(); }
}
async function fixture() {
  const db = new DatabaseSync(':memory:'); db.exec('PRAGMA foreign_keys=ON');
  for (const file of readdirSync(resolve('drizzle')).filter(f => f.endsWith('.sql')).sort()) db.exec(readFileSync(resolve('drizzle', file), 'utf8'));
  const env = { DB: {
    prepare(sql: string) { return new Statement(db, sql); },
    async batch(statements: Statement[]) { db.exec('BEGIN'); try { const result = statements.map(s => s.execute()); db.exec('COMMIT'); return result; } catch (error) { db.exec('ROLLBACK'); throw error; } },
  } };
  await ensureUser(env, { id: 1001, first_name: 'مالك', username: 'owner' });
  await ensureUser(env, { id: 1002, first_name: 'لاعب', username: 'member' });
  await ensureUser(env, { id: 1003, first_name: 'زائر' });
  async function call(path: string, method = 'GET', userId: string | null = '1001', payload?: any) {
    const user = userId ? mapUser(db.prepare('SELECT * FROM users WHERE id=?').get(userId) as any) : null;
    const result = await platformApi(new Request(`https://test.invalid${path}`, { method, ...(payload === undefined ? {} : { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }) }), env, user);
    assert.ok(result, `route ${path} handled`); return { status: result.status, data: await result.json() as any };
  }
  const world = await call('/api/worlds', 'POST', '1001', { name: 'مملكة الاختبار', description: 'عالم حقيقي', kind: 'puzzles' });
  assert.equal(world.status, 201); const worldId = world.data.world.id;
  await call(`/api/worlds/${worldId}/join`, 'POST', '1002');
  return { db, env, call, worldId };
}
async function createChallenge(call: any, worldId: string, extra: any = {}) {
  const result = await call('/api/challenges', 'POST', '1001', { worldId, title: 'سر البوابة', status: 'published', xpReward: 50, pointsReward: 20, stages: [{ kind: 'quiz', prompt: 'كم يساوي 2 + 2؟', options: ['3', '4'], answer: '4', seconds: 60 }, { kind: 'riddle', prompt: 'اكتب كلمة أرض', answer: 'أرض', seconds: 60 }], ...extra });
  assert.equal(result.status, 201); return result.data.challenge.id;
}

test('world ownership, challenges, persisted stages and exactly-once verified progress', async () => {
  const { db, call, worldId } = await fixture();
  try {
    assert.equal(db.prepare('SELECT role FROM world_members WHERE world_id=? AND user_id=?').get(worldId, '1001')?.role, 'owner');
    assert.equal((await call('/api/challenges', 'POST', '1002', { worldId })).status, 403);
    const challengeId = await createChallenge(call, worldId);
    const details = await call(`/api/challenges/${challengeId}`, 'GET', '1002');
    assert.equal('answer' in details.data.challenge.stages[0], false);
    assert.equal((await call(`/api/challenges/${challengeId}`, 'GET', '1001')).data.challenge.stages[0].answer, '4');
    const start = await call(`/api/challenges/${challengeId}/start`, 'POST', '1002');
    assert.equal(start.status, 200); assert.equal('answer' in start.data.stage, false);
    const first = await call(`/api/attempts/${start.data.attempt.id}/answer`, 'POST', '1002', { answer: '4' });
    assert.equal(first.data.completed, false); assert.equal(first.data.attempt.stage_index, 1);
    const resume = await call(`/api/challenges/${challengeId}/start`, 'POST', '1002');
    assert.equal(resume.data.attempt.id, start.data.attempt.id); assert.equal(resume.data.stage.prompt, 'اكتب كلمة أرض');
    const win = await call(`/api/attempts/${start.data.attempt.id}/answer`, 'POST', '1002', { answer: 'أرض' });
    assert.equal(win.data.completed, true); assert.deepEqual(win.data.reward, { earned: true, xp: 50, points: 20, reason: null });
    assert.equal(win.data.user.xp, 50); assert.equal(win.data.user.points, 20);
    assert.equal((await call(`/api/attempts/${start.data.attempt.id}/answer`, 'POST', '1002', { answer: 'أرض' })).status, 409);
    const again = await call(`/api/challenges/${challengeId}/start`, 'POST', '1002');
    await call(`/api/attempts/${again.data.attempt.id}/answer`, 'POST', '1002', { answer: '4' });
    const duplicate = await call(`/api/attempts/${again.data.attempt.id}/answer`, 'POST', '1002', { answer: 'أرض' });
    assert.equal(duplicate.data.reward.earned, false); assert.equal(duplicate.data.user.xp, 50);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM xp_transactions WHERE user_id=?').get('1002')?.n, 1);
    assert.equal((await call(`/api/challenges/${challengeId}`, 'PATCH', '1001', { xpReward: 500 })).status, 409);
    assert.equal((await call(`/api/challenges/${challengeId}`, 'DELETE', '1001')).status, 409);
  } finally { db.close(); }
});

test('private worlds, approval hierarchy, suspended worlds and account status enforce server permissions', async () => {
  const { db, call, worldId } = await fixture();
  try {
    const created = await call('/api/worlds', 'POST', '1001', { name: 'العالم الخاص', visibility: 'private', joinMode: 'approval' }); const id = created.data.world.id;
    assert.equal((await call(`/api/worlds/${id}`, 'GET', '1003')).status, 403);
    assert.equal((await call('/api/worlds', 'GET', null)).data.worlds.some((w: any) => w.id === id), false);
    assert.equal((await call(`/api/worlds/${id}/join`, 'POST', '1003')).status, 403);
    const invite = await call(`/api/worlds/${id}/invite`, 'POST', '1001');
    assert.equal((await call(`/api/worlds/${id}?invite=${invite.data.invite}`, 'GET', '1003')).data.invitePreview, true);
    assert.equal((await call(`/api/worlds/${id}/join`, 'POST', '1003', { invite: invite.data.invite })).data.membership.status, 'pending');
    assert.equal((await call(`/api/worlds/${id}`, 'GET', '1003')).status, 403);
    assert.equal((await call(`/api/worlds/${id}/members/1003`, 'PATCH', '1001', { status: 'active' })).status, 200);
    assert.equal((await call(`/api/worlds/${id}`, 'GET', '1003')).data.world.isMember, true);
    assert.equal((await call(`/api/worlds/${worldId}/members/1001`, 'PATCH', '1002', { status: 'removed' })).status, 403);
    const challengeId = await createChallenge(call, worldId);
    db.prepare("UPDATE worlds SET status='suspended' WHERE id=?").run(worldId);
    assert.equal((await call(`/api/challenges/${challengeId}/start`, 'POST', '1002')).status, 404);
    assert.equal((await call('/api/worlds', 'GET', null)).data.worlds.length, 0);
    db.prepare("UPDATE users SET status='banned' WHERE id='1003'").run();
    assert.equal((await call('/api/profile', 'GET', '1003')).status, 403);
  } finally { db.close(); }
});

test('wrong answers, server expiry and concurrent attempts cannot manufacture success', async () => {
  const { db, call, worldId } = await fixture();
  try {
    const id = await createChallenge(call, worldId, { attemptLimit: 2 });
    const starts = await Promise.all([call(`/api/challenges/${id}/start`, 'POST', '1002'), call(`/api/challenges/${id}/start`, 'POST', '1002')]);
    assert.equal(starts[0].data.attempt.id, starts[1].data.attempt.id);
    const failed = await call(`/api/attempts/${starts[0].data.attempt.id}/answer`, 'POST', '1002', { answer: '3', score: 100, xp: 50000 });
    assert.equal(failed.data.attempt.status, 'failed'); assert.equal(failed.data.user.xp, 0);
    const second = await call(`/api/challenges/${id}/start`, 'POST', '1002');
    db.prepare('UPDATE attempts SET stage_started_at=? WHERE id=?').run(Date.now() - 61000, second.data.attempt.id);
    const expired = await call(`/api/attempts/${second.data.attempt.id}/answer`, 'POST', '1002', { answer: '4' });
    assert.equal(expired.data.expired, true); assert.equal(expired.data.correct, false);
    assert.equal((await call(`/api/challenges/${id}/start`, 'POST', '1002')).status, 409);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM xp_transactions').get()?.n, 0);
  } finally { db.close(); }
});

test('daily rewards and shop purchases are atomic and duplicate-safe under concurrent requests', async () => {
  const { db, call } = await fixture();
  try {
    const daily = await Promise.all([call('/api/daily', 'POST', '1002'), call('/api/daily', 'POST', '1002')]);
    assert.deepEqual(daily.map(r => r.status).sort(), [200, 409]);
    assert.equal(db.prepare('SELECT xp FROM users WHERE id=?').get('1002')?.xp, 25);
    assert.equal(db.prepare('SELECT points FROM users WHERE id=?').get('1002')?.points, 25);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM daily_claims').get()?.n, 1);
    for (const id of ['frame-a', 'frame-b']) db.prepare('INSERT INTO rewards(id,name,kind,price,created_at) VALUES(?,?,?,?,?)').run(id, id, 'frame', 20, Date.now());
    const purchases = await Promise.all([call('/api/store/frame-a/buy', 'POST', '1002'), call('/api/store/frame-b/buy', 'POST', '1002')]);
    assert.deepEqual(purchases.map(r => r.status).sort(), [200, 409]);
    assert.equal(db.prepare('SELECT points FROM users WHERE id=?').get('1002')?.points, 5);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM inventory WHERE user_id=?').get('1002')?.n, 1);
    const owned: any = db.prepare('SELECT * FROM inventory WHERE user_id=?').get('1002');
    assert.equal((await call(`/api/store/${owned.reward_id}/buy`, 'POST', '1002')).status, 409);
    assert.equal((await call(`/api/inventory/${owned.id}`, 'PATCH', '1003', { equipped: true })).status, 404);
  } finally { db.close(); }
});

test('idempotent ledger caps positive daily earnings and updates team balance once', async () => {
  const { db, env, call, worldId } = await fixture();
  try {
    const team = await call('/api/teams', 'POST', '1002', { worldId, name: 'النجوم' }); assert.equal(team.status, 201);
    await env.DB.batch(grantRewardStatements(env, '1002', 'test:reward', 100, 80, 'اختبار', worldId));
    await env.DB.batch(grantRewardStatements(env, '1002', 'test:reward', 100, 80, 'اختبار', worldId));
    assert.equal(db.prepare('SELECT xp FROM users WHERE id=?').get('1002')?.xp, 100);
    assert.equal(db.prepare('SELECT points FROM teams WHERE id=?').get(team.data.team.id)?.points, 80);
    await env.DB.batch(grantRewardStatements(env, '1002', 'test:cap', 3000, 20, 'اختبار', worldId));
    assert.equal(db.prepare('SELECT xp FROM users WHERE id=?').get('1002')?.xp, 100);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM xp_transactions').get()?.n, 1);
    assert.equal((await call('/api/teams?worldId=' + worldId, 'GET', '1002')).data.teams[0].isMember, true);
    assert.equal((await call(`/api/worlds/${worldId}/leave`, 'POST', '1002')).status, 409);
  } finally { db.close(); }
});

test('maintenance, feature settings and support ticket privacy use saved configuration', async () => {
  const { db, call } = await fixture();
  try {
    db.prepare('INSERT INTO settings(key,value,updated_at) VALUES(?,?,?)').run('features.world_creation', 'false', Date.now());
    assert.equal((await call('/api/worlds', 'POST', '1002', { name: 'متوقف' })).status, 503);
    db.prepare('INSERT INTO settings(key,value,updated_at) VALUES(?,?,?)').run('maintenance.enabled', 'true', Date.now());
    assert.equal((await call('/api/daily', 'POST', '1002')).status, 503);
    const ticket = await call('/api/tickets', 'POST', '1002', { subject: 'مساعدة', message: 'أحتاج مساعدة' });
    assert.equal(ticket.status, 201);
    assert.equal((await call(`/api/tickets/${ticket.data.ticket.id}/replies`, 'POST', '1003', { message: 'تزوير' })).status, 404);
    assert.equal((await call('/api/tickets', 'GET', '1003')).data.tickets.length, 0);
    assert.equal((await call(`/api/tickets/${ticket.data.ticket.id}/replies`, 'POST', '1002', { message: 'متابعة' })).status, 200);
  } finally { db.close(); }
});
