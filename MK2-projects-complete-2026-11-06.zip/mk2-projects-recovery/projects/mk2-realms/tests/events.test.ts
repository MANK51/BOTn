import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { eventTransition, normalizeEventAnswer, eventsApi } from '../lib/events';

class Statement {
  values: any[] = [];
  constructor(private db: DatabaseSync, private sql: string) {}
  bind(...values: any[]) { this.values = values; return this; }
  async first() { return this.db.prepare(this.sql).get(...this.values) || null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.values) }; }
  async run() {
    const result = this.db.prepare(this.sql).run(...this.values);
    return { success: true, meta: { changes: Number(result.changes), last_row_id: Number(result.lastInsertRowid) } };
  }
}

function fixture() {
  const db = new DatabaseSync(':memory:');
  db.exec(`
    PRAGMA foreign_keys=ON;
    CREATE TABLE users(id TEXT PRIMARY KEY,name TEXT,avatar TEXT,username TEXT,telegram_id TEXT,xp INTEGER DEFAULT 0,points INTEGER DEFAULT 0,level INTEGER DEFAULT 1,role TEXT DEFAULT 'user',status TEXT DEFAULT 'active');
    CREATE TABLE worlds(id TEXT PRIMARY KEY,owner_id TEXT,name TEXT,visibility TEXT,status TEXT DEFAULT 'active');
    CREATE TABLE world_members(world_id TEXT,user_id TEXT,role TEXT,status TEXT,PRIMARY KEY(world_id,user_id));
    CREATE TABLE teams(id TEXT PRIMARY KEY,world_id TEXT,points INTEGER DEFAULT 0);
    CREATE TABLE team_members(team_id TEXT,world_id TEXT,user_id TEXT);
    CREATE TABLE challenges(id TEXT PRIMARY KEY,world_id TEXT,title TEXT,created_by TEXT);
    CREATE TABLE attempts(id TEXT PRIMARY KEY,challenge_id TEXT,user_id TEXT,status TEXT,score INTEGER,completed_at INTEGER);
    CREATE TABLE events(id TEXT PRIMARY KEY,world_id TEXT,creator_id TEXT,title TEXT,description TEXT,status TEXT,stage TEXT,starts_at INTEGER,ends_at INTEGER,revision INTEGER DEFAULT 0,puzzle_prompt TEXT,puzzle_answer TEXT,puzzle_goal INTEGER,vote_goal INTEGER,contribution_goal INTEGER,chosen_door TEXT,effective_goal INTEGER,reward_xp INTEGER,reward_points INTEGER,created_at INTEGER,updated_at INTEGER);
    CREATE TABLE event_participants(event_id TEXT,user_id TEXT,puzzle_solved INTEGER DEFAULT 0,puzzle_guesses INTEGER DEFAULT 0,contributed INTEGER DEFAULT 0,reward_claimed INTEGER DEFAULT 0,created_at INTEGER,PRIMARY KEY(event_id,user_id));
    CREATE TABLE votes(event_id TEXT,user_id TEXT,option TEXT,created_at INTEGER,PRIMARY KEY(event_id,user_id));
    CREATE TABLE event_contributions(event_id TEXT,user_id TEXT,attempt_id TEXT UNIQUE,created_at INTEGER,PRIMARY KEY(event_id,user_id));
    CREATE TABLE event_logs(id TEXT PRIMARY KEY,event_id TEXT,kind TEXT,payload TEXT,created_at INTEGER);
    CREATE TABLE audit_logs(id TEXT PRIMARY KEY,actor_id TEXT,action TEXT,entity_type TEXT,entity_id TEXT,before_data TEXT,after_data TEXT,created_at INTEGER);
    CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT);
    CREATE TABLE xp_transactions(id TEXT PRIMARY KEY,user_id TEXT,world_id TEXT,source_key TEXT,xp INTEGER,points INTEGER,reason TEXT,created_at INTEGER,UNIQUE(user_id,source_key));
    CREATE TABLE rewards(id TEXT PRIMARY KEY,name TEXT,description TEXT,kind TEXT,rarity TEXT,image TEXT,price INTEGER,enabled INTEGER,conditions TEXT,created_at INTEGER);
    CREATE TABLE inventory(id TEXT PRIMARY KEY,user_id TEXT,reward_id TEXT,equipped INTEGER,acquired_at INTEGER,source TEXT,UNIQUE(user_id,reward_id));
    INSERT INTO users(id,name) VALUES('owner','المالك'),('member','اللاعب'),('outsider','زائر');
    INSERT INTO worlds(id,owner_id,name,visibility) VALUES('world','owner','عالم الاختبار','public'),('private','owner','عالم خاص','private');
    INSERT INTO world_members VALUES('world','owner','owner','active'),('world','member','member','active'),('private','owner','owner','active');
    INSERT INTO challenges VALUES('challenge','world','تحدي حقيقي','owner');
  `);
  const env = {
    DB: {
      prepare(sql: string) { return new Statement(db, sql); },
      async batch(statements: Statement[]) {
        db.exec('BEGIN');
        try {
          const result = [];
          for (const statement of statements) result.push(await statement.run());
          db.exec('COMMIT');
          return result;
        } catch (error) { db.exec('ROLLBACK'); throw error; }
      },
    },
  };
  async function call(path: string, method = 'GET', user: any = { id: 'member', status: 'active' }, body?: any) {
    const response = await eventsApi(new Request(`https://test.invalid${path}`, {
      method, ...(body !== undefined ? { body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } } : {}),
    }), env, user);
    assert.ok(response, 'Event route should be handled');
    return { status: response.status, data: await response.json() as any };
  }
  return { db, env, call };
}

test('event transition respects server times, majority branch and valid final contribution', () => {
  const event = { status: 'scheduled', stage: 'puzzle', starts_at: 100, ends_at: 500, puzzle_goal: 2, vote_goal: 3, contribution_goal: 4, effective_goal: 4 };
  assert.equal(eventTransition(event, {}, 99), null);
  assert.deepEqual(eventTransition(event, {}, 100), { status: 'active', stage: 'puzzle' });
  assert.deepEqual(eventTransition(event, {}, 501), { status: 'failed', stage: 'failed' });
  const active = { ...event, status: 'active' };
  assert.equal(eventTransition(active, { solved: 1 }, 200), null);
  assert.deepEqual(eventTransition(active, { solved: 2 }, 200), { stage: 'vote' });
  assert.deepEqual(eventTransition({ ...active, stage: 'vote' }, { votes: 3, red: 2, blue: 1 }, 200), { stage: 'cooperate', chosen_door: 'red', effective_goal: 5 });
  assert.deepEqual(eventTransition({ ...active, stage: 'vote' }, { votes: 4, red: 2, blue: 2 }, 200), { stage: 'cooperate', chosen_door: 'blue', effective_goal: 4 });
  assert.deepEqual(eventTransition({ ...active, stage: 'cooperate' }, { contributions: 4 }, 501), { status: 'completed', stage: 'opened' });
  assert.deepEqual(eventTransition({ ...active, stage: 'cooperate' }, { contributions: 3 }, 501), { status: 'failed', stage: 'failed' });
  assert.equal(eventTransition({ ...active, status: 'cancelled' }, { contributions: 10 }, 200), null);
  assert.equal(normalizeEventAnswer('  أَرْضـ  '), 'ارض');
});

test('real vault cycle validates identity and challenge evidence, then awards once', async () => {
  const { db, call } = fixture();
  try {
    const create = await call('/api/events', 'POST', { id: 'owner' }, {
      worldId: 'world', title: 'الخزنة', puzzlePrompt: 'ما موطننا؟', puzzleAnswer: 'أرض',
      puzzleGoal: 1, voteGoal: 1, contributionGoal: 1, rewardXp: 40, rewardPoints: 20,
    });
    assert.equal(create.status, 201);
    const eventId = create.data.event.id;
    assert.equal('puzzle_answer' in create.data.event, false);
    assert.equal('puzzleAnswer' in create.data.event, false);
    assert.equal((await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'outsider' }, { answer: 'ارض' })).status, 403);
    const wrong = await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'member' }, { answer: 'شمس' });
    assert.equal(wrong.status, 200);
    assert.equal(wrong.data.participant.puzzleGuesses, 1);
    assert.equal(wrong.data.participant.puzzleSolved, false);
    const solved = await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'member' }, { answer: 'ارض' });
    assert.equal(solved.data.event.stage, 'vote');
    const vote = await call(`/api/events/${eventId}/vote`, 'POST', { id: 'member' }, { option: 'blue' });
    assert.equal(vote.status, 200);
    assert.equal(vote.data.event.stage, 'cooperate');
    assert.equal((await call(`/api/events/${eventId}/vote`, 'POST', { id: 'member' }, { option: 'red' })).status, 409);
    assert.equal((await call(`/api/events/${eventId}/contribute`, 'POST', { id: 'member' }, { attemptId: 'forged' })).status, 409);
    db.prepare(`INSERT INTO attempts VALUES(?,?,?,?,?,?)`).run('valid-attempt', 'challenge', 'member', 'completed', 1, Date.now());
    const opened = await call(`/api/events/${eventId}/contribute`, 'POST', { id: 'member' }, { attemptId: 'valid-attempt' });
    assert.equal(opened.status, 200);
    assert.equal(opened.data.event.stage, 'opened');
    assert.equal(opened.data.participant.rewardClaimed, true);
    assert.equal(db.prepare('SELECT xp FROM users WHERE id=?').get('member')?.xp, 40);
    assert.equal(db.prepare('SELECT points FROM users WHERE id=?').get('member')?.points, 20);
    assert.equal((await call(`/api/events/${eventId}/claim`, 'POST', { id: 'member' }, {})).status, 200);
    assert.equal((await call(`/api/events/${eventId}/claim`, 'POST', { id: 'member' }, {})).status, 200);
    assert.equal(db.prepare('SELECT xp FROM users WHERE id=?').get('member')?.xp, 40);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM xp_transactions').get()?.n, 1);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM inventory').get()?.n, 1);
    assert.equal((await call(`/api/events/${eventId}/claim`, 'POST', { id: 'owner' }, {})).status, 403);
    assert.equal((await call(`/api/events/${eventId}/cancel`, 'POST', { id: 'owner' }, {})).status, 409);
  } finally { db.close(); }
});

test('private events are hidden and unprivileged creation/cancellation is rejected', async () => {
  const { db, call } = fixture();
  try {
    assert.equal((await call('/api/events', 'POST', { id: 'member' }, { worldId: 'world', templateId: 'black-vault' })).status, 403);
    const created = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'private', templateId: 'black-vault' });
    assert.equal(created.status, 201);
    const eventId = created.data.event.id;
    assert.equal((await call(`/api/events/${eventId}`, 'GET', null)).status, 404);
    assert.equal((await call('/api/events', 'GET', null)).data.events.length, 0);
    assert.equal((await call(`/api/events/${eventId}/cancel`, 'POST', { id: 'member' }, {})).status, 403);
    assert.equal((await call(`/api/events/${eventId}/cancel`, 'POST', { id: 'owner' }, {})).data.event.status, 'cancelled');
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM xp_transactions').get()?.n, 0);
  } finally { db.close(); }
});

test('puzzle guess limit and future scheduling are persisted server rules', async () => {
  const { db, call } = fixture();
  try {
    const created = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault' });
    const eventId = created.data.event.id;
    for (let i = 0; i < 5; i++) assert.equal((await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'member' }, { answer: 'wrong' })).status, 200);
    assert.equal((await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'member' }, { answer: '12' })).status, 409);
    assert.equal(db.prepare('SELECT puzzle_guesses FROM event_participants WHERE event_id=? AND user_id=?').get(eventId, 'member')?.puzzle_guesses, 5);
    const scheduled = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault', startsAt: Date.now() + 60000 });
    assert.equal(scheduled.data.event.status, 'scheduled');
    assert.equal((await call(`/api/events/${scheduled.data.event.id}/puzzle`, 'POST', { id: 'member' }, { answer: '12' })).status, 409);
  } finally { db.close(); }
});

test('a successful challenge result cannot be recycled into another event', async () => {
  const { db, call } = fixture();
  try {
    const first = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault', contributionGoal: 1 });
    const second = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault', contributionGoal: 1 });
    for (const event of [first, second]) {
      await call(`/api/events/${event.data.event.id}/puzzle`, 'POST', { id: 'member' }, { answer: '12' });
      await call(`/api/events/${event.data.event.id}/vote`, 'POST', { id: 'member' }, { option: 'blue' });
    }
    db.prepare(`INSERT INTO attempts VALUES(?,?,?,?,?,?)`).run('attempt-once', 'challenge', 'member', 'completed', 1, Date.now());
    assert.equal((await call(`/api/events/${first.data.event.id}/contribute`, 'POST', { id: 'member' }, { attemptId: 'attempt-once' })).status, 200);
    assert.equal((await call(`/api/events/${second.data.event.id}/contribute`, 'POST', { id: 'member' }, { attemptId: 'attempt-once' })).status, 409);
    db.prepare(`INSERT INTO attempts VALUES(?,?,?,?,?,?)`).run('new-attempt-same-challenge', 'challenge', 'member', 'completed', 1, Date.now());
    assert.equal((await call(`/api/events/${second.data.event.id}/contribute`, 'POST', { id: 'member' }, { attemptId: 'new-attempt-same-challenge' })).status, 409);
    assert.equal((await call(`/api/events/${second.data.event.id}`)).data.availableAttempts.length, 0);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM event_contributions').get()?.n, 1);
  } finally { db.close(); }
});

test('self-authored challenges cannot earn event rewards and platform feature controls apply', async () => {
  const { db, call } = fixture();
  try {
    const created = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault', contributionGoal: 1 });
    const eventId = created.data.event.id;
    await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'member' }, { answer: '12' });
    await call(`/api/events/${eventId}/vote`, 'POST', { id: 'member' }, { option: 'blue' });
    db.prepare(`INSERT INTO challenges VALUES(?,?,?,?)`).run('self', 'world', 'تحدّي اللاعب', 'member');
    db.prepare(`INSERT INTO attempts VALUES(?,?,?,?,?,?)`).run('self-attempt', 'self', 'member', 'completed', 1, Date.now());
    assert.equal((await call(`/api/events/${eventId}/contribute`, 'POST', { id: 'member' }, { attemptId: 'self-attempt' })).status, 409);
    assert.equal((await call(`/api/events/${eventId}`)).data.availableAttempts.length, 0);
    db.prepare(`INSERT INTO settings VALUES('features.events','false')`).run();
    assert.equal((await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault' })).status, 503);
    assert.equal((await call(`/api/events/${eventId}/cancel`, 'POST', { id: 'owner' }, {})).status, 200);
  } finally { db.close(); }
});

test('daily reward cap never marks an unawarded contributor claimed', async () => {
  const { db, call } = fixture();
  try {
    const created = await call('/api/events', 'POST', { id: 'owner' }, { worldId: 'world', templateId: 'black-vault', contributionGoal: 1 });
    const eventId = created.data.event.id;
    await call(`/api/events/${eventId}/puzzle`, 'POST', { id: 'member' }, { answer: '12' });
    await call(`/api/events/${eventId}/vote`, 'POST', { id: 'member' }, { option: 'blue' });
    db.prepare(`INSERT INTO attempts VALUES(?,?,?,?,?,?)`).run('valid-capped', 'challenge', 'member', 'completed', 1, Date.now());
    db.prepare(`INSERT INTO xp_transactions VALUES(?,?,?,?,?,?,?,?)`).run('at-cap', 'member', 'world', 'previous-earned', 3000, 1500, 'مكافآت موثوقة سابقة', Date.now());
    const opened = await call(`/api/events/${eventId}/contribute`, 'POST', { id: 'member' }, { attemptId: 'valid-capped' });
    assert.equal(opened.data.event.status, 'completed');
    assert.equal(opened.data.participant.rewardClaimed, false);
    assert.equal((await call(`/api/events/${eventId}/claim`, 'POST', { id: 'member' }, {})).status, 429);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM inventory').get()?.n, 0);
    assert.equal(db.prepare(`SELECT COUNT(*) AS n FROM xp_transactions WHERE source_key=?`).get(`event:${eventId}`)?.n, 0);
  } finally { db.close(); }
});
