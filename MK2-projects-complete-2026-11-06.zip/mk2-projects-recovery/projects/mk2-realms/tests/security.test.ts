import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { ApiError, verifyTelegramInitData } from '../lib/security';

// Deliberately fake, offline-only credentials. Never use a real bot token in tests.
const TEST_BOT_TOKEN = '0000000000:offline-unit-test-token-never-deploy';
const NOW = 1_700_000_000;
const TELEGRAM_USER = {
  id: 123456789,
  first_name: 'ريم + & =\n🌙',
  last_name: 'النجار',
  username: 'reem_test',
  photo_url: 'https://images.example.invalid/reem.png',
  allows_write_to_pm: true,
};

type Pair = [string, string];

function fields(user: unknown = TELEGRAM_USER, authDate = NOW): Pair[] {
  // Transport order intentionally differs from check-string order.
  return [
    ['user', JSON.stringify(user)],
    ['start_param', 'realm=القمر&invitation=one + two'],
    ['auth_date', String(authDate)],
    ['query_id', 'AAExample+Encoded/Value='],
  ];
}

function signedInitData(pairs: Pair[], token = TEST_BOT_TOKEN): string {
  // Independent implementation of Telegram's published two-stage HMAC scheme.
  // Sort decoded key/value pairs and exclude only the hash parameter.
  const check = pairs
    .filter(([key]) => key !== 'hash')
    .slice()
    .sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(token).digest();
  const hash = createHmac('sha256', secret).update(check).digest('hex');
  const transport = new URLSearchParams(pairs.filter(([key]) => key !== 'hash'));
  transport.set('hash', hash);
  return transport.toString();
}

async function assertUnauthorized(raw: string, token = TEST_BOT_TOKEN, now = NOW) {
  await assert.rejects(
    () => verifyTelegramInitData(raw, token, now),
    (error: unknown) => error instanceof ApiError && error.status === 401,
  );
}

test('accepts an independently signed Telegram payload with decoded Unicode and punctuation', async () => {
  const user = await verifyTelegramInitData(signedInitData(fields()), TEST_BOT_TOKEN, NOW);
  assert.deepEqual(user, TELEGRAM_USER);
});

test('uses ordinal key sorting for every signed parameter', async () => {
  const raw = signedInitData([...fields(), ['Z_extension', 'upper'], ['a_extension', 'lower']]);
  assert.equal((await verifyTelegramInitData(raw, TEST_BOT_TOKEN, NOW)).id, TELEGRAM_USER.id);
});

test('rejects modified signed user data and a different bot token', async () => {
  const original = signedInitData(fields());
  const tampered = new URLSearchParams(original);
  tampered.set('user', JSON.stringify({ ...TELEGRAM_USER, id: 987654321 }));
  await assertUnauthorized(tampered.toString());
  await assertUnauthorized(original, '0000000000:another-offline-test-token');
});

test('enforces the one-hour freshness window including its boundary', async () => {
  assert.equal((await verifyTelegramInitData(signedInitData(fields(TELEGRAM_USER, NOW - 3600)), TEST_BOT_TOKEN, NOW)).id, TELEGRAM_USER.id);
  await assertUnauthorized(signedInitData(fields(TELEGRAM_USER, NOW - 3601)));
});

test('allows at most thirty seconds of future clock skew', async () => {
  assert.equal((await verifyTelegramInitData(signedInitData(fields(TELEGRAM_USER, NOW + 30)), TEST_BOT_TOKEN, NOW)).id, TELEGRAM_USER.id);
  await assertUnauthorized(signedInitData(fields(TELEGRAM_USER, NOW + 31)));
});

test('rejects duplicate parameters even when their values are identical', async t => {
  const original = signedInitData(fields());
  for (const key of ['user', 'auth_date', 'query_id', 'hash']) {
    await t.test(key, async () => {
      const duplicated = new URLSearchParams(original);
      duplicated.append(key, duplicated.get(key)!);
      await assertUnauthorized(duplicated.toString());
    });
  }
});

test('rejects nonpositive, fractional, unsafe and nonnumeric Telegram user IDs', async t => {
  for (const id of [-1, 0, 1.5, Number.MAX_SAFE_INTEGER + 1, '123456789', null]) {
    await t.test(String(id), async () => {
      await assertUnauthorized(signedInitData(fields({ ...TELEGRAM_USER, id })));
    });
  }
});

test('rejects malformed, missing and incorrectly shaped user JSON despite a valid signature', async t => {
  const invalidUsers: Array<[string, string | undefined]> = [
    ['malformed JSON', '{'],
    ['missing user', undefined],
    ['null', 'null'],
    ['array', '[]'],
    ['missing first_name', JSON.stringify({ id: TELEGRAM_USER.id })],
    ['nonstring first_name', JSON.stringify({ ...TELEGRAM_USER, first_name: 7 })],
  ];
  for (const [label, value] of invalidUsers) {
    await t.test(label, async () => {
      const pairs = fields().filter(([key]) => key !== 'user');
      if (value !== undefined) pairs.push(['user', value]);
      await assertUnauthorized(signedInitData(pairs));
    });
  }
});

test('rejects malformed or missing hashes and well-shaped hashes with the wrong signature', async t => {
  for (const hash of [undefined, '', 'abc', 'g'.repeat(64), 'a'.repeat(63), 'a'.repeat(65), '0'.repeat(64)]) {
    await t.test(hash === undefined ? 'missing' : `hash ${hash.length}: ${hash.slice(0, 4)}`, async () => {
      const params = new URLSearchParams(signedInitData(fields()));
      if (hash === undefined) params.delete('hash'); else params.set('hash', hash);
      await assertUnauthorized(params.toString());
    });
  }
});

test('accepts uppercase hexadecimal signature encoding', async () => {
  const params = new URLSearchParams(signedInitData(fields()));
  params.set('hash', params.get('hash')!.toUpperCase());
  assert.equal((await verifyTelegramInitData(params.toString(), TEST_BOT_TOKEN, NOW)).id, TELEGRAM_USER.id);
});

test('rejects invalid or missing auth_date, empty credentials and oversized input', async t => {
  for (const date of [undefined, '', 'invalid', '1700000000.5', String(Number.MAX_SAFE_INTEGER + 1)]) {
    await t.test(`auth_date ${String(date)}`, async () => {
      const pairs = fields().filter(([key]) => key !== 'auth_date');
      if (date !== undefined) pairs.push(['auth_date', date]);
      await assertUnauthorized(signedInitData(pairs));
    });
  }
  await assertUnauthorized('');
  await assertUnauthorized(signedInitData(fields()), '');
  await assertUnauthorized('a'.repeat(16385));
});

test('limits optional profile fields and accepts only HTTPS photos', async () => {
  const user = await verifyTelegramInitData(signedInitData(fields({
    ...TELEGRAM_USER,
    first_name: 'x'.repeat(101),
    last_name: 'y'.repeat(101),
    username: 'z'.repeat(65),
    photo_url: 'http://images.example.invalid/reem.png',
    allows_write_to_pm: 'true',
  })), TEST_BOT_TOKEN, NOW);
  assert.equal(user.first_name, 'x'.repeat(100));
  assert.equal(user.last_name, 'y'.repeat(100));
  assert.equal(user.username, 'z'.repeat(64));
  assert.equal(user.photo_url, undefined);
  assert.equal(user.allows_write_to_pm, false);
});
