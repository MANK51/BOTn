import test, { type TestContext } from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { botWebhook, flushEventAnnouncements } from '../lib/bot';
import { ensureUser } from '../lib/platform';

// Offline provider credentials: these cannot authenticate with Telegram.
const token = '999999999:TEST_ONLY_BOT_PROVIDER_TOKEN';
const botId = 999999999;
const secret = 'local-bot-test-webhook-secret';
const appOrigin = 'https://bot-tests.invalid';
const groupId = -1009876543210;

class Statement {
  values: any[] = [];
  constructor(private db: DatabaseSync, private sql: string) {}
  bind(...values: any[]) { this.values = values; return this; }
  async first() { return this.db.prepare(this.sql).get(...this.values) ?? null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.values) }; }
  execute() { const result = this.db.prepare(this.sql).run(...this.values); return { success: true, meta: { changes: Number(result.changes) } }; }
  async run() { return this.execute(); }
}

function fixture() {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys=ON');
  for (const file of readdirSync(resolve('drizzle')).filter(file => file.endsWith('.sql')).sort()) db.exec(readFileSync(resolve('drizzle', file), 'utf8'));
  const env = {
    DB: {
      prepare(sql: string) { return new Statement(db, sql); },
      async batch(statements: Statement[]) {
        db.exec('BEGIN');
        try { const result = statements.map(statement => statement.execute()); db.exec('COMMIT'); return result; }
        catch (error) { db.exec('ROLLBACK'); throw error; }
      },
    },
    TELEGRAM_BOT_TOKEN: token,
    TELEGRAM_WEBHOOK_SECRET: secret,
    APP_URL: appOrigin,
    BOT_USERNAME: 'LOCAL_REALMS_TEST_BOT',
  };
  async function webhook(update: any) {
    const response = await botWebhook(new Request(`${appOrigin}/api/bot/webhook`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-telegram-bot-api-secret-token': secret }, body: JSON.stringify(update) }), env);
    return { status: response.status, data: await response.json() as any };
  }
  return { db, env, webhook };
}

type Delivery = { method: string, payload: any };
function provider(t: TestContext, respond?: (delivery: Delivery) => any | Promise<any>) {
  const calls: Delivery[] = [];
  t.mock.method(globalThis, 'fetch', async (input: any, options: any) => {
    const url = new URL(String(input));
    assert.equal(url.origin, 'https://api.telegram.org');
    assert.equal(url.pathname.startsWith(`/bot${token}/`), true);
    assert.equal(options.method, 'POST');
    const delivery = { method: url.pathname.split('/').at(-1)!, payload: JSON.parse(options.body) };
    calls.push(delivery);
    const answer = respond ? await respond(delivery) : { ok: true, result: { message_id: calls.length } };
    return new Response(JSON.stringify(answer), { headers: { 'content-type': 'application/json' } });
  });
  return calls;
}

const command = (updateId: number, text: string, userId = 1001, group = false) => ({ update_id: updateId, message: { message_id: updateId, from: { id: userId, is_bot: false, first_name: `مستخدم ${userId}`, username: `local_${userId}` }, chat: { id: group ? groupId : userId, type: group ? 'supergroup' : 'private' }, text } });

async function seedWorld(db: DatabaseSync, env: any, id = 'local-world', linked = false) {
  for (const userId of [1001, 1002, 1003]) await ensureUser(env, { id: userId, first_name: `مستخدم ${userId}` });
  const now = Date.now();
  db.prepare('INSERT INTO worlds(id,owner_id,name,telegram_chat_id,created_at,updated_at) VALUES(?,?,?,?,?,?)').run(id, '1001', `عالم ${id}`, linked ? String(groupId) : null, now, now);
  db.prepare("INSERT INTO world_members(world_id,user_id,role,status,joined_at) VALUES(?,'1001','owner','active',?)").run(id, now);
  db.prepare("INSERT INTO world_members(world_id,user_id,role,status,joined_at) VALUES(?,'1002','member','active',?)").run(id, now);
  return id;
}

function seedEvent(db: DatabaseSync, id: string, worldId: string, status = 'completed') {
  const now = Date.now();
  db.prepare('INSERT INTO events(id,world_id,creator_id,title,status,stage,puzzle_prompt,puzzle_answer,starts_at,ends_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)').run(id, worldId, '1001', `فعالية ${id}`, status, status === 'completed' ? 'opened' : 'puzzle', 'لغز محلي', 'أرض', now - 60000, now + 60000, now, now);
}

test('authenticated /start persists the Telegram sender and sends a welcome image with usable Mini App sections', async t => {
  const { db, webhook } = fixture();
  const calls = provider(t);
  try {
    const response = await webhook(command(10001, '/start'));
    assert.equal(response.status, 200);
    assert.equal(db.prepare('SELECT telegram_id FROM users WHERE id=?').get('1001')?.telegram_id, '1001');
    assert.equal(db.prepare('SELECT COUNT(*) n FROM users').get()?.n, 1);
    assert.equal(calls.length, 1);
    assert.equal(calls[0].method, 'sendPhoto');
    assert.equal(calls[0].payload.chat_id, 1001);
    assert.equal(calls[0].payload.photo, `${appOrigin}/assets/welcome.jpg`);
    assert.match(calls[0].payload.caption, /MK~2 REALMS/);
    const buttons = calls[0].payload.reply_markup.inline_keyboard.flat();
    const appUrls = buttons.filter((button: any) => button.web_app).map((button: any) => new URL(button.web_app.url));
    assert.deepEqual(appUrls.map((url: URL) => url.searchParams.get('view')).sort(), ['challenges', 'create', 'home', 'rewards', 'worlds']);
    for (const url of appUrls) { assert.equal(url.origin, appOrigin); assert.equal(url.pathname, '/'); }
    assert.deepEqual(buttons.filter((button: any) => button.callback_data).map((button: any) => button.callback_data).sort(), ['help', 'rank', 'settings']);
    assert.equal((await webhook(command(10001, '/start'))).status, 200);
    assert.equal(calls.length, 1, 'repeated update must not send another welcome');
    const deepLink = await webhook(command(10002, '/start world_local-world'));
    assert.equal(deepLink.status, 200);
    const enter = new URL(calls[1].payload.reply_markup.inline_keyboard[0][0].web_app.url);
    assert.equal(enter.searchParams.get('view'), 'worlds');
    assert.equal(enter.searchParams.get('world'), 'local-world');
  } finally { db.close(); }
});

test('welcome falls back to text when Telegram cannot deliver its image', async t => {
  const { db, webhook } = fixture();
  const calls = provider(t, ({ method }) => method === 'sendPhoto' ? { ok: false, error_code: 400 } : { ok: true, result: { message_id: 1 } });
  try {
    assert.equal((await webhook(command(11001, '/start events'))).status, 200);
    assert.deepEqual(calls.map(call => call.method), ['sendPhoto', 'sendMessage']);
    assert.match(calls[1].payload.text, /MK~2 REALMS/);
    assert.equal(new URL(calls[1].payload.reply_markup.inline_keyboard[0][0].web_app.url).searchParams.get('view'), 'events');
    assert.equal(db.prepare('SELECT status FROM webhook_updates WHERE update_id=?').get(11001)?.status, 'done');
  } finally { db.close(); }
});

test('banned callback users receive an answer without changing preferences or receiving app content', async t => {
  const { db, env, webhook } = fixture();
  const calls = provider(t);
  try {
    await ensureUser(env, { id: 1001, first_name: 'حساب موقوف' });
    db.prepare("UPDATE users SET status='banned',notify_allowed=0 WHERE id='1001'").run();
    const response = await webhook({ update_id: 12001, callback_query: { id: 'local-callback', from: { id: 1001, is_bot: false, first_name: 'حساب موقوف' }, message: { message_id: 1, chat: { id: 1001, type: 'private' } }, data: 'notify:on' } });
    assert.equal(response.status, 200);
    assert.equal(db.prepare("SELECT notify_allowed FROM users WHERE id='1001'").get()?.notify_allowed, 0);
    assert.deepEqual(calls.map(call => call.method), ['answerCallbackQuery']);
    assert.equal(calls[0].payload.callback_query_id, 'local-callback');
    assert.match(calls[0].payload.text, /موقوف/);
  } finally { db.close(); }
});

test('linking requires a world manager and administrator status for both the human and bot in the target group', async t => {
  const { db, env, webhook } = fixture();
  let humanStatus = 'member', robotStatus = 'administrator';
  const calls = provider(t, ({ method, payload }) => ({ ok: true, result: method === 'getChatMember' ? { status: payload.user_id === botId ? robotStatus : humanStatus, user: { id: payload.user_id, is_bot: payload.user_id === botId, first_name: 'مستخدم محلي' } } : { message_id: 1 } }));
  try {
    const worldId = await seedWorld(db, env);
    assert.equal((await webhook(command(13001, `/link ${worldId}`, 1003, true))).status, 200);
    assert.equal(calls.some(call => call.method === 'getChatMember'), false, 'outsiders must fail before external permission lookup');
    assert.equal(db.prepare('SELECT telegram_chat_id FROM worlds WHERE id=?').get(worldId)?.telegram_chat_id, null);
    calls.length = 0;
    assert.equal((await webhook(command(13002, `/link ${worldId}`, 1002, true))).status, 200);
    assert.equal(calls.some(call => call.method === 'getChatMember'), false, 'ordinary members cannot link');
    calls.length = 0;
    assert.equal((await webhook(command(13003, `/link ${worldId}`, 1001, true))).status, 200);
    assert.deepEqual(calls.filter(call => call.method === 'getChatMember').map(call => call.payload.user_id).sort((a, b) => a - b), [1001, botId]);
    assert.equal(db.prepare('SELECT telegram_chat_id FROM worlds WHERE id=?').get(worldId)?.telegram_chat_id, null, 'world ownership does not establish group administration');
    humanStatus = 'creator'; robotStatus = 'member'; calls.length = 0;
    assert.equal((await webhook(command(13004, `/link ${worldId}`, 1001, true))).status, 200);
    assert.equal(db.prepare('SELECT telegram_chat_id FROM worlds WHERE id=?').get(worldId)?.telegram_chat_id, null, 'bot must also administer this group');
    robotStatus = 'administrator'; calls.length = 0;
    assert.equal((await webhook(command(13005, `/link ${worldId}`, 1001, true))).status, 200);
    assert.equal(db.prepare('SELECT telegram_chat_id FROM worlds WHERE id=?').get(worldId)?.telegram_chat_id, String(groupId));
    for (const lookup of calls.filter(call => call.method === 'getChatMember')) assert.equal(lookup.payload.chat_id, groupId);
    const success = calls.find(call => call.method === 'sendMessage')!;
    assert.equal(success.payload.chat_id, groupId);
    const button = success.payload.reply_markup.inline_keyboard[0][0];
    assert.equal(button.web_app, undefined, 'group messages must use a private-bot deep link');
    assert.equal(button.url, `https://t.me/${env.BOT_USERNAME}?start=world_${worldId}`);
    assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []);
  } finally { db.close(); }
});

test('restricted world managers cannot link groups and private /link cannot establish a group binding', async t => {
  const { db, env, webhook } = fixture();
  const calls = provider(t);
  try {
    const worldId = await seedWorld(db, env);
    db.prepare("UPDATE users SET status='restricted' WHERE id='1001'").run();
    assert.equal((await webhook(command(14001, `/link ${worldId}`, 1001, true))).status, 200);
    assert.equal(calls.some(call => call.method === 'getChatMember'), false);
    assert.equal(db.prepare('SELECT telegram_chat_id FROM worlds WHERE id=?').get(worldId)?.telegram_chat_id, null);
    db.prepare("UPDATE users SET status='active' WHERE id='1001'").run();
    calls.length = 0;
    assert.equal((await webhook(command(14002, `/link ${worldId}`))).status, 200);
    assert.equal(calls.some(call => call.method === 'getChatMember'), false);
    assert.equal(db.prepare('SELECT telegram_chat_id FROM worlds WHERE id=?').get(worldId)?.telegram_chat_id, null);
  } finally { db.close(); }
});

test('completed-event announcements go once to the linked active group and include only that event reward ledger', async t => {
  const { db, env } = fixture();
  const calls = provider(t);
  try {
    const linked = await seedWorld(db, env, 'linked', true);
    const unlinked = await seedWorld(db, env, 'unlinked');
    const suspended = await seedWorld(db, env, 'suspended', true);
    db.prepare("UPDATE worlds SET status='suspended' WHERE id=?").run(suspended);
    seedEvent(db, 'winner-event', linked);
    seedEvent(db, 'unfinished-event', linked, 'active');
    seedEvent(db, 'unlinked-event', unlinked);
    seedEvent(db, 'suspended-event', suspended);
    const now = Date.now();
    db.prepare('INSERT INTO xp_transactions(id,user_id,world_id,source_key,xp,points,reason,created_at) VALUES(?,?,?,?,?,?,?,?)').run('earned-event-reward', '1002', linked, 'event:winner-event', 90, 45, 'مكافأة فعالية', now);
    db.prepare('INSERT INTO xp_transactions(id,user_id,world_id,source_key,xp,points,reason,created_at) VALUES(?,?,?,?,?,?,?,?)').run('unrelated-event-reward', '1003', linked, 'event:another-event', 500, 200, 'مكافأة أخرى', now);
    await Promise.all([flushEventAnnouncements(env), flushEventAnnouncements(env)]);
    assert.equal(calls.length, 1, 'concurrent flushes must claim a single announcement');
    assert.equal(calls[0].method, 'sendMessage');
    assert.equal(calls[0].payload.chat_id, String(groupId));
    assert.match(calls[0].payload.text, /winner-event/);
    assert.match(calls[0].payload.text, /مستخدم 1002 — 90 XP · 45/);
    assert.doesNotMatch(calls[0].payload.text, /مستخدم 1003/);
    for (const button of calls[0].payload.reply_markup.inline_keyboard.flat()) {
      assert.equal(button.web_app, undefined);
      if (button.url) assert.equal(new URL(button.url).hostname, 't.me');
    }
    assert.equal(db.prepare("SELECT kind FROM event_actions WHERE event_id=? AND action_key='telegram:result'").get('winner-event')?.kind, 'telegram_sent');
    assert.equal(db.prepare("SELECT COUNT(*) n FROM event_actions WHERE action_key='telegram:result'").get()?.n, 1);
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 1, 'already delivered announcement must not be sent again');
    assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []);
  } finally { db.close(); }
});

test('failed announcements are durable and throttled before a successful retry', async t => {
  const { db, env } = fixture();
  let fail = true;
  const calls = provider(t, () => fail ? { ok: false, error_code: 429 } : { ok: true, result: { message_id: 1 } });
  t.mock.method(console, 'error', () => {});
  try {
    const worldId = await seedWorld(db, env, 'retry-world', true);
    seedEvent(db, 'retry-event', worldId);
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 1);
    assert.equal(db.prepare("SELECT kind FROM event_actions WHERE event_id='retry-event'").get()?.kind, 'telegram_failed');
    assert.equal(JSON.parse(String(db.prepare("SELECT data FROM event_actions WHERE event_id='retry-event'").get()?.data)).code, 429);
    fail = false;
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 1, 'an immediate provider retry must be throttled');
    db.prepare("UPDATE event_actions SET created_at=? WHERE event_id='retry-event'").run(Date.now() - 5 * 60000 - 1000);
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 2);
    assert.equal(db.prepare("SELECT kind FROM event_actions WHERE event_id='retry-event'").get()?.kind, 'telegram_sent');
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 2);
  } finally { db.close(); }
});

test('fresh announcement locks prevent duplicate work while expired locks recover abandoned delivery', async t => {
  const { db, env } = fixture();
  const calls = provider(t);
  try {
    const worldId = await seedWorld(db, env, 'recover-world', true);
    seedEvent(db, 'recover-event', worldId);
    db.prepare("INSERT INTO event_actions(id,event_id,user_id,action_key,kind,created_at) VALUES(?,?,?,'telegram:result','telegram_processing',?)").run('abandoned-delivery', 'recover-event', '1001', Date.now());
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 0);
    db.prepare("UPDATE event_actions SET created_at=? WHERE id='abandoned-delivery'").run(Date.now() - 90000 - 1000);
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 1);
    assert.equal(db.prepare("SELECT kind FROM event_actions WHERE id='abandoned-delivery'").get()?.kind, 'telegram_sent');
  } finally { db.close(); }
});

test('recent failed announcements do not block an older completed event that is ready to deliver', async t => {
  const { db, env } = fixture();
  const calls = provider(t);
  try {
    const worldId = await seedWorld(db, env, 'backlog-world', true);
    const now = Date.now();
    for (let index = 0; index < 3; index++) {
      const eventId = `recent-failed-${index}`;
      seedEvent(db, eventId, worldId);
      db.prepare('UPDATE events SET updated_at=? WHERE id=?').run(now + index, eventId);
      db.prepare("INSERT INTO event_actions(id,event_id,user_id,action_key,kind,created_at) VALUES(?,?,?,'telegram:result','telegram_failed',?)").run(`recent-failure-action-${index}`, eventId, '1001', now);
    }
    seedEvent(db, 'older-ready-event', worldId);
    db.prepare("UPDATE events SET updated_at=? WHERE id='older-ready-event'").run(now - 60000);
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 1, 'the throttle must defer only failed events rather than block other completed events');
    assert.match(calls[0].payload.text, /older-ready-event/);
    assert.equal(db.prepare("SELECT kind FROM event_actions WHERE event_id='older-ready-event'").get()?.kind, 'telegram_sent');
    assert.equal(db.prepare("SELECT COUNT(*) n FROM event_actions WHERE kind='telegram_failed'").get()?.n, 3);
  } finally { db.close(); }
});

test('a successful Telegram delivery is never resent after a finalization database failure', async t => {
  const { db, env } = fixture();
  const calls = provider(t);
  t.mock.method(console, 'error', () => {});
  let finalizationFailed = false;
  const originalPrepare = env.DB.prepare.bind(env.DB);
  t.mock.method(env.DB, 'prepare', (sql: string) => {
    const statement = originalPrepare(sql);
    if (sql.includes("SET kind='telegram_sent'")) {
      const originalRun = statement.run.bind(statement);
      statement.run = async () => {
        if (!finalizationFailed) { finalizationFailed = true; throw new Error('Local fixture: transient write failure after confirmed delivery'); }
        return originalRun();
      };
    }
    return statement;
  });
  try {
    const worldId = await seedWorld(db, env, 'finalization-world', true);
    seedEvent(db, 'finalization-event', worldId);
    await flushEventAnnouncements(env);
    assert.equal(finalizationFailed, true);
    assert.equal(calls.length, 1);
    const action: any = db.prepare("SELECT kind FROM event_actions WHERE event_id='finalization-event'").get();
    assert.equal(['telegram_unknown', 'telegram_sending'].includes(action.kind), true, 'uncertain bookkeeping must preserve a non-retryable delivery outcome');
    db.prepare("UPDATE event_actions SET created_at=? WHERE event_id='finalization-event'").run(Date.now() - 10 * 60000);
    await flushEventAnnouncements(env);
    assert.equal(calls.length, 1, 'the retry window must never resend a confirmed delivery');
  } finally { db.close(); }
});
