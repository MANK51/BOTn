import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { handleApi } from '../lib/api';

// These are deliberately invalid Telegram credentials, used exclusively against
// local Request objects and an in-memory database. No production auth is minted.
const TEST_TOKEN = '999999999:TEST_ONLY_LOCAL_TOKEN_NEVER_VALID_ON_TELEGRAM';
const TEST_WEBHOOK_SECRET = 'test-only-webhook-secret';
const origin = 'https://local-api.test.invalid';

class Statement {
  values: any[] = [];
  constructor(private db: DatabaseSync, private sql: string) {}
  bind(...values: any[]) { this.values = values; return this; }
  async first() { return this.db.prepare(this.sql).get(...this.values) ?? null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.values) }; }
  execute() {
    const result = this.db.prepare(this.sql).run(...this.values);
    return { success: true, meta: { changes: Number(result.changes), last_row_id: Number(result.lastInsertRowid) } };
  }
  async run() { return this.execute(); }
}

function signedInitData(id: number, extra: Record<string, string> = {}) {
  const params = new URLSearchParams({
    auth_date: String(Math.floor(Date.now() / 1000)),
    query_id: `LOCAL_TEST_QUERY_${id}`,
    user: JSON.stringify({ id, first_name: id === 6103685685 ? 'مدير الاختبار' : `لاعب ${id}`, username: `local_${id}` }),
    ...extra,
  });
  // Telegram's published bot-token verification algorithm, implemented with
  // Node crypto independently of the application's Web Crypto verifier.
  const check = [...params.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => `${key}=${value}`).join('\n');
  const secret = createHmac('sha256', 'WebAppData').update(TEST_TOKEN).digest();
  params.set('hash', createHmac('sha256', secret).update(check).digest('hex'));
  return params.toString();
}

function fixture() {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys=ON');
  for (const file of readdirSync(resolve('drizzle')).filter(file => file.endsWith('.sql')).sort()) {
    db.exec(readFileSync(resolve('drizzle', file), 'utf8'));
  }
  const env: any = {
    DB: {
      prepare(sql: string) { return new Statement(db, sql); },
      async batch(statements: Statement[]) {
        db.exec('BEGIN');
        try { const results = statements.map(statement => statement.execute()); db.exec('COMMIT'); return results; }
        catch (error) { db.exec('ROLLBACK'); throw error; }
      },
    },
    TELEGRAM_BOT_TOKEN: TEST_TOKEN,
    TELEGRAM_WEBHOOK_SECRET: TEST_WEBHOOK_SECRET,
    ADMIN_TELEGRAM_IDS: '6103685685',
    ADMIN_OWNER_EMAIL: 'owner@local.test.invalid',
    APP_URL: origin,
    BOT_USERNAME: 'LOCAL_UNIT_TEST_BOT',
  };
  async function call(path: string, method = 'GET', telegramId: number | null = null, payload?: any, extraHeaders: Record<string, string> = {}) {
    const headers = new Headers(extraHeaders);
    if (telegramId !== null) headers.set('authorization', `tma ${signedInitData(telegramId)}`);
    if (payload !== undefined) headers.set('content-type', 'application/json');
    const response = await handleApi(new Request(`${origin}${path}`, { method, headers, ...(payload === undefined ? {} : { body: JSON.stringify(payload) }) }), env);
    return { status: response.status, headers: response.headers, data: await response.json() as any };
  }
  return { db, env, call };
}

test('API gateway permits anonymous browsing while denying writes, profiles, and administration', async () => {
  const { db, call } = fixture();
  try {
    const health = await call('/api/health');
    assert.equal(health.status, 200);
    assert.equal(health.data.database, 'ok');
    const bootstrap = await call('/api/bootstrap');
    assert.equal(bootstrap.status, 200);
    assert.equal(bootstrap.data.user, null);
    assert.equal(bootstrap.headers.get('cache-control'), 'no-store');
    assert.equal(bootstrap.headers.get('x-content-type-options'), 'nosniff');
    assert.equal((await call('/api/worlds', 'POST', null, { name: 'دخول بلا هوية' })).status, 401);
    assert.equal((await call('/api/daily', 'POST')).status, 401);
    assert.equal((await call('/api/profile')).status, 401);
    assert.equal((await call('/api/admin/overview')).status, 401);
    assert.equal((await call('/api/admin/settings', 'PATCH', null, { values: { 'maintenance.enabled': true } })).status, 401);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM users').get()?.n, 0);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM worlds').get()?.n, 0);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM settings').get()?.n, 0);
  } finally { db.close(); }
});

test('real signed local Telegram login grants only the runtime allowlisted administrator and persists role/audit FKs', async () => {
  const { db, call } = fixture();
  try {
    const admin = await call('/api/auth', 'POST', null, { initData: signedInitData(6103685685) });
    assert.equal(admin.status, 200);
    assert.equal(admin.data.user.id, '6103685685');
    assert.equal(admin.data.user.role, 'super_admin');
    assert.equal((await call('/api/admin/overview', 'GET', 6103685685)).status, 200);
    assert.equal(db.prepare('SELECT role FROM admin_roles WHERE user_id=?').get('6103685685')?.role, 'super_admin');
    assert.equal(db.prepare("SELECT COUNT(*) n FROM audit_logs WHERE actor_id=? AND action='admin.configured'").get('6103685685')?.n, 1);
    const ordinary = await call('/api/auth', 'POST', null, { initData: signedInitData(1001) });
    assert.equal(ordinary.data.user.role, 'user');
    assert.equal((await call('/api/admin/overview', 'GET', 1001)).status, 403);
    assert.equal((await call('/api/admin/overview', 'GET', null, undefined, { 'oai-authenticated-user-id': 'unconfigured-site-identity', 'oai-authenticated-user-email': 'visitor@local.test.invalid' })).status, 401);
    const tampered = new URLSearchParams(signedInitData(1001));
    tampered.set('user', JSON.stringify({ id: 6103685685, first_name: 'تزوير مدير' }));
    assert.equal((await call('/api/auth', 'POST', null, { initData: tampered.toString() })).status, 401);
    assert.equal((await call('/api/auth', 'POST', null, { initData: '' })).status, 401);
    assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []);
  } finally { db.close(); }
});

test('configured local dispatcher owner identity becomes a durable administrator and cross-origin mutation is rejected', async () => {
  const { db, env, call } = fixture();
  // This fixture represents the trusted Sites dispatcher headers. It does not
  // attempt to validate the external hosting boundary or send forged live headers.
  const ownerHeaders = {
    'oai-authenticated-user-id': 'local-site-scoped-owner',
    'oai-authenticated-user-email': 'OWNER@LOCAL.TEST.INVALID',
    'oai-authenticated-user-full-name': encodeURIComponent('مالك محلي'),
    'oai-authenticated-user-full-name-encoding': 'percent-encoded-utf-8',
  };
  try {
    const owner = await call('/api/auth', 'GET', null, undefined, ownerHeaders);
    assert.equal(owner.status, 200);
    assert.equal(owner.data.user.id, 'owner:local-site-scoped-owner');
    assert.equal(owner.data.user.name, 'مالك محلي');
    assert.equal(owner.data.user.role, 'super_admin');
    assert.equal(JSON.parse(String(db.prepare("SELECT value FROM settings WHERE key='_owner_identity'").get()?.value)), 'local-site-scoped-owner');
    assert.equal(db.prepare('SELECT role FROM admin_roles WHERE user_id=?').get(owner.data.user.id)?.role, 'super_admin');
    const blocked = await call('/api/admin/settings', 'PATCH', null, { values: { 'maintenance.enabled': true } }, { ...ownerHeaders, origin: 'https://attacker.test.invalid' });
    assert.equal(blocked.status, 403);
    assert.equal(db.prepare("SELECT value FROM settings WHERE key='maintenance.enabled'").get(), undefined);
    const saved = await call('/api/admin/settings', 'PATCH', null, { values: { 'display.tagline': 'إعداد حقيقي محفوظ' } }, { ...ownerHeaders, origin });
    assert.equal(saved.status, 200);
    assert.equal(db.prepare("SELECT updated_by FROM settings WHERE key='display.tagline'").get()?.updated_by, owner.data.user.id);
    assert.equal(db.prepare("SELECT actor_id FROM audit_logs WHERE action='settings.update'").get()?.actor_id, owner.data.user.id);
    env.ADMIN_OWNER_EMAIL = 'changed-config@local.test.invalid';
    assert.equal((await call('/api/admin/overview', 'GET', null, undefined, ownerHeaders)).status, 200);
    assert.equal((await call('/api/admin/overview', 'GET', null, undefined, { 'oai-authenticated-user-id': 'different-verified-identity', 'oai-authenticated-user-email': env.ADMIN_OWNER_EMAIL })).status, 401);
    assert.equal(db.prepare('SELECT COUNT(*) n FROM users').get()?.n, 1);
    assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []);
  } finally { db.close(); }
});

test('signed API flow persists a world, membership, challenge, verified attempt, and exactly-once rewards', async () => {
  const { db, call } = fixture();
  try {
    assert.equal((await call('/api/auth', 'POST', null, { initData: signedInitData(1001) })).status, 200);
    assert.equal((await call('/api/auth', 'POST', null, { initData: signedInitData(1002) })).status, 200);
    const created = await call('/api/worlds', 'POST', 1001, { name: 'عالم من البوابة', kind: 'puzzles' });
    assert.equal(created.status, 201);
    const worldId = created.data.world.id;
    assert.equal(db.prepare('SELECT owner_id FROM worlds WHERE id=?').get(worldId)?.owner_id, '1001');
    assert.equal(db.prepare('SELECT role FROM world_members WHERE world_id=? AND user_id=?').get(worldId, '1001')?.role, 'owner');
    assert.equal((await call(`/api/worlds/${worldId}/join`, 'POST', 1002)).status, 200);
    const challengePayload = { worldId, title: 'اختبار البوابة الحقيقي', status: 'published', xpReward: 55, pointsReward: 18, stages: [
      { kind: 'quiz', prompt: 'كم يساوي 2 + 2؟', options: ['3', '4'], answer: '4', seconds: 60 },
      { kind: 'riddle', prompt: 'اكتب كلمة أرض', answer: 'أرض', seconds: 60 },
    ] };
    assert.equal((await call('/api/challenges', 'POST', 1002, challengePayload)).status, 403);
    const challenge = await call('/api/challenges', 'POST', 1001, challengePayload);
    assert.equal(challenge.status, 201);
    const challengeId = challenge.data.challenge.id;
    const details = await call(`/api/challenges/${challengeId}`, 'GET', 1002);
    assert.equal('answer' in details.data.challenge.stages[0], false);
    assert.equal((await call(`/api/challenges/${challengeId}/start`, 'POST')).status, 401);
    const start = await call(`/api/challenges/${challengeId}/start`, 'POST', 1002);
    assert.equal(start.status, 200);
    const attemptId = start.data.attempt.id;
    assert.equal((await call(`/api/attempts/${attemptId}/answer`, 'POST', 1001, { answer: '4' })).status, 404);
    assert.equal((await call(`/api/attempts/${attemptId}/answer`, 'POST', 1002, { answer: '4', xp: 999999, score: 100 })).data.completed, false);
    const win = await call(`/api/attempts/${attemptId}/answer`, 'POST', 1002, { answer: 'أرض', xp: 999999, points: 999999 });
    assert.equal(win.status, 200);
    assert.equal(win.data.completed, true);
    assert.deepEqual(win.data.reward, { earned: true, xp: 55, points: 18, reason: null });
    assert.equal(win.data.user.xp, 55);
    assert.equal(win.data.user.points, 18);
    assert.equal((await call(`/api/attempts/${attemptId}/answer`, 'POST', 1002, { answer: 'أرض' })).status, 409);
    const retry = await call(`/api/challenges/${challengeId}/start`, 'POST', 1002);
    await call(`/api/attempts/${retry.data.attempt.id}/answer`, 'POST', 1002, { answer: '4' });
    const repeatedWin = await call(`/api/attempts/${retry.data.attempt.id}/answer`, 'POST', 1002, { answer: 'أرض' });
    assert.equal(repeatedWin.data.reward.earned, false);
    assert.equal(repeatedWin.data.user.xp, 55);
    assert.equal(db.prepare("SELECT COUNT(*) n FROM xp_transactions WHERE user_id='1002' AND source_key=?").get(`challenge:${challengeId}`)?.n, 1);
    const reward = await call('/api/admin/rewards', 'POST', 6103685685, { name: 'إطار محلي', type: 'frame', image: '/assets/frame-nebula.svg', price: 10, active: true });
    assert.equal(reward.status, 201);
    const item = db.prepare("SELECT id FROM rewards WHERE name='إطار محلي'").get()!;
    assert.equal((await call(`/api/store/${item.id}/buy`, 'POST', 1002)).status, 200);
    assert.equal((await call(`/api/store/${item.id}/buy`, 'POST', 1002)).status, 409);
    assert.equal(db.prepare("SELECT points FROM users WHERE id='1002'").get()?.points, 8);
    assert.equal(db.prepare("SELECT COUNT(*) n FROM inventory WHERE user_id='1002'").get()?.n, 1);
    assert.equal((await call('/api/daily', 'POST', 1002)).status, 200);
    assert.equal((await call('/api/daily', 'POST', 1002)).status, 409);
    assert.equal(db.prepare("SELECT xp FROM users WHERE id='1002'").get()?.xp, 80);
    assert.equal(db.prepare("SELECT points FROM users WHERE id='1002'").get()?.points, 33);
    assert.deepEqual(db.prepare('PRAGMA foreign_key_check').all(), []);
  } finally { db.close(); }
});

test('webhook rejects unauthorized requests before database/network access and deduplicates completed reward updates', async t => {
  const { db, env, call } = fixture();
  const deliveries: { method: string, payload: any }[] = [];
  t.mock.method(globalThis, 'fetch', async (input: any, options: any) => {
    assert.equal(String(input).startsWith(`https://api.telegram.org/bot${TEST_TOKEN}/`), true);
    deliveries.push({ method: String(input).split('/').at(-1)!, payload: JSON.parse(options.body) });
    return new Response(JSON.stringify({ ok: true, result: { message_id: deliveries.length } }), { headers: { 'content-type': 'application/json' } });
  });
  try {
    const noDatabaseEnv = { ...env, DB: { prepare() { assert.fail('Unauthorized webhook touched the database'); } } };
    const unauthorized = await handleApi(new Request(`${origin}/api/bot/webhook`, { method: 'POST', body: '{not-valid-json' }), noDatabaseEnv);
    assert.equal(unauthorized.status, 403);
    assert.equal(deliveries.length, 0);
    assert.equal((await call('/api/bot/webhook', 'GET')).status, 405);
    const webhookHeaders = { 'x-telegram-bot-api-secret-token': TEST_WEBHOOK_SECRET };
    assert.equal((await call('/api/bot/webhook', 'POST', null, null, webhookHeaders)).status, 400);
    assert.equal((await call('/api/bot/webhook', 'POST', null, { update_id: 'invalid' }, webhookHeaders)).status, 400);
    assert.equal(deliveries.length, 0);
    const update = { update_id: 8123456, message: { message_id: 1, from: { id: 1002, first_name: 'لاعب البوت' }, chat: { id: 1002, type: 'private' }, text: '/daily' } };
    assert.equal((await call('/api/bot/webhook', 'POST', null, update, webhookHeaders)).status, 200);
    assert.equal(deliveries.length, 1);
    assert.equal(deliveries[0].method, 'sendMessage');
    assert.equal(db.prepare('SELECT status FROM webhook_updates WHERE update_id=?').get(update.update_id)?.status, 'done');
    assert.equal(db.prepare("SELECT xp FROM users WHERE id='1002'").get()?.xp, 25);
    assert.equal((await call('/api/bot/webhook', 'POST', null, update, webhookHeaders)).status, 200);
    assert.equal(deliveries.length, 1);
    assert.equal(db.prepare("SELECT COUNT(*) n FROM daily_claims WHERE user_id='1002'").get()?.n, 1);
    const timestamp = Date.now();
    db.prepare("INSERT INTO webhook_updates(update_id,status,created_at,updated_at) VALUES(?,'processing',?,?)").run(8123457, timestamp, timestamp);
    assert.equal((await call('/api/bot/webhook', 'POST', null, { ...update, update_id: 8123457 }, webhookHeaders)).status, 503);
    assert.equal(deliveries.length, 1);
  } finally { db.close(); }
});
