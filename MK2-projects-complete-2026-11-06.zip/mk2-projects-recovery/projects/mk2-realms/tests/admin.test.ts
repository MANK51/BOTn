import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { adminApi } from '../lib/admin';

const owner={id:'1',role:'super_admin',status:'active'};
class Statement {
  bindings:any[]=[];
  constructor(private db:DatabaseSync,private sql:string){}
  bind(...bindings:any[]){this.bindings=bindings;return this}
  async first(){return this.db.prepare(this.sql).get(...this.bindings)||null}
  async all(){return{results:this.db.prepare(this.sql).all(...this.bindings)}}
  async run(){const result=this.db.prepare(this.sql).run(...this.bindings);return{success:true,meta:{changes:Number(result.changes)}}}
}
function fixture(){
  const db=new DatabaseSync(':memory:');db.exec('PRAGMA foreign_keys=ON;');
  const migrationDirectory=new URL('../drizzle/',import.meta.url);
  for(const file of readdirSync(migrationDirectory).filter(file=>file.endsWith('.sql')).sort())db.exec(readFileSync(new URL(file,migrationDirectory),'utf8'));
  // D1 serializes transactions. Keep this one-connection SQLite adapter equally serialized.
  let batchQueue=Promise.resolve();
  const env:any={DB:{prepare:(sql:string)=>new Statement(db,sql),batch:(statements:Statement[])=>{
    const result=batchQueue.then(async()=>{db.exec('BEGIN');try{const rows=[];for(const statement of statements)rows.push(await statement.run());db.exec('COMMIT');return rows}catch(error){db.exec('ROLLBACK');throw error}});
    batchQueue=result.then(()=>undefined,()=>undefined);return result;
  }}};
  const timestamp=Date.now();
  for(const [id,role] of [['1','super_admin'],['2','user'],['3','support'],['4','moderator']])db.prepare('INSERT INTO users(id,telegram_id,name,role,created_at,last_seen)VALUES(?,?,?,?,?,?)').run(id,id,'مستخدم '+id,role,timestamp,timestamp);
  db.prepare('INSERT INTO worlds(id,owner_id,name,created_at,updated_at)VALUES(?,?,?,?,?)').run('world','2','عالم الاختبار',timestamp,timestamp);
  db.prepare('INSERT INTO support_tickets(id,user_id,subject,message,created_at,updated_at)VALUES(?,?,?,?,?,?)').run('ticket','2','مساعدة','لا أستطيع الدخول',timestamp,timestamp);
  async function call(path:string,method='GET',user:any=owner,body?:any,origin?:string){
    const request=new Request(`https://test.invalid/api/admin/${path}`,{method,headers:body?{'Content-Type':'application/json',...(origin?{Origin:origin}:{})}:{},body:body?JSON.stringify(body):undefined});
    const response=await adminApi(request,env,user);assert.ok(response,'Administration route should be handled');return{status:response.status,data:await response.json() as any};
  }
  return{db,env,call,timestamp};
}

test('administration verifies role, prevents cross-role moderation and protects the current owner',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  assert.equal((await call('overview','GET',null)).status,401);
  assert.equal((await call('overview','GET',{id:'2',role:'user'})).status,403);
  assert.equal((await call('users/2','PATCH',{id:'3',role:'support'},{status:'banned',reason:'تجربة'})).status,403);
  assert.equal((await call('settings','PATCH',{id:'4',role:'moderator'},{values:{'daily.xp':70}})).status,403);
  assert.equal((await call('users/1','PATCH',{id:'4',role:'moderator'},{status:'banned',reason:'تجربة'})).status,403);
  assert.equal((await call('users/1','PATCH',owner,{role:'user'})).status,409);
  assert.equal((db.prepare("SELECT role,status FROM users WHERE id='1'").get() as any).role,'super_admin');
});

test('world and user moderation persist alongside their audit and reject foreign origins',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  assert.equal((await call('worlds/world','PATCH',owner,{status:'suspended',reason:'مراجعة الإدارة'},'https://evil.invalid')).status,403);
  assert.equal((await call('worlds/world','PATCH',owner,{status:'suspended',reason:'مراجعة الإدارة'})).status,200);
  assert.equal((db.prepare("SELECT status FROM worlds WHERE id='world'").get() as any).status,'suspended');
  assert.equal((await call('users/2','PATCH',owner,{status:'restricted',reason:'بلاغ تم التحقق منه'})).status,200);
  assert.equal((db.prepare("SELECT status FROM users WHERE id='2'").get() as any).status,'restricted');
  const actions=db.prepare('SELECT action,actor_id,after_data FROM audit_logs ORDER BY created_at').all() as any[];
  assert.equal(actions.length,2);assert.ok(actions.every(row=>row.actor_id==='1'));
  assert.equal(JSON.parse(actions[0].after_data).status,'suspended');
});

test('daily reward settings honor platform limits and invalid batches leave saved settings unchanged',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  assert.equal((await call('settings','PATCH',owner,{values:{'daily.xp':500,'daily.points':200,'display.tagline':'عالمك. قوانينك. مغامرتك.'}})).status,200);
  assert.equal((db.prepare("SELECT value FROM settings WHERE key='daily.xp'").get() as any).value,'500');
  assert.equal((await call('settings','PATCH',owner,{values:{'daily.xp':501}})).status,400);
  assert.equal((await call('settings','PATCH',owner,{values:{'daily.xp':40,'daily.points':201}})).status,400);
  assert.equal((db.prepare("SELECT value FROM settings WHERE key='daily.xp'").get() as any).value,'500');
  assert.equal((db.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action='settings.update'").get() as any).count,1);
});

test('reward catalog updates price and availability in durable store records',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  const created=await call('rewards','POST',owner,{name:'إطار أسطوري',description:'إطار بنفسجي',type:'frame',price:100,image:'/assets/frame-nebula.svg',active:true});assert.equal(created.status,201);
  assert.equal((await call(`rewards/${created.data.id}`,'PATCH',owner,{name:'إطار أسطوري',type:'frame',price:120,image:'/assets/frame-nebula.svg',active:false})).status,200);
  const item=db.prepare('SELECT price,enabled FROM rewards WHERE id=?').get(created.data.id) as any;assert.equal(item.price,120);assert.equal(item.enabled,0);
  assert.equal((db.prepare('SELECT COUNT(*) AS count FROM audit_logs').get() as any).count,2);
});

test('support role can resolve and reply to tickets, notifying only the ticket owner',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  assert.equal((await call('tickets/ticket','PATCH',{id:'3',role:'support'},{status:'resolved',message:'افتح التطبيق من تيليجرام'})).status,200);
  assert.equal((db.prepare("SELECT status,assigned_to FROM support_tickets WHERE id='ticket'").get() as any).status,'resolved');
  const reply=db.prepare('SELECT user_id,message FROM ticket_replies').get() as any;assert.equal(reply.user_id,'3');assert.equal(reply.message,'افتح التطبيق من تيليجرام');
  const notification=db.prepare('SELECT user_id FROM notifications').all() as any[];assert.deepEqual(notification.map(row=>row.user_id),['2']);
  const tickets=await call('tickets','GET',{id:'3',role:'support'});assert.equal(tickets.data.items[0].replies.length,1);assert.equal(tickets.data.items[0].initial_message,'لا أستطيع الدخول');
});

test('app broadcast records actual recipients and duplicate requests never deliver twice',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  const campaign={title:'مرحبًا',body:'مغامرة جديدة',channel:'app',requestId:crypto.randomUUID()};
  assert.equal((await call('notifications','POST',owner,campaign)).status,201);
  assert.equal((db.prepare('SELECT COUNT(*) AS count FROM notifications').get() as any).count,4);
  assert.equal((await call('notifications','POST',owner,campaign)).status,200);
  assert.equal((db.prepare('SELECT COUNT(*) AS count FROM notifications').get() as any).count,4);
  assert.equal((db.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action='notification.broadcast'").get() as any).count,1);
});

test('overview totals and historical series come from the actual persisted users',async t=>{
  const {db,call}=fixture();t.after(()=>db.close());
  const result=await call('overview');assert.equal(result.status,200);assert.equal(result.data.counts.users,4);assert.equal(result.data.counts.worlds,1);assert.equal(result.data.counts.attempts,0);assert.equal(result.data.series.length,7);assert.equal(result.data.newUsers,4);assert.equal(result.data.health.database,'ok');
});

test('Telegram delivery filters consent, limits batches to20 and persists partial failure without retry sends',async t=>{
  const {db,env,call,timestamp}=fixture();t.after(()=>db.close());
  for(let id=30;id<55;id++)db.prepare('INSERT INTO users(id,telegram_id,name,notify_allowed,created_at,last_seen)VALUES(?,?,?,?,?,?)').run(String(id),String(id),'موافق '+id,1,timestamp,timestamp+id);
  db.prepare("INSERT INTO users(id,telegram_id,name,status,notify_allowed,created_at,last_seen)VALUES('99','99','محظور','banned',1,?,?)").run(timestamp,timestamp+999);
  let sends=0;env.TELEGRAM_BOT_TOKEN='test-only-token';
  t.mock.method(globalThis,'fetch',async(_input:any,options:any)=>{const payload=JSON.parse(options.body);assert.ok(Number(payload.chat_id)>=30&&Number(payload.chat_id)<55);sends++;return Response.json(sends===1?{ok:false,error_code:403}:{ok:true})});
  const campaign={title:'إشعار مختبر',body:'اختبار موافقة المستخدم',channel:'telegram',requestId:crypto.randomUUID()};
  const delivered=await call('notifications','POST',owner,campaign);assert.equal(delivered.status,201);assert.equal(sends,20);assert.equal(delivered.data.sent,19);assert.equal(delivered.data.failed,1);assert.equal(delivered.data.status,'partial');assert.equal(delivered.data.delivery.length,20);
  assert.equal((db.prepare("SELECT COUNT(*) AS count FROM audit_logs WHERE action='notification.telegram.delivery'").get() as any).count,20);
  assert.equal((await call('notifications','POST',owner,campaign)).status,200);assert.equal(sends,20);
});
