#!/usr/bin/env node
// Creates an INSERT-only import file. It never connects to a database or hosting API.
import { readFile, writeFile, stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

// Fixed, FK-safe table order matching db/schema.ts and the v1 admin backup export.
const columns = {
  users: 'id telegram_id name username avatar xp points level role status notify_allowed streak last_daily created_at last_seen',
  worlds: 'id owner_id name description kind visibility rules image background color join_mode telegram_chat_id status created_at updated_at',
  world_members: 'world_id user_id role status joined_at',
  world_invites: 'token world_id created_by expires_at created_at',
  world_posts: 'id world_id user_id title body created_at',
  teams: 'id world_id leader_id name description logo points created_at',
  team_members: 'team_id world_id user_id role joined_at',
  team_invites: 'id team_id user_id invited_by status created_at',
  challenges: 'id world_id created_by title description type difficulty xp_reward points_reward attempt_limit time_limit status scheduled_at created_at updated_at',
  challenge_stages: 'id challenge_id position kind prompt options answer seconds branch',
  attempts: 'id challenge_id user_id attempt_no status stage_index score answers started_at stage_started_at completed_at updated_at version',
  events: 'id world_id creator_id title description status stage revision puzzle_prompt puzzle_answer puzzle_goal vote_goal contribution_goal chosen_door effective_goal reward_xp reward_points starts_at ends_at created_at updated_at',
  event_participants: 'event_id user_id puzzle_solved puzzle_guesses contributed reward_claimed created_at',
  event_actions: 'id event_id user_id action_key kind data created_at',
  votes: 'event_id user_id option created_at',
  event_contributions: 'event_id user_id attempt_id created_at',
  event_logs: 'id event_id kind payload created_at',
  rewards: 'id name description kind rarity image price enabled conditions created_at',
  inventory: 'id user_id reward_id equipped acquired_at source',
  xp_transactions: 'id user_id world_id source_key xp points reason created_at',
  daily_claims: 'user_id day streak created_at',
  notifications: 'id user_id title body href read_at created_at',
  support_tickets: 'id user_id subject message priority status assigned_to created_at updated_at',
  ticket_replies: 'id ticket_id user_id message created_at',
  admin_roles: 'user_id role granted_by created_at',
  audit_logs: 'id actor_id action entity_type entity_id before_data after_data created_at',
  settings: 'key value updated_by updated_at',
  reports: 'id user_id world_id reason status created_at',
};
const tables = Object.keys(columns);
const emptyTables = [...tables, 'sessions', 'webhook_updates', 'rate_limits'];
const identifier = (name) => {
  if (!/^[a-z_][a-z0-9_]*$/.test(name)) throw new Error('Invalid internal SQL identifier.');
  return `"${name}"`;
};
const literal = (value, label) => {
  if (value === null) return 'NULL';
  if (typeof value === 'number' && Number.isFinite(value) && Number.isSafeInteger(value)) return String(value);
  if (typeof value === 'string') {
    if (value.includes('\0')) throw new Error(`Unsupported NUL character at ${label}.`);
    return `'${value.replaceAll("'", "''")}'`;
  }
  throw new Error(`Expected null, text, or a safe integer at ${label}.`);
};
const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

export function backupToSql(backup) {
  if (!isObject(backup) || backup.format !== 'mk2-realms-backup-v1' || backup.version !== 1 || typeof backup.createdAt !== 'string' || Number.isNaN(Date.parse(backup.createdAt)) || !isObject(backup.records)) throw new Error('Expected a mk2-realms-backup-v1 JSON export with version 1.');
  for (const key of Object.keys(backup.records)) if (!Object.hasOwn(columns, key)) throw new Error(`Unknown backup table: ${key}.`);
  let total = 0;
  const insertions = [];
  for (const table of tables) {
    const rows = backup.records[table];
    if (!Array.isArray(rows)) throw new Error(`Missing table array: ${table}.`);
    if (rows.length > 50000) throw new Error(`The v1 export limit is 50,000 rows per table: ${table}.`);
    const names = columns[table].split(' ');
    const columnSet = new Set(names);
    for (const [index, row] of rows.entries()) {
      if (!isObject(row)) throw new Error(`Expected a row object at ${table}[${index}].`);
      for (const key of Object.keys(row)) if (!columnSet.has(key)) throw new Error(`Unknown column at ${table}[${index}].${key}.`);
      for (const name of names) if (!Object.hasOwn(row, name)) throw new Error(`Missing column at ${table}[${index}].${name}.`);
      insertions.push(`INSERT INTO ${identifier(table)} (${names.map(identifier).join(',')}) VALUES (${names.map(name => literal(row[name], `${table}[${index}].${name}`)).join(',')});`);
    }
    total += rows.length;
  }
  // SQLite raises integer overflow only on the selected ELSE branch. This asserts
  // empty application tables without temporary tables, DROP, DELETE, or REPLACE.
  const assert = (condition, label) => `SELECT CASE WHEN ${condition} THEN 1 ELSE abs(-9223372036854775808) END AS ${identifier(label)};`;
  const emptiness = emptyTables.map(t => `(SELECT COUNT(*) FROM ${identifier(t)})`).join('+');
  const sql = [
    '-- MK~2 REALMS v1 backup restore. FRESH, ISOLATED DATABASE ONLY.',
    '-- Apply the application migrations first. Import must stop on the first SQL error.',
    '-- Never import into the live DB. The emptiness assertion fails with integer overflow.',
    '-- No existing application rows are replaced or removed. Keep this file private.',
    'PRAGMA foreign_keys=ON;',
    assert(`(${emptiness})=0`, 'fresh_empty_database_required'),
    ...insertions,
    'PRAGMA foreign_keys=ON;',
    'PRAGMA foreign_key_check;',
    assert('NOT EXISTS(SELECT 1 FROM pragma_foreign_key_check)', 'foreign_keys_valid'),
    ...tables.map(table => assert(`(SELECT COUNT(*) FROM ${identifier(table)})=${backup.records[table].length}`, `${table}_count_valid`)),
    `SELECT ${total} AS imported_rows, ${tables.length} AS imported_tables;`,
    '',
  ].join('\n');
  return { sql, total, tableCount: tables.length };
}

async function main() {
  const [input, output, ...extra] = process.argv.slice(2);
  if (!input || !output || extra.length) throw new Error('Usage: node scripts/restore-backup.mjs BACKUP.json RESTORE.sql');
  const inputPath = resolve(input), outputPath = resolve(output);
  if (inputPath === outputPath) throw new Error('Input and output paths must differ.');
  const inputStat = await stat(inputPath);
  if (!inputStat.isFile() || inputStat.size > 256 * 1024 * 1024) throw new Error('Backup must be a regular JSON file up to 256 MiB.');
  let backup;
  try { backup = JSON.parse(await readFile(inputPath, 'utf8')); } catch { throw new Error('Backup file is not valid JSON.'); }
  const { sql, total, tableCount } = backupToSql(backup);
  await writeFile(outputPath, sql, { encoding: 'utf8', flag: 'wx', mode: 0o600 });
  console.log(`Created ${outputPath}: ${total} rows across ${tableCount} tables. No database was contacted. Import only into a newly migrated empty database.`);
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) main().catch(error => { console.error(error.message); process.exitCode = 1; });
