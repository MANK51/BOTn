import json,sys,urllib.request,urllib.error,termios
if sys.stdin.isatty():
    flags=termios.tcgetattr(sys.stdin.fileno());flags[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,flags)
print('READY for hidden runtime check JSON',flush=True)
args=json.loads(sys.stdin.readline())
for op in args['operations']:
    payload=op.get('body');data=json.dumps(payload).encode() if payload is not None else None
    try:
        req=urllib.request.Request(op['url'],data=data,method=op.get('method','GET'),headers={'Content-Type':'application/json','User-Agent':'MK2-Realms-Runtime-Check/1.0',**op.get('headers',{})})
        with urllib.request.urlopen(req,timeout=45) as response:
            if op.get('binary'):
                result={'contentType':response.headers.get('Content-Type'),'bytes':len(response.read())}
            else:
                raw=response.read().decode()
                try:result=json.loads(raw)
                except:result={'html':True,'bytes':len(raw),'hasBrand':'MK~2' in raw}
            print(json.dumps({'name':op['name'],'status':response.status,'result':result},ensure_ascii=False),flush=True)
    except urllib.error.HTTPError as exc:
        raw=exc.read().decode()
        try:result=json.loads(raw)
        except:result={'html':True,'bytes':len(raw)}
        print(json.dumps({'name':op['name'],'status':exc.code,'result':result},ensure_ascii=False),flush=True)
    except Exception as exc:print(json.dumps({'name':op['name'],'error':type(exc).__name__}),flush=True)
