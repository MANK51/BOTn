#!/usr/bin/env node
// Portable source/publish fallback when the supplied Sites workflow helper is absent.
// Credentials enter only over hidden stdin and exist only in this process and Git's
// transient environment. No credential-bearing URL or configuration is persisted.
import { spawn } from 'node:child_process';
import { access, mkdir, readFile, realpath, readdir, stat } from 'node:fs/promises';
import path from 'node:path';

const root = await realpath(process.cwd());
let redactions = [];
const clean = (value) => redactions.reduce((s, secret) => secret ? s.split(secret).join('[REDACTED]') : s, String(value));

function run(command, args, { env = process.env, silent = false } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    child.on('error', (error) => reject(new Error(clean(error.message))));
    child.on('close', (code) => {
      if (!silent) {
        if (stdout) process.stdout.write(clean(stdout));
        if (stderr) process.stderr.write(clean(stderr));
      }
      if (code !== 0) reject(new Error(`${command} exited ${code}: ${clean(stderr).trim()}`));
      else resolve(stdout.trim());
    });
  });
}

const git = (args, options = {}) => run('git', ['-c', 'core.hooksPath=/dev/null', ...args], options);

async function hiddenJson() {
  const wasRaw = process.stdin.isRaw;
  if (process.stdin.isTTY) process.stdin.setRawMode(true);
  process.stdout.write('Ready for Site workflow JSON on stdin (input is hidden).\n');
  return new Promise((resolve, reject) => {
    let input = '';
    const restore = () => {
      process.stdin.off('data', onData);
      process.stdin.off('end', onEnd);
      if (process.stdin.isTTY) process.stdin.setRawMode(Boolean(wasRaw));
      process.stdin.pause();
    };
    const onEnd = () => { restore(); reject(new Error('Expected one newline-terminated JSON object on stdin.')); };
    const onData = (chunk) => {
      input += chunk.toString();
      if (input.includes('\u0003') || input.length > 1_000_000) {
        restore(); reject(new Error('Workflow input interrupted or too large.')); return;
      }
      const end = input.indexOf('\n');
      if (end < 0) return;
      restore();
      try { resolve(JSON.parse(input.slice(0, end).replace(/\r$/, ''))); }
      catch { reject(new Error('Workflow input must be valid JSON.')); }
      input = '';
    };
    process.stdin.on('data', onData);
    process.stdin.on('end', onEnd);
    process.stdin.resume();
  });
}

function authenticatedEnv(credential) {
  if (credential.auth_mode !== 'http_extra_header') {
    throw new Error('Unsupported credential auth_mode; expected http_extra_header.');
  }
  if (credential.provider && credential.provider !== 'cloudflare_artifact') {
    throw new Error('Unsupported source repository provider for http_extra_header.');
  }
  const remote = new URL(credential.remote_url);
  if (remote.protocol !== 'https:' || remote.username || remote.password || remote.search || remote.hash) {
    throw new Error('Source remote must be an HTTPS URL without embedded credentials, query, or fragment.');
  }
  if (typeof credential.token !== 'string' || !credential.token || /[\r\n]/.test(credential.token)) {
    throw new Error('Invalid source credential token.');
  }
  const authorization = `Authorization: Bearer ${credential.token}`;
  redactions = [credential.token, authorization, Buffer.from(`x-access-token:${credential.token}`).toString('base64')];
  const env = { ...process.env, GIT_TERMINAL_PROMPT: '0', GIT_ASKPASS: '/bin/false', GIT_TRACE_REDACT: '1' };
  // Git enables curl verbosity whenever this variable exists, even with "0".
  delete env.GIT_CURL_VERBOSE;
  for (const name of ['GIT_TRACE', 'GIT_TRACE_PACKET', 'GIT_TRACE_PERFORMANCE', 'GIT_TRACE_SETUP', 'GIT_TRACE_SHALLOW', 'GIT_TRACE_CURL', 'GIT_TRACE2', 'GIT_TRACE2_EVENT', 'GIT_TRACE2_PERF']) env[name] = '0';
  env.GIT_TRACE2_CONFIG_PARAMS = '';
  env.GIT_TRACE2_ENV_VARS = '';
  for (const key of Object.keys(env)) {
    if (/^GIT_CONFIG_(COUNT|KEY_\d+|VALUE_\d+|PARAMETERS)$/.test(key)) delete env[key];
  }
  const config = [
    ['credential.helper', ''],
    ['http.extraHeader', ''],
    [`http.${remote.href}.extraHeader`, authorization],
    ['http.followRedirects', 'false'],
    ['trace2.normalTarget', '0'],
    ['trace2.eventTarget', '0'],
    ['trace2.perfTarget', '0'],
    ['trace2.configParams', ''],
    ['trace2.envVars', ''],
  ];
  env.GIT_CONFIG_COUNT = String(config.length);
  config.forEach(([key, value], index) => {
    env[`GIT_CONFIG_KEY_${index}`] = key;
    env[`GIT_CONFIG_VALUE_${index}`] = value;
  });
  return env;
}

async function assertSafeIndex() {
  const tracked = await git(['ls-files', '-z'], { silent: true });
  for (const file of tracked.split('\0').filter(Boolean)) {
    if (/(^|\/)(node_modules|\.wrangler|\.sites-runtime|\.git)(\/|$)/.test(file) ||
        /(^|\/)\.env(?:\..+)?$/.test(file) && !file.endsWith('.env.example') ||
        /\.(?:tar\.gz|tgz)$/.test(file)) {
      throw new Error(`Refusing to publish a sensitive or runtime file: ${file}`);
    }
  }
}

async function main() {
  const input = await hiddenJson();
  const credential = input.credential;
  if (!credential || typeof credential !== 'object') throw new Error('Missing credential object.');
  if (typeof credential.branch !== 'string' || !credential.branch) throw new Error('Missing source branch.');
  const authEnv = authenticatedEnv(credential);
  await git(['check-ref-format', '--branch', credential.branch], { silent: true });
  const manifestPath = path.join(root, '.openai', 'hosting.json');
  let manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
  if (typeof manifest.project_id !== 'string' || !manifest.project_id) throw new Error('Persist the native project_id in .openai/hosting.json first.');
  if (input.source?.project_id && input.source.project_id !== manifest.project_id) throw new Error('Source project_id does not match the hosting manifest.');
  if (!Array.isArray(input.commands ?? [])) throw new Error('commands must be ordered argument arrays.');
  if (typeof input.archivePath !== 'string' || !path.isAbsolute(input.archivePath)) throw new Error('An absolute archivePath is required for packaging.');
  const archive = path.resolve(input.archivePath);
  const dist = path.join(root, 'dist');
  if (archive === root || archive.startsWith(`${dist}${path.sep}`)) throw new Error('Archive cannot be written inside the build output.');
  for (const command of input.commands ?? []) {
    if (!Array.isArray(command) || command.length === 0 || command.some((arg) => typeof arg !== 'string')) throw new Error('Each command must contain only string arguments.');
    await run(command[0], command.slice(1));
  }
  const latestManifest = JSON.parse(await readFile(manifestPath, 'utf8'));
  if (latestManifest.project_id !== manifest.project_id) throw new Error('The project_id changed during checks/build.');
  manifest = latestManifest;
  const builtManifest = JSON.parse(await readFile(path.join(dist, '.openai', 'hosting.json'), 'utf8'));
  if (JSON.stringify(builtManifest) !== JSON.stringify(manifest)) throw new Error('Built hosting manifest differs from current source; rebuild before packaging.');
  if (!manifest.static) await access(path.join(dist, 'server', 'index.js'));
  await mkdir(path.dirname(archive), { recursive: true });
  try { await access(path.join(root, '.git')); }
  catch { await git(['init', '--initial-branch', credential.branch]); }
  const top = await git(['rev-parse', '--show-toplevel'], { silent: true });
  if (await realpath(top) !== root) throw new Error('Run this helper in the selected repository root.');
  await git(['add', '--all']);
  await assertSafeIndex();
  const staged = await git(['diff', '--cached', '--name-only'], { silent: true });
  if (staged) await git(['-c', 'user.name=Sites Builder', '-c', 'user.email=sites-builder@openai.com', 'commit', '-m', 'Build MK2 Realms platform']);
  const commit = await git(['rev-parse', 'HEAD'], { silent: true });
  if (!/^[0-9a-f]{40}$/.test(commit)) throw new Error('Invalid source HEAD.');
  if (await git(['status', '--porcelain', '--untracked-files=all'], { silent: true })) throw new Error('Source changed during preparation; repeat checks/build and retry.');
  await git(['push', '--', credential.remote_url, `${commit}:refs/heads/${credential.branch}`], { env: authEnv });
  const remoteHead = await git(['ls-remote', '--exit-code', credential.remote_url, `refs/heads/${credential.branch}`], { env: authEnv, silent: true });
  if (remoteHead.split(/\s+/)[0] !== commit) throw new Error('Remote source branch HEAD does not match the prepared commit.');
  const entries = (await readdir(dist)).sort();
  if (!manifest.static && entries.some((entry) => !['.openai', 'client', 'server'].includes(entry))) throw new Error('Unexpected Worker build output; package only .openai, client, and server.');
  // Vinext publication resolves dist/server/index.js relative to archive root.
  // Keep generated migration metadata at root .openai as well.
  const outputPaths = manifest.static ? [manifest.static.directory] : ['dist'];
  await run('tar', ['--hard-dereference', '-czf', archive, '-C', dist, '.openai', '-C', root, ...outputPaths], { silent: true });
  if (await git(['status', '--porcelain', '--untracked-files=all'], { silent: true })) throw new Error('Source changed during packaging; do not publish this archive.');
  const archiveStat = await stat(archive);
  if (!archiveStat.isFile() || !archiveStat.size) throw new Error('Archive packaging failed.');
  process.stdout.write(`${JSON.stringify({ project_id: manifest.project_id, commit_sha: commit, archive })}\n`);
  // No native save/deploy action is performed by this helper.
}

main().catch((error) => { process.stderr.write(`${clean(error.message)}\n`); process.exitCode = 1; });
