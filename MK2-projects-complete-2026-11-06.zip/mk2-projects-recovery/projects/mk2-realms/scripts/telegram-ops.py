import json, sys, urllib.request, urllib.error, termios
if sys.stdin.isatty():
    flags=termios.tcgetattr(sys.stdin.fileno()); flags[3]&=~termios.ECHO; termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,flags)
print('READY for hidden Telegram operation JSON',flush=True)
args=json.loads(sys.stdin.readline())
for op in args.get('operations',[{'method':'getMe'},{'method':'getWebhookInfo'}]):
    method=op['method']
    try:
        req=urllib.request.Request('https://api.telegram.org/bot'+args['token']+'/'+method,data=json.dumps(op.get('payload',{})).encode(),headers={'Content-Type':'application/json'})
        with urllib.request.urlopen(req, timeout=30) as response: result=json.load(response)
        if method=='getWebhookInfo' and result.get('ok'): result['result'].pop('url',None)
        print(json.dumps({'method':method,'response':result},ensure_ascii=False),flush=True)
    except urllib.error.HTTPError as exc:
        data=exc.read().decode(); print(json.dumps({'method':method,'status':exc.code,'error':data},ensure_ascii=False),flush=True)
    except Exception as exc: print(json.dumps({'method':method,'error':type(exc).__name__},ensure_ascii=False),flush=True)
