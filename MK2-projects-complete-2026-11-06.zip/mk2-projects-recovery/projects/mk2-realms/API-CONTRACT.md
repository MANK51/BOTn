# MK~2 REALMS Core API

Every response is JSON `{ ok: true, ... }`, or `{ ok: false, error }` with an appropriate status. Protected requests use `Authorization: tma <Telegram.WebApp.initData>` verified on the server for each request; `/api/auth` returns the verified user. The server uses the authenticated user's Telegram ID. All timestamps are Unix milliseconds. Mutation bodies are JSON. Public browse excludes private worlds. Lists contain real database values, with no production seeds.

## Profile and progress
- `GET /api/profile`: `{user, achievements, transactions, inventory, notifications}`.
- `POST /api/daily`: once per UTC day; `{points, xp, streak, user}`. Duplicate returns 409.
- `GET /api/leaderboard?worldId=&period=all|week|month`: `{users:[{id,name,username,avatar,xp,points,level,rank}]}`.

## Worlds
- `GET /api/worlds?search=&mine=1`: `{worlds}` including `memberCount`, `role`, `isMember`.
- `POST /api/worlds`: `{name,description,kind,visibility,rules,image,background,color,joinMode}`; `{world}`. `kind`: games/puzzles/community/competitions/adventures. `joinMode`: open/approval. Owner membership created atomically.
- `GET /api/worlds/:id`: `{world, members, challenges, teams, posts}`. Private worlds require membership/invite; invite query `?invite=TOKEN` gives preview.
- `PATCH /api/worlds/:id`: editable world metadata, owner/admin only.
- `POST /api/worlds/:id/join`: `{invite?}`; open join or request pending approval. `{membership}`.
- `POST /api/worlds/:id/leave`: removes own membership; owner must transfer ownership before leaving.
- `POST /api/worlds/:id/invite`: owner/admin/moderator; creates token `{invite,urlPath}` (expiry seven days).
- `PATCH /api/worlds/:id/members/:userId`: `{role?}` or `{status:"active"|"removed"}`; owner/admin with hierarchy enforcement.
- `POST /api/worlds/:id/posts`: staff `{title,body}`; `{post}`.

## Challenges and attempts
- `GET /api/challenges?worldId=&mine=1`: `{challenges}`. Members see published challenges, editors their drafts; private worlds hidden.
- `POST /api/challenges`: world editor `{worldId,title,description,type,difficulty,xpReward,pointsReward,attemptLimit,timeLimit,status,scheduledAt,stages}`. Each stage `{kind,prompt,options:string[],answer:string,seconds,branch?:Record<string,number>}`. Types quiz/riddle/guess/image/team/poll/branch; status draft/published/scheduled. Server caps rewards. `{challenge}`.
- `GET /api/challenges/:id`: `{challenge,attempt}`; answers withheld from participants.
- `PATCH /api/challenges/:id`: editor changes; stages immutable once attempts begin. `{challenge}`.
- `DELETE /api/challenges/:id`: owner/admin, rejects challenges with attempts.
- `POST /api/challenges/:id/start`: resumes pending attempt or creates one within limit; `{attempt,stage,serverTime}`. Stage has no correct answer.
- `POST /api/attempts/:id/answer`: `{answer}`; server verifies stage, time, state and correct answer. `{attempt,stage?,correct,completed,user?,reward:{earned,xp,points,reason}}`. Sequential answers only; repeated completion never awards twice. Poll choices are validated against options. Participation in one's own challenge saves rehearsal results without awards. Positive earnings are limited to 3000 XP and 1500 points per UTC day; daily sign-in remains available. Receipt values indicate actual granted rewards.

## Store, teams, notifications, support
- `GET /api/store`: `{items}`; `POST /api/store/:id/buy`: `{item,user}` debits atomically, duplicate ownership rejected.
- `PATCH /api/inventory/:id`: `{equipped:boolean}` for owned cosmetic.
- `GET /api/teams?worldId=`: `{teams}` including `isMember`, `role`, `memberCount`, `leaderId`; `POST /api/teams`: `{worldId,name,description,logo}`; `{team}`.
- `POST /api/teams/:id/join`: `{team}`; world member required, one team per world.
- `POST /api/teams/:id/leave`: leader cannot leave.
- `PATCH /api/teams/:id/members/:userId`: leader `{role:"deputy"|"member"}` or `{remove:true}`.
- `GET /api/notifications`: `{notifications}`; `POST /api/notifications/:id/read`.
- `POST /api/tickets`: `{subject,message,priority}`; `{ticket}`. `GET /api/tickets`: own `{tickets}`. `POST /api/tickets/:id/replies`: `{message}`.
- `GET /api/settings/public`: `{settings}` containing public display, feature and reward settings only.

Core exports: `platformApi(request,env,user)`, `ensureUser(env,telegramUser)`, `getProfile(env,userId)`, `dailyClaim(env,userId)`, `q(env,sql,...bindings)`, `all(env,sql,...bindings)`, `run(env,sql,...bindings)`, `grantRewardStatements(env,userId,key,xp,points,reason,worldId?)`, `getWorldAccess(env,worldId,userId)` and `mapUser(row)`. `env.DB` is D1. User `{id,telegramId,name,username,avatar,xp,points,level,role,status}`. DB table names in `db/schema.ts` use snake_case. Schema includes events/votes for the event API and admin roles/audit/settings for administration.
