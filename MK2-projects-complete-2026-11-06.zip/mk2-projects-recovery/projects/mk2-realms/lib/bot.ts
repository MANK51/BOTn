import {ensureUser,getProfile,dailyClaim,all,q} from './platform';
import {ApiError,constantEqual,json,rateLimit} from './security';

export async function telegramCall(env:any,method:string,payload:any){
  if(!env.TELEGRAM_BOT_TOKEN)throw new ApiError(503,'لم يتم إعداد اتصال Telegram.');
  const response=await fetch('https://api.telegram.org/bot'+env.TELEGRAM_BOT_TOKEN+'/'+method,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
  const result:any=await response.json();if(!result.ok){const error:any=new ApiError(502,'تعذّر تنفيذ عملية Telegram ('+String(result.error_code||response.status)+').');error.telegramRejected=true;error.providerCode=result.error_code||response.status;throw error;}return result.result;
}
const appUrl=(env:any,view='home',extra='')=>`${env.APP_URL}/?view=${encodeURIComponent(view)}${extra}`;
const keyboard=(env:any,group=false)=>({inline_keyboard:[
  [{text:'🚀 تشغيل التطبيق',...(group?{url:`https://t.me/${env.BOT_USERNAME}?start=app`}:{web_app:{url:appUrl(env)}})}],
  [{text:'🌍 عوالمي',...(group?{url:`https://t.me/${env.BOT_USERNAME}?start=worlds`}:{web_app:{url:appUrl(env,'worlds')}})},{text:'🎮 التحديات',...(group?{url:`https://t.me/${env.BOT_USERNAME}?start=challenges`}:{web_app:{url:appUrl(env,'challenges')}})}],
  [{text:'🏆 ترتيبي',callback_data:'rank'},{text:'👥 إنشاء عالم',...(group?{url:`https://t.me/${env.BOT_USERNAME}?start=create`}:{web_app:{url:appUrl(env,'create')}})}],
  [{text:'🎁 المكافآت',...(group?{url:`https://t.me/${env.BOT_USERNAME}?start=rewards`}:{web_app:{url:appUrl(env,'rewards')}})},{text:'⚙️ الإعدادات',callback_data:'settings'}],
  [{text:'📞 الدعم والمساعدة',callback_data:'help'}]
]});
async function say(env:any,chatId:number|string,text:string,reply_markup?:any){return telegramCall(env,'sendMessage',{chat_id:chatId,text,reply_markup,disable_web_page_preview:true});}
async function settings(env:any,chatId:any,user:any){const row:any=await q(env,'SELECT notify_allowed FROM users WHERE id=?',user.id);return say(env,chatId,'⚙️ إعدادات MK~2 REALMS\n\nتنبيهات الرسائل الخاصة: '+(row?.notify_allowed?'مفعّلة':'متوقفة')+'\nيمكنك تغييرها في أي وقت. تنبيهات التطبيق تبقى محفوظة في حسابك.',{inline_keyboard:[[{text:row?.notify_allowed?'🔕 إيقاف التنبيهات':'🔔 تفعيل التنبيهات',callback_data:row?.notify_allowed?'notify:off':'notify:on'}],[{text:'🚀 التطبيق',web_app:{url:appUrl(env,'profile')}}]]});}
async function profile(env:any,chatId:any,user:any){const p:any=await getProfile(env,user.id);const u=p.user||user;return say(env,chatId,`👤 ${u.name}\n\nالمستوى: ${u.level}\nالخبرة: ${u.xp} XP\nالنقاط: ${u.points}\n\nعالمك. قوانينك. مغامرتك.`,{inline_keyboard:[[{text:'👤 حسابي',web_app:{url:appUrl(env,'profile')}}]]});}
async function rank(env:any,chatId:any,user:any){const count:any=await q(env,'SELECT COUNT(*)+1 AS rank FROM users WHERE status=\'active\' AND xp>(SELECT xp FROM users WHERE id=?)',user.id);return say(env,chatId,`🏆 ترتيبك العالمي: ${count?.rank||1}\n⭐ ${user.xp} XP`,{inline_keyboard:[[{text:'🏆 لوحة الترتيب',web_app:{url:appUrl(env,'leaderboard')}}]]});}
async function welcome(env:any,chatId:any,param:string){
 const caption='🌌 أهلًا بك في MK~2 REALMS!\n\nعالمك الرقمي يبدأ من هنا.\n\nأنشئ عالمك، اكتشف أسراره، تنافس مع اللاعبين، وشارك في مغامرات تتغير بقراراتك.\n\n🚀 هل أنت مستعد للانطلاق؟';
 const view=['worlds','challenges','rewards','create','events','profile'].includes(param)?param:'home';
 const k=keyboard(env);if(param?.startsWith('world_'))k.inline_keyboard.unshift([{text:'🌌 دخول العالم',web_app:{url:appUrl(env,'worlds','&world='+encodeURIComponent(param.slice(6)))}}]);else if(view!=='home')k.inline_keyboard[0]=[{text:'🚀 فتح القسم',web_app:{url:appUrl(env,view)}}];
 try{await telegramCall(env,'sendPhoto',{chat_id:chatId,photo:env.APP_URL+'/assets/welcome.jpg',caption,reply_markup:k});}catch{await say(env,chatId,caption,k);}
}
async function linkWorld(env:any,message:any,user:any,worldId:string){
 if(user.status!=='active')throw new ApiError(403,'هذا الحساب مقيّد ولا يمكنه ربط القروبات.');
 if(message.chat.type==='private')return say(env,message.chat.id,'أضف البوت مديرًا إلى القروب، ثم أرسل داخله:\n/link معرف_العالم');
 const world:any=await q(env,'SELECT * FROM worlds WHERE id=? AND status=\'active\'',worldId);if(!world)return say(env,message.chat.id,'معرّف العالم غير موجود. انسخه من صفحة العالم في التطبيق.');
 const member:any=await q(env,'SELECT role FROM world_members WHERE world_id=? AND user_id=? AND status=\'active\'',worldId,user.id);if(!member||!['owner','admin'].includes(member.role))throw new ApiError(403,'يلزم أن تكون مالك العالم أو مديره لربطه.');
 const botId=Number(env.TELEGRAM_BOT_TOKEN.split(':')[0]);const [human,bot]=await Promise.all([telegramCall(env,'getChatMember',{chat_id:message.chat.id,user_id:message.from.id}),telegramCall(env,'getChatMember',{chat_id:message.chat.id,user_id:botId})]);
 if(!['creator','administrator'].includes(human.status)||!['administrator','creator'].includes(bot.status))throw new ApiError(403,'يجب أن تكون أنت والبوت من مديري القروب قبل الربط.');
 await env.DB.prepare('UPDATE worlds SET telegram_chat_id=?,updated_at=? WHERE id=?').bind(String(message.chat.id),Date.now(),worldId).run();
 await say(env,message.chat.id,`🌍 تم ربط القروب بعالم «${world.name}».\n\nيمكن استخدام /events و/rank لعرض النشاط، وستظهر هنا نتائج الفعاليات المكتملة.`,{inline_keyboard:[[{text:'🌌 دخول العالم',url:`https://t.me/${env.BOT_USERNAME}?start=world_${worldId}`}]]});
}
async function groupCommand(env:any,message:any,command:string,user:any,args:string){
 if(command==='link')return linkWorld(env,message,user,args.trim());
 const worlds:any[]=await all(env,'SELECT id,name FROM worlds WHERE telegram_chat_id=? AND status=\'active\'',String(message.chat.id));
 if(command==='events'&&worlds.length){const rows:any[]=await all(env,'SELECT title,ends_at,status FROM events WHERE world_id=? AND status IN (\'active\',\'scheduled\') ORDER BY starts_at LIMIT 8',worlds[0].id);return say(env,message.chat.id,rows.length?'🔥 فعاليات العالم\n\n'+rows.map(e=>'• '+e.title+' — '+(e.status==='scheduled'?'مجدولة':'مباشرة')).join('\n'):'لا توجد فعاليات مباشرة حاليًا.',{inline_keyboard:[[{text:'🌌 الدخول والمشاركة',url:`https://t.me/${env.BOT_USERNAME}?start=world_${worlds[0].id}`}]]});}
 if(command==='rank'&&worlds.length){const rows:any[]=await all(env,'SELECT u.name,COALESCE(SUM(x.xp),0) AS xp FROM world_members wm JOIN users u ON u.id=wm.user_id LEFT JOIN xp_transactions x ON x.user_id=u.id AND x.world_id=wm.world_id WHERE wm.world_id=? AND wm.status=\'active\' GROUP BY u.id ORDER BY xp DESC LIMIT 10',worlds[0].id);return say(env,message.chat.id,'🏆 ترتيب العالم\n\n'+rows.map((r,i)=>`${i+1}. ${r.name} — ${r.xp} XP`).join('\n'));}
 return say(env,message.chat.id,'🌌 MK~2 REALMS\nافتح المحادثة الخاصة مع البوت لإنشاء عالم والمشاركة في التحديات.\n\nلربط القروب: امنح البوت صلاحية المدير، ثم أرسل /link معرف_العالم.',keyboard(env,true));
}

/** Deliver completed-event announcements only to groups explicitly linked by
 * both a verified world manager and a Telegram group administrator. */
export async function flushEventAnnouncements(env:any){
 const eligibleAt=Date.now();
 const rows:any[]=await all(env,"SELECT e.id,e.title,e.creator_id,w.telegram_chat_id FROM events e JOIN worlds w ON w.id=e.world_id WHERE e.status='completed' AND w.telegram_chat_id IS NOT NULL AND w.status='active' AND NOT EXISTS (SELECT 1 FROM event_actions a WHERE a.event_id=e.id AND a.action_key='telegram:result' AND (a.kind IN ('telegram_sent','telegram_sending','telegram_unknown') OR (a.kind='telegram_failed' AND a.created_at>?) OR (a.kind='telegram_processing' AND a.created_at>?))) ORDER BY e.updated_at DESC LIMIT 3",eligibleAt-300000,eligibleAt-90000);
 for(const event of rows){
  const key='telegram:result';const now=Date.now();
  await env.DB.prepare("INSERT OR IGNORE INTO event_actions(id,event_id,user_id,action_key,kind,data,created_at) VALUES (?,?,?,?,'telegram_pending','{}',?)").bind(crypto.randomUUID(),event.id,event.creator_id,key,now).run();
  const lock:any=await env.DB.prepare("UPDATE event_actions SET kind='telegram_processing',created_at=? WHERE event_id=? AND action_key=? AND (kind='telegram_pending' OR (kind='telegram_failed' AND created_at<?) OR (kind='telegram_processing' AND created_at<?))").bind(now,event.id,key,now-300000,now-90000).run();
  if(!lock.meta?.changes)continue;
  let sent=false;
  try{
   const winners:any[]=await all(env,"SELECT u.name,x.xp,x.points FROM xp_transactions x JOIN users u ON u.id=x.user_id WHERE x.source_key=? ORDER BY x.xp DESC,x.created_at ASC LIMIT 10",'event:'+event.id);
   const sending:any=await env.DB.prepare("UPDATE event_actions SET kind='telegram_sending' WHERE event_id=? AND action_key=? AND kind='telegram_processing' AND created_at=?").bind(event.id,key,now).run();if(!sending.meta?.changes)continue;
   await say(env,event.telegram_chat_id,'🔐 فُتحت الخزنة!\n\n'+event.title+'\n\n🏆 المساهمون الذين حصلوا على المكافأة\n'+(winners.length?winners.map((u,i)=>`${i+1}. ${u.name} — ${u.xp} XP · ${u.points} نقطة`).join('\n'):'المكافآت محفوظة في حسابات المساهمين.'),keyboard(env,true));
   sent=true;
   await env.DB.prepare("UPDATE event_actions SET kind='telegram_sent',data=?,created_at=? WHERE event_id=? AND action_key=? AND kind='telegram_sending' AND created_at=?").bind(JSON.stringify({delivered:true}),Date.now(),event.id,key,now).run();
  }catch(error:any){
   const state=!sent&&error.telegramRejected?'telegram_failed':'telegram_unknown';
   try{await env.DB.prepare("UPDATE event_actions SET kind=?,data=?,created_at=? WHERE event_id=? AND action_key=? AND created_at=?").bind(state,JSON.stringify({code:error.providerCode||error.status||500,delivery:sent?'confirmed':'unknown'}),Date.now(),event.id,key,now).run();}catch{console.error('event_announcement_state_failed',{eventId:event.id});}
   console.error('event_announcement_failed',{eventId:event.id,code:error.providerCode||error.status||500,state});
  }
 }
}
async function processUpdate(env:any,update:any){
 const callback=update.callback_query;
 if(callback){if(!callback.message||callback.message.chat.type!=='private'){await telegramCall(env,'answerCallbackQuery',{callback_query_id:callback.id,text:'افتح المحادثة الخاصة مع البوت.'});return;}
 const user:any=await ensureUser(env,callback.from);if(user.status==='banned'){await telegramCall(env,'answerCallbackQuery',{callback_query_id:callback.id,text:'هذا الحساب موقوف.'});return;}await telegramCall(env,'answerCallbackQuery',{callback_query_id:callback.id});const chat=callback.message.chat.id;
 if(callback.data==='rank')return rank(env,chat,user);if(callback.data==='settings')return settings(env,chat,user);if(callback.data==='notify:on'||callback.data==='notify:off'){await env.DB.prepare('UPDATE users SET notify_allowed=? WHERE id=?').bind(callback.data==='notify:on'?1:0,user.id).run();return settings(env,chat,user);}return say(env,chat,'📞 المساعدة\n\nأنشئ عالمك، انشر تحديًا، وشارك في فعاليات تعاونية.\nللإبلاغ عن مشكلة افتح «حسابي ← الدعم» داخل التطبيق.',keyboard(env));
 }
 const message=update.message;if(!message?.from||typeof message.text!=='string')return;
 const match=message.text.match(/^\/([a-z]+)(?:@([a-zA-Z0-9_]+))?(?:\s+([\s\S]*))?$/);if(!match)return;if(match[2]&&match[2].toLowerCase()!==String(env.BOT_USERNAME).toLowerCase())return;
 const user:any=await ensureUser(env,message.from);const command=match[1],args=match[3]||'',chat=message.chat.id;
 if(user.status==='banned')return say(env,chat,'هذا الحساب موقوف. يمكنك التواصل عبر الدعم.');
 if(message.chat.type!=='private')return groupCommand(env,message,command,user,args);
 if(command==='start')return welcome(env,chat,args);
 if(command==='profile')return profile(env,chat,user);if(command==='rank')return rank(env,chat,user);if(command==='settings')return settings(env,chat,user);
 if(command==='daily'){try{const result:any=await dailyClaim(env,user.id);return say(env,chat,`🎁 استلمت مكافأتك اليومية!\n⭐ ${result.xp} XP\n🪙 ${result.points} نقطة\n🔥 سلسلة النشاط: ${result.streak} يوم`,keyboard(env));}catch(e:any){return say(env,chat,e.message||'تم استلام المكافأة اليوم.');}}
 if(command==='worlds'){const worlds:any[]=await all(env,'SELECT w.name FROM worlds w JOIN world_members m ON m.world_id=w.id WHERE m.user_id=? AND m.status=\'active\' AND w.status=\'active\' ORDER BY m.joined_at DESC LIMIT 12',user.id);return say(env,chat,worlds.length?'🌍 عوالمي\n\n'+worlds.map(w=>'• '+w.name).join('\n'):'🌍 عالمك الأول ينتظرك. افتح التطبيق لإنشاء عالم أو الانضمام إلى عالم عام.',keyboard(env));}
 if(command==='events')return say(env,chat,'🔥 افتح الفعاليات لرؤية الألغاز والتصويت والتحديات التعاونية المتاحة في عوالمك.',{inline_keyboard:[[{text:'🔥 الفعاليات',web_app:{url:appUrl(env,'events')}}]]});
 return say(env,chat,'🌌 أوامر MK~2 REALMS\n\n/start — البداية\n/help — المساعدة\n/profile — الملف الشخصي\n/worlds — عوالمي\n/rank — ترتيبي\n/daily — المكافأة اليومية\n/events — الفعاليات\n/settings — الإعدادات\n\nداخل القروب: /link معرف_العالم لربط عالمك بعد منح البوت صلاحية المدير.',keyboard(env));
}
export async function botWebhook(request:Request,env:any){
 if(!env.TELEGRAM_WEBHOOK_SECRET||!constantEqual(request.headers.get('x-telegram-bot-api-secret-token')||'',env.TELEGRAM_WEBHOOK_SECRET))return json({ok:false,error:'غير مصرح.'},403);
 const raw=await request.text();if(raw.length>65536)return json({ok:false,error:'طلب كبير.'},413);let update:any;try{update=JSON.parse(raw);}catch{return json({ok:false,error:'طلب غير صالح.'},400);}
 if(!update||typeof update!=='object'||Array.isArray(update)||!Number.isSafeInteger(update.update_id))return json({ok:false,error:'معرّف تحديث غير صالح.'},400);
 const now=Date.now();const existing:any=await q(env,'SELECT * FROM webhook_updates WHERE update_id=?',update.update_id);if(existing?.status==='done')return json({ok:true});if(existing?.status==='processing'&&now-existing.updated_at<45000)return json({ok:false},503);
 const result:any=await env.DB.prepare('INSERT INTO webhook_updates (update_id,status,created_at,updated_at) VALUES (?,\'processing\',?,?) ON CONFLICT(update_id) DO UPDATE SET status=\'processing\',updated_at=excluded.updated_at WHERE webhook_updates.status=\'failed\' OR webhook_updates.updated_at<?').bind(update.update_id,now,now,now-45000).run();if(!result.meta?.changes)return json({ok:false},503);
 try{await rateLimit(env,'bot:'+String(update.message?.chat?.id||update.callback_query?.from?.id||'other'),100);await processUpdate(env,update);await env.DB.prepare('UPDATE webhook_updates SET status=\'done\',updated_at=? WHERE update_id=?').bind(Date.now(),update.update_id).run();return json({ok:true});}catch(e:any){if(e instanceof ApiError&&e.status<500){const chat=update.message?.chat?.id;if(chat)try{await say(env,chat,e.message);}catch{}await env.DB.prepare('UPDATE webhook_updates SET status=\'done\',updated_at=? WHERE update_id=?').bind(Date.now(),update.update_id).run();return json({ok:true});}await env.DB.prepare('UPDATE webhook_updates SET status=\'failed\',updated_at=?,error_code=? WHERE update_id=?').bind(Date.now(),String(e.status||500),update.update_id).run();console.error('telegram_update_failed',{updateId:update.update_id,code:e.status||500});return json({ok:false},500);}
}
