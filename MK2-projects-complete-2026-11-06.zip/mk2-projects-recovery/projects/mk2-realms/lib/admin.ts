import { q, all } from './platform';

type Env = { DB: any; BOT_TOKEN?: string; TELEGRAM_BOT_TOKEN?: string; [key:string]: any };
type AdminUser = { id: string; role: string; name?: string; status?: string; [key:string]: any };
class AdminError extends Error { status: number; constructor(message:string,status=400){super(message);this.status=status} }
const staff=['super_admin','admin','moderator','support'];
const full=['super_admin','admin'];
const moderators=['super_admin','admin','moderator'];
const permissions: Record<string,string[]>={overview:staff,users:moderators,worlds:moderators,challenges:moderators,events:moderators,rewards:full,teams:moderators,notifications:full,settings:full,tickets:staff,audit:full};
const now=()=>Date.now();
const uid=()=>crypto.randomUUID();
const json=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}});
const parse=(value:any,fallback:any={})=>{try{return typeof value==='string'?JSON.parse(value):value??fallback}catch{return fallback}};
const statement=(env:Env,sql:string,...params:any[])=>env.DB.prepare(sql).bind(...params);
const audit=(env:Env,user:AdminUser,action:string,entity:string,id:string|null,before:any,after:any)=>statement(env,'INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,before_data,after_data,created_at) VALUES(?,?,?,?,?,?,?,?)',uid(),user.id,action,entity,id,before?JSON.stringify(before):null,JSON.stringify(after),now());
const requiredText=(value:any,label:string,max=120,min=1)=>{if(typeof value!=='string'||value.trim().length<min||value.trim().length>max)throw new AdminError(`${label}: أدخل نصًا بطول ${min} إلى ${max} حرف`);return value.trim()};
const imagePath=(value:any)=>{if(!value)return '/assets/badge-gold.svg';const text=requiredText(value,'مسار الصورة',500);if(!/^\/assets\/[\w./-]+$|^https:\/\/[^\s]+$/i.test(text))throw new AdminError('استخدم مسارًا من /assets/ أو رابط HTTPS للصورة');return text};
const option=(value:any,values:string[],name='الحالة')=>{if(!values.includes(value))throw new AdminError(`${name} غير صالح`);return value};
const integer=(value:any,name:string,min=0,max=1000000)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw new AdminError(`${name} يجب أن يكون عددًا صحيحًا بين ${min} و${max}`);return value};
const count=async(env:Env,sql:string,...params:any[])=>Number((await q(env,sql,...params))?.count||0);
async function body(request:Request){if(Number(request.headers.get('content-length')||0)>18000)throw new AdminError('حجم الطلب أكبر من المسموح',413);let data:any;try{const raw=await request.text();if(raw.length>18000)throw new AdminError('حجم الطلب أكبر من المسموح',413);data=JSON.parse(raw)}catch(error){if(error instanceof AdminError)throw error;throw new AdminError('الطلب يجب أن يحتوي بيانات JSON صحيحة')};if(!data||typeof data!=='object'||Array.isArray(data))throw new AdminError('بيانات الطلب غير صالحة');return data}
function identity(user:AdminUser){return {id:user.id,name:user.name||'مدير المنصة',role:user.role}}

/** All administration paths require a user identity authenticated by the parent router. */
export async function adminApi(request:Request,env:Env,user:AdminUser|null):Promise<Response|null>{
  const url=new URL(request.url);if(!url.pathname.startsWith('/api/admin/'))return null;
  try{
    if(!user)throw new AdminError('سجّل الدخول بحساب إداري مخوّل',401);
    if(!staff.includes(user.role)||user.status==='banned'||user.status==='restricted')throw new AdminError('لا تملك صلاحية الوصول إلى لوحة الإدارة',403);
    if(!['GET','HEAD'].includes(request.method)){
      const origin=request.headers.get('origin');if(origin&&origin!==url.origin)throw new AdminError('مصدر الطلب غير مسموح',403);
      if(!request.headers.get('content-type')?.toLowerCase().startsWith('application/json'))throw new AdminError('استخدم Content-Type: application/json',415);
    }
    const paths=url.pathname.slice('/api/admin/'.length).split('/').filter(Boolean).map(decodeURIComponent);
    const [resource,id]=paths;if(!permissions[resource])throw new AdminError('القسم المطلوب غير موجود',404);
    if(!permissions[resource].includes(user.role))throw new AdminError('لا تملك صلاحية هذا القسم',403);
    if(paths.length>2)throw new AdminError('المسار غير موجود',404);
    const finish=(data:any,status=200)=>json({ok:true,role:user.role,user:identity(user),...data},status);
    if(resource==='overview'&&request.method==='GET'){
      const days=url.searchParams.get('days')==='30'?30:7;const today=new Date().toISOString().slice(0,10);const start=Date.parse(today+'T00:00:00Z')-(days-1)*86400000;
      const values=await Promise.all([
        count(env,'SELECT COUNT(*) AS count FROM users'),count(env,"SELECT COUNT(*) AS count FROM worlds WHERE status='active'"),
        count(env,"SELECT COUNT(*) AS count FROM events WHERE status='active' AND starts_at<=? AND ends_at>?",now(),now()),count(env,'SELECT COUNT(*) AS count FROM attempts'),
        count(env,"SELECT COUNT(*) AS count FROM challenges WHERE status='published'"),count(env,"SELECT COUNT(*) AS count FROM support_tickets WHERE status IN ('open','pending')"),
        all(env,"SELECT strftime('%Y-%m-%d', created_at/1000, 'unixepoch') AS day,COUNT(*) AS users FROM users WHERE created_at>=? GROUP BY day ORDER BY day",start),
        user.role==='support'?all(env,"SELECT a.*,u.name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id WHERE a.entity_type='support_tickets' AND a.actor_id=? ORDER BY a.created_at DESC LIMIT 8",user.id):all(env,'SELECT a.*,u.name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.created_at DESC LIMIT 8')
      ]);
      const series=Array.from({length:days},(_,i)=>{const day=new Date(start+i*86400000).toISOString().slice(0,10);return{day,users:Number((values[6] as any[]).find(x=>x.day===day)?.users||0)}});
      return finish({counts:{users:values[0],worlds:values[1],events:values[2],attempts:values[3],challenges:values[4],tickets:values[5]},series,newUsers:series.reduce((n,x)=>n+x.users,0),activity:(values[7] as any[]).map(x=>({...x,resource_type:x.entity_type,resource_id:x.entity_id})),health:{database:'ok',botConfigured:!!(env.BOT_TOKEN||env.TELEGRAM_BOT_TOKEN)},serverTime:now()});
    }
    if(request.method==='GET'){
      const search=(url.searchParams.get('search')||'').trim().slice(0,120);const like=`%${search}%`;
      if(resource==='users'){
        const items=await all(env,"SELECT id,telegram_id,name,username,avatar,xp,points,level,role,status,notify_allowed,created_at,last_seen FROM users WHERE (?='' OR name LIKE ? OR username LIKE ? OR telegram_id=?) ORDER BY created_at DESC LIMIT 101",search,like,like,search);
        const total=await count(env,"SELECT COUNT(*) AS count FROM users WHERE (?='' OR name LIKE ? OR username LIKE ? OR telegram_id=?)",search,like,like,search);
        return finish({items:items.slice(0,100),total,truncated:items.length>100});
      }
      if(resource==='worlds'){
        const items=await all(env,"SELECT w.*,u.name AS owner_name,(SELECT COUNT(*) FROM world_members m WHERE m.world_id=w.id AND m.status='active') AS member_count FROM worlds w JOIN users u ON u.id=w.owner_id WHERE (?='' OR w.name LIKE ? OR w.id=?) ORDER BY w.created_at DESC LIMIT 101",search,like,search);return finish({items:items.slice(0,100),total:await count(env,"SELECT COUNT(*) AS count FROM worlds WHERE (?='' OR name LIKE ? OR id=?)",search,like,search),truncated:items.length>100});
      }
      if(resource==='challenges'){
        const items=await all(env,"SELECT c.*,w.name AS world_name,(SELECT COUNT(*) FROM attempts a WHERE a.challenge_id=c.id) AS attempt_count FROM challenges c JOIN worlds w ON w.id=c.world_id WHERE (?='' OR c.title LIKE ? OR c.id=?) ORDER BY c.created_at DESC LIMIT 101",search,like,search);return finish({items:items.slice(0,100),total:await count(env,"SELECT COUNT(*) AS count FROM challenges WHERE (?='' OR title LIKE ? OR id=?)",search,like,search),truncated:items.length>100});
      }
      if(resource==='events'){
        const items=await all(env,"SELECT e.id,e.world_id,e.title,e.description,e.status,e.stage,e.revision,e.starts_at,e.ends_at,e.created_at,e.reward_xp,e.reward_points,w.name AS world_name,(SELECT COUNT(*) FROM event_participants p WHERE p.event_id=e.id) AS participant_count,(SELECT COUNT(*) FROM votes v WHERE v.event_id=e.id) AS vote_count FROM events e LEFT JOIN worlds w ON w.id=e.world_id WHERE (?='' OR e.title LIKE ? OR e.id=?) ORDER BY e.created_at DESC LIMIT 101",search,like,search);return finish({items:items.slice(0,100),total:await count(env,"SELECT COUNT(*) AS count FROM events WHERE (?='' OR title LIKE ? OR id=?)",search,like,search),truncated:items.length>100});
      }
      if(resource==='teams'){
        const items=await all(env,"SELECT t.*,w.name AS world_name,u.name AS leader_name,(SELECT COUNT(*) FROM team_members m WHERE m.team_id=t.id) AS member_count FROM teams t JOIN worlds w ON w.id=t.world_id JOIN users u ON u.id=t.leader_id WHERE (?='' OR t.name LIKE ? OR t.id=?) ORDER BY t.created_at DESC LIMIT 101",search,like,search);return finish({items:items.slice(0,100),total:await count(env,"SELECT COUNT(*) AS count FROM teams WHERE (?='' OR name LIKE ? OR id=?)",search,like,search),truncated:items.length>100});
      }
      if(resource==='rewards'){
        const items=await all(env,"SELECT * FROM rewards WHERE (?='' OR name LIKE ? OR id=?) ORDER BY created_at DESC LIMIT 101",search,like,search);return finish({items:items.slice(0,100).map(x=>({...x,type:x.kind,active:!!x.enabled})),total:await count(env,"SELECT COUNT(*) AS count FROM rewards WHERE (?='' OR name LIKE ? OR id=?)",search,like,search),truncated:items.length>100});
      }
      if(resource==='tickets'){
        const items=await all(env,"SELECT t.*,u.name AS user_name FROM support_tickets t JOIN users u ON u.id=t.user_id WHERE (?='' OR t.subject LIKE ? OR t.id=?) ORDER BY t.updated_at DESC LIMIT 101",search,like,search);
        const selected=items.slice(0,100);const replies=selected.length?await all(env,`SELECT r.*,u.name AS author_name FROM ticket_replies r JOIN users u ON u.id=r.user_id WHERE r.ticket_id IN (${selected.map(()=>'?').join(',')}) ORDER BY r.created_at ASC LIMIT 500`,...selected.map(x=>x.id)):[];
        return finish({items:selected.map(x=>({...x,initial_message:x.message,replies:replies.filter(r=>r.ticket_id===x.id).slice(-50)})),total:await count(env,"SELECT COUNT(*) AS count FROM support_tickets WHERE (?='' OR subject LIKE ? OR id=?)",search,like,search),truncated:items.length>100});
      }
      if(resource==='settings')return finish({items:(await all(env,'SELECT key,value,updated_by,updated_at FROM settings ORDER BY key')).map(x=>({...x,value:parse(x.value,null)}))});
      if(resource==='audit'){
        const items=await all(env,"SELECT a.*,u.name AS actor_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id WHERE (?='' OR a.action LIKE ? OR a.entity_type LIKE ? OR a.actor_id=?) ORDER BY a.created_at DESC LIMIT 101",search,like,like,search);
        return finish({items:items.slice(0,100).map(x=>({...x,resource_type:x.entity_type,resource_id:x.entity_id,before_data:parse(x.before_data,null),after_data:parse(x.after_data,null)})),total:await count(env,"SELECT COUNT(*) AS count FROM audit_logs WHERE (?='' OR action LIKE ? OR entity_type LIKE ? OR actor_id=?)",search,like,like,search),truncated:items.length>100});
      }
      if(resource==='notifications')return finish({items:(await all(env,"SELECT id,after_data,created_at FROM audit_logs WHERE action='notification.broadcast' ORDER BY created_at DESC LIMIT 100")).map(x=>({...x,...parse(x.after_data)}))});
      throw new AdminError('المسار غير موجود',404);
    }
    const data=await body(request);
    if(resource==='settings'&&request.method==='PATCH'&&!id){
      if(!data.values||typeof data.values!=='object'||Array.isArray(data.values))throw new AdminError('قيم الإعدادات غير صالحة');
      const keys=Object.keys(data.values);if(!keys.length||keys.length>15)throw new AdminError('عدد الإعدادات غير صالح');
      const allowed=['display.tagline','display.hero_title','display.hero_text','display.hero_image','display.accent','daily.xp','daily.points','features.world_creation','features.store','features.events','maintenance.enabled'];
      const before:any={};const changes:any[]=[];
      for(const key of keys){if(!allowed.includes(key))throw new AdminError('هذا الإعداد غير قابل للتعديل');let value=data.values[key];
        if(key.startsWith('features.')||key==='maintenance.enabled'){if(typeof value!=='boolean')throw new AdminError('قيمة الميزة يجب أن تكون صحيحة أو خاطئة')}
        else if(key.startsWith('daily.'))value=integer(value,'المكافأة اليومية',0,key==='daily.xp'?500:200);
        else if(key==='display.accent'){if(typeof value!=='string'||!/^#[a-f0-9]{6}$/i.test(value))throw new AdminError('اللون يجب أن يكون بصيغة #RRGGBB')}
        else if(key==='display.hero_image'){value=value?imagePath(value):''}
        else value=requiredText(value,'النص',key==='display.hero_text'?1000:150);
        before[key]=parse((await q(env,'SELECT value FROM settings WHERE key=?',key))?.value,null);data.values[key]=value;
        changes.push(statement(env,'INSERT INTO settings(key,value,updated_by,updated_at) VALUES(?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_by=excluded.updated_by,updated_at=excluded.updated_at',key,JSON.stringify(value),user.id,now()));
      }
      await env.DB.batch([...changes,audit(env,user,'settings.update','settings',null,before,data.values)]);return finish({message:'حُفظت إعدادات المنصة'});
    }
    if(resource==='users'&&request.method==='PATCH'&&id){
      const target=await q(env,'SELECT * FROM users WHERE id=?',id);if(!target)throw new AdminError('المستخدم غير موجود',404);
      if(data.role!==undefined){
        if(user.role!=='super_admin')throw new AdminError('تغيير صلاحيات الإدارة متاح للمالك فقط',403);
        const next=option(data.role,['user',...staff],'الدور');if(target.id===user.id&&next!=='super_admin')throw new AdminError('لا يمكنك إزالة صلاحية حسابك الحالي',409);
        if(target.role==='super_admin'&&next!=='super_admin'&&(await count(env,"SELECT COUNT(*) AS count FROM users WHERE role='super_admin' AND status='active'"))<=1)throw new AdminError('لا يمكن إزالة آخر مالك للمنصة',409);
        const update=statement(env,"UPDATE users SET role=? WHERE id=? AND (role<>'super_admin' OR ?='super_admin' OR (SELECT COUNT(*) FROM users WHERE role='super_admin' AND status='active')>1)",next,id,next);
        const roleStmt=next==='user'?statement(env,'DELETE FROM admin_roles WHERE user_id=?',id):statement(env,'INSERT INTO admin_roles(user_id,role,granted_by,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET role=excluded.role,granted_by=excluded.granted_by,created_at=excluded.created_at',id,next,user.id,now());
        await env.DB.batch([update,roleStmt,audit(env,user,'user.role.update','users',id,{role:target.role},{role:next})]);return finish({message:'حُفظت صلاحيات الحساب'});
      }
      const status=option(data.status,['active','restricted','banned']);const reason=requiredText(data.reason,'سبب الإجراء',1000,3);
      if(id===user.id)throw new AdminError('لا يمكنك تقييد حساب الإدارة الذي تستخدمه',409);
      if(target.role==='super_admin'||(target.role!=='user'&&user.role!=='super_admin'))throw new AdminError('لا تملك صلاحية تقييد هذا الحساب الإداري',403);
      await env.DB.batch([statement(env,'UPDATE users SET status=? WHERE id=?',status,id),audit(env,user,'user.status.update','users',id,{status:target.status},{status,reason})]);return finish({message:'حُدّثت حالة المستخدم'});
    }
    if(resource==='worlds'&&request.method==='PATCH'&&id){
      const target=await q(env,'SELECT id,status FROM worlds WHERE id=?',id);if(!target)throw new AdminError('العالم غير موجود',404);
      const status=option(data.status,['active','suspended']);const reason=requiredText(data.reason,'سبب المراجعة',1000,3);
      await env.DB.batch([statement(env,'UPDATE worlds SET status=?,updated_at=? WHERE id=?',status,now(),id),audit(env,user,'world.moderation','worlds',id,{status:target.status},{status,reason})]);return finish({message:'حُفظت مراجعة العالم'});
    }
    if(resource==='challenges'&&request.method==='PATCH'&&id){
      const target=await q(env,'SELECT id,status,world_id FROM challenges WHERE id=?',id);if(!target)throw new AdminError('التحدي غير موجود',404);
      const status=option(data.status,['draft','published','paused']);const reason=requiredText(data.reason,'سبب الإجراء',1000,3);
      if(status==='published'){if(!(await count(env,'SELECT COUNT(*) AS count FROM challenge_stages WHERE challenge_id=?',id)))throw new AdminError('لا يمكن نشر تحدٍ دون مراحل');if((await q(env,'SELECT status FROM worlds WHERE id=?',target.world_id))?.status!=='active')throw new AdminError('العالم موقوف؛ لا يمكن نشر التحدي')}
      await env.DB.batch([statement(env,'UPDATE challenges SET status=?,updated_at=? WHERE id=?',status,now(),id),audit(env,user,'challenge.status.update','challenges',id,{status:target.status},{status,reason})]);return finish({message:'حُدّثت حالة التحدي'});
    }
    if(resource==='events'&&request.method==='PATCH'&&id){
      const target=await q(env,'SELECT id,status,stage FROM events WHERE id=?',id);if(!target)throw new AdminError('الفعالية غير موجودة',404);
      const status=option(data.status,['cancelled']);const reason=requiredText(data.reason,'سبب الإيقاف',1000,3);
      if(['won','lost','completed','failed','cancelled'].includes(target.status))throw new AdminError('انتهت هذه الفعالية بالفعل',409);
      await env.DB.batch([statement(env,"UPDATE events SET status='cancelled',revision=revision+1,updated_at=? WHERE id=? AND status IN ('active','scheduled')",now(),id),statement(env,'INSERT INTO event_logs(id,event_id,kind,payload,created_at) VALUES(?,?,?,?,?)',uid(),id,'admin_cancel',JSON.stringify({reason,actor:user.id}),now()),audit(env,user,'event.cancel','events',id,{status:target.status},{status,reason})]);return finish({message:'أُوقفت الفعالية وسُجّل سبب الإيقاف'});
    }
    if(resource==='rewards'&&((request.method==='POST'&&!id)||(request.method==='PATCH'&&id))){
      const name=requiredText(data.name,'اسم العنصر',120);const description=typeof data.description==='string'?data.description.trim().slice(0,1000):'';
      const kind=option(data.type||data.kind,['frame','name_color','background','badge','effect'],'نوع العنصر');const price=integer(data.price,'السعر');const image=imagePath(data.image);const enabled=data.active===true?1:0;
      if(id){const before=await q(env,'SELECT * FROM rewards WHERE id=?',id);if(!before)throw new AdminError('العنصر غير موجود',404);await env.DB.batch([statement(env,'UPDATE rewards SET name=?,description=?,kind=?,price=?,image=?,enabled=? WHERE id=?',name,description,kind,price,image,enabled,id),audit(env,user,'reward.update','rewards',id,before,{name,description,kind,price,image,enabled})]);return finish({message:'حُدّث عنصر المتجر'})}
      const rewardId=uid();await env.DB.batch([statement(env,'INSERT INTO rewards(id,name,description,kind,rarity,image,price,enabled,conditions,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',rewardId,name,description,kind,'common',image,price,enabled,'{}',now()),audit(env,user,'reward.create','rewards',rewardId,null,{name,description,kind,price,image,enabled})]);return finish({id:rewardId,message:'أُضيف عنصر المتجر'},201);
    }
    if(resource==='tickets'&&request.method==='PATCH'&&id){
      const target=await q(env,'SELECT * FROM support_tickets WHERE id=?',id);if(!target)throw new AdminError('التذكرة غير موجودة',404);
      const status=option(data.status,['open','pending','resolved','closed']);const message=data.message?requiredText(data.message,'الرد',4000):'';
      const tasks=[statement(env,'UPDATE support_tickets SET status=?,assigned_to=?,updated_at=? WHERE id=?',status,user.id,now(),id)];
      if(message){tasks.push(statement(env,'INSERT INTO ticket_replies(id,ticket_id,user_id,message,created_at) VALUES(?,?,?,?,?)',uid(),id,user.id,message,now()));tasks.push(statement(env,'INSERT INTO notifications(id,user_id,title,body,href,created_at) VALUES(?,?,?,?,?,?)',uid(),target.user_id,'رد جديد على تذكرة الدعم',message.slice(0,300),'/tickets',now()))}
      tasks.push(audit(env,user,'ticket.update','support_tickets',id,{status:target.status,assigned_to:target.assigned_to},{status,assigned_to:user.id,message}));await env.DB.batch(tasks);return finish({message:'حُفظت التذكرة'+(message?' وأُرسل الرد داخل التطبيق':'')});
    }
    if(resource==='notifications'&&request.method==='POST'&&!id){
      const title=requiredText(data.title,'عنوان الإشعار',120);const text=requiredText(data.body,'نص الإشعار',2000);const channel=option(data.channel||'app',['app','telegram'],'قناة الإرسال');
      const requestId=requiredText(data.requestId,'معرّف الطلب',100);if(!/^[a-f0-9-]{36}$/i.test(requestId))throw new AdminError('معرّف الطلب غير صالح');
      const existing=await q(env,"SELECT actor_id,after_data FROM audit_logs WHERE id=? AND action='notification.broadcast'",requestId);
      if(existing){if(existing.actor_id!==user.id)throw new AdminError('معرّف الطلب مستخدم',409);const previous=parse(existing.after_data);return finish({message:previous.status==='queued'?'الطلب مسجل وقيد المعالجة؛ راجع سجل الإرسال.':'الطلب مسجل سابقًا؛ لم يتكرر الإرسال.',...previous})}
      let recipients:any[];
      if(channel==='telegram'){
        if(!env.TELEGRAM_BOT_TOKEN&&!env.BOT_TOKEN)throw new AdminError('لم يُضبط توكن البوت بعد',409);
        const ids=typeof data.telegramIds==='string'?data.telegramIds.split(/[\s,،]+/).filter(Boolean):[];if(ids.length>20||ids.some((value:string)=>!/^\d{1,20}$/.test(value)))throw new AdminError('أدخل حتى 20 معرّف Telegram رقميًا');
        recipients=ids.length?await all(env,`SELECT id,telegram_id FROM users WHERE status='active' AND notify_allowed=1 AND telegram_id IN (${ids.map(()=>'?').join(',')}) ORDER BY last_seen DESC LIMIT 20`,...ids):await all(env,"SELECT id,telegram_id FROM users WHERE status='active' AND notify_allowed=1 AND telegram_id NOT LIKE 'owner:%' ORDER BY last_seen DESC LIMIT 20");
      }else recipients=await all(env,"SELECT id FROM users WHERE status='active'");
      if(!recipients.length)throw new AdminError(channel==='telegram'?'لا يوجد مستخدمون مؤهلون وافقوا على التواصل':'لا يوجد مستخدمون نشطون لإرسال الإشعار',409);
      if(recipients.length>5000)throw new AdminError('عدد المستلمين أكبر من حد الإرسال المباشر؛ استخدم تقسيم حملات الإرسال',409);
      const timestamp=now();const initial={title,body:text,channel,recipient_count:recipients.length,status:'queued'};
      try{await env.DB.batch([statement(env,'INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,after_data,created_at) VALUES(?,?,?,?,?,?,?)',requestId,user.id,'notification.broadcast','notifications',requestId,JSON.stringify(initial),timestamp)])}catch(error){const duplicate=await q(env,'SELECT after_data FROM audit_logs WHERE id=?',requestId);if(duplicate)return finish({message:'الطلب مسجل بالفعل؛ لم يتكرر الإرسال.',...parse(duplicate.after_data)});throw error}
      if(channel==='app'){
        for(let i=0;i<recipients.length;i+=80)await env.DB.batch(recipients.slice(i,i+80).map(target=>statement(env,'INSERT OR IGNORE INTO notifications(id,user_id,title,body,created_at) VALUES(?,?,?,?,?)',requestId+':'+target.id,target.id,title,text,timestamp)));
        const summary={...initial,status:'sent',sent:recipients.length,failed:0};await env.DB.batch([statement(env,'UPDATE audit_logs SET after_data=? WHERE id=?',JSON.stringify(summary),requestId)]);return finish({message:`أُرسل الإشعار داخل التطبيق إلى ${recipients.length} مستخدم`,...summary},201);
      }
      const delivery:any[]=[];
      // Twenty recipients per explicit action. A receipt is reserved before remote delivery so a retry cannot resubmit it.
      for(let offset=0;offset<recipients.length;offset+=5){
        const result=await Promise.all(recipients.slice(offset,offset+5).map(async target=>{
          const deliveryId=requestId+':'+target.id;await env.DB.batch([statement(env,'INSERT INTO audit_logs(id,actor_id,action,entity_type,entity_id,after_data,created_at) VALUES(?,?,?,?,?,?,?)',deliveryId,user.id,'notification.telegram.delivery','users',target.id,JSON.stringify({campaign:requestId,status:'queued'}),now())]);
          let status='failed';let code='network_error';
          try{const response=await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN||env.BOT_TOKEN}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:target.telegram_id,text:title+'\n\n'+text,disable_web_page_preview:true}),signal:AbortSignal.timeout(8000)});const responseData:any=await response.json();if(response.ok&&responseData.ok){status='sent';code='ok'}else code=String(responseData.error_code||response.status)}catch{/* Never log provider URLs or credentials. */}
          const receipt={userId:target.id,status,code};await env.DB.batch([statement(env,'UPDATE audit_logs SET after_data=? WHERE id=?',JSON.stringify({campaign:requestId,...receipt}),deliveryId)]);return receipt;
        }));delivery.push(...result);
      }
      const sent=delivery.filter(x=>x.status==='sent').length;const failed=delivery.length-sent;const summary={...initial,status:sent===0?'failed':failed?'partial':'sent',sent,failed,delivery};await env.DB.batch([statement(env,'UPDATE audit_logs SET after_data=? WHERE id=?',JSON.stringify(summary),requestId)]);return finish({message:`Telegram: نجح الإرسال إلى ${sent} مستخدم وتعذّر لدى ${failed}. الحد الأقصى 20 مستلمًا لكل إجراء.`,...summary},201);
    }
    throw new AdminError('هذا الإجراء غير متاح في هذا القسم',405);
  }catch(error:any){if(error instanceof AdminError)return json({ok:false,error:error.message},error.status);console.error('admin_api_error',{path:new URL(request.url).pathname,message:error?.message||'Unknown error'});return json({ok:false,error:'تعذّر إتمام العملية. حاول مرة أخرى.'},500)}
}
