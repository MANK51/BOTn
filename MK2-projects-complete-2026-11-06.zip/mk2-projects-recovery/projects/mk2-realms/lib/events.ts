import { q, all, grantRewardStatements } from './platform';

type Env = { DB: any };
type User = { id: string; status?: string; role?: string };
type Row = Record<string, any>;

class EventError extends Error {
  constructor(public status: number, message: string) { super(message); }
}
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {
  status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
});
const fail = (status: number, message: string): never => { throw new EventError(status, message); };
const id = () => crypto.randomUUID();
const count = (value: unknown, fallback: number, max: number) => {
  if (value === undefined) return fallback;
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 1 || n > max) fail(400, 'قيمة الهدف خارج النطاق المسموح.');
  return n;
};
const text = (value: unknown, max: number, fallback = '') => {
  if (value === undefined) return fallback;
  if (typeof value !== 'string' || value.trim().length > max) fail(400, 'النص غير صالح أو طويل جدًا.');
  return (value as string).trim();
};

/** Arabic answers are compared on the server; no answer is serialized into participant responses. */
export function normalizeEventAnswer(value: string): string {
  return value.normalize('NFKC').trim().toLocaleLowerCase('ar')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/\s+/g, ' ');
}

export const eventTemplates = [{
  id: 'black-vault', title: 'سر الخزنة السوداء',
  description: 'اكتشفوا الشيفرة، اختاروا البوابة، وأنجزوا تحديات عالمكم لفتح الخزنة.',
  image: '/assets/vault.webp',
  stages: ['اكتشاف الشيفرة', 'التصويت الجماعي', 'التحدي التعاوني', 'فتح الخزنة'],
  puzzlePrompt: 'ما عدد شهور السنة؟ اكتب الإجابة بالأرقام الإنجليزية.',
  defaults: { puzzleGoal: 1, voteGoal: 1, contributionGoal: 3, rewardXp: 100, rewardPoints: 40, durationHours: 24 },
  doors: [
    { id: 'blue', name: 'البوابة الزرقاء', description: 'الهدف والمكافأة الأساسية.' },
    { id: 'red', name: 'البوابة الحمراء', description: 'مساهمات أكثر بنسبة 25٪ ومكافأة XP أعلى بنسبة 25٪.' },
  ],
}];

/** Pure transition calculation; the database applies this with an optimistic revision guard. */
export function eventTransition(event: Row, stats: Row, now: number): Row | null {
  if (['completed', 'failed', 'cancelled'].includes(event.status)) return null;
  if (event.status === 'scheduled' && now < event.starts_at) return null;
  if (event.status === 'scheduled') {
    if (now >= event.ends_at) return { status: 'failed', stage: 'failed' };
    return { status: 'active', stage: 'puzzle' };
  }
  if (event.stage === 'cooperate' && stats.contributions >= event.effective_goal) {
    return { status: 'completed', stage: 'opened' };
  }
  if (now >= event.ends_at) return { status: 'failed', stage: 'failed' };
  if (event.stage === 'puzzle' && stats.solved >= event.puzzle_goal) return { stage: 'vote' };
  if (event.stage === 'vote' && stats.votes >= event.vote_goal) {
    const chosen_door = stats.red > stats.blue ? 'red' : 'blue';
    return {
      stage: 'cooperate', chosen_door,
      effective_goal: chosen_door === 'red' ? Math.ceil(event.contribution_goal * 1.25) : event.contribution_goal,
    };
  }
  return null;
}

async function eventStats(env: Env, eventId: string): Promise<Row> {
  return await q(env, `SELECT
    (SELECT COUNT(*) FROM event_participants WHERE event_id=? AND puzzle_solved=1) AS solved,
    (SELECT COUNT(*) FROM votes WHERE event_id=?) AS votes,
    (SELECT COUNT(*) FROM votes WHERE event_id=? AND option='blue') AS blue,
    (SELECT COUNT(*) FROM votes WHERE event_id=? AND option='red') AS red,
    (SELECT COUNT(*) FROM event_contributions WHERE event_id=?) AS contributions,
    (SELECT COUNT(*) FROM event_participants WHERE event_id=?) AS participants`,
  eventId, eventId, eventId, eventId, eventId, eventId) || {};
}

async function rawEvent(env: Env, eventId: string): Promise<Row | null> {
  return await q(env, `SELECT e.*,w.name AS world_name,w.visibility AS world_visibility,
    w.status AS world_status,w.owner_id AS world_owner FROM events e JOIN worlds w ON w.id=e.world_id WHERE e.id=?`, eventId);
}

async function access(env: Env, event: Row, user: User | null, memberRequired = false, staffRequired = false): Promise<Row | null> {
  if (event.world_status !== 'active') fail(404, 'الحدث غير متاح.');
  const member = user ? await q(env, `SELECT * FROM world_members WHERE world_id=? AND user_id=? AND status='active'`, event.world_id, user.id) : null;
  const owner = user?.id === event.world_owner;
  if (staffRequired && !(owner || ['owner', 'admin', 'moderator'].includes(member?.role))) fail(403, 'هذه العملية متاحة لإدارة العالم فقط.');
  if (memberRequired && !(owner || member)) fail(403, 'انضم إلى العالم أولًا للمشاركة في الحدث.');
  if (event.world_visibility === 'private' && !(owner || member)) fail(404, 'الحدث غير متاح.');
  return member;
}

async function awardParticipant(env: Env, event: Row, userId: string): Promise<'claimed' | 'limited' | 'ineligible'> {
  const participant = await q(env, `SELECT * FROM event_participants WHERE event_id=? AND user_id=? AND contributed=1`, event.id, userId);
  if (!participant || event.status !== 'completed') return 'ineligible';
  if (participant.reward_claimed) return 'claimed';
  const now = Date.now();
  const xp = event.chosen_door === 'red' ? Math.ceil(event.reward_xp * 1.25) : event.reward_xp;
  const statements = grantRewardStatements(env, userId, `event:${event.id}`, xp, event.reward_points,
    `فتح خزنة: ${event.title}`, event.world_id);
  // The ledger helper updates balances only for a newly inserted transaction id.
  // D1 batch is transactional, so ledger, cosmetic ownership and claim state commit together.
  await env.DB.batch([
    ...statements,
    env.DB.prepare(`INSERT OR IGNORE INTO rewards (id,name,description,kind,rarity,image,price,enabled,conditions,created_at)
      VALUES ('vault-pioneer','فاتح الخزنة','أكملت مساهمة موثوقة في خزنة جماعية ناجحة.','badge','rare','/assets/badge.svg',0,0,'{}',?)`).bind(now),
    env.DB.prepare(`INSERT OR IGNORE INTO inventory (id,user_id,reward_id,equipped,acquired_at,source)
      SELECT ?,?,'vault-pioneer',0,?,? WHERE EXISTS
      (SELECT 1 FROM xp_transactions WHERE user_id=? AND source_key=?)`).bind(id(), userId, now, `event:${event.id}`, userId, `event:${event.id}`),
    env.DB.prepare(`UPDATE event_participants SET reward_claimed=1 WHERE event_id=? AND user_id=?
      AND EXISTS (SELECT 1 FROM xp_transactions WHERE user_id=? AND source_key=?)`).bind(event.id, userId, userId, `event:${event.id}`),
  ]);
  const received = await q(env, `SELECT 1 FROM xp_transactions WHERE user_id=? AND source_key=?`, userId, `event:${event.id}`);
  return received ? 'claimed' : 'limited';
}

/** Real server progression. Concurrent readers cannot advance a revision twice. */
export async function refreshEvent(env: Env, eventId: string): Promise<Row | null> {
  for (let i = 0; i < 6; i++) {
    const event = await rawEvent(env, eventId);
    if (!event) return null;
    const stats = await eventStats(env, eventId);
    const transition = eventTransition(event, stats, Date.now());
    if (!transition) {
      if (event.status === 'completed') {
        // Bounded recovery for any interrupted request; eligibility and the ledger are idempotent.
        const pending = await all(env, `SELECT p.user_id FROM event_participants p JOIN users u ON u.id=p.user_id
          WHERE p.event_id=? AND p.contributed=1 AND p.reward_claimed=0 AND u.status='active' LIMIT 25`, eventId);
        for (const row of pending) await awardParticipant(env, event, row.user_id);
      }
      return { ...event, stats };
    }
    const now = Date.now();
    const fields = Object.keys(transition);
    const revision = event.revision + 1;
    const result = await env.DB.batch([
      env.DB.prepare(`UPDATE events SET ${fields.map(field => `${field}=?`).join(',')},revision=revision+1,updated_at=? WHERE id=? AND revision=?`)
        .bind(...fields.map(field => transition[field]), now, eventId, event.revision),
      env.DB.prepare(`INSERT INTO event_logs (id,event_id,kind,payload,created_at)
        SELECT ?,?,'phase',?,? WHERE changes()>0`).bind(id(), eventId, JSON.stringify({ ...transition, revision }), now),
    ]);
    if (!result[0]?.meta?.changes) continue;
  }
  const event = await rawEvent(env, eventId);
  return event ? { ...event, stats: await eventStats(env, eventId) } : null;
}

function publicEvent(event: Row): Row {
  return {
    id: event.id, worldId: event.world_id, worldName: event.world_name, title: event.title,
    description: event.description, image: '/assets/vault.webp', status: event.status, stage: event.stage,
    startsAt: event.starts_at, endsAt: event.ends_at, revision: event.revision,
    puzzlePrompt: event.puzzle_prompt, puzzleGoal: event.puzzle_goal, voteGoal: event.vote_goal,
    contributionGoal: event.contribution_goal, effectiveGoal: event.effective_goal,
    chosenDoor: event.chosen_door, rewardXp: event.chosen_door === 'red' ? Math.ceil(event.reward_xp * 1.25) : event.reward_xp,
    rewardPoints: event.reward_points, stats: event.stats, doors: eventTemplates[0].doors,
  };
}

export async function getEvents(env: Env, user: User | null, worldId?: string): Promise<Row[]> {
  const rows = await all(env, `SELECT e.id FROM events e JOIN worlds w ON w.id=e.world_id
    WHERE w.status='active' AND (w.visibility='public' OR EXISTS
      (SELECT 1 FROM world_members m WHERE m.world_id=w.id AND m.user_id=? AND m.status='active') OR w.owner_id=?)
    AND (? IS NULL OR e.world_id=?) ORDER BY e.starts_at DESC LIMIT 40`, user?.id || '', user?.id || '', worldId || null, worldId || null);
  const values: Row[] = [];
  for (const row of rows) {
    const event = await refreshEvent(env, row.id);
    if (event) values.push(publicEvent(event));
  }
  return values;
}

async function eventDetail(env: Env, event: Row, user: User | null): Promise<Row> {
  const participant = user ? await q(env, `SELECT puzzle_solved,puzzle_guesses,contributed,reward_claimed FROM event_participants WHERE event_id=? AND user_id=?`, event.id, user.id) : null;
  const ownVote = user ? await q(env, `SELECT option FROM votes WHERE event_id=? AND user_id=?`, event.id, user.id) : null;
  const logs = await all(env, `SELECT kind,payload,created_at FROM event_logs WHERE event_id=? ORDER BY created_at DESC LIMIT 20`, event.id);
  const contributors = await all(env, `SELECT u.name,u.avatar,c.created_at FROM event_contributions c JOIN users u ON u.id=c.user_id
    WHERE c.event_id=? ORDER BY c.created_at ASC LIMIT 20`, event.id);
  // Select only server-verified, unused challenge attempts. Clients never submit a score.
  const availableAttempts = user && event.stage === 'cooperate' ? await all(env, `SELECT a.id,c.title,a.completed_at FROM attempts a
    JOIN challenges c ON c.id=a.challenge_id WHERE a.user_id=? AND c.world_id=? AND a.status='completed'
    AND a.score>0 AND c.created_by<>a.user_id AND a.completed_at>=? AND a.completed_at<? AND NOT EXISTS
      (SELECT 1 FROM event_contributions x JOIN attempts used ON used.id=x.attempt_id
        WHERE x.attempt_id=a.id OR (x.user_id=a.user_id AND used.challenge_id=a.challenge_id)) ORDER BY a.completed_at DESC LIMIT 20`,
  user.id, event.world_id, event.starts_at, event.ends_at) : [];
  return {
    event: publicEvent(event), participant: participant ? {
      puzzleSolved: !!participant.puzzle_solved, puzzleGuesses: participant.puzzle_guesses,
      contributed: !!participant.contributed, rewardClaimed: !!participant.reward_claimed, vote: ownVote?.option || null,
    } : null,
    availableAttempts, contributors, logs: logs.map((log: Row) => ({ kind: log.kind, payload: JSON.parse(log.payload), at: log.created_at })),
    serverTime: Date.now(), pollIntervalMs: 8000,
  };
}

async function createEvent(env: Env, user: User, body: Row): Promise<Row> {
  const worldId = text(body.worldId, 100);
  const world = await q(env, `SELECT * FROM worlds WHERE id=?`, worldId);
  if (!world || world.status !== 'active') fail(404, 'العالم غير متاح.');
  await access(env, { world_id: worldId, world_visibility: world.visibility, world_status: world.status, world_owner: world.owner_id }, user, true, true);
  const existing = await q(env, `SELECT COUNT(*) AS total FROM events WHERE world_id=? AND status IN ('active','scheduled') AND ends_at>?`, worldId, Date.now());
  if (existing.total >= 5) fail(409, 'للعالم خمسة أحداث نشطة أو مجدولة بالفعل.');
  const now = Date.now();
  const template = body.templateId === 'black-vault';
  if (body.templateId && !template) fail(400, 'قالب الحدث غير معروف.');
  const title = text(body.title, 100, template ? 'سر الخزنة السوداء' : '');
  const description = text(body.description, 2000, template ? eventTemplates[0].description : '');
  const puzzlePrompt = text(body.puzzlePrompt, 1200, template ? eventTemplates[0].puzzlePrompt : '');
  const puzzleAnswer = text(body.puzzleAnswer, 120, template ? '12' : '');
  if (!title || !puzzlePrompt || !puzzleAnswer) fail(400, 'اسم الحدث ولغزه وإجابته مطلوبة.');
  const startsAt = body.startsAt === undefined ? now : Number(body.startsAt);
  const endsAt = body.endsAt === undefined ? startsAt + 24 * 60 * 60 * 1000 : Number(body.endsAt);
  if (!Number.isSafeInteger(startsAt) || !Number.isSafeInteger(endsAt) || startsAt < now - 60000 || startsAt > now + 90 * 86400000 || endsAt - startsAt < 300000 || endsAt - startsAt > 7 * 86400000) fail(400, 'موعد الحدث غير صالح. مدته بين 5 دقائق و7 أيام.');
  const puzzleGoal = count(body.puzzleGoal, 1, 1000);
  const voteGoal = count(body.voteGoal, 1, 1000);
  if (voteGoal > puzzleGoal) fail(400, 'عدد الأصوات المطلوبة لا يمكن أن يتجاوز عدد محلّي الشيفرة المطلوبة.');
  const goal = count(body.contributionGoal, 3, 1000);
  const xp = count(body.rewardXp, 100, 400);
  const points = count(body.rewardPoints, 40, 200);
  const eventId = id();
  await env.DB.batch([
    env.DB.prepare(`INSERT INTO events (id,world_id,creator_id,title,description,status,stage,starts_at,ends_at,revision,
      puzzle_prompt,puzzle_answer,puzzle_goal,vote_goal,contribution_goal,chosen_door,effective_goal,reward_xp,reward_points,created_at,updated_at)
      VALUES (?,?,?,?,?,?,'puzzle',?,?,0,?,?,?,?,?,NULL,?,?,?,?,?)`).bind(eventId, worldId, user.id, title, description,
      startsAt > now ? 'scheduled' : 'active', startsAt, endsAt, puzzlePrompt, normalizeEventAnswer(puzzleAnswer), puzzleGoal, voteGoal, goal, goal, xp, points, now, now),
    env.DB.prepare(`INSERT INTO event_logs (id,event_id,kind,payload,created_at) VALUES (?,?,'created',?,?)`).bind(id(), eventId, JSON.stringify({ startsAt, endsAt }), now),
    env.DB.prepare(`INSERT INTO audit_logs (id,actor_id,action,entity_type,entity_id,before_data,after_data,created_at)
      VALUES (?,?,'event.create','event',?,NULL,?,?)`).bind(id(), user.id, eventId, JSON.stringify({ worldId, title, startsAt, endsAt }), now),
  ]);
  return (await refreshEvent(env, eventId))!;
}

async function participate(env: Env, event: Row, user: User, action: string, body: Row): Promise<void> {
  const now = Date.now();
  if (event.status !== 'active' || event.starts_at > now || event.ends_at <= now) fail(409, 'الحدث غير نشط حاليًا.');
  const guard = `id=? AND revision=? AND status='active' AND stage=? AND starts_at<=? AND ends_at>?`;
  let statements: any[];
  if (action === 'puzzle') {
    if (event.stage !== 'puzzle') fail(409, 'مرحلة اكتشاف الشيفرة انتهت.');
    const answer = text(body.answer, 120);
    if (!answer) fail(400, 'اكتب إجابتك أولًا.');
    const correct = normalizeEventAnswer(answer) === event.puzzle_answer;
    statements = [
      env.DB.prepare(`INSERT OR IGNORE INTO event_participants (event_id,user_id,puzzle_solved,puzzle_guesses,contributed,reward_claimed,created_at)
        SELECT ?,?,0,0,0,0,? WHERE EXISTS (SELECT 1 FROM events WHERE ${guard})`).bind(event.id, user.id, now, event.id, event.revision, 'puzzle', now, now),
      env.DB.prepare(`UPDATE event_participants SET puzzle_guesses=puzzle_guesses+1,puzzle_solved=? WHERE event_id=? AND user_id=?
        AND puzzle_solved=0 AND puzzle_guesses<5 AND EXISTS (SELECT 1 FROM events WHERE ${guard})`).bind(correct ? 1 : 0, event.id, user.id, event.id, event.revision, 'puzzle', now, now),
      env.DB.prepare(`UPDATE events SET revision=revision+1,updated_at=? WHERE ${guard} AND changes()>0`).bind(now, event.id, event.revision, 'puzzle', now, now),
    ];
  } else if (action === 'vote') {
    if (event.stage !== 'vote') fail(409, 'التصويت غير متاح في هذه المرحلة.');
    const option = text(body.option, 10);
    if (!['blue', 'red'].includes(option)) fail(400, 'اختر إحدى البوابتين.');
    statements = [
      env.DB.prepare(`INSERT OR IGNORE INTO votes (event_id,user_id,option,created_at)
        SELECT ?,?,?,? WHERE EXISTS (SELECT 1 FROM events WHERE ${guard})
        AND EXISTS (SELECT 1 FROM event_participants WHERE event_id=? AND user_id=? AND puzzle_solved=1)`)
        .bind(event.id, user.id, option, now, event.id, event.revision, 'vote', now, now, event.id, user.id),
      env.DB.prepare(`UPDATE events SET revision=revision+1,updated_at=? WHERE ${guard} AND changes()>0`).bind(now, event.id, event.revision, 'vote', now, now),
    ];
  } else if (action === 'contribute') {
    if (event.stage !== 'cooperate') fail(409, 'التعاون غير متاح في هذه المرحلة.');
    const attemptId = text(body.attemptId, 100);
    if (!attemptId) fail(400, 'أكمل تحديًا في العالم ثم اختر نتيجته للمساهمة.');
    statements = [
      env.DB.prepare(`INSERT OR IGNORE INTO event_participants (event_id,user_id,puzzle_solved,puzzle_guesses,contributed,reward_claimed,created_at)
        SELECT ?,?,0,0,0,0,? WHERE EXISTS (SELECT 1 FROM events WHERE ${guard})`).bind(event.id, user.id, now, event.id, event.revision, 'cooperate', now, now),
      env.DB.prepare(`INSERT OR IGNORE INTO event_contributions (event_id,user_id,attempt_id,created_at)
        SELECT ?,?,?,? WHERE EXISTS (SELECT 1 FROM events WHERE ${guard}) AND EXISTS
        (SELECT 1 FROM attempts a JOIN challenges c ON c.id=a.challenge_id WHERE a.id=? AND a.user_id=?
          AND a.status='completed' AND a.score>0 AND c.created_by<>a.user_id AND c.world_id=? AND a.completed_at>=? AND a.completed_at<?)
        AND NOT EXISTS (SELECT 1 FROM event_contributions x JOIN attempts used ON used.id=x.attempt_id
          JOIN attempts candidate ON candidate.id=? WHERE x.attempt_id=candidate.id
          OR (x.user_id=candidate.user_id AND used.challenge_id=candidate.challenge_id))`)
        .bind(event.id, user.id, attemptId, now, event.id, event.revision, 'cooperate', now, now, attemptId, user.id, event.world_id, event.starts_at, event.ends_at, attemptId),
      env.DB.prepare(`UPDATE event_participants SET contributed=1 WHERE event_id=? AND user_id=? AND changes()>0`).bind(event.id, user.id),
      env.DB.prepare(`UPDATE events SET revision=revision+1,updated_at=? WHERE ${guard} AND changes()>0`).bind(now, event.id, event.revision, 'cooperate', now, now),
    ];
  } else fail(404, 'العملية غير موجودة.');
  const result = await env.DB.batch(statements!);
  if (!result[result.length - 1]?.meta?.changes) fail(409, action === 'contribute'
    ? 'المساهمة تحتاج نتيجة تحدٍّ ناجح في هذا العالم أثناء الحدث، لم تُستخدم سابقًا. يمكن المساهمة مرة واحدة.'
    : 'سبق تسجيل مشاركتك، أو وصلت لحد المحاولات، أو تغيرت مرحلة الحدث. حدّث الصفحة.');
}

export async function eventsApi(request: Request, env: Env, user: User | null): Promise<Response | null> {
  const url = new URL(request.url);
  if (!url.pathname.startsWith('/api/events')) return null;
  try {
    const path = url.pathname.replace(/\/$/, '');
    if (request.method === 'GET' && path === '/api/events/templates') return json({ ok: true, templates: eventTemplates });
    if (request.method === 'GET' && path === '/api/events') return json({ ok: true, events: await getEvents(env, user, url.searchParams.get('worldId') || undefined), serverTime: Date.now(), pollIntervalMs: 8000 });
    if (request.method !== 'GET' && !user) fail(401, 'افتح التطبيق عبر Telegram لتسجيل الدخول.');
    if (user?.status && user.status !== 'active') fail(403, 'حسابك مقيّد.');
    if (request.method !== 'GET' && !/\/(claim|cancel)$/.test(path)) {
      const setting = await q(env, `SELECT value FROM settings WHERE key='features.events'`);
      if (setting && ['false', '0'].includes(String(setting.value))) fail(503, 'الفعاليات متوقفة مؤقتًا من إدارة المنصة.');
    }
    let body: Row = {};
    if (request.method !== 'GET') {
      if (Number(request.headers.get('content-length') || '0') > 64000) fail(413, 'حجم الطلب أكبر من الحد المسموح.');
      try {
        const raw = await request.text();
        if (raw.length > 64000) fail(413, 'حجم الطلب أكبر من الحد المسموح.');
        body = raw ? JSON.parse(raw) : {};
      } catch (error) {
        if (error instanceof EventError) throw error;
        fail(400, 'أرسل بيانات JSON صحيحة.');
      }
      if (!body || Array.isArray(body) || typeof body !== 'object') fail(400, 'بيانات الطلب غير صالحة.');
    }
    if (request.method === 'POST' && path === '/api/events') {
      const event = await createEvent(env, user!, body);
      return json({ ok: true, ...(await eventDetail(env, event, user)) }, 201);
    }
    const match = path.match(/^\/api\/events\/([^/]+)(?:\/(puzzle|vote|contribute|claim|cancel))?$/);
    if (!match) return json({ ok: false, error: 'المسار غير موجود.' }, 404);
    let event = await rawEvent(env, match[1]);
    if (!event) fail(404, 'الحدث غير موجود.');
    await access(env, event!, user, request.method !== 'GET', match[2] === 'cancel');
    event = await refreshEvent(env, match[1]);
    if (!event) fail(404, 'الحدث غير موجود.');
    if (request.method === 'GET' && !match[2]) return json({ ok: true, ...(await eventDetail(env, event!, user)) });
    if (request.method !== 'POST' || !match[2]) return json({ ok: false, error: 'العملية غير مدعومة.' }, 405);
    if (match[2] === 'cancel') {
      if (!['active', 'scheduled'].includes(event!.status)) fail(409, 'لا يمكن إيقاف حدث منتهٍ.');
      const now = Date.now();
      const result = await env.DB.batch([
        env.DB.prepare(`UPDATE events SET status='cancelled',revision=revision+1,updated_at=? WHERE id=? AND revision=? AND status IN ('active','scheduled')`).bind(now, event!.id, event!.revision),
        env.DB.prepare(`INSERT INTO event_logs (id,event_id,kind,payload,created_at) SELECT ?,?,'cancelled','{}',? WHERE changes()>0`).bind(id(), event!.id, now),
        env.DB.prepare(`INSERT INTO audit_logs (id,actor_id,action,entity_type,entity_id,before_data,after_data,created_at)
          VALUES (?,?,'event.cancel','event',?,?,?,?)`).bind(id(), user!.id, event!.id, JSON.stringify({ status: event!.status }), JSON.stringify({ status: 'cancelled' }), now),
      ]);
      if (!result[0]?.meta?.changes) fail(409, 'تغيرت حالة الحدث. حدّث الصفحة.');
    } else if (match[2] === 'claim') {
      if (event!.status !== 'completed') fail(409, 'المكافأة متاحة بعد فتح الخزنة.');
      const reward = await awardParticipant(env, event!, user!.id);
      if (reward === 'ineligible') fail(403, 'المكافأة للمشاركين الذين أكملوا مساهمة موثوقة.');
      if (reward === 'limited') fail(429, 'بلغت الحد اليومي للمكافآت. أعد المحاولة بعد منتصف الليل بتوقيت UTC.');
    } else await participate(env, event!, user!, match[2], body);
    const refreshed = await refreshEvent(env, event!.id);
    return json({ ok: true, ...(await eventDetail(env, refreshed!, user)) });
  } catch (error) {
    if (error instanceof EventError) return json({ ok: false, error: error.message }, error.status);
    console.error('events.api', error instanceof Error ? error.message : 'unknown');
    return json({ ok: false, error: 'تعذر حفظ الحدث. حاول مرة أخرى.' }, 500);
  }
}
