export class ApiError extends Error { constructor(public status:number,message:string){super(message);} }
const encoder=new TextEncoder();
export async function hmac(key:Uint8Array|string,value:string){const bytes=typeof key==='string'?encoder.encode(key):new Uint8Array(key);const imported=await crypto.subtle.importKey('raw',bytes,{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',imported,encoder.encode(value)));}
export const hex=(value:Uint8Array)=>Array.from(value,v=>v.toString(16).padStart(2,'0')).join('');
export function constantEqual(a:string,b:string){if(a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0;}
export async function verifyTelegramInitData(raw:string,token:string,nowSeconds=Math.floor(Date.now()/1000)){
  if(!token||!raw||raw.length>16384)throw new ApiError(401,'افتح التطبيق من بوت Telegram لتسجيل الدخول.');
  const params=new URLSearchParams(raw);const keys=new Set<string>();for(const [key]of params){if(keys.has(key))throw new ApiError(401,'بيانات الدخول غير صالحة.');keys.add(key);}
  const hash=params.get('hash')||'';if(!/^[a-f0-9]{64}$/i.test(hash))throw new ApiError(401,'تعذّر التحقق من هوية Telegram.');
  const date=Number(params.get('auth_date'));if(!Number.isSafeInteger(date)||date>nowSeconds+30||nowSeconds-date>3600)throw new ApiError(401,'انتهت صلاحية الدخول. أغلق التطبيق وافتحه من Telegram.');
  const check=Array.from(params.entries()).filter(([key])=>key!=='hash').sort(([a],[b])=>a<b?-1:a>b?1:0).map(([key,value])=>`${key}=${value}`).join('\n');
  const secret=await hmac('WebAppData',token);const expected=hex(await hmac(secret,check));if(!constantEqual(expected,hash.toLowerCase()))throw new ApiError(401,'تعذّر التحقق من هوية Telegram.');
  let user:any;try{user=JSON.parse(params.get('user')||'null');}catch{throw new ApiError(401,'بيانات حساب Telegram غير صالحة.');}
  if(!user||!Number.isSafeInteger(user.id)||user.id<=0||typeof user.first_name!=='string')throw new ApiError(401,'بيانات حساب Telegram غير صالحة.');
  return {id:user.id,first_name:user.first_name.slice(0,100),last_name:typeof user.last_name==='string'?user.last_name.slice(0,100):undefined,username:typeof user.username==='string'?user.username.slice(0,64):undefined,photo_url:typeof user.photo_url==='string'&&user.photo_url.startsWith('https://')?user.photo_url:undefined,allows_write_to_pm:user.allows_write_to_pm===true};
}
export function json(value:any,status=200){return new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
export async function rateLimit(env:any,key:string,limit=80){
  const now=Date.now(),bucket=Math.floor(now/60000);
  const row:any=await env.DB.prepare('INSERT INTO rate_limits (key,bucket,hits,updated_at) VALUES (?, ?, 1, ?) ON CONFLICT(key) DO UPDATE SET hits=CASE WHEN bucket=excluded.bucket THEN hits+1 ELSE 1 END,bucket=excluded.bucket,updated_at=excluded.updated_at RETURNING hits').bind(key,bucket,now).first();
  if(row?.hits>limit)throw new ApiError(429,'طلبات كثيرة خلال وقت قصير. انتظر دقيقة ثم حاول مجددًا.');
  if(Math.random()<0.002)await env.DB.prepare('DELETE FROM rate_limits WHERE updated_at < ?').bind(now-86400000).run();
}
