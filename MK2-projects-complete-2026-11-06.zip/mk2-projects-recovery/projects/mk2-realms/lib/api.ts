import {platformApi,ensureUser,mapUser,bootstrapData,q,all,getProfile} from './platform';
import {eventsApi} from './events';
import {adminApi} from './admin';
import {botWebhook,flushEventAnnouncements} from './bot';
import {verifyTelegramInitData,ApiError,json,rateLimit,constantEqual} from './security';

async function grantConfiguredRole(env:any,user:any){
 const ids=String(env.ADMIN_TELEGRAM_IDS||'').split(',').map(v=>v.trim());
 if(ids.includes(user.telegramId)&&user.role!=='super_admin'){
  const now=Date.now();await env.DB.batch([
   env.DB.prepare("UPDATE users SET role='super_admin' WHERE id=?").bind(user.id),
   env.DB.prepare("INSERT INTO admin_roles (user_id,role,created_at) VALUES (?,'super_admin',?) ON CONFLICT(user_id) DO UPDATE SET role='super_admin'").bind(user.id,now),
   env.DB.prepare("INSERT INTO audit_logs (id,actor_id,action,entity_type,entity_id,after_data,created_at) VALUES (?,?,'admin.configured','users',?, ?,?)").bind(crypto.randomUUID(),user.id,user.id,JSON.stringify({role:'super_admin',source:'runtime_allowlist'}),now)
  ]);user.role='super_admin';
 }
 return user;
}
async function authenticate(request:Request,env:any){
 const auth=request.headers.get('authorization')||'';
 if(auth.startsWith('tma ')){const telegram=await verifyTelegramInitData(auth.slice(4),env.TELEGRAM_BOT_TOKEN);return grantConfiguredRole(env,await ensureUser(env,telegram));}
 const identity=request.headers.get('oai-authenticated-user-id'),email=request.headers.get('oai-authenticated-user-email');
 if(identity){
  // The hosting dispatcher validates and strips spoofed identity headers. Persist
  // the Site-scoped owner identity after the first verified owner email login.
  const existing:any=await q(env,"SELECT value FROM settings WHERE key='_owner_identity'");
  const pinned=existing?JSON.parse(existing.value):null;
  const isOwner=pinned?identity===pinned:(identity===env.ADMIN_OWNER_ID||Boolean(env.ADMIN_OWNER_EMAIL&&email?.toLowerCase()===String(env.ADMIN_OWNER_EMAIL).toLowerCase()));
  if(isOwner){
   if(!pinned)await env.DB.prepare("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES ('_owner_identity',?,?)").bind(JSON.stringify(identity),Date.now()).run();
   const current:any=await q(env,"SELECT value FROM settings WHERE key='_owner_identity'");if(JSON.parse(current.value)!==identity)throw new ApiError(403,'حساب الإدارة غير مخوّل.');
   const id='owner:'+identity;let name=request.headers.get('oai-authenticated-user-full-name')||'مالك المنصة';if(request.headers.get('oai-authenticated-user-full-name-encoding')==='percent-encoded-utf-8')try{name=decodeURIComponent(name);}catch{}
   const now=Date.now();await env.DB.batch([
    env.DB.prepare("INSERT INTO users(id,telegram_id,name,role,created_at,last_seen) VALUES (?,?,?,'super_admin',?,?) ON CONFLICT(id) DO UPDATE SET last_seen=excluded.last_seen").bind(id,id,name.slice(0,120),now,now),
    env.DB.prepare("INSERT INTO admin_roles(user_id,role,created_at) VALUES (?,'super_admin',?) ON CONFLICT(user_id) DO NOTHING").bind(id,now)
   ]);return mapUser(await q(env,'SELECT * FROM users WHERE id=?',id));
  }
 }
 return null;
}

async function installCatalog(request:Request,env:any){
 if(request.method!=='POST'||!env.INSTALL_SECRET||!constantEqual(request.headers.get('x-realm-install-secret')||'',env.INSTALL_SECRET))throw new ApiError(403,'غير مصرح.');
 if(await q(env,"SELECT 1 FROM settings WHERE key='_installed'"))return json({ok:true,alreadyInstalled:true});
 const now=Date.now();const catalog=[
  ['frame-purple','إطار البوابة البنفسجية','إطار متوهج لملفك الشخصي.','frame','rare','/assets/frame-purple.svg',150],
  ['frame-gold','إطار المجرة الذهبي','إطار ذهبي للملف الشخصي.','frame','legendary','/assets/frame-gold.svg',750],
  ['background-cosmic','خلفية العوالم الكونية','خلفية بوابة كونية لملفك الشخصي.','background','rare','/assets/portal.webp',300],
  ['background-castle','خلفية القلعة الغامضة','قلعة عائمة بين النجوم.','background','epic','/assets/castle.webp',400],
  ['name-violet','اسم بنفسجي مضيء','لون بنفسجي لاسمك في ملفك الشخصي.','name_color','common','/assets/logo.svg',100],
  ['badge-explorer','شارة المستكشف','شارة تجميلية تعبّر عن حبك للاستكشاف.','badge','common','/assets/badge-bronze.svg',200]
 ];
 const statements=catalog.map(([id,name,description,kind,rarity,image,price])=>env.DB.prepare('INSERT OR IGNORE INTO rewards(id,name,description,kind,rarity,image,price,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(id,name,description,kind,rarity,image,price,now));
 statements.push(env.DB.prepare("INSERT INTO settings(key,value,updated_at) VALUES ('_installed',?,?)").bind(JSON.stringify({version:1}),now));
 await env.DB.batch(statements);return json({ok:true,catalogItems:catalog.length});
}

const backupTables=['users','worlds','world_members','world_invites','world_posts','teams','team_members','team_invites','challenges','challenge_stages','attempts','events','event_participants','event_actions','votes','event_contributions','event_logs','rewards','inventory','xp_transactions','daily_claims','notifications','support_tickets','ticket_replies','admin_roles','audit_logs','settings','reports'];
async function backup(env:any,user:any){
 if(!user||user.role!=='super_admin')throw new ApiError(403,'النسخ الاحتياطي متاح للمدير الرئيسي فقط.');
 const records:any={};for(const table of backupTables){const count:any=await q(env,'SELECT COUNT(*) total FROM '+table);if(count.total>50000)throw new ApiError(413,'حجم البيانات كبير للتصدير المباشر. استخدم تصدير قاعدة البيانات في مزود الاستضافة.');records[table]=await all(env,'SELECT * FROM '+table);}
 await env.DB.prepare("INSERT INTO audit_logs(id,actor_id,action,entity_type,created_at) VALUES (?,?,'backup.export','database',?)").bind(crypto.randomUUID(),user.id,Date.now()).run();
 return new Response(JSON.stringify({format:'mk2-realms-backup-v1',version:1,createdAt:new Date().toISOString(),records}),{headers:{'Content-Type':'application/json','Content-Disposition':'attachment; filename="mk2-realms-backup.json"','Cache-Control':'no-store'}});
}

export async function handleApi(request:Request,env:any,ctx?:any):Promise<Response>{
 const url=new URL(request.url);const path=url.pathname;const started=Date.now();
 try{
  if(path==='/api/bot/webhook')return request.method==='POST'?await botWebhook(request,env):json({ok:false,error:'طريقة غير مسموحة.'},405);
  if(path==='/api/health'){const schema:any=await env.DB.prepare("SELECT COUNT(*) AS tables_ready FROM sqlite_master WHERE type='table' AND name IN ('users','worlds','challenges','events','xp_transactions')").first();if(schema?.tables_ready!==5)throw new ApiError(503,'قاعدة البيانات لم تكتمل تهيئتها.');return json({ok:true,service:'MK~2 REALMS',database:'ok',botConfigured:Boolean(env.TELEGRAM_BOT_TOKEN),version:'1.0.0',serverTime:Date.now()});}
  if(path==='/api/internal/install')return await installCatalog(request,env);
  if(!['GET','POST','PATCH','DELETE'].includes(request.method))return json({ok:false,error:'طريقة غير مسموحة.'},405);
  if(request.method!=='GET'){
   const origin=request.headers.get('origin');if(origin&&origin!==url.origin)throw new ApiError(403,'مصدر الطلب غير مصرح.');
   if(Number(request.headers.get('content-length')||0)>65536)throw new ApiError(413,'حجم الطلب أكبر من المسموح.');
   const length=(await request.clone().text()).length;if(length>65536)throw new ApiError(413,'حجم الطلب أكبر من المسموح.');
  }
  let user=await authenticate(request,env);
  if(path==='/api/auth'&&request.method==='POST'&&!user){let data:any;try{data=await request.json();}catch{throw new ApiError(400,'طلب غير صالح.');}if(!data||typeof data!=='object'||Array.isArray(data))throw new ApiError(400,'طلب غير صالح.');const telegram=await verifyTelegramInitData(data.initData,env.TELEGRAM_BOT_TOKEN);user=await grantConfiguredRole(env,await ensureUser(env,telegram));}
  const key=user?'user:'+user.id:'public:'+(request.headers.get('cf-connecting-ip')||'unknown');await rateLimit(env,key+(request.method==='GET'?':read':':write'),request.method==='GET'?180:60);
  if(user?.status==='banned')throw new ApiError(403,'الحساب موقوف. تواصل مع الدعم.');
  if(user?.status==='restricted'&&request.method!=='GET'&&!path.startsWith('/api/tickets'))throw new ApiError(403,'هذا الحساب مقيّد مؤقتًا.');
  if(path==='/api/auth')return json({ok:true,user,expiresIn:3600});
  const maintenance:any=await q(env,"SELECT value FROM settings WHERE key='maintenance.enabled'");if(maintenance&&maintenance.value==='true'&&!['super_admin','admin'].includes(user?.role)&&!path.startsWith('/api/tickets'))throw new ApiError(503,'المنصة تحت الصيانة. عد قريبًا.');
  if(path==='/api/bootstrap'&&request.method==='GET'){
   const data=await bootstrapData(env,user);const eventsResponse=await eventsApi(new Request(url.origin+'/api/events'),env,user);const eventData:any=eventsResponse?await eventsResponse.json():{};
   if(ctx?.waitUntil)ctx.waitUntil(flushEventAnnouncements(env));
   if(user)data.user=(await getProfile(env,user.id)).user;
   return json({ok:true,...data,events:eventData.events||[],config:{...data.config,botUsername:env.BOT_USERNAME,appUrl:env.APP_URL,brandName:'MK~2 REALMS',tagline:data.config['display.tagline']||'عالمك. قوانينك. مغامرتك.'}});
  }
  if(path==='/api/admin/backup'&&request.method==='GET')return backup(env,user);
  const response=await adminApi(request,env,user)||await eventsApi(request,env,user)||await platformApi(request,env,user);
  if(response){if(path.startsWith('/api/events')&&ctx?.waitUntil)ctx.waitUntil(flushEventAnnouncements(env));response.headers.set('Cache-Control','no-store');response.headers.set('X-Content-Type-Options','nosniff');return response;}
  return json({ok:false,error:'المسار المطلوب غير موجود.'},404);
 }catch(error:any){const known=Number.isInteger(error?.status)&&error.status>=400&&error.status<600;if(!known)console.error('api_error',{path,code:'internal',elapsedMs:Date.now()-started});return json({ok:false,error:known?error.message:'حدث خطأ في الخادم. حاول مرة أخرى.'},known?error.status:500);}
}
