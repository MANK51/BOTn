/* Durable D1 domain services. All progress and permissions are computed here. */
export type PlatformUser = { id: string; telegramId: string; name: string; username?: string; avatar?: string; xp: number; points: number; level: number; role: string; status: string };
type Env = { DB: any; [key: string]: any };
type Row = Record<string, any>;
export const q = async (env: Env, sql: string, ...bindings: any[]): Promise<any> => env.DB.prepare(sql).bind(...bindings).first();
export const all = async (env: Env, sql: string, ...bindings: any[]): Promise<any[]> => (await env.DB.prepare(sql).bind(...bindings).all()).results ?? [];
export const run = async (env: Env, sql: string, ...bindings: any[]): Promise<any> => env.DB.prepare(sql).bind(...bindings).run();
const stmt = (env: Env, sql: string, ...bindings: any[]) => env.DB.prepare(sql).bind(...bindings);
const uid = () => crypto.randomUUID();
const now = () => Date.now();
const parse = (value: any, fallback: any) => { try { return typeof value === 'string' ? JSON.parse(value) : value ?? fallback; } catch { return fallback; } };
const response = (data: any, status = 200) => Response.json({ ok: true, ...data }, { status });
class ApiError extends Error { constructor(public status: number, message: string) { super(message); } }
const fail = (status: number, message: string): never => { throw new ApiError(status, message); };
const clean = (value: any, max: number, required = false): string => { const s = typeof value === 'string' ? value.trim() : ''; if (s.length > max || (required && !s)) fail(400, `النص مطلوب ويجب ألا يتجاوز ${max} حرفًا.`); return s; };
const int = (v: any, min: number, max: number, defaultValue: number) => { if (v === undefined || v === null || v === '') return defaultValue; const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) fail(400, `القيمة يجب أن تكون عددًا بين ${min} و${max}.`); return n; };
const choice = (value: any, options: string[], defaultValue: string) => { const v = value ?? defaultValue; if (!options.includes(v)) fail(400, 'خيار غير صالح.'); return v; };
const image = (value: any, fallback: string) => { const v = clean(value, 500); if (!v) return fallback; if (!/^\/assets\/[a-zA-Z0-9_./-]+$/.test(v) && !/^https:\/\/[a-zA-Z0-9.-]+(?:\/[^\s]*)?$/.test(v)) fail(400, 'رابط الصورة غير صالح.'); return v; };
const requireUser = (user: PlatformUser | null, mutation = false): PlatformUser => { if (!user) fail(401, 'افتح التطبيق من تيليجرام لتسجيل الدخول.'); if (user.status === 'banned' || (mutation && user.status !== 'active')) fail(403, 'هذا الحساب مقيّد. تواصل مع الدعم.'); return user; };
const publicSettingKeys = ['platform_name','tagline','hero_title','hero_description','hero_image','maintenance','features','theme','support_text','display.hero_title','display.hero_text','display.hero_image','display.tagline','display.accent','maintenance.enabled','features.world_creation','features.store','features.events'];
async function setting(env: Env, key: string, fallback: any): Promise<any> { const row = await q(env, 'SELECT value FROM settings WHERE key=?', key); return row ? parse(row.value, fallback) : fallback; }
async function feature(env: Env, key: string) { if (await setting(env, `features.${key}`, true) === false) fail(503, 'هذه الميزة متوقفة مؤقتًا.'); }
async function body(request: Request): Promise<Row> { if (Number(request.headers.get('content-length') ?? '0') > 64_000) fail(413, 'الطلب كبير جدًا.'); try { const raw = await request.text(); if (raw.length > 64_000) fail(413, 'الطلب كبير جدًا.'); const value = raw ? JSON.parse(raw) : {}; if (!value || Array.isArray(value) || typeof value !== 'object') fail(400, 'بيانات غير صالحة.'); return value; } catch (error) { if (error instanceof ApiError) throw error; fail(400, 'تعذر قراءة البيانات.'); } }
export function mapUser(row: Row): PlatformUser { return { id: row.id, telegramId: row.telegram_id, name: row.name, username: row.username || undefined, avatar: row.avatar || undefined, xp: row.xp, points: row.points, level: row.level, role: row.role, status: row.status }; }

export async function ensureUser(env: Env, telegram: Row): Promise<PlatformUser> {
  const id = String(telegram.id); if (!/^\d{1,20}$/.test(id)) fail(400, 'حساب تيليجرام غير صالح.');
  const name = clean([telegram.first_name, telegram.last_name].filter(Boolean).join(' ').slice(0,120), 120) || 'مستكشف';
  const username = clean(telegram.username, 64) || null; const avatar = telegram.photo_url && /^https:\/\//.test(telegram.photo_url) ? String(telegram.photo_url).slice(0, 500) : null;
  await run(env, 'INSERT INTO users(id,telegram_id,name,username,avatar,created_at,last_seen) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,username=excluded.username,avatar=excluded.avatar,last_seen=excluded.last_seen', id, id, name, username, avatar, now(), now());
  return mapUser(await q(env, 'SELECT * FROM users WHERE id=?', id));
}

/** Append these statements to a D1 batch. Only a freshly inserted unique ledger id updates balances. */
export function grantRewardStatements(env: Env, userId: string, sourceKey: string, xp: number, points: number, reason: string, worldId: string | null = null, condition?: { sql: string; bindings?: any[] }): any[] {
  const transactionId = uid(); const timestamp = now(); const guard = condition ? ` AND (${condition.sql})` : ''; const bindings = condition?.bindings ?? [];
  const dayStart = Math.floor(timestamp / 86400000) * 86400000;
  const capGuard = sourceKey.startsWith('daily:') ? '' : ' AND (SELECT COALESCE(SUM(MAX(xp,0)),0) FROM xp_transactions WHERE user_id=? AND created_at>=?)+?<=3000 AND (SELECT COALESCE(SUM(MAX(points,0)),0) FROM xp_transactions WHERE user_id=? AND created_at>=?)+?<=1500';
  const capBindings = sourceKey.startsWith('daily:') ? [] : [userId, dayStart, xp, userId, dayStart, points];
  return [
    stmt(env, `INSERT OR IGNORE INTO xp_transactions(id,user_id,world_id,source_key,xp,points,reason,created_at) SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM users WHERE id=? AND status='active')${capGuard}${guard}`, transactionId, userId, worldId, sourceKey, xp, points, reason, timestamp, userId, ...capBindings, ...bindings),
    stmt(env, 'UPDATE users SET xp=xp+?,points=points+?,level=CAST((xp+?)/250 AS INTEGER)+1 WHERE id=? AND EXISTS(SELECT 1 FROM xp_transactions WHERE id=?)', xp, points, xp, userId, transactionId),
    stmt(env, 'UPDATE teams SET points=points+? WHERE id=(SELECT team_id FROM team_members WHERE user_id=? AND world_id=?) AND EXISTS(SELECT 1 FROM xp_transactions WHERE id=?)', Math.max(0, points), userId, worldId, transactionId),
  ];
}

export async function getProfile(env: Env, userId: string): Promise<Row> {
  const row = await q(env, 'SELECT * FROM users WHERE id=?', userId); if (!row) fail(404, 'الحساب غير موجود.');
  const [inventory, transactions, notifications] = await Promise.all([
    all(env, 'SELECT i.id,i.equipped,i.acquired_at,i.source,r.id reward_id,r.name,r.description,r.kind,r.rarity,r.image FROM inventory i JOIN rewards r ON r.id=i.reward_id WHERE i.user_id=? ORDER BY i.acquired_at DESC', userId),
    all(env, 'SELECT id,xp,points,reason,created_at,world_id FROM xp_transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 50', userId),
    all(env, 'SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50', userId),
  ]);
  return { user: { ...mapUser(row), streak: row.streak, lastDaily: row.last_daily, notifyAllowed: Boolean(row.notify_allowed) }, achievements: inventory.filter((r: Row) => r.kind === 'badge'), inventory, transactions, notifications };
}

export async function dailyClaim(env: Env, userId: string): Promise<Row> {
  const timestamp = now(); const day = new Date(timestamp).toISOString().slice(0, 10); const yesterday = new Date(timestamp - 86400000).toISOString().slice(0, 10);
  const user = await q(env, 'SELECT * FROM users WHERE id=?', userId); if (!user || user.status !== 'active') fail(403, 'الحساب غير مخوّل.');
  if (await q(env, 'SELECT 1 FROM daily_claims WHERE user_id=? AND day=?', userId, day)) fail(409, 'استلمت مكافأة اليوم بالفعل. عد غدًا!');
  const streak = user.last_daily === yesterday ? Math.min(user.streak + 1, 3650) : 1;
  const configuredXp = await setting(env, 'daily.xp', 25); const configuredPoints = await setting(env, 'daily.points', 20);
  const points = int(configuredPoints, 0, 200, 20) + Math.min(streak, 7) * 5; const xp = int(configuredXp, 0, 500, 25);
  const results = await env.DB.batch([
    stmt(env, 'INSERT OR IGNORE INTO daily_claims(user_id,day,streak,created_at) VALUES(?,?,?,?)', userId, day, streak, timestamp),
    ...grantRewardStatements(env, userId, `daily:${day}`, xp, points, 'المكافأة اليومية'),
    stmt(env, 'UPDATE users SET streak=?,last_daily=? WHERE id=? AND EXISTS(SELECT 1 FROM daily_claims WHERE user_id=? AND day=?)', streak, day, userId, userId, day),
  ]);
  if (!results[0].meta?.changes) fail(409, 'استلمت مكافأة اليوم بالفعل. عد غدًا!');
  return { points, xp, streak, user: mapUser(await q(env, 'SELECT * FROM users WHERE id=?', userId)) };
}

export async function getWorldAccess(env: Env, worldId: string, userId?: string | null): Promise<any> {
  const world = await q(env, `SELECT w.*,u.name owner_name,u.avatar owner_avatar,(SELECT COUNT(*) FROM world_members WHERE world_id=w.id AND status='active') member_count FROM worlds w JOIN users u ON u.id=w.owner_id WHERE w.id=?`, worldId);
  if (!world) fail(404, 'العالم غير موجود.');
  const membership = userId ? await q(env, 'SELECT * FROM world_members WHERE world_id=? AND user_id=?', worldId, userId) : null;
  return { ...world, role: membership?.status === 'active' ? membership.role : null, membership, isMember: membership?.status === 'active' };
}
const worldView = (w: Row): Row => ({ ...w, ownerId: w.owner_id, ownerName: w.owner_name, ownerAvatar: w.owner_avatar, joinMode: w.join_mode, memberCount: w.member_count ?? 0, isMember: Boolean(w.isMember ?? (w.member_status === 'active')), role: w.role ?? null, createdAt: w.created_at });
const requireWorldRead = (world: Row) => { if (world.status !== 'active') fail(404, 'العالم غير متاح.'); if (world.visibility === 'private' && !world.isMember) fail(403, 'هذا عالم خاص. تحتاج دعوة للانضمام.'); };
const requireEditor = (world: Row, admin = false) => { if (world.status !== 'active') fail(403, 'هذا العالم معلّق.'); if (!(admin ? ['owner', 'admin'] : ['owner', 'admin', 'moderator']).includes(world.role)) fail(403, 'لا تملك صلاحية إدارة هذا العالم.'); };
async function listWorlds(env: Env, userId?: string, mine = false, search = ''): Promise<Row[]> {
  return (await all(env, `SELECT w.*,u.name owner_name,u.avatar owner_avatar,m.role,m.status member_status,(SELECT COUNT(*) FROM world_members WHERE world_id=w.id AND status='active') member_count FROM worlds w JOIN users u ON u.id=w.owner_id LEFT JOIN world_members m ON m.world_id=w.id AND m.user_id=? WHERE w.status='active' AND ${mine ? "m.status='active'" : "(w.visibility='public' OR m.status='active')"} AND (w.name LIKE ? OR w.description LIKE ?) ORDER BY member_count DESC,w.created_at DESC LIMIT 100`, userId ?? '', `%${search}%`, `%${search}%`)).map(worldView);
}
function challengeView(c: Row): Row { return { ...c, worldId: c.world_id, worldName: c.world_name, xpReward: c.xp_reward, pointsReward: c.points_reward, attemptLimit: c.attempt_limit, timeLimit: c.time_limit, scheduledAt: c.scheduled_at, participantCount: c.participant_count ?? 0, stageCount: c.stage_count ?? 0 }; }
async function listTeams(env: Env, worldId: string, userId?: string): Promise<Row[]> { return (await all(env, 'SELECT t.*,m.role member_role,(SELECT COUNT(*) FROM team_members WHERE team_id=t.id) member_count FROM teams t LEFT JOIN team_members m ON m.team_id=t.id AND m.user_id=? WHERE t.world_id=? ORDER BY t.points DESC LIMIT 100', userId ?? '', worldId)).map(t => ({ ...t, worldId: t.world_id, leaderId: t.leader_id, memberCount: t.member_count, isMember: Boolean(t.member_role), role: t.member_role ?? null })); }
async function listChallenges(env: Env, userId?: string, worldId = '', mine = false): Promise<Row[]> {
  const timestamp=now(); await run(env, "UPDATE challenges SET status='published',updated_at=? WHERE status='scheduled' AND scheduled_at<=?",timestamp,timestamp);
  return (await all(env, `SELECT c.*,w.name world_name,w.image world_image,(SELECT COUNT(*) FROM challenge_stages WHERE challenge_id=c.id) stage_count,(SELECT COUNT(DISTINCT user_id) FROM attempts WHERE challenge_id=c.id) participant_count FROM challenges c JOIN worlds w ON w.id=c.world_id LEFT JOIN world_members m ON m.world_id=w.id AND m.user_id=? WHERE w.status='active' AND (w.visibility='public' OR m.status='active') AND (?='' OR w.id=?) AND ${mine ? 'c.created_by=?' : "(c.status='published' OR (c.status='scheduled' AND c.scheduled_at<=?) OR (m.status='active' AND m.role IN('owner','admin','moderator')))"} ORDER BY c.created_at DESC LIMIT 100`, userId ?? '', worldId, worldId, mine ? userId ?? '' : now())).map(challengeView);
}
function stageView(stage: Row, editor = false) { const view: Row = { id: stage.id, position: stage.position, kind: stage.kind, prompt: stage.prompt, options: parse(stage.options, []), seconds: stage.seconds, branch: parse(stage.branch, {}) }; if (editor) view.answer = stage.answer; return view; }
async function challengeAccess(env: Env, id: string, userId?: string): Promise<any> {
  const challenge = await q(env, 'SELECT c.*,w.name world_name,(SELECT COUNT(*) FROM challenge_stages WHERE challenge_id=c.id) stage_count,(SELECT COUNT(DISTINCT user_id) FROM attempts WHERE challenge_id=c.id) participant_count FROM challenges c JOIN worlds w ON w.id=c.world_id WHERE c.id=?', id); if (!challenge) fail(404, 'التحدي غير موجود.');
  if(challenge.status==='scheduled' && challenge.scheduled_at<=now()){challenge.status='published';await run(env,"UPDATE challenges SET status='published',updated_at=? WHERE id=? AND status='scheduled'",now(),id);}
  const world = await getWorldAccess(env, challenge.world_id, userId); requireWorldRead(world);
  const editor = ['owner', 'admin', 'moderator'].includes(world.role);
  const available = challenge.status === 'published' || (challenge.status === 'scheduled' && challenge.scheduled_at <= now());
  if (!available && !editor) fail(404, 'هذا التحدي لم يُنشر بعد.');
  return { challenge, world, editor, available };
}
function validateStages(value: any): Row[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 30) fail(400, 'أضف من مرحلة واحدة إلى 30 مرحلة.');
  return value.map((s, index) => {
    const kind = choice(s.kind, ['quiz', 'riddle', 'guess', 'image', 'team', 'poll', 'branch'], 'quiz');
    const options = Array.isArray(s.options) ? s.options.map((o: any) => clean(o, 300, true)) : [];
    if (options.length > 8 || new Set(options).size !== options.length) fail(400, 'الخيارات يجب أن تكون مختلفة وبحد أقصى 8.');
    const answer = clean(s.answer, 500, kind !== 'poll');
    if (['quiz', 'poll', 'branch'].includes(kind) && options.length < 2) fail(400, 'أضف خيارين على الأقل.');
    if (['quiz', 'branch'].includes(kind) && !options.includes(answer)) fail(400, 'الإجابة الصحيحة يجب أن تكون ضمن الخيارات.');
    const branch: Row = {}; if (s.branch && typeof s.branch === 'object') for (const [key, target] of Object.entries(s.branch)) { if (!options.includes(key) || !Number.isInteger(target) || Number(target) <= index || Number(target) >= value.length) fail(400, 'تفرّع المرحلة يجب أن يتجه إلى مرحلة لاحقة صحيحة.'); branch[key] = target; }
    return { kind, prompt: clean(s.prompt, 2000, true), options, answer, seconds: int(s.seconds, 5, 3600, 60), branch };
  });
}

export async function bootstrapData(env: Env, user: PlatformUser | null): Promise<Row> {
  const [worlds, challenges, shop, notifications, configRows, stats] = await Promise.all([
    listWorlds(env, user?.id), listChallenges(env, user?.id), all(env, 'SELECT * FROM rewards WHERE enabled=1 ORDER BY price,name'),
    user ? all(env, 'SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 20', user.id) : Promise.resolve([]),
    all(env, `SELECT key,value FROM settings WHERE key IN(${publicSettingKeys.map(() => '?').join(',')})`, ...publicSettingKeys),
    q(env, "SELECT (SELECT COUNT(*) FROM users WHERE status='active') users,(SELECT COUNT(*) FROM worlds WHERE status='active' AND visibility='public') worlds,(SELECT COUNT(*) FROM challenges c JOIN worlds w ON w.id=c.world_id WHERE c.status='published' AND w.status='active' AND w.visibility='public') challenges"),
  ]);
  return { user, worlds, challenges, shop, notifications, config: Object.fromEntries(configRows.map(r => [r.key, parse(r.value, r.value)])), stats, serverTime: now() };
}

export async function platformApi(request: Request, env: Env, providedUser: PlatformUser | null): Promise<Response | null> {
  const url = new URL(request.url); const path = url.pathname; const method = request.method; let user = providedUser;
  if (!path.startsWith('/api/') || path === '/api/auth' || path.startsWith('/api/admin') || path.startsWith('/api/bot') || path.startsWith('/api/events')) return null;
  try {
    if (user) { const row = await q(env, 'SELECT * FROM users WHERE id=?', user.id); user = row ? mapUser(row) : null; }
    if (!['GET','HEAD'].includes(method) && !path.startsWith('/api/tickets') && !['super_admin','admin'].includes(user?.role ?? '') && await setting(env, 'maintenance.enabled', false) === true) fail(503, 'المنصة تحت الصيانة حاليًا. حاول لاحقًا.');
    if (path === '/api/profile' && method === 'GET') return response(await getProfile(env, requireUser(user).id));
    if (path === '/api/profile' && method === 'PATCH') { const u = requireUser(user, true), b = await body(request); if (typeof b.notifyAllowed !== 'boolean') fail(400, 'إعداد الإشعارات غير صالح.'); await run(env, 'UPDATE users SET notify_allowed=? WHERE id=?', b.notifyAllowed ? 1 : 0, u.id); return response(await getProfile(env, u.id)); }
    if (path === '/api/daily' && method === 'POST') return response(await dailyClaim(env, requireUser(user, true).id));
    if (path === '/api/settings/public' && method === 'GET') { const rows = await all(env, `SELECT key,value FROM settings WHERE key IN(${publicSettingKeys.map(() => '?').join(',')})`, ...publicSettingKeys); return response({ settings: Object.fromEntries(rows.map(r => [r.key, parse(r.value, r.value)])) }); }
    if (path === '/api/worlds' && method === 'GET') { const mine = url.searchParams.get('mine') === '1'; if (mine) requireUser(user); return response({ worlds: await listWorlds(env, user?.id, mine, clean(url.searchParams.get('search'), 100)) }); }
    if (path === '/api/worlds' && method === 'POST') {
      const u = requireUser(user, true), b = await body(request); await feature(env, 'world_creation'); if ((await q(env, "SELECT COUNT(*) total FROM worlds WHERE owner_id=? AND status='active'", u.id)).total >= 20) fail(409, 'بلغت الحد الأقصى: 20 عالمًا.');
      const id = uid(), timestamp = now(); const color = /^#[0-9a-fA-F]{6}$/.test(b.color ?? '') ? b.color : '#7C3AED';
      await env.DB.batch([
        stmt(env, 'INSERT INTO worlds(id,owner_id,name,description,kind,visibility,rules,image,background,color,join_mode,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', id, u.id, clean(b.name, 80, true), clean(b.description, 2000), choice(b.kind, ['games','puzzles','community','competitions','adventures'], 'games'), choice(b.visibility, ['public','private'], 'public'), clean(b.rules, 3000), image(b.image, '/assets/castle.webp'), image(b.background ?? b.image, '/assets/castle.webp'), color, choice(b.joinMode, ['open','approval'], 'open'), timestamp, timestamp),
        stmt(env, "INSERT INTO world_members(world_id,user_id,role,status,joined_at) VALUES(?,?,'owner','active',?)", id, u.id, timestamp),
      ]); return response({ world: worldView(await getWorldAccess(env, id, u.id)) }, 201);
    }
    let match = path.match(/^\/api\/worlds\/([^/]+)(?:\/(join|leave|invite|posts))?$/);
    if (match) {
      const [, id, operation] = match; const world = await getWorldAccess(env, id, user?.id);
      if (!operation && method === 'GET') {
        if (world.visibility === 'private' && !world.isMember) { const token = url.searchParams.get('invite'); const invite = token && await q(env, 'SELECT 1 FROM world_invites WHERE token=? AND world_id=? AND expires_at>?', token, id, now()); if (!invite) fail(403, 'هذا عالم خاص. تحتاج دعوة للانضمام.'); return response({ world: worldView(world), members: [], challenges: [], teams: [], posts: [], invitePreview: true }); }
        requireWorldRead(world); const [members, challenges, teams, posts] = await Promise.all([world.isMember ? all(env, "SELECT u.id,u.name,u.username,u.avatar,u.level,(SELECT COALESCE(SUM(x.xp),0) FROM xp_transactions x WHERE x.user_id=u.id AND x.world_id=m.world_id) xp,m.role,m.status FROM world_members m JOIN users u ON u.id=m.user_id WHERE m.world_id=? AND (m.status='active' OR ? IN('owner','admin','moderator')) ORDER BY m.joined_at LIMIT 100", id, world.role ?? '') : Promise.resolve([]), listChallenges(env, user?.id, id), listTeams(env, id, user?.id), all(env, 'SELECT p.*,u.name author_name FROM world_posts p JOIN users u ON u.id=p.user_id WHERE p.world_id=? ORDER BY p.created_at DESC LIMIT 50', id)]);
        return response({ world: worldView(world), members, challenges, teams, posts });
      }
      const u = requireUser(user, true);
      if (!operation && method === 'PATCH') { requireEditor(world, true); const b = await body(request); const fields: Row = {}; for (const key of ['name','description','rules']) if (b[key] !== undefined) fields[key] = clean(b[key], key === 'name' ? 80 : 3000, key === 'name'); if (b.image !== undefined) fields.image = image(b.image, '/assets/castle.webp'); if (b.background !== undefined) fields.background = image(b.background, '/assets/castle.webp'); if (b.visibility !== undefined) fields.visibility = choice(b.visibility, ['public','private'], 'public'); if (b.joinMode !== undefined) fields.join_mode = choice(b.joinMode, ['open','approval'], 'open'); if (b.kind !== undefined) fields.kind = choice(b.kind, ['games','puzzles','community','competitions','adventures'], 'games'); if (b.color !== undefined) { if (!/^#[0-9a-fA-F]{6}$/.test(b.color)) fail(400, 'لون غير صالح.'); fields.color = b.color; } fields.updated_at = now(); await run(env, `UPDATE worlds SET ${Object.keys(fields).map(k => `${k}=?`).join(',')} WHERE id=?`, ...Object.values(fields), id); return response({ world: worldView(await getWorldAccess(env, id, u.id)) }); }
      if (operation === 'join' && method === 'POST') { if (world.status !== 'active') fail(403, 'هذا العالم غير متاح.'); if (world.membership) fail(409, world.isMember ? 'أنت عضو بالفعل.' : 'طلب انضمامك قيد المراجعة.'); const b = await body(request); if (world.visibility === 'private' && !await q(env, 'SELECT 1 FROM world_invites WHERE token=? AND world_id=? AND expires_at>?', b.invite ?? '', id, now())) fail(403, 'رابط الدعوة غير صالح أو انتهى.'); const status = world.join_mode === 'approval' ? 'pending' : 'active'; await run(env, "INSERT INTO world_members(world_id,user_id,role,status,joined_at) VALUES(?,?,'member',?,?)", id, u.id, status, now()); return response({ membership: { worldId: id, userId: u.id, role: 'member', status } }); }
      if (operation === 'leave' && method === 'POST') { if (world.owner_id === u.id) fail(409, 'مالك العالم لا يمكنه المغادرة.'); await env.DB.batch([stmt(env, 'DELETE FROM team_members WHERE world_id=? AND user_id=? AND role<>\'leader\'', id, u.id), stmt(env, 'DELETE FROM world_members WHERE world_id=? AND user_id=? AND NOT EXISTS(SELECT 1 FROM teams WHERE world_id=? AND leader_id=?)', id, u.id, id, u.id)]); if (await q(env, 'SELECT 1 FROM teams WHERE world_id=? AND leader_id=?', id, u.id)) fail(409, 'أنت قائد فريق. أدِر الفريق قبل المغادرة.'); return response({ left: true }); }
      if (operation === 'invite' && method === 'POST') { requireEditor(world); const token = uid().replaceAll('-', ''); const expiresAt = now() + 7 * 86400000; await run(env, 'INSERT INTO world_invites(token,world_id,created_by,expires_at,created_at) VALUES(?,?,?,?,?)', token, id, u.id, expiresAt, now()); return response({ invite: token, expiresAt, urlPath: `/?world=${id}&invite=${token}` }); }
      if (operation === 'posts' && method === 'POST') { requireEditor(world); const b = await body(request); const post = { id: uid(), world_id: id, user_id: u.id, title: clean(b.title, 160, true), body: clean(b.body, 5000, true), created_at: now() }; await run(env, 'INSERT INTO world_posts(id,world_id,user_id,title,body,created_at) VALUES(?,?,?,?,?,?)', ...Object.values(post)); return response({ post }, 201); }
    }
    match = path.match(/^\/api\/worlds\/([^/]+)\/members\/([^/]+)$/);
    if (match && method === 'PATCH') { const u = requireUser(user, true), [, worldId, targetId] = match; const world = await getWorldAccess(env, worldId, u.id); requireEditor(world); const target = await q(env, 'SELECT * FROM world_members WHERE world_id=? AND user_id=?', worldId, targetId); if (!target) fail(404, 'العضو غير موجود.'); if (target.role === 'owner' || target.user_id === u.id) fail(403, 'لا يمكن تغيير هذه العضوية.'); const b = await body(request); if (world.role !== 'owner' && target.role !== 'member') fail(403, 'لا يمكن تعديل مسؤول مساوٍ أو أعلى منك.'); if (b.status === 'removed') { await env.DB.batch([stmt(env, 'DELETE FROM team_members WHERE world_id=? AND user_id=? AND NOT EXISTS(SELECT 1 FROM teams WHERE world_id=? AND leader_id=?)', worldId, targetId, worldId, targetId), stmt(env, 'DELETE FROM world_members WHERE world_id=? AND user_id=? AND NOT EXISTS(SELECT 1 FROM teams WHERE world_id=? AND leader_id=?)', worldId, targetId, worldId, targetId)]); if (await q(env, 'SELECT 1 FROM teams WHERE world_id=? AND leader_id=?', worldId, targetId)) fail(409, 'العضو قائد فريق.'); } else { const role = choice(b.role, world.role === 'owner' ? ['admin','moderator','member'] : ['member'], target.role); const status = choice(b.status, ['active','pending'], target.status); await run(env, 'UPDATE world_members SET role=?,status=? WHERE world_id=? AND user_id=?', role, status, worldId, targetId); } return response({ updated: true }); }

    if (path === '/api/challenges' && method === 'GET') return response({ challenges: await listChallenges(env, user?.id, url.searchParams.get('worldId') ?? '', url.searchParams.get('mine') === '1') });
    if (path === '/api/challenges' && method === 'POST') {
      const u = requireUser(user, true), b = await body(request); const world = await getWorldAccess(env, clean(b.worldId, 80, true), u.id); requireEditor(world); const stages = validateStages(b.stages); const id = uid(), timestamp = now(); const status = choice(b.status, ['draft','published','scheduled'], 'draft'); const scheduled = status === 'scheduled' ? int(b.scheduledAt, timestamp + 1000, timestamp + 365 * 86400000, timestamp + 3600000) : null;
      await env.DB.batch([stmt(env, 'INSERT INTO challenges(id,world_id,created_by,title,description,type,difficulty,xp_reward,points_reward,attempt_limit,time_limit,status,scheduled_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)', id, world.id, u.id, clean(b.title, 160, true), clean(b.description, 2000), choice(b.type, ['quiz','riddle','guess','image','team','poll','branch'], 'quiz'), choice(b.difficulty, ['easy','normal','hard','legendary'], 'normal'), int(b.xpReward, 0, 500, 50), int(b.pointsReward, 0, 200, 20), int(b.attemptLimit, 1, 10, 3), int(b.timeLimit, 10, 86400, 300), status, scheduled, timestamp, timestamp), ...stages.map((s, position) => stmt(env, 'INSERT INTO challenge_stages(id,challenge_id,position,kind,prompt,options,answer,seconds,branch) VALUES(?,?,?,?,?,?,?,?,?)', uid(), id, position, s.kind, s.prompt, JSON.stringify(s.options), s.answer, s.seconds, JSON.stringify(s.branch)))]);
      return response({ challenge: challengeView(await q(env, 'SELECT * FROM challenges WHERE id=?', id)) }, 201);
    }
    match = path.match(/^\/api\/challenges\/([^/]+)(?:\/(start))?$/);
    if (match) {
      const [, id, operation] = match; const access = await challengeAccess(env, id, user?.id); const c = access.challenge; const stages = await all(env, 'SELECT * FROM challenge_stages WHERE challenge_id=? ORDER BY position', id);
      if (!operation && method === 'GET') { const attempt = user ? await q(env, 'SELECT * FROM attempts WHERE challenge_id=? AND user_id=? ORDER BY attempt_no DESC LIMIT 1', id, user.id) : null; return response({ challenge: { ...challengeView(c), stages: stages.map(s => stageView(s, access.editor)), canEdit: access.editor,hasAttempts:Boolean(await q(env,'SELECT 1 FROM attempts WHERE challenge_id=? LIMIT 1',id)) }, attempt }); }
      const u = requireUser(user, true);
      if (!operation && method === 'PATCH') {
        requireEditor(access.world); const b = await body(request); const started = await q(env, 'SELECT 1 FROM attempts WHERE challenge_id=? LIMIT 1', id); if (started && ['stages','xpReward','pointsReward','attemptLimit','timeLimit','type'].some(k => b[k] !== undefined)) fail(409, 'بعد بدء المشاركة يمكنك تعديل النص والحالة فقط.');
        const fields: Row = {}; for (const key of ['title','description']) if (b[key] !== undefined) fields[key] = clean(b[key], key === 'title' ? 160 : 2000, key === 'title'); if (b.type !== undefined) fields.type = choice(b.type, ['quiz','riddle','guess','image','team','poll','branch'], 'quiz'); if (b.difficulty !== undefined) fields.difficulty = choice(b.difficulty, ['easy','normal','hard','legendary'], 'normal'); if (b.status !== undefined) fields.status = choice(b.status, ['draft','published','scheduled','paused'], 'draft'); if (b.scheduledAt !== undefined) fields.scheduled_at = int(b.scheduledAt, now() + 1000, now() + 365 * 86400000, now() + 3600000); if ((fields.status ?? c.status) === 'scheduled' && !(fields.scheduled_at ?? c.scheduled_at)) fail(400, 'حدد وقت نشر التحدي.');
        for (const [input, column, max] of [['xpReward','xp_reward',500],['pointsReward','points_reward',200],['attemptLimit','attempt_limit',10],['timeLimit','time_limit',86400]] as const) if (b[input] !== undefined) fields[column] = int(b[input], input.includes('Reward') ? 0 : 1, max, c[column]); fields.updated_at = now();
        const structural = ['stages','xpReward','pointsReward','attemptLimit','timeLimit','type'].some(k => b[k] !== undefined);
        const edits = [stmt(env, `UPDATE challenges SET ${Object.keys(fields).map(k => `${k}=?`).join(',')} WHERE id=?${structural ? ' AND NOT EXISTS(SELECT 1 FROM attempts WHERE challenge_id=challenges.id)' : ''}`, ...Object.values(fields), id)]; if (b.stages !== undefined) { const newStages = validateStages(b.stages); edits.push(stmt(env, 'DELETE FROM challenge_stages WHERE challenge_id=? AND NOT EXISTS(SELECT 1 FROM attempts WHERE challenge_id=?)', id, id)); for (const [position, s] of newStages.entries()) edits.push(stmt(env, 'INSERT INTO challenge_stages(id,challenge_id,position,kind,prompt,options,answer,seconds,branch) SELECT ?,?,?,?,?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM attempts WHERE challenge_id=?)', uid(), id, position, s.kind, s.prompt, JSON.stringify(s.options), s.answer, s.seconds, JSON.stringify(s.branch), id)); } const changed = await env.DB.batch(edits); if (!changed[0].meta?.changes) fail(409, 'بدأ لاعب المشاركة أثناء التعديل. حدّث التحدي.'); return response({ challenge: challengeView(await q(env, 'SELECT * FROM challenges WHERE id=?', id)) });
      }
      if (!operation && method === 'DELETE') { requireEditor(access.world, true); const deleted = await run(env, 'DELETE FROM challenges WHERE id=? AND NOT EXISTS(SELECT 1 FROM attempts WHERE challenge_id=challenges.id)', id); if (!deleted.meta?.changes) fail(409, 'لا يمكن حذف تحدٍّ له نتائج. أوقفه بدلًا من ذلك.'); return response({ deleted: true }); }
      if (operation === 'start' && method === 'POST') {
        if (!access.available) fail(409, 'التحدي غير متاح للمشاركة الآن.'); if (!access.world.isMember) fail(403, 'انضم إلى العالم أولًا.'); if (!stages.length) fail(409, 'هذا التحدي لا يحتوي مراحل.');
        const timestamp = now(); let active = await q(env, "SELECT * FROM attempts WHERE challenge_id=? AND user_id=? AND status='active' ORDER BY attempt_no DESC LIMIT 1", id, u.id);
        if (active && (timestamp - active.started_at > c.time_limit * 1000 || timestamp - active.stage_started_at > (stages[active.stage_index]?.seconds ?? 0) * 1000)) { await run(env, "UPDATE attempts SET status='failed',completed_at=?,updated_at=?,version=version+1 WHERE id=? AND status='active'", timestamp, timestamp, active.id); active = null; }
        if (!active) { const count = (await q(env, 'SELECT COUNT(*) n FROM attempts WHERE challenge_id=? AND user_id=?', id, u.id)).n; if (count >= c.attempt_limit) fail(409, 'انتهت محاولاتك لهذا التحدي.'); const attemptId = uid(); await run(env, "INSERT OR IGNORE INTO attempts(id,challenge_id,user_id,attempt_no,status,started_at,stage_started_at,updated_at) SELECT ?,?,?,?,'active',?,?,? WHERE NOT EXISTS(SELECT 1 FROM attempts WHERE challenge_id=? AND user_id=? AND status='active') AND (SELECT COUNT(*) FROM attempts WHERE challenge_id=? AND user_id=?)<?", attemptId, id, u.id, count + 1, timestamp, timestamp, timestamp, id, u.id, id, u.id, c.attempt_limit); active = await q(env, "SELECT * FROM attempts WHERE challenge_id=? AND user_id=? AND status='active' ORDER BY attempt_no DESC LIMIT 1", id, u.id); }
        if (!active) fail(409, 'حدث تعارض في المحاولة. أعد المحاولة.'); return response({ attempt: active, stage: stageView(stages[active.stage_index]), serverTime: timestamp });
      }
    }
    match = path.match(/^\/api\/attempts\/([^/]+)\/answer$/);
    if (match && method === 'POST') {
      const u = requireUser(user, true), b = await body(request); const attempt = await q(env, 'SELECT * FROM attempts WHERE id=? AND user_id=?', match[1], u.id); if (!attempt) fail(404, 'المحاولة غير موجودة.'); if (attempt.status !== 'active') fail(409, 'هذه المحاولة انتهت بالفعل.');
      const access = await challengeAccess(env, attempt.challenge_id, u.id); if (!access.available || !access.world.isMember) fail(403, 'التحدي غير متاح أو عضويتك غير فعالة.'); const stages = await all(env, 'SELECT * FROM challenge_stages WHERE challenge_id=? ORDER BY position', attempt.challenge_id); const stage = stages[attempt.stage_index]; if (!stage) fail(409, 'حالة المرحلة غير صالحة.'); const timestamp = now();
      const expired = timestamp - attempt.started_at > access.challenge.time_limit * 1000 || timestamp - attempt.stage_started_at > stage.seconds * 1000; const answer = clean(b.answer, 500, true); const options = parse(stage.options, []); if (options.length && !options.includes(answer)) fail(400, 'الإجابة يجب أن تكون من الخيارات.');
      const normalize = (v: string) => v.trim().normalize('NFKC').toLocaleLowerCase().replace(/\s+/g, ' '); const correct = !expired && (stage.kind === 'poll' || normalize(answer) === normalize(stage.answer)); const branch = parse(stage.branch, {}); const next = Number.isInteger(branch[answer]) ? branch[answer] : attempt.stage_index + 1; const completed = correct && next >= stages.length; const status = !correct ? 'failed' : completed ? 'completed' : 'active';
      const answers = parse(attempt.answers, []); answers.push({ stage: attempt.stage_index, answer, correct, at: timestamp });
      const updates = [stmt(env, 'UPDATE attempts SET status=?,stage_index=?,score=score+?,answers=?,stage_started_at=?,completed_at=?,updated_at=?,version=version+1 WHERE id=? AND user_id=? AND status=\'active\' AND version=?', status, correct ? next : attempt.stage_index, correct ? 1 : 0, JSON.stringify(answers), timestamp, status === 'active' ? null : timestamp, timestamp, attempt.id, u.id, attempt.version)];
      if (completed && access.challenge.created_by !== u.id) updates.push(...grantRewardStatements(env, u.id, `challenge:${attempt.challenge_id}`, access.challenge.xp_reward, access.challenge.points_reward, `إكمال تحدي: ${access.challenge.title}`, access.world.id, { sql: "EXISTS(SELECT 1 FROM attempts WHERE id=? AND status='completed')", bindings: [attempt.id] }));
      const result = await env.DB.batch(updates); if (!result[0].meta?.changes) fail(409, 'تم تسجيل إجابة أخرى لهذه المرحلة. حدّث المحاولة.'); const updated = await q(env, 'SELECT * FROM attempts WHERE id=?', attempt.id);
      const earned = completed && access.challenge.created_by !== u.id && Boolean(result[1]?.meta?.changes);
      return response({ attempt: updated, stage: status === 'active' ? stageView(stages[next]) : null, correct, completed, expired, reward: { earned, xp: earned ? access.challenge.xp_reward : 0, points: earned ? access.challenge.points_reward : 0, reason: completed && !earned ? access.challenge.created_by === u.id ? 'المشاركة في تحديك معاينة دون نقاط.' : 'المكافأة استُلمت سابقًا أو بلغت حد المكافآت اليومي.' : null }, user: mapUser(await q(env, 'SELECT * FROM users WHERE id=?', u.id)), serverTime: timestamp });
    }

    if (path === '/api/store' && method === 'GET') return response({ items: await all(env, 'SELECT * FROM rewards WHERE enabled=1 ORDER BY price,name') });
    match = path.match(/^\/api\/store\/([^/]+)\/buy$/);
    if (match && method === 'POST') {
      const u = requireUser(user, true); await feature(env, 'store'); const item = await q(env, 'SELECT * FROM rewards WHERE id=? AND enabled=1', match[1]); if (!item) fail(404, 'العنصر غير متاح.'); if (await q(env, 'SELECT 1 FROM inventory WHERE user_id=? AND reward_id=?', u.id, item.id)) fail(409, 'هذا العنصر موجود في مقتنياتك.');
      const inventoryId = uid(), transactionId = uid(), timestamp = now();
      const result = await env.DB.batch([
        stmt(env, 'INSERT OR IGNORE INTO inventory(id,user_id,reward_id,acquired_at,source) SELECT ?,?,?,?,\'store\' WHERE EXISTS(SELECT 1 FROM users WHERE id=? AND points>=? AND status=\'active\') AND EXISTS(SELECT 1 FROM rewards WHERE id=? AND enabled=1 AND price=?)', inventoryId, u.id, item.id, timestamp, u.id, item.price, item.id, item.price),
        stmt(env, 'INSERT OR IGNORE INTO xp_transactions(id,user_id,source_key,xp,points,reason,created_at) SELECT ?,?,?,0,?,?,? WHERE EXISTS(SELECT 1 FROM inventory WHERE id=?)', transactionId, u.id, `store:${item.id}`, -item.price, `شراء: ${item.name}`, timestamp, inventoryId),
        stmt(env, 'UPDATE users SET points=points-? WHERE id=? AND EXISTS(SELECT 1 FROM xp_transactions WHERE id=?)', item.price, u.id, transactionId),
      ]); if (!result[0].meta?.changes) fail(409, 'النقاط غير كافية أو العنصر مملوك بالفعل.'); return response({ item, user: mapUser(await q(env, 'SELECT * FROM users WHERE id=?', u.id)) });
    }
    match = path.match(/^\/api\/inventory\/([^/]+)$/);
    if (match && method === 'PATCH') { const u = requireUser(user, true), b = await body(request); if (typeof b.equipped !== 'boolean') fail(400, 'إعداد العنصر غير صالح.'); const item = await q(env, 'SELECT i.*,r.kind FROM inventory i JOIN rewards r ON r.id=i.reward_id WHERE i.id=? AND i.user_id=?', match[1], u.id); if (!item) fail(404, 'العنصر غير موجود.'); await env.DB.batch([stmt(env, 'UPDATE inventory SET equipped=0 WHERE user_id=? AND reward_id IN(SELECT id FROM rewards WHERE kind=?) AND ?=1', u.id, item.kind, b.equipped ? 1 : 0), stmt(env, 'UPDATE inventory SET equipped=? WHERE id=? AND user_id=?', b.equipped ? 1 : 0, item.id, u.id)]); return response({ updated: true }); }
    if (path === '/api/leaderboard' && method === 'GET') {
      const worldId = url.searchParams.get('worldId') ?? ''; if (worldId) requireWorldRead(await getWorldAccess(env, worldId, user?.id)); const period = choice(url.searchParams.get('period'), ['all','week','month'], 'all'); const since = period === 'week' ? now() - 7 * 86400000 : period === 'month' ? now() - 30 * 86400000 : 0;
      const rows = worldId || period !== 'all' ? await all(env, `SELECT u.id,u.name,u.username,u.avatar,u.level,u.points,COALESCE(SUM(t.xp),0) xp FROM users u ${worldId ? "JOIN world_members m ON m.user_id=u.id AND m.world_id=? AND m.status='active'" : ''} LEFT JOIN xp_transactions t ON t.user_id=u.id AND t.created_at>=? ${worldId ? 'AND t.world_id=?' : ''} WHERE u.status='active' GROUP BY u.id ORDER BY xp DESC,u.id LIMIT 100`, ...(worldId ? [worldId] : []), since, ...(worldId ? [worldId] : [])) : await all(env, "SELECT id,name,username,avatar,xp,points,level FROM users WHERE status='active' ORDER BY xp DESC,id LIMIT 100"); return response({ users: rows.map((r, i) => ({ ...r, rank: i + 1 })), period });
    }

    if (path === '/api/teams' && method === 'GET') { const worldId = clean(url.searchParams.get('worldId'), 80, true); requireWorldRead(await getWorldAccess(env, worldId, user?.id)); return response({ teams: await listTeams(env, worldId, user?.id) }); }
    if (path === '/api/teams' && method === 'POST') { const u = requireUser(user, true), b = await body(request); const world = await getWorldAccess(env, clean(b.worldId, 80, true), u.id); requireWorldRead(world); if (!world.isMember) fail(403, 'انضم إلى العالم أولًا.'); if (await q(env, 'SELECT 1 FROM team_members WHERE world_id=? AND user_id=?', world.id, u.id)) fail(409, 'لديك فريق بالفعل في هذا العالم.'); const id = uid(), timestamp = now(); await env.DB.batch([stmt(env, 'INSERT INTO teams(id,world_id,leader_id,name,description,logo,created_at) VALUES(?,?,?,?,?,?,?)', id, world.id, u.id, clean(b.name, 80, true), clean(b.description, 1000), image(b.logo, '/assets/quest-team.svg'), timestamp), stmt(env, "INSERT INTO team_members(team_id,world_id,user_id,role,joined_at) VALUES(?,?,?,'leader',?)", id, world.id, u.id, timestamp)]); return response({ team: await q(env, 'SELECT * FROM teams WHERE id=?', id) }, 201); }
    match = path.match(/^\/api\/teams\/([^/]+)\/(join|leave)$/);
    if (match && method === 'POST') { const u = requireUser(user, true), team = await q(env, 'SELECT * FROM teams WHERE id=?', match[1]); if (!team) fail(404, 'الفريق غير موجود.'); const world = await getWorldAccess(env, team.world_id, u.id); requireWorldRead(world); if (!world.isMember) fail(403, 'انضم إلى العالم أولًا.'); if (match[2] === 'join') { if (await q(env, 'SELECT 1 FROM team_members WHERE world_id=? AND user_id=?', world.id, u.id)) fail(409, 'أنت عضو في فريق داخل هذا العالم.'); await run(env, "INSERT INTO team_members(team_id,world_id,user_id,role,joined_at) VALUES(?,?,?,'member',?)", team.id, world.id, u.id, now()); } else { if (team.leader_id === u.id) fail(409, 'قائد الفريق لا يستطيع المغادرة.'); await run(env, 'DELETE FROM team_members WHERE team_id=? AND user_id=?', team.id, u.id); } return response({ team }); }
    match = path.match(/^\/api\/teams\/([^/]+)\/members\/([^/]+)$/);
    if (match && method === 'PATCH') { const u = requireUser(user, true), team = await q(env, 'SELECT * FROM teams WHERE id=?', match[1]); if (!team || team.leader_id !== u.id) fail(403, 'قائد الفريق فقط يستطيع إدارة الأعضاء.'); if (match[2] === u.id) fail(403, 'لا يمكن تغيير القائد.'); const b = await body(request); if (b.remove) await run(env, 'DELETE FROM team_members WHERE team_id=? AND user_id=?', team.id, match[2]); else await run(env, 'UPDATE team_members SET role=? WHERE team_id=? AND user_id=?', choice(b.role, ['deputy','member'], 'member'), team.id, match[2]); return response({ updated: true }); }
    if (path === '/api/notifications' && method === 'GET') return response({ notifications: await all(env, 'SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100', requireUser(user).id) });
    match = path.match(/^\/api\/notifications\/([^/]+)\/read$/);
    if (match && method === 'POST') { const u = requireUser(user); await run(env, 'UPDATE notifications SET read_at=? WHERE id=? AND user_id=?', now(), match[1], u.id); return response({ updated: true }); }
    if (path === '/api/tickets' && method === 'GET') { const u = requireUser(user); const tickets = await all(env, 'SELECT * FROM support_tickets WHERE user_id=? ORDER BY updated_at DESC LIMIT 100', u.id); for (const ticket of tickets) ticket.replies = await all(env, 'SELECT r.*,u.name author_name,u.role author_role FROM ticket_replies r JOIN users u ON u.id=r.user_id WHERE ticket_id=? ORDER BY created_at', ticket.id); return response({ tickets }); }
    if (path === '/api/tickets' && method === 'POST') { const u = requireUser(user), b = await body(request); if ((await q(env, "SELECT COUNT(*) n FROM support_tickets WHERE user_id=? AND status='open'", u.id)).n >= 5) fail(409, 'لديك خمس تذاكر مفتوحة. تابع تذكرة موجودة.'); const id = uid(), timestamp = now(); await run(env, 'INSERT INTO support_tickets(id,user_id,subject,message,priority,created_at,updated_at) VALUES(?,?,?,?,?,?,?)', id, u.id, clean(b.subject, 160, true), clean(b.message, 5000, true), choice(b.priority, ['low','normal','high'], 'normal'), timestamp, timestamp); return response({ ticket: await q(env, 'SELECT * FROM support_tickets WHERE id=?', id) }, 201); }
    match = path.match(/^\/api\/tickets\/([^/]+)\/replies$/);
    if (match && method === 'POST') { const u = requireUser(user), ticket = await q(env, 'SELECT * FROM support_tickets WHERE id=? AND user_id=?', match[1], u.id); if (!ticket) fail(404, 'التذكرة غير موجودة.'); if (ticket.status === 'closed') fail(409, 'التذكرة مغلقة. افتح تذكرة جديدة.'); const b = await body(request), id = uid(), timestamp = now(); await env.DB.batch([stmt(env, 'INSERT INTO ticket_replies(id,ticket_id,user_id,message,created_at) VALUES(?,?,?,?,?)', id, ticket.id, u.id, clean(b.message, 5000, true), timestamp), stmt(env, 'UPDATE support_tickets SET updated_at=? WHERE id=?', timestamp, ticket.id)]); return response({ reply: await q(env, 'SELECT * FROM ticket_replies WHERE id=?', id) }); }
    if (path === '/api/reports' && method === 'POST') { const u = requireUser(user, true), b = await body(request); if (b.worldId) requireWorldRead(await getWorldAccess(env, b.worldId, u.id)); await run(env, 'INSERT INTO reports(id,user_id,world_id,reason,created_at) VALUES(?,?,?,?,?)', uid(), u.id, b.worldId ?? null, clean(b.reason, 2000, true), now()); return response({ reported: true }, 201); }
    return null;
  } catch (error: any) {
    if (error instanceof ApiError) return Response.json({ ok: false, error: error.message }, { status: error.status });
    if (String(error?.message ?? '').includes('UNIQUE constraint')) return Response.json({ ok: false, error: 'هذا الاسم أو الإجراء موجود بالفعل.' }, { status: 409 });
    console.error('platform request failed', { path, message: error?.message });
    return Response.json({ ok: false, error: 'تعذّر إتمام العملية. أعد المحاولة لاحقًا.' }, { status: 500 });
  }
}
