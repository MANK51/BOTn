import RealmsApp from "./RealmsApp";export default function Page(){return <RealmsApp/>;}
