import type { ReactNode } from "react";

export const metadata = {
  title: "MK~2 REALMS — عالمك. قوانينك. مغامرتك.",
  description: "منصة عوالم وتحديات وفعاليات تفاعلية داخل Telegram.",
};

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
        <meta name="theme-color" content="#08080F" />
        <link rel="icon" href="/assets/logo.svg" type="image/svg+xml" />
        <script src="https://telegram.org/js/telegram-web-app.js" />
      </head>
      <body style={{ margin: 0, background: "#08080F", color: "#F5F3FF" }}>{children}</body>
    </html>
  );
}
