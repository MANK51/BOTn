# MK~2 Canva source

Created in the user's connected Canva account on 2026-10-25.

- Editable five-page layout design: `DAHY-6mxdr4`, title «لوحة تصميم موقع شخصي MK~2».
- Canva design link: https://canva.link/adnao01ldul0uru
- Design page dimensions: 1920×1080. Returned page-preview files are only 600×337; they are previews, not full-resolution design exports.
- `page-1.png` through `page-5.png` are unedited Canva page previews. `contact.jpg` is a research contact sheet.
- Visual source: black metallic spiral/ridged shell, lime reflections, left image/right Arabic text, progressively revealed M, three project rows, underwater social scene, final glass orb.
- Generated design has minor Arabic text defects. The rebuilt site should retain the user's correct text and real project screenshots rather than copying incorrect letters or synthetic project thumbnails.

## Generated Canva images

1. Atmospheric background media `MAHY-98A-_Y`: [Open generated image](https://www.canva.com/M/MAHY-98A-_Y?utm_source=OC-AaBlKrqBJJNF&utm_campaign=agent_connector_create_image_asset_opened)
2. Black shell/lime M media `MAHY-x9n6BE`: [Open generated image](https://www.canva.com/M/MAHY-x9n6BE?utm_source=OC-AaBlKrqBJJNF&utm_campaign=agent_connector_create_image_asset_opened)

Canva tools provide 199×112 inline preview images and 200px media thumbnails. The thumbnail download URL returned403; files were saved from the returned inline image blocks. No original-resolution image download or design-export tool is available. Saved WEBP previews:

- `public/assets/canva-atmosphere.webp`
- `public/assets/canva-identity.webp`

These should only serve as subtle small/background previews, not enlarged primary hero imagery. Main movement is independently implemented with live3D geometry in the site.

All five page thumbnails were shown in chat as required by Canva. An inspection-only editing transaction was cancelled without changes; original completed design remains saved.
