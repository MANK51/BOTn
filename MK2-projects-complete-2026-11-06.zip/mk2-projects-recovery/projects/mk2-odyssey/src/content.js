// Edit text, projects, and social accounts here. Add accounts only with real URLs.
export const content = {
 about: 'أهتم بصناعة المواقع والتجارب الرقمية والمشاريع الإبداعية. أبدأ بفكرة، وأمنحها شكلًا وتجربة تستحق الاكتشاف.',
 projects: [
  {name:'تحدي اليوم',kind:'تجربة تفاعلية',description:'مسابقات ثقافية تختبر معرفتك، وتفتح باب التحدي.',url:'https://games.mk2space.cfd',image:'/assets/games-preview.webp',alt:'الواجهة الفعلية لموقع تحدي اليوم'},
  {name:'مراجعات القدرات',kind:'منصة تعليمية',description:'مراجعات ومصادر للكمي واللفظي، في مكان واحد.',url:'https://qudrat.mk2space.cfd',image:'/assets/qudrat-preview.webp',alt:'الواجهة الفعلية لمنصة مراجعات القدرات'},
  {name:'MK2 MOVIE',kind:'تجربة سينمائية',description:'مساحة لتصفّح الأفلام والمسلسلات واستكشافها.',url:'https://movie.mk2space.cfd',image:'/assets/movie-preview.webp',alt:'الواجهة الفعلية لموقع MK2 MOVIE'}
 ],
 accounts: [
  {name:'Instagram',handle:'@mllia51',url:'https://www.instagram.com/mllia51',icon:'instagram'},
  {name:'TikTok',handle:'@4ikv',url:'https://www.tiktok.com/@4ikv',icon:'tiktok'}
 ]
};
