import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
const smooth=(a,b,p)=>{const v=clamp((p-a)/(b-a));return v*v*(3-2*v)};
const mix=THREE.MathUtils.lerp;

// A modeled scallop, not a stock mesh: both skins share a ribbed polar surface.
function shellGeometry(inner=false,lower=false){
 const A=112,R=42,positions=[],uvs=[],indices=[];
 for(let j=0;j<=R;j++)for(let i=0;i<=A;i++){
  const v=j/R,theta=(i/A-.5)*Math.PI*1.13;
  const radius=2.20*(.87+.13*Math.cos(theta));
  const scallop=1+.026*Math.cos(theta*21);
  const r=v*radius*scallop;
  const rib=Math.cos(theta*21)*.052*Math.sin(Math.PI*v)*Math.pow(v,.4);
  let y=.53*Math.sin(Math.PI*v*.86)*( .72+.28*Math.cos(theta))+rib;
  if(inner)y-=.055;
  if(lower)y=-y;
  positions.push(r*Math.sin(theta),y,r*Math.cos(theta));uvs.push(i/A,v);
 }
 for(let j=0;j<R;j++)for(let i=0;i<A;i++){
  const a=j*(A+1)+i,b=a+A+1;
  indices.push(a,b,a+1,b,b+1,a+1);
 }
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));g.setIndex(indices);g.computeVertexNormals();return g;
}
function line(points,material){return new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),material)}
function shellRibs(group,lower=false){
 const material=new THREE.LineBasicMaterial({color:0x94bd42,transparent:true,opacity:.38});
 for(let k=-10;k<=10;k++){
  const theta=k*Math.PI/21,points=[];
  for(let j=1;j<=48;j++){
   const v=j/48,r=v*2.20*(.87+.13*Math.cos(theta))*(1+.026*Math.cos(theta*21));
   const rib=Math.cos(theta*21)*.052*Math.sin(Math.PI*v)*Math.pow(v,.4);
   let y=.53*Math.sin(Math.PI*v*.86)*(.72+.28*Math.cos(theta))+rib+.008;
   if(lower)y=-y;
   points.push(new THREE.Vector3(r*Math.sin(theta),y,r*Math.cos(theta)));
  }
  group.add(line(points,material));
 }
 const rim=[];for(let i=0;i<=160;i++){
  const theta=(i/160-.5)*Math.PI*1.13,r=2.20*(.87+.13*Math.cos(theta))*(1+.026*Math.cos(theta*21));
  let y=.53*Math.sin(Math.PI*.86)*(.72+.28*Math.cos(theta));if(lower)y=-y;
  rim.push(new THREE.Vector3(r*Math.sin(theta),y,r*Math.cos(theta)));
 }
 const rimMesh=new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(rim),160,.012,5,false),new THREE.MeshStandardMaterial({color:0xc7ff3d,metalness:.75,roughness:.22,emissive:0x2d3f02,emissiveIntensity:.8}));group.add(rimMesh);
}
function makeM(){
 const s=new THREE.Shape();
 s.moveTo(-.8,-.65);s.lineTo(-.8,.65);s.lineTo(-.45,.65);s.lineTo(0,-.02);s.lineTo(.45,.65);s.lineTo(.8,.65);s.lineTo(.8,-.65);s.lineTo(.42,-.65);s.lineTo(.42,.02);s.lineTo(.12,-.43);s.lineTo(-.12,-.43);s.lineTo(-.42,.02);s.lineTo(-.42,-.65);s.closePath();
 const g=new THREE.ExtrudeGeometry(s,{depth:.23,bevelEnabled:true,bevelThickness:.035,bevelSize:.035,bevelSegments:3,steps:1,curveSegments:8});g.translate(0,0,-.115);return g;
}

export async function createScene(canvas,{onReady}={}){
 const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance'});
 renderer.setClearColor(0x080a07,0);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
 const scene=new THREE.Scene();scene.fog=new THREE.FogExp2(0x080a07,.035);
 const camera=new THREE.PerspectiveCamera(36,1,.1,100);
 const envGen=new THREE.PMREMGenerator(renderer);const room=new RoomEnvironment();const env=envGen.fromScene(room,.06);scene.environment=env.texture;scene.environmentIntensity=.7;room.dispose();envGen.dispose();
 const world=new THREE.Group();scene.add(world);
 const ambient=new THREE.HemisphereLight(0xf4f7ee,0x111b08,1.5);scene.add(ambient);
 const key=new THREE.DirectionalLight(0xf4f7ee,3.4);key.position.set(-3,7,4);scene.add(key);
 const lime=new THREE.PointLight(0xc7ff3d,35,14,2);lime.position.set(-3,3,-1);scene.add(lime);
 const rimLight=new THREE.DirectionalLight(0xc7ff3d,3);rimLight.position.set(4,2,-4);scene.add(rimLight);
 const spot=new THREE.PointLight(0xf4f7ee,13,12,2);spot.position.set(2,1,4);scene.add(spot);
 const shell=new THREE.Group();world.add(shell);shell.position.set(0,0,-.8);
 const outer=new THREE.MeshPhysicalMaterial({color:0x11180d,metalness:.78,roughness:.33,clearcoat:1,clearcoatRoughness:.22,side:THREE.DoubleSide});
 const inner=new THREE.MeshPhysicalMaterial({color:0x23331a,metalness:.62,roughness:.33,clearcoat:1,side:THREE.DoubleSide});
 const lid=new THREE.Group(),base=new THREE.Group();shell.add(lid,base);lid.position.y=.04;base.position.y=-.025;
 lid.add(new THREE.Mesh(shellGeometry(false,false),outer),new THREE.Mesh(shellGeometry(true,false),inner));
 base.add(new THREE.Mesh(shellGeometry(false,true),outer),new THREE.Mesh(shellGeometry(true,true),inner));shellRibs(lid);shellRibs(base,true);
 const hinge=new THREE.Mesh(new THREE.CapsuleGeometry(.13,.5,4,12),outer);hinge.rotation.z=Math.PI/2;hinge.position.y=.03;shell.add(hinge);
 const emblem=new THREE.Group();world.add(emblem);
 const m=new THREE.Mesh(makeM(),new THREE.MeshPhysicalMaterial({color:0xc7ff3d,metalness:.63,roughness:.17,emissive:0x446c00,emissiveIntensity:.5,clearcoat:1,clearcoatRoughness:.12}));emblem.add(m);
 const inset=new THREE.Mesh(makeM(),new THREE.MeshStandardMaterial({color:0x659807,metalness:.48,roughness:.24,envMapIntensity:.6}));inset.scale.set(.88,.88,.25);inset.position.z=.125;emblem.add(inset);
 // Transparent optical chamber material appears only in the last two chapters.
 const chamber=new THREE.Group();world.add(chamber);
 const orb=new THREE.Mesh(new THREE.SphereGeometry(1.35,52,36),new THREE.MeshPhysicalMaterial({color:0xbddea7,metalness:0,roughness:.035,transmission:.92,thickness:.42,ior:1.4,envMapIntensity:1.8,transparent:true,opacity:.60,clearcoat:1,side:THREE.FrontSide,depthWrite:false}));chamber.add(orb);
 const orbitMat=new THREE.MeshPhysicalMaterial({color:0xc7ff3d,metalness:.8,roughness:.22,emissive:0x4c6a09,emissiveIntensity:.8,transparent:true,opacity:.85});
 const orbitA=new THREE.Mesh(new THREE.TorusGeometry(1.5,.008,5,160),orbitMat);orbitA.rotation.set(.5,.5,.1);chamber.add(orbitA);
 const orbitB=new THREE.Mesh(new THREE.TorusGeometry(1.64,.006,5,160),orbitMat);orbitB.rotation.set(1.5,-.8,.4);chamber.add(orbitB);
 const halo=new THREE.Mesh(new THREE.TorusGeometry(1.36,.014,6,160),new THREE.MeshBasicMaterial({color:0xc7ff3d,transparent:true,opacity:.38}));chamber.add(halo);
 // Fine deterministic particles: scroll is the only source of movement.
 const partPos=[],partBase=[];for(let i=0;i<100;i++){
  const x=Math.sin(i*127.1)*5,z=Math.cos(i*74.7)*4,y=((Math.sin(i*34.13)+1)/2)*5-1;partPos.push(x,y,z);partBase.push(x,y,z);
 }
 const pg=new THREE.BufferGeometry();pg.setAttribute('position',new THREE.Float32BufferAttribute(partPos,3));const particles=new THREE.Points(pg,new THREE.PointsMaterial({size:.018,color:0xc7ff3d,transparent:true,opacity:.45,sizeAttenuation:true,depthWrite:false}));world.add(particles);
 // A broad, subdued mirror surface with concentric wave geometry.
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(60,60),new THREE.MeshStandardMaterial({color:0x0d1409,metalness:.88,roughness:.25,transparent:true,opacity:.9}));floor.rotation.x=-Math.PI/2;floor.position.y=-.62;floor.material.side=THREE.DoubleSide;floor.material.depthWrite=false;world.add(floor);
 const waterMat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,side:THREE.DoubleSide,uniforms:{uProgress:{value:0},uOpacity:{value:0}},vertexShader:`varying vec3 vWorld;uniform float uProgress;void main(){vec3 p=position;float a=sin(p.x*1.1+p.y*.7+uProgress*3.0)*.045+sin(p.y*1.8-p.x*.8+uProgress*2.)*.025;p.z+=a;vec4 w=modelMatrix*vec4(p,1.);vWorld=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}`,fragmentShader:`varying vec3 vWorld;uniform float uProgress;uniform float uOpacity;void main(){float a=sin(vWorld.x*2.3+sin(vWorld.z*1.7)+uProgress*7.);float b=sin(vWorld.z*3.1+sin(vWorld.x*1.4)-uProgress*3.);float lines=pow(max(0.,1.-abs(a+b)*.6),12.);float fade=exp(-length(vWorld.xz)*.07);gl_FragColor=vec4(mix(vec3(.035,.065,.018),vec3(.55,.72,.19),lines*.35),uOpacity*fade*(.3+lines*.7));}`});
 const water=new THREE.Mesh(new THREE.PlaneGeometry(45,45,50,50),waterMat);water.rotation.x=-Math.PI/2;water.position.y=-.59;world.add(water);
 const shafts=new THREE.Group();world.add(shafts);shafts.position.set(0,-1,-3);const shaftMat=new THREE.MeshBasicMaterial({color:0xc7ff3d,transparent:true,opacity:.035,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending});
 for(let i=0;i<8;i++){const geo=new THREE.ConeGeometry(.13+i*.035,7,4,1,true);const ray=new THREE.Mesh(geo,shaftMat);ray.position.set((i-3.5)*.6,0,Math.sin(i)*1.2);ray.rotation.z=.24;shafts.add(ray);}
 const waves=new THREE.Group();world.add(waves);waves.position.y=-.60;
 const waveMat=new THREE.MeshBasicMaterial({color:0x89aa47,transparent:true,opacity:.085});
 for(let i=0;i<12;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(2.3+i*.57,.006,4,180),waveMat);ring.rotation.x=-Math.PI/2;ring.scale.y=.75;waves.add(ring);}
 // A diffuse circular ground light avoids a flat black void without a texture download.
 const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=128;const cx=glowCanvas.getContext('2d');const grad=cx.createRadialGradient(64,64,0,64,64,64);grad.addColorStop(0,'rgba(199,255,61,.32)');grad.addColorStop(.35,'rgba(125,165,44,.12)');grad.addColorStop(1,'rgba(8,10,7,0)');cx.fillStyle=grad;cx.fillRect(0,0,128,128);const glowTex=new THREE.CanvasTexture(glowCanvas);const glow=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex,color:0xc7ff3d,transparent:true,opacity:.6,depthWrite:false}));glow.scale.set(9,9,1);glow.position.set(0,-.5,-2);world.add(glow);
 let width=0,height=0,mobile=false,current=0;
 function resize(){width=canvas.clientWidth||innerWidth;height=canvas.clientHeight||innerHeight;mobile=width<760;renderer.setSize(width,height,false);renderer.setPixelRatio(Math.min(devicePixelRatio||1,mobile?1.6:2));camera.aspect=width/height;camera.fov=mobile?41:36;camera.updateProjectionMatrix();update(current);}
 function update(progress){
  current=clamp(progress);const p=current;
  const opening=smooth(.015,.23,p),emerge=smooth(.23,.43,p),horizon=smooth(.43,.65,p),dive=smooth(.65,.80,p),arrival=smooth(.8,1,p);
  lid.rotation.x=-opening*1.93;
  shell.rotation.y=mix(.06,-.12,emerge);shell.rotation.z=.025*Math.sin(p*Math.PI*2);shell.scale.setScalar(mix(1,.94,emerge));
  shell.position.y=dive*.65; shell.position.z=-.8-dive*1.7;
  shell.visible=p<.91;
  emblem.position.set(.02,mix(.09,.95,emerge)-dive*2.4,mix(.28,.8,emerge)+dive*.9);
  emblem.rotation.set(mix(-Math.PI/2,0,horizon),mix(-.07,.26,dive)+arrival*.28,mix(0,-.08,emerge));
  emblem.scale.setScalar(mix(.66,1.04,emerge)*mix(1,1.14,dive));
  chamber.position.copy(emblem.position);chamber.visible=p>.72;chamber.scale.setScalar(Math.max(.001,smooth(.72,.88,p)));
  orb.material.opacity=.60*smooth(.72,.88,p);orbitA.rotation.z=.1+p*.9;orbitB.rotation.z=.4-p*.7;halo.rotation.set(0,.15,0);
  const angle=mix(.14,1.30,horizon);const distance=mix(mobile?15.8:10.6,mobile?18:8.5,emerge)-dive*(mobile?1.8:1.5);
  const targetY=mix(0,.7,emerge)-dive*2.1;
  camera.position.set(.08,mix(Math.cos(angle)*distance+mix(0,.7,emerge),-1.85,dive),Math.sin(angle)*distance+.15+dive*.4);
  camera.lookAt(0,targetY,.1+dive*1.0);
  // Lens shift places the whole scene beside copy, and above the mobile copy.
  camera.setViewOffset(width,height,mobile?0:width*.225,mobile?height*.24:height*.025,width,height);
  floor.position.y=-.62;floor.material.opacity=mix(.78,.06,dive);floor.visible=p<.88;waves.position.y=floor.position.y+.02;waves.visible=p<.88;water.visible=p>.60&&p<.94;waterMat.uniforms.uProgress.value=p;waterMat.uniforms.uOpacity.value=smooth(.60,.72,p)*(1-smooth(.84,.94,p))*.8;shafts.visible=p>.68;shaftMat.opacity=.022*smooth(.68,.82,p);
  particles.rotation.y=p*.13;particles.position.y=-p*.4;particles.material.opacity=mix(.20,.52,dive);
  glow.position.y=mix(-.5,.7,dive);glow.position.z=mix(-2,-1,dive);glow.material.opacity=mix(.4,.64,dive);
  lime.intensity=mix(35,52,dive);rimLight.intensity=mix(3,4.5,dive);renderer.toneMappingExposure=mix(1.12,1.0,dive);
  scene.fog.density=mix(.035,.05,dive);
  renderer.render(scene,camera);
 }
 resize();onReady?.();
 return {update,resize,dispose(){scene.traverse(o=>{o.geometry?.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose())});env.dispose();glowTex.dispose();renderer.dispose()}};
}
