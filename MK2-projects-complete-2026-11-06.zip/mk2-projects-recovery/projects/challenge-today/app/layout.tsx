import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "تحدي اليوم | منصة المسابقات الثقافية",
  description: "اختبر معلوماتك في تحدٍ ثقافي عربي من 50 سؤالًا، واحصل على شهادة إنجاز عند الإجابة الصحيحة عن 25 سؤالًا على الأقل.",
  icons: { icon: "/favicon.png" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
