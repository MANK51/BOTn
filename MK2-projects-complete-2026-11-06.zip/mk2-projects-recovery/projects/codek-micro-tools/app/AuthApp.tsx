"use client";

import { FormEvent, useEffect, useState } from "react";

type User = { id: string; username: string };

type AuthMode = "login" | "register";

export default function AuthApp() {
  const [user, setUser] = useState<User | null>(null);
  const [mode, setMode] = useState<AuthMode>("login");
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) return null;
        return (await response.json()) as { user: User | null };
      })
      .then((data) => setUser(data?.user ?? null))
      .catch(() => setUser(null))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetch("/api/visit", { method: "POST" }).catch(() => undefined);
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const form = new FormData(event.currentTarget);
    const username = String(form.get("username") ?? "");
    const password = String(form.get("password") ?? "");
    if (!username.trim() || Array.from(username).length > 100) {
      setError("اكتب اسم مستخدم من حرف واحد إلى 100 حرف.");
      return;
    }
    if (password.length < 8 || password.length > 128) {
      setError("كلمة المرور يجب أن تكون بين 8 و128 حرفًا.");
      return;
    }
    setWorking(true);
    try {
      const response = await fetch(`${window.location.origin}/api/auth/${mode === "login" ? "login" : "register"}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ username, password }),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok) throw new Error(data?.error || "تعذر إكمال الطلب. حاول تحديث الصفحة ثم أعد المحاولة.");
      if (!data?.user) throw new Error("تعذر قراءة نتيجة التسجيل. أعد تحديث الصفحة.");
      setUser(data.user);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "حدث خطأ. حاول مرة أخرى.");
    } finally {
      setWorking(false);
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setUser(null);
    setMode("login");
  }

  if (loading) return <main className="loading-screen" aria-label="جارٍ التحميل"><div className="loader" /></main>;

  if (user) {
    return (
      <main className="app-shell" dir="rtl">
        <header className="app-header">
          <div className="brand-lockup"><span className="brand-mark">MK</span><span>MK~2</span></div>
          <div className="account-row"><span>أهلًا، {user.username}</span><button className="quiet-button" onClick={logout}>تسجيل الخروج</button></div>
        </header>
        <iframe className="generator-frame" src="/generator.html" title="أداة كودك لتوليد المشاريع" />
      </main>
    );
  }

  return (
    <main className="auth-screen" dir="rtl">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="auth-header"><div className="brand-lockup"><span className="brand-mark">MK</span><span>MK~2</span></div><span className="header-tag">مساحة تصميم وبرمجة</span></header>
      <section className="auth-layout">
        <div className="auth-copy">
          <p className="eyebrow">مساحة إبداعك البرمجي</p>
          <h1>تصميم وبرمجة <span>MK~2</span></h1>
          <p className="lead">حوّل فكرتك إلى مشروع صغير، وابدأ من أول سطر كود.</p>
          <div className="auth-card">
            <div className="mode-tabs" role="tablist" aria-label="نوع الدخول">
              <button className={mode === "login" ? "mode-tab active" : "mode-tab"} onClick={() => { setMode("login"); setError(""); }}>تسجيل الدخول</button>
              <button className={mode === "register" ? "mode-tab active" : "mode-tab"} onClick={() => { setMode("register"); setError(""); }}>إنشاء حساب</button>
            </div>
            <form onSubmit={submit} className="auth-form" noValidate>
              <label>اسم المستخدم<input name="username" type="text" autoComplete="username" required placeholder="اكتب اسم المستخدم بأي أحرف أو رموز" /></label>
              <label>كلمة المرور<input name="password" type="password" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={8} required placeholder="٨ أحرف على الأقل" /></label>
              {error && <p className="form-error" role="alert">{error}</p>}
              <button className="submit-button" type="submit" disabled={working}>{working ? "لحظة..." : mode === "login" ? "دخول إلى حسابك" : "إنشاء الحساب"}</button>
            </form>
            <p className="privacy-note">نحفظ اسم المستخدم وعدد زياراتك لعرض إحصاءات الموقع في لوحة الإدارة. لا نعرض كلمات المرور.</p>
          </div>
        </div>
        <div className="visual-panel" aria-hidden="true"><div className="code-window"><div className="window-top"><i/><i/><i/><span>MK~2 / workspace</span></div><div className="code-art"><p><b>01</b> <em>const</em> idea = <strong>"مشروعك"</strong>;</p><p><b>02</b> <em>function</em> <i>build</i>() &#123;</p><p><b>03</b>　 <span>turn</span>(idea, <strong>code</strong>);</p><p><b>04</b> &#125;</p><div className="cursor-line">⌁</div></div><div className="window-status"><span>بيئة العمل جاهزة</span><span className="live-dot" /></div></div><div className="orb-label">ابدأ بفكرتك التالية</div></div>
      </section>
      <footer className="auth-footer">© 2026 MK~2 · تصميم وبرمجة</footer>
    </main>
  );
}
