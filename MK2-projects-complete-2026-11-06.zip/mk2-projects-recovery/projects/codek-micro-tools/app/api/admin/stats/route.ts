import { appEnv, isAdminSession } from "@/lib/auth";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  if (!(await isAdminSession(request))) return Response.json({ error: "يلزم تسجيل دخول الإدارة." }, { status: 401 });
  const db = appEnv().DB;
  const summary = await db.prepare("SELECT (SELECT COUNT(*) FROM users) AS registered_users, COALESCE((SELECT total_visits FROM site_stats WHERE id = 1), 0) AS total_visits").first<{ registered_users: number; total_visits: number }>();
  const list = await db.prepare("SELECT username, visits, created_at, last_seen FROM users ORDER BY last_seen DESC").all<{ username: string; visits: number; created_at: number; last_seen: number }>();
  return Response.json({ summary: summary ?? { registered_users: 0, total_visits: 0 }, users: list.results ?? [] }, { headers: { "cache-control": "no-store" } });
}
