import { adminCookie, appEnv, clearFailedAttempts, createSignedToken, isRateLimited, rateLimitKey, recordFailedAttempt, sameOrigin } from "@/lib/auth";

export const dynamic = "force-dynamic";
function same(a: string, b: string) { let diff = a.length ^ b.length; const n = Math.max(a.length, b.length); for (let i = 0; i < n; i++) diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0); return diff === 0; }

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "تعذر التحقق من الطلب." }, { status: 403 });
  const key = await rateLimitKey(request, "admin");
  if (await isRateLimited(key)) return Response.json({ error: "محاولات كثيرة. انتظر 15 دقيقة ثم حاول." }, { status: 429 });
  let body: { username?: string; password?: string };
  try { body = await request.json(); } catch { return Response.json({ error: "البيانات غير مكتملة." }, { status: 400 }); }
  const config = appEnv();
  const submittedUsername = (body.username ?? "").trim().toLowerCase();
  if (!same(submittedUsername, config.ADMIN_USERNAME.toLowerCase()) || !same(body.password ?? "", config.ADMIN_PASSWORD)) {
    await recordFailedAttempt(key);
    return Response.json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." }, { status: 401 });
  }
  await clearFailedAttempts(key);
  const token = await createSignedToken("admin", "MK2", Math.floor(Date.now() / 1000) + 8 * 60 * 60);
  return Response.json({ ok: true }, { headers: { "set-cookie": adminCookie(token), "cache-control": "no-store" } });
}
