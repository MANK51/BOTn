import { appEnv, getAccountUser, sameOrigin } from "@/lib/auth";
export const dynamic = "force-dynamic";
export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "تعذر التحقق من الطلب." }, { status: 403 });
  const db = appEnv().DB;
  await db.prepare("INSERT INTO site_stats (id, total_visits) VALUES (1, 1) ON CONFLICT(id) DO UPDATE SET total_visits = total_visits + 1").run();
  const user = await getAccountUser(request);
  if (user) await db.prepare("UPDATE users SET visits = visits + 1, last_seen = ? WHERE id = ?").bind(Date.now(), user.id).run();
  return Response.json({ ok: true }, { headers: { "cache-control": "no-store" } });
}
