import { clearedSessionCookie, sameOrigin } from "@/lib/auth";
export const dynamic = "force-dynamic";
export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "تعذر التحقق من الطلب." }, { status: 403 });
  return Response.json({ ok: true }, { headers: { "set-cookie": clearedSessionCookie(), "cache-control": "no-store" } });
}
