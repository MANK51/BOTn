import { appEnv, clearFailedAttempts, createSignedToken, getAccountUser, hashPassword, isRateLimited, rateLimitKey, recordFailedAttempt, sameOrigin, sessionCookie } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "تعذر التحقق من الطلب." }, { status: 403 });
  const key = await rateLimitKey(request, "login");
  if (await isRateLimited(key)) return Response.json({ error: "محاولات كثيرة. انتظر 15 دقيقة ثم حاول." }, { status: 429 });
  let body: { username?: string; password?: string };
  try { body = await request.json(); } catch { return Response.json({ error: "البيانات غير مكتملة." }, { status: 400 }); }
  const username = body.username ?? "";
  const password = body.password ?? "";
  if (!username.trim() || Array.from(username).length > 100) return Response.json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." }, { status: 401 });
  const row = await appEnv().DB.prepare("SELECT id, username, password_hash, password_salt FROM users WHERE username = ? LIMIT 1").bind(username).first<{ id: string; username: string; password_hash: string; password_salt: string }>();
  if (!row || password.length > 128 || await hashPassword(password, row?.password_salt ?? "00".repeat(16)) !== row?.password_hash) {
    await recordFailedAttempt(key);
    return Response.json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة." }, { status: 401 });
  }
  await clearFailedAttempts(key);
  await appEnv().DB.prepare("UPDATE users SET last_seen = ? WHERE id = ?").bind(Date.now(), row.id).run();
  const token = await createSignedToken("user", row.id, Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60);
  return Response.json({ user: { id: row.id, username: row.username } }, { headers: { "set-cookie": sessionCookie(token), "cache-control": "no-store" } });
}
