import { appEnv, clearFailedAttempts, createSignedToken, hashPassword, isRateLimited, randomSalt, rateLimitKey, recordFailedAttempt, sameOrigin, sessionCookie } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "تعذر التحقق من الطلب." }, { status: 403 });
  const key = await rateLimitKey(request, "register");
  if (await isRateLimited(key)) return Response.json({ error: "محاولات كثيرة. انتظر قليلًا ثم حاول." }, { status: 429 });
  let body: { username?: string; password?: string };
  try { body = await request.json(); } catch { return Response.json({ error: "البيانات غير مكتملة." }, { status: 400 }); }
  const username = body.username ?? "";
  const password = body.password ?? "";
  const usernameLength = Array.from(username).length;
  if (!username.trim() || usernameLength > 100) return Response.json({ error: "اكتب اسم مستخدم بين حرف واحد و100 حرف." }, { status: 400 });
  if (password.length < 8 || password.length > 128) return Response.json({ error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل." }, { status: 400 });
  const salt = randomSalt();
  const passwordHash = await hashPassword(password, salt);
  const id = crypto.randomUUID();
  const now = Date.now();
  try {
    await appEnv().DB.prepare("INSERT INTO users (id, username, password_hash, password_salt, visits, created_at, last_seen) VALUES (?, ?, ?, ?, 0, ?, ?)").bind(id, username, passwordHash, salt, now, now).run();
  } catch {
    await recordFailedAttempt(key);
    return Response.json({ error: "اسم المستخدم مستخدم بالفعل." }, { status: 409 });
  }
  await clearFailedAttempts(key);
  const token = await createSignedToken("user", id, Math.floor(now / 1000) + 7 * 24 * 60 * 60);
  return Response.json({ user: { id, username } }, { headers: { "set-cookie": sessionCookie(token), "cache-control": "no-store" }, status: 201 });
}
