import { getAccountUser } from "@/lib/auth";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const user = await getAccountUser(request);
  return Response.json({ user }, { headers: { "cache-control": "no-store" } });
}
