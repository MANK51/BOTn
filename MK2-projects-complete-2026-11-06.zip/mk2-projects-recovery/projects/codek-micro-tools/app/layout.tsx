import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MK~2 — تصميم وبرمجة",
  description: "سجّل حسابًا وابدأ ببناء مشروعك البرمجي الصغير.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
