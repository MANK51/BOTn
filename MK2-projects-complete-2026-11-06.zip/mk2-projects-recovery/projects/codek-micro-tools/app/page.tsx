import AuthApp from "./AuthApp";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "MK~2 — تصميم وبرمجة",
  description: "سجّل حسابًا وابدأ ببناء مشروعك البرمجي الصغير.",
};

export default function Home() {
  return <AuthApp />;
}
