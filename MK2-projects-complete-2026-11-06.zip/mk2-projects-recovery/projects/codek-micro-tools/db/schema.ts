import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  visits: integer("visits").notNull().default(0),
  createdAt: integer("created_at").notNull(),
  lastSeen: integer("last_seen").notNull(),
});

export const authLimits = sqliteTable("auth_limits", {
  key: text("key").primaryKey(),
  attempts: integer("attempts").notNull().default(0),
  windowStart: integer("window_start").notNull(),
});

export const siteStats = sqliteTable("site_stats", {
  id: integer("id").primaryKey(),
  totalVisits: integer("total_visits").notNull().default(0),
});
