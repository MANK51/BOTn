import { env } from "cloudflare:workers";

type RuntimeEnv = {
  DB: D1Database;
  AUTH_SECRET: string;
  ADMIN_USERNAME: string;
  ADMIN_PASSWORD: string;
};

export type AccountUser = { id: string; username: string };
const runtime = () => env as unknown as RuntimeEnv;
const encoder = new TextEncoder();
const ITERATIONS = 150_000;
const RATE_WINDOW_MS = 15 * 60 * 1000;
const RATE_LIMIT = 8;

function base64url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromBase64url(value: string) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64 + "=".repeat((4 - (base64.length % 4)) % 4);
  return Uint8Array.from(atob(padded), (char) => char.charCodeAt(0));
}
function toHex(bytes: Uint8Array) {
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function fromHex(value: string) {
  return Uint8Array.from(value.match(/.{1,2}/g) ?? [], (byte) => parseInt(byte, 16));
}
function equalBytes(a: Uint8Array, b: Uint8Array) {
  let diff = a.length ^ b.length;
  const length = Math.max(a.length, b.length);
  for (let i = 0; i < length; i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
  return diff === 0;
}
async function hmac(value: string) {
  const secret = runtime().AUTH_SECRET;
  if (!secret) throw new Error("Authentication is not configured.");
  const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}

export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  return !!origin && origin === new URL(request.url).origin;
}

export async function hashPassword(password: string, saltHex: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt: fromHex(saltHex), iterations: ITERATIONS, hash: "SHA-256" }, key, 256);
  return toHex(new Uint8Array(bits));
}

export async function createSignedToken(kind: "user" | "admin", subject: string, expiresAt: number) {
  const payload = base64url(encoder.encode(`${kind}|${subject}|${expiresAt}`));
  return `${payload}.${base64url(await hmac(payload))}`;
}

async function verifySignedToken(token: string | undefined, expectedKind: "user" | "admin") {
  if (!token) return null;
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return null;
  let actual: Uint8Array;
  try { actual = fromBase64url(signature); } catch { return null; }
  if (!equalBytes(actual, await hmac(payload))) return null;
  let parts: string[];
  try { parts = new TextDecoder().decode(fromBase64url(payload)).split("|"); } catch { return null; }
  const expiry = Number(parts[2]);
  if (parts.length !== 3 || parts[0] !== expectedKind || !Number.isFinite(expiry) || expiry <= Math.floor(Date.now() / 1000)) return null;
  return { subject: parts[1], expiry };
}

function cookieValue(request: Request, name: string) {
  const item = request.headers.get("cookie")?.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : undefined;
}
export function sessionCookie(token: string) {
  return `codek_session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`;
}
export function clearedSessionCookie() {
  return "codek_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";
}
export function adminCookie(token: string) {
  return `codek_admin=${encodeURIComponent(token)}; Path=/api/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`;
}
export function clearedAdminCookie() {
  return "codek_admin=; Path=/api/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=0";
}

export async function getAccountUser(request: Request): Promise<AccountUser | null> {
  const token = await verifySignedToken(cookieValue(request, "codek_session"), "user");
  if (!token) return null;
  const row = await runtime().DB.prepare("SELECT id, username FROM users WHERE id = ? LIMIT 1").bind(token.subject).first<AccountUser>();
  return row ?? null;
}
export async function isAdminSession(request: Request) {
  const token = await verifySignedToken(cookieValue(request, "codek_admin"), "admin");
  return token?.subject === "MK2";
}

export async function rateLimitKey(request: Request, scope: string) {
  const ip = request.headers.get("cf-connecting-ip") ?? "unknown";
  return toHex(await hmac(`${scope}|${ip}`));
}
export async function isRateLimited(key: string) {
  const db = runtime().DB;
  const now = Date.now();
  await db.prepare("DELETE FROM auth_limits WHERE window_start < ?").bind(now - 24 * RATE_WINDOW_MS).run();
  const row = await db.prepare("SELECT attempts, window_start FROM auth_limits WHERE key = ? LIMIT 1").bind(key).first<{ attempts: number; window_start: number }>();
  if (!row) return false;
  if (now - row.window_start >= RATE_WINDOW_MS) {
    await db.prepare("DELETE FROM auth_limits WHERE key = ?").bind(key).run();
    return false;
  }
  return row.attempts >= RATE_LIMIT;
}
export async function recordFailedAttempt(key: string) {
  const now = Date.now();
  await runtime().DB.prepare(`INSERT INTO auth_limits (key, attempts, window_start) VALUES (?, 1, ?) ON CONFLICT(key) DO UPDATE SET attempts = CASE WHEN ? - window_start >= ? THEN 1 ELSE attempts + 1 END, window_start = CASE WHEN ? - window_start >= ? THEN ? ELSE window_start END`).bind(key, now, now, RATE_WINDOW_MS, now, RATE_WINDOW_MS, now).run();
}
export async function clearFailedAttempts(key: string) {
  await runtime().DB.prepare("DELETE FROM auth_limits WHERE key = ?").bind(key).run();
}
export function appEnv() { return runtime(); }
export function randomSalt() { return toHex(crypto.getRandomValues(new Uint8Array(16))); }
