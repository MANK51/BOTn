# MK~2 REALITY ENGINE

**Don’t Browse Reality. Create It.**

A runnable, local-first MVP with actual procedural WebGL worlds, a visual world editor, validated scene configurations, and an optional secure cloud backend. English LTR and Arabic RTL are supported.

## Run locally

Requires Node.js 22+ and npm. No service credentials are needed for the core experience.

```sh
npm install
npm run dev
```

Open http://localhost:3000. Projects are saved in the browser’s IndexedDB. Clearing browser data removes them; use **Export scene** for a backup. The first short intro can be skipped and will not replay on later visits. WebGL rendering needs a compatible browser and hardware acceleration; editing and saving remain available through the fallback interface.

For a production build and local static preview:

```sh
npm run build
npm start
```

Development uses `.next-dev`, production uses `.next`, and the deployable static output is `out/`.

## Working features

- A cinematic live 3D city with an illuminated portal, stars, adaptive particles, lighting and optional ambient audio.
- Three actual geometry-based worlds: Skyborne City, Neon Abyss, The Forgotten Temple. Drag to orbit, pinch/scroll to zoom, select elements and points of interest, capture PNG screenshots, return to the explorer, or remix the scene.
- Visual editor with seven procedural assets, object selection, position/rotation/scale controls, names, surface colors, text markers, point descriptions, atmosphere controls, template replacement, rain and particles, undo/redo, preview, import/export and camera reset.
- Local IndexedDB save/open/delete and local favorites. Desktop tools and a compact mobile layout share the same scene engine.
- **Local prompt composer** that recognizes supported English/Arabic instructions for colors, rain, more islands, and template selection for new scenes. This deterministic composer is explicitly labeled. It is not a language model or freeform 3D generator.
- **Portable share links** embed a validated scene in the URL fragment. They work without a backend, contain the scene itself, and are accessible to anyone with the link. They do not synchronize later changes and are not private access controls. Creators can disable the product’s remix action; publicly shared scene data is still readable.
- Optional cloud backend: hashed-password accounts, hashed-token sessions, server roles, public/private world records, ownership checks, moderated public gallery, likes/favorites API, existing-account administrator promotion, protected review/user-role administration and audit logs.
- Optional OpenAI architect: authenticated server requests, daily allowance reservation, bounded requests, provider timeout, Zod scene validation, no execution of generated code.

## Architecture

```text
app/page.tsx             Experience, explorer, library, sharing, account/admin UI
components/WorldCanvas  Shared React Three Fiber / Three.js scene renderer
components/Editor       Live visual scene controls and prompt interface
lib/scene.ts            Strict Zod contract, templates, assets, safe share codec
lib/store.ts            Zustand world state with bounded undo/redo history
lib/storage.ts          IndexedDB transactions and local favorites
lib/api.ts              Optional configured API client, no client-side secrets
server/index.ts         Express API, sessions, access control, AI, moderation
prisma/schema.prisma    PostgreSQL models and indexes
prisma/seed.ts          Promote an existing registered account to admin
server/static.mjs       Static production preview of out/
tests/                  Unit, browser and API smoke checks
```

The frontend uses Next.js 15, React 19, TypeScript, R3F, Drei, Three.js, postprocessing, Zustand and Zod. Static export keeps the experience independent of a specific server host. The API is a separate Node process so secrets and database access never enter frontend bundles. CSS implements the custom Reality Interface rather than a generic dashboard template. World thumbnails are captures of the real rendered geometry, not promised scenes that differ from the experience.

`SceneSchema` limits scenes to 80 known assets and validates colors, unique IDs, coordinate/scale bounds and strings. Templates and scenes reuse the renderer. The next stage can replace procedural assets with lazily loaded glTF assets while preserving the data contract. Realtime collaboration should use authenticated room membership, authoritative scene revisions, validated operation messages and presence; it is intentionally not implemented in this MVP.

## Optional cloud configuration

See [docs/BACKEND.md](docs/BACKEND.md) and [.env.example](.env.example). No external database or AI provider was connected during this build. PostgreSQL-dependent workflows and OpenAI responses require integration testing after credentials are supplied.

## Tests

```sh
npm run typecheck
npm test
npm run test:e2e
# In a second terminal, start the API (no DB needed for these checks):
npm run server
npm run test:api
```

Playwright uses `/usr/bin/chromium` in this environment. Else set `PLAYWRIGHT_CHROMIUM_PATH` to a Chromium executable. The mobile project uses touch-enabled iPhone 13 viewport emulation in Chromium; this is not a test on physical iOS Safari. The config can be extended with Playwright WebKit after installing that browser. Actual results and limits are in [docs/VERIFICATION.md](docs/VERIFICATION.md).

## Deployment

- Static frontend: run `npm ci && npm run build`, deploy **out/** to Sites, Cloudflare Pages, Netlify or another static HTTPS host. Sites metadata is `.openai/hosting.json`. The Sites deployment is owner-private; portable world links will open for other people only on a host whose audience allows them access.
- API: deploy the repository to a Node host (Render, Railway, Fly.io, a container/VPS). Build/start command: `npm ci && npm run db:generate`, then `npm run server`. Configure server environment variables and a managed PostgreSQL database. Provision schema with `npm run db:push`; use reviewed Prisma migrations for production changes.
- Set `NEXT_PUBLIC_API_URL` to the HTTPS API origin **before rebuilding the frontend**. Set `CLIENT_ORIGIN` on the API to the exact frontend origin. Different site origins need `SESSION_SAME_SITE=none` with `SESSION_COOKIE_SECURE=true`; prefer same-site subdomains or a same-origin reverse proxy for Safari compatibility.
- Register your own account, then set `ADMIN_EMAIL` and run `npm run db:seed` to promote it. There is no default administrator password or frontend bypass.
- Set `OPENAI_API_KEY` only on the backend. Do not commit `.env` files. Add database backups, operational monitoring, deployment-specific abuse controls and database integration tests before opening a cloud service widely.

## Scope remaining

The local MVP is functional. Asset uploading, advanced brand settings, authenticated profile editing, a complete cloud project manager UI, realtime multiuser rooms, freeform model generation, and real iPhone/Safari hardware verification are future work. Asset/template libraries are code defined. The administration UI currently covers summary counts, moderation, roles and activity, not a full asset CMS. Quality settings bound DPR, star/particle counts and bloom; do not mistake the adaptive heuristic for a measured device benchmark.
