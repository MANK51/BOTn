"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import dynamic from "next/dynamic";
import {
  ArrowUpRight,
  ArrowRight,
  Plus,
  Compass,
  Sparkles,
  Globe2,
  Volume2,
  VolumeX,
  Settings2,
  Heart,
  Bookmark,
  Check,
  ChevronRight,
  ChevronLeft,
  Play,
  Pause,
  Camera,
  X,
  Search,
  FolderOpen,
  Trash2,
  Cloud,
  User,
  LogIn,
  LogOut,
  ShieldCheck,
  Loader2,
  Copy,
  SlidersHorizontal,
  Menu,
  Link as LinkIcon,
  Download,
} from "lucide-react";
import {
  createScene,
  makeId,
  TEMPLATES,
  SceneConfig,
  TemplateId,
  decodeScene,
  SceneSchema,
} from "@/lib/scene";
import {
  listProjects,
  loadProject,
  deleteProject,
  SavedProject,
  favorites,
  toggleFavorite,
} from "@/lib/storage";
import { useWorldStore } from "@/lib/store";
import { api, API_BASE } from "@/lib/api";
import { readPreference, writePreference } from "@/lib/preferences";
const WorldCanvas = dynamic(() => import("@/components/WorldCanvas"), {
  ssr: false,
  loading: () => (
    <div className="canvas-loading">
      <span className="loading-ring" />
      <span>Loading render module…</span>
    </div>
  ),
});
const Editor = dynamic(() => import("@/components/Editor"), {
  ssr: false,
  loading: () => (
    <div className="page-loading">
      <span className="loading-ring" />
      Opening your studio…
    </div>
  ),
});
type View =
  | "home"
  | "explore"
  | "editor"
  | "community"
  | "library"
  | "world"
  | "admin";
type UserInfo = { id: string; name: string; email: string; role: string };
type Published = {
  id: string;
  name: string;
  scene: SceneConfig;
  author: { name: string };
  _count: { likes: number };
};
export default function App() {
  const [ar, setAr] = useState(false),
    [view, setView] = useState<View>("home"),
    [activeScene, setActiveScene] = useState<SceneConfig | null>(null),
    [toast, setToast] = useState(""),
    [intro, setIntro] = useState(false),
    [sound, setSound] = useState(false),
    [settings, setSettings] = useState(false),
    [quality, setQuality] = useState<"auto" | "low" | "high">("auto"),
    [reducedMotion, setReducedMotion] = useState(false),
    [fav, setFav] = useState<string[]>([]),
    [filter, setFilter] = useState("All worlds"),
    [query, setQuery] = useState(""),
    [projects, setProjects] = useState<SavedProject[]>([]),
    [poi, setPoi] = useState<string | null>(null),
    [showMenu, setShowMenu] = useState(false),
    [services, setServices] = useState(false),
    [auth, setAuth] = useState(false),
    [user, setUser] = useState<UserInfo | null>(null),
    [publicWorlds, setPublicWorlds] = useState<Published[]>([]),
    [cloudError, setCloudError] = useState(""),
    [loaded, setLoaded] = useState(false),
    [shared, setShared] = useState(false),
    [likeIds, setLikeIds] = useState<string[]>([]),
    [publishedId, setPublishedId] = useState<string | null>(null);
  const [cloudAi, setCloudAi] = useState(false);
  useEffect(() => {
    if (API_BASE)
      api<{ ai: boolean }>("/api/health")
        .then((r) => setCloudAi(r.ai))
        .catch(() => setCloudAi(false));
  }, []);
  const heroScene = useMemo(() => createScene("skyborne"), []),
    introScene = useMemo(() => {
      const s = createScene("neon");
      return {
        ...s,
        objects: [
          {
            ...s.objects.find((o) => o.kind === "portal")!,
            position: [0, 0, 0] as [number, number, number],
            scale: [1.6, 1.6, 1.6] as [number, number, number],
            color: "#bc9aff",
          },
        ],
        camera: { position: [0, 0, 10] as [number, number, number] },
        environment: { ...s.environment, sky: "#05060b", fog: 0 },
      };
    }, []),
    captureRef = useRef<(() => void) | null>(null),
    audioRef = useRef<AudioContext | null>(null),
    toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const tr = (en: string, arab: string) => (ar ? arab : en);
  const notify = (s: string) => {
    setToast(s);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 4500);
  };
  useEffect(() => {
    const lang = readPreference("mk2-lang") === "ar";
    setAr(lang);
    setFav(favorites());
    const mq = matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    const h = () => setReducedMotion(mq.matches);
    mq.addEventListener("change", h);
    if (!readPreference("mk2-visited") && !mq.matches && !location.hash) {
      setIntro(true);
      const timer = setTimeout(() => {
        setIntro(false);
        writePreference("mk2-visited", "1");
      }, 4200);
      return () => {
        clearTimeout(timer);
        mq.removeEventListener("change", h);
      };
    }
    return () => mq.removeEventListener("change", h);
  }, []);
  useEffect(() => {
    if (!intro || reducedMotion) return;
    const timer = setTimeout(() => {
      setIntro(false);
      writePreference("mk2-visited", "1");
    }, 4200);
    return () => clearTimeout(timer);
  }, [intro, reducedMotion]);
  useEffect(() => {
    document.documentElement.lang = ar ? "ar" : "en";
    document.documentElement.dir = ar ? "rtl" : "ltr";
    writePreference("mk2-lang", ar ? "ar" : "en");
  }, [ar]);
  useEffect(() => {
    const handleHash = async () => {
      const hash = location.hash.slice(1);
      if (hash.startsWith("world=")) {
        try {
          const s = decodeScene(decodeURIComponent(hash.slice(6)));
          setActiveScene(s);
          setView("world");
          setShared(true);
          setPublishedId(null);
        } catch {
          notify("This share link is invalid or too large.");
        }
      } else if (hash.startsWith("published=")) {
        try {
          const id = hash.slice(10);
          const r = await api<{ world: Published }>(
            "/api/worlds/" + encodeURIComponent(id),
          );
          setActiveScene(SceneSchema.parse(r.world.scene));
          setView("world");
          setShared(true);
          setPublishedId(id);
        } catch (e) {
          notify((e as Error).message);
        }
      }
    };
    handleHash();
    window.addEventListener("hashchange", handleHash);
    return () => window.removeEventListener("hashchange", handleHash);
  }, []);
  useEffect(() => {
    if (API_BASE)
      api<{ user: UserInfo | null }>("/api/auth/me")
        .then((r) => setUser(r.user))
        .catch(() => {});
  }, []);
  useEffect(() => {
    if (view === "library")
      listProjects()
        .then(setProjects)
        .catch(() => notify("Browser storage is unavailable."));
    if (view === "community" && API_BASE) {
      setCloudError("");
      api<{ worlds: Published[] }>("/api/worlds")
        .then((r) => setPublicWorlds(r.worlds))
        .catch((e) => setCloudError(e.message));
    }
  }, [view]);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setSettings(false);
        setAuth(false);
        setServices(false);
        setPoi(null);
        setShowMenu(false);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, []);
  useEffect(
    () => () => {
      audioRef.current?.close();
    },
    [],
  );
  function navigate(v: View) {
    setView(v);
    setShowMenu(false);
    setPoi(null);
    window.scrollTo({ top: 0, behavior: "instant" });
    if (v !== "world" && location.hash)
      history.replaceState(null, "", location.pathname);
  }
  function enterWorld(template: TemplateId) {
    setActiveScene(createScene(template));
    setShared(false);
    setPublishedId(null);
    setLoaded(false);
    navigate("world");
  }
  function createWorld(template: TemplateId = "skyborne") {
    useWorldStore.getState().setScene(createScene(template), true);
    navigate("editor");
  }
  async function openProject(id: string) {
    try {
      const p = await loadProject(id);
      if (p) {
        useWorldStore.getState().setScene(p.scene, true);
        navigate("editor");
      }
    } catch {
      notify(tr("Could not open this project.", "تعذر فتح المشروع."));
    }
  }
  async function toggleAudio() {
    if (sound) {
      await audioRef.current?.suspend();
      setSound(false);
      return;
    }
    try {
      if (!audioRef.current) {
        const ctx = new AudioContext();
        audioRef.current = ctx;
        const gain = ctx.createGain();
        gain.gain.value = 0.017;
        const filter = ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.value = 400;
        filter.connect(gain);
        gain.connect(ctx.destination);
        [110, 164.81, 220].forEach((f, i) => {
          const o = ctx.createOscillator();
          o.type = "sine";
          o.frequency.value = f;
          o.detune.value = i * 3;
          o.connect(filter);
          o.start();
        });
      }
      await audioRef.current.resume();
      setSound(true);
    } catch {
      notify(
        tr(
          "Audio is not available in this browser.",
          "الصوت غير متاح في هذا المتصفح.",
        ),
      );
    }
  }
  const bookmark = (id: string) => {
    try {
      setFav(toggleFavorite(id));
    } catch {
      notify("Local storage is unavailable.");
    }
  };
  const sceneInfo =
    activeScene && TEMPLATES.find((t) => t.id === activeScene.template);
  const selectedPoi = activeScene?.objects.find((o) => o.id === poi);
  const filtered = TEMPLATES.filter(
    (t) =>
      t.name.toLowerCase().includes(query.toLowerCase()) &&
      (filter === "All worlds" ||
        (filter === "Saved" && fav.includes(t.id)) ||
        t.tags.includes(filter)),
  );
  const header = (
    <header className="site-header">
      <button
        className="brand"
        onClick={() => navigate("home")}
        aria-label="MK2 Home"
      >
        <span className="brand-mark">
          <i />
          <i />
          <i />
        </span>
        <span className="brand-word">
          MK<span>~</span>2
        </span>
        <span className="brand-divider" />
        <span className="brand-caption">
          REALITY
          <br />
          ENGINE
        </span>
      </button>
      <nav className={showMenu ? "nav-open" : ""}>
        {(
          [
            { v: "home", en: "Discover", ar: "الرئيسية" },
            { v: "explore", en: "Explore worlds", ar: "استكشف العوالم" },
            { v: "editor", en: "Create", ar: "أنشئ عالمًا" },
            { v: "community", en: "Community", ar: "المجتمع" },
          ] as const
        ).map((n) => (
          <button
            key={n.v}
            className={view === n.v ? "active" : ""}
            onClick={() => (n.v === "editor" ? createWorld() : navigate(n.v))}
          >
            {ar ? n.ar : n.en}
            {view === n.v && <i />}
          </button>
        ))}
      </nav>
      <div className="header-actions">
        <button
          className="language-button"
          aria-label="Switch language"
          onClick={() => setAr(!ar)}
        >
          <Globe2 size={15} />
          <span>{ar ? "EN" : "عربي"}</span>
        </button>
        <button
          aria-label={tr("My workspace", "مساحتي")}
          className="workspace-button"
          onClick={() => navigate("library")}
        >
          <FolderOpen size={16} />
          <span>{tr("My workspace", "مساحتي")}</span>
          <ArrowUpRight size={14} />
        </button>
        <button
          className="mobile-menu icon-button"
          aria-label="Menu"
          onClick={() => setShowMenu(!showMenu)}
        >
          <Menu size={20} />
        </button>
      </div>
    </header>
  );
  return (
    <div className={"app-shell " + (ar ? "arabic" : "")}>
      {view !== "editor" && header}
      {view === "home" && (
        <main>
          <section className="hero-section">
            <div className="hero-scene">
              {!intro && (
                <WorldCanvas
                  scene={heroScene}
                  hero
                  reducedMotion={reducedMotion}
                  quality={quality}
                />
              )}
            </div>
            <div className="hero-shade" />
            <div className="hero-grid" />
            <div className="hero-content">
              <button
                className="release-pill"
                onClick={() => setServices(true)}
              >
                <span className="pulse-dot" />
                {tr("THE POSSIBILITIES ARE OPEN", "الاحتمالات بلا حدود")}
                <ChevronRight size={13} />
              </button>
              <h1>
                {tr("Don’t browse", "لا تتصفح")}
                <br />
                {tr("reality.", "الواقع.")}
                <br />
                <span>{tr("Create it.", "اصنعه.")}</span>
              </h1>
              <p>
                {tr(
                  "Step beyond the screen. Explore impossible worlds, shape your own, and turn a spark of imagination into somewhere real.",
                  "تجاوز حدود الشاشة. استكشف عوالم مستحيلة، وصمّم عالمك الخاص، وحوّل شرارة الخيال إلى مكان تعيشه.",
                )}
              </p>
              <div className="hero-actions">
                <button
                  className="button primary"
                  onClick={() => createWorld()}
                >
                  <Sparkles size={17} />
                  {tr("Create your reality", "اصنع واقعك")}
                  <ArrowUpRight size={18} />
                </button>
                <button
                  className="button text-button"
                  onClick={() => navigate("explore")}
                >
                  <span className="play-circle">
                    <Play size={12} fill="currentColor" />
                  </span>
                  {tr("Explore the worlds", "ادخل العالم")}
                </button>
              </div>
              <div className="hero-proof">
                <div className="proof-symbols">
                  <span>◈</span>
                  <span>◎</span>
                  <span>◇</span>
                </div>
                <span>
                  {tr(
                    "No code. Just a little imagination.",
                    "بلا برمجة. فقط قليل من الخيال.",
                  )}
                  <small>
                    {tr(
                      "Built to be explored. Made to be yours.",
                      "للاستكشاف. ولتكون عالمك.",
                    )}
                  </small>
                </span>
              </div>
            </div>
            <div className="scene-coordinates">
              <span className="small-cross">＋</span>
              <span>
                28.4° N<br />
                92.1° E
              </span>
              <span className="coordinate-line" />
            </div>
            <div className="hero-scene-label">
              <span className="tiny-label">WORLD 001 / LIVE RENDER</span>
              <strong>
                Skyborne City <ArrowUpRight size={17} />
              </strong>
              <button onClick={() => enterWorld("skyborne")}>
                {tr("Enter this world", "ادخل هذا العالم")}{" "}
                <ArrowRight size={14} />
              </button>
            </div>
            <div className="hero-bottom">
              <div className="hero-bottom-left">
                <span className="tiny-label">DESIGNED FOR THE IMPOSSIBLE</span>
                <span className="hero-bottom-line" />
                <span>
                  {tr(
                    "A new dimension of creative freedom",
                    "بُعد جديد من الحرية الإبداعية",
                  )}
                </span>
              </div>
              <button
                className={"sound-control " + (sound ? "on" : "")}
                onClick={toggleAudio}
              >
                {sound ? <Volume2 size={15} /> : <VolumeX size={15} />}
                <span>AMBIENCE {sound ? "ON" : "OFF"}</span>
                <i />
              </button>
            </div>
          </section>
          <div className="capability-strip">
            <span>
              <i className="pulse-dot" />
              REALITY ENGINE <b>v1.0</b>
            </span>
            <span>
              <Compass size={15} />
              {tr("3 explorable worlds", "3 عوالم للاستكشاف")}
            </span>
            <span>
              <LayersIcon />
              {tr("An infinite blank canvas", "مساحة للخيال")}
            </span>
            <span>
              <Sparkles size={15} />
              {tr("Your imagination, in real time", "خيالك، في الوقت الحقيقي")}
            </span>
            <button onClick={() => setServices(true)}>
              {tr("Local first. Yours forever.", "محلي أولًا. عالمك دائمًا.")}
              <ArrowUpRight size={14} />
            </button>
          </div>
          <section className="worlds-section">
            <div className="section-heading">
              <div>
                <span className="eyebrow">
                  <span />
                  THE WORLD EXPLORER
                </span>
                <h2>
                  {tr("Somewhere beyond the ordinary.", "مكان يتجاوز المألوف.")}
                </h2>
                <p>
                  {tr(
                    "Three worlds. Three ways to leave the everyday behind.",
                    "ثلاثة عوالم. ثلاث طرق لمغادرة اليومي.",
                  )}
                </p>
              </div>
              <button
                className="button subtle"
                onClick={() => navigate("explore")}
              >
                {tr("View all worlds", "كل العوالم")}
                <ArrowUpRight size={16} />
              </button>
            </div>
            <div className="world-card-grid">
              {TEMPLATES.map((t, i) => (
                <WorldCard
                  key={t.id}
                  template={t}
                  index={i}
                  saved={fav.includes(t.id)}
                  ar={ar}
                  onEnter={() => enterWorld(t.id)}
                  onSave={() => bookmark(t.id)}
                />
              ))}
            </div>
          </section>
          <section className="creation-banner">
            <div>
              <span className="eyebrow">FROM A THOUGHT TO A PLACE</span>
              <h2>
                {tr("What if your next idea", "ماذا لو كانت فكرتك القادمة")}
                <br />
                {tr("was a whole world?", "عالمًا كاملًا؟")}
              </h2>
              <p>
                {tr(
                  "Choose a beginning. Change every detail. Make something only you could imagine.",
                  "اختر البداية. غيّر كل تفصيل. اصنع ما لا يتخيله سواك.",
                )}
              </p>
              <button className="button primary" onClick={() => createWorld()}>
                {tr("Open the creator", "افتح المحرر")}
                <Plus size={17} />
              </button>
            </div>
            <div className="banner-art">
              <div className="wire-orbit o1" />
              <div className="wire-orbit o2" />
              <div className="wire-orbit o3" />
              <div className="banner-core">✦</div>
              <span className="orbit-label">YOUR NEXT REALITY</span>
            </div>
          </section>
        </main>
      )}
      {(view === "explore" || view === "community") && (
        <main className="browse-page">
          <div className="browse-heading">
            <span className="eyebrow">
              {view === "explore"
                ? "THE WORLD EXPLORER"
                : "THE REALITY COLLECTIVE"}
            </span>
            <h1>
              {view === "explore"
                ? tr("Find your next dimension.", "اكتشف بُعدك القادم.")
                : tr(
                    "Different minds. New realities.",
                    "خيالات مختلفة. عوالم جديدة.",
                  )}
            </h1>
            <p>
              {view === "explore"
                ? tr(
                    "These aren’t destinations. They’re beginnings. Step inside and see what’s possible.",
                    "هذه ليست وجهات. إنها بدايات. ادخل واكتشف الممكن.",
                  )
                : tr(
                    "Explore the curated collection, remix a starting point, and make it your own.",
                    "استكشف المجموعة المختارة، وأعد تشكيل عالم، واجعله خاصًا بك.",
                  )}
            </p>
          </div>
          <div className="browse-controls">
            <div className="filter-tabs">
              {["All worlds", "Fantasy", "Sci-fi", "Mystery", "Saved"].map(
                (f) => (
                  <button
                    key={f}
                    className={filter === f ? "active" : ""}
                    onClick={() => setFilter(f)}
                  >
                    {ar
                      ? {
                          "All worlds": "كل العوالم",
                          Fantasy: "خيال",
                          "Sci-fi": "خيال علمي",
                          Mystery: "غموض",
                          Saved: "المفضلة",
                        }[f]
                      : f}
                  </button>
                ),
              )}
            </div>
            <label className="search-field">
              <Search size={16} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={tr("Find a world…", "ابحث عن عالم…")}
              />
            </label>
          </div>
          <div className="world-card-grid">
            {filtered.map((t, i) => (
              <WorldCard
                key={t.id}
                template={t}
                index={i}
                saved={fav.includes(t.id)}
                ar={ar}
                onEnter={() => enterWorld(t.id)}
                onSave={() => bookmark(t.id)}
              />
            ))}
          </div>
          {!filtered.length && (
            <div className="empty-state">
              <Search size={30} />
              <h3>{tr("No worlds found.", "لا توجد نتائج.")}</h3>
              <button
                className="button subtle"
                onClick={() => {
                  setFilter("All worlds");
                  setQuery("");
                }}
              >
                {tr("Reset filters", "إعادة ضبط البحث")}
              </button>
            </div>
          )}
          {view === "community" && (
            <section className="community-cloud">
              <div>
                <Cloud size={28} />
                <h3>
                  {tr("The community starts with you.", "المجتمع يبدأ بك.")}
                </h3>
                <p>
                  {API_BASE
                    ? tr(
                        "Public worlds from the connected service appear here after moderation.",
                        "تظهر العوالم العامة بعد مراجعتها هنا.",
                      )
                    : tr(
                        "The worlds above are our built-in curated collection. A shared public gallery, accounts, and likes become available when cloud services are connected. You can already share portable scene links from the editor.",
                        "العوالم أعلاه مجموعة مدمجة. يتطلب المعرض العام والحسابات والإعجابات إعداد الخدمات. يمكنك الآن مشاركة روابط المشاهد من المحرر.",
                      )}
                </p>
              </div>
              <button
                className="button subtle"
                onClick={() => (API_BASE ? setAuth(true) : setServices(true))}
              >
                {API_BASE
                  ? tr("Sign in to publish", "سجّل الدخول للنشر")
                  : tr("Connection details", "تفاصيل الربط")}
                <ArrowUpRight size={16} />
              </button>
            </section>
          )}
          {cloudError && <p className="error-message">{cloudError}</p>}
          {view === "community" && publicWorlds.length > 0 && (
            <div className="community-list">
              {publicWorlds.map((w) => (
                <article className="published-card" key={w.id}>
                  <span className="world-mini-icon">◎</span>
                  <div>
                    <h3>{w.name}</h3>
                    <p>
                      {tr("By", "بواسطة")} {w.author.name} · {w.scene.template}
                    </p>
                  </div>
                  <button
                    className="button subtle small"
                    onClick={() => {
                      setActiveScene(SceneSchema.parse(w.scene));
                      setShared(true);
                      setPublishedId(w.id);
                      navigate("world");
                    }}
                  >
                    {tr("Explore", "استكشاف")}
                    <ArrowUpRight size={15} />
                  </button>
                  <button
                    className={
                      "icon-button " + (likeIds.includes(w.id) ? "liked" : "")
                    }
                    aria-label="Like world"
                    onClick={async () => {
                      try {
                        const r = await api<{ liked: boolean }>(
                          "/api/worlds/" + w.id + "/like",
                          { method: "POST" },
                        );
                        setLikeIds(
                          r.liked
                            ? [...likeIds, w.id]
                            : likeIds.filter((x) => x !== w.id),
                        );
                        setPublicWorlds(
                          publicWorlds.map((p) =>
                            p.id === w.id
                              ? {
                                  ...p,
                                  _count: {
                                    likes: p._count.likes + (r.liked ? 1 : -1),
                                  },
                                }
                              : p,
                          ),
                        );
                      } catch (e) {
                        notify((e as Error).message);
                      }
                    }}
                  >
                    <Heart size={16} /> {w._count.likes}
                  </button>
                </article>
              ))}
            </div>
          )}
        </main>
      )}
      {view === "library" && (
        <main className="browse-page">
          <div className="browse-heading">
            <span className="eyebrow">YOUR CREATIVE SPACE</span>
            <h1>{tr("A universe of your own.", "عالم من صنعك.")}</h1>
            <p>
              {tr(
                "Your worlds, saved on this device. Pick up where imagination left off.",
                "عوالمك محفوظة على هذا الجهاز. أكمل من حيث توقف الخيال.",
              )}
            </p>
          </div>
          <div className="library-toolbar">
            <span className="local-indicator">
              <i />
              {projects.length} {tr("local projects", "مشروع محلي")}
            </span>
            <button className="button primary" onClick={() => createWorld()}>
              <Plus size={17} />
              {tr("New world", "عالم جديد")}
            </button>
          </div>
          {projects.length ? (
            <div className="project-grid">
              {projects.map((p) => (
                <article className="project-card" key={p.id}>
                  <div
                    className="project-cover"
                    style={{ background: p.scene.environment.sky }}
                  >
                    <span style={{ color: p.scene.environment.accent }}>◎</span>
                    <span className="tiny-label">
                      {p.scene.template.toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <h3>{p.name}</h3>
                    <p>
                      {new Date(p.updatedAt).toLocaleString(ar ? "ar" : "en", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}{" "}
                      · {p.scene.objects.length} {tr("elements", "عنصر")}
                    </p>
                    <div className="project-actions">
                      <button
                        className="button subtle small"
                        onClick={() => openProject(p.id)}
                      >
                        {tr("Open in studio", "فتح في المحرر")}
                        <ArrowUpRight size={14} />
                      </button>
                      <button
                        className="icon-button"
                        aria-label="Delete project"
                        onClick={async () => {
                          if (
                            confirm(
                              tr(
                                "Delete this local project permanently?",
                                "حذف هذا المشروع المحلي نهائيًا؟",
                              ),
                            )
                          ) {
                            await deleteProject(p.id);
                            setProjects(await listProjects());
                            notify(tr("Project deleted.", "تم حذف المشروع."));
                          }
                        }}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <FolderOpen size={35} />
              <h3>
                {tr(
                  "Every universe starts somewhere.",
                  "كل عالم يبدأ من مكان ما.",
                )}
              </h3>
              <p>
                {tr(
                  "Create a world and save it. It will be waiting right here.",
                  "أنشئ عالمًا واحفظه، وستجده هنا.",
                )}
              </p>
              <button className="button primary" onClick={() => createWorld()}>
                {tr("Create your first world", "أنشئ عالمك الأول")}
                <Plus size={16} />
              </button>
            </div>
          )}
          <div className="storage-note">
            <ShieldCheck size={18} />
            {tr(
              "Your projects live in this browser’s IndexedDB. Export a scene for a backup, or use a portable share link. Clearing browser data removes local projects.",
              "تُحفظ مشاريعك في IndexedDB بهذا المتصفح. صدّر المشهد لحفظ نسخة احتياطية. مسح بيانات المتصفح يحذف المشاريع المحلية.",
            )}
          </div>
        </main>
      )}
      {view === "world" && activeScene && (
        <main className="world-view">
          <WorldCanvas
            scene={activeScene}
            reducedMotion={reducedMotion}
            quality={quality}
            onSelect={(id) => setPoi(id)}
            captureRef={captureRef}
            onReady={() => setLoaded(true)}
          />
          <div className="world-top-overlay">
            <button
              className="button glass"
              onClick={() => navigate("explore")}
            >
              <ChevronLeft size={16} />
              {tr("All worlds", "كل العوالم")}
            </button>
            <div>
              <span className="tiny-label">{sceneInfo?.subtitle}</span>
              <h2>{activeScene.name}</h2>
            </div>
            <span className="viewport-badge">
              <i />
              {loaded ? "LIVE WORLD" : "INITIALIZING"}
            </span>
          </div>
          <div className="world-story">
            <span className="eyebrow">
              {shared ? "A SHARED REALITY" : "YOU’VE ARRIVED"}
            </span>
            <h3>
              {tr("Take a moment. Look around.", "تأمل لحظة. انظر حولك.")}
            </h3>
            <p>{sceneInfo?.description}</p>
            <span className="world-instruction">
              {tr(
                "Drag to orbit · Scroll or pinch to zoom",
                "اسحب للدوران · باعد للتكبير",
              )}
            </span>
            <div className="poi-list">
              {activeScene.objects
                .filter(
                  (o) =>
                    o.kind === "portal" || o.kind === "temple" || o.description,
                )
                .slice(0, 4)
                .map((o) => (
                  <button key={o.id} onClick={() => setPoi(o.id)}>
                    <span>◈</span>
                    {o.name}
                    <ArrowUpRight size={13} />
                  </button>
                ))}
            </div>
          </div>
          <div className="world-bottom-overlay">
            <div className="world-render-label">
              <span className="pulse-dot" />
              REALTIME WEBGL
              <span className="tiny-label">
                {activeScene.objects.length} ELEMENTS
              </span>
            </div>
            <div className="world-action-buttons">
              <button className="button glass small" onClick={toggleAudio}>
                {sound ? <Volume2 size={16} /> : <VolumeX size={16} />}
                <span>{tr("Ambience", "صوت")}</span>
              </button>
              <button
                className="button glass small"
                onClick={() =>
                  captureRef.current
                    ? captureRef.current()
                    : notify(
                        tr(
                          "Capture needs an active WebGL viewport.",
                          "التقاط الصور يتطلب معاينة WebGL نشطة.",
                        ),
                      )
                }
              >
                <Camera size={16} />
                <span>{tr("Capture", "التقاط")}</span>
              </button>
              <button
                className="button primary small"
                disabled={shared && !activeScene.allowRemix}
                title={
                  !activeScene.allowRemix
                    ? "Remixing is disabled by the creator"
                    : undefined
                }
                onClick={() => {
                  const copy = structuredClone(activeScene);
                  copy.id = makeId();
                  copy.name += " · Remix";
                  useWorldStore.getState().setScene(copy, true);
                  navigate("editor");
                }}
              >
                <Sparkles size={16} />
                <span>{tr("Make it yours", "اجعله عالمك")}</span>
              </button>
            </div>
          </div>
          {selectedPoi && (
            <div className="poi-popup">
              <button
                className="icon-button"
                aria-label="Close point of interest"
                onClick={() => setPoi(null)}
              >
                <X size={16} />
              </button>
              <span className="tiny-label">
                POINT OF INTEREST / {selectedPoi.kind.toUpperCase()}
              </span>
              <h3>{selectedPoi.name}</h3>
              <p>
                {selectedPoi.description ||
                  (selectedPoi.kind === "portal"
                    ? tr(
                        "A threshold between what is and what could be. The gate pulses with the energy of a thousand unwritten stories.",
                        "عتبة بين ما هو كائن وما يمكن أن يكون. تنبض البوابة بطاقة ألف قصة لم تُكتب بعد.",
                      )
                    : tr(
                        "Every structure holds a story. Remix this world to write your own.",
                        "كل بناء يحمل قصة. أعد تشكيل العالم لتكتب قصتك.",
                      ))}
              </p>
              <span className="poi-coordinates">
                X {selectedPoi.position[0]} / Y {selectedPoi.position[1]} / Z{" "}
                {selectedPoi.position[2]}
              </span>
            </div>
          )}
        </main>
      )}
      {view === "editor" && (
        <Editor
          ar={ar}
          reducedMotion={reducedMotion}
          quality={quality}
          aiAvailable={cloudAi}
          onBack={() => navigate("library")}
          notify={notify}
        />
      )}
      {view === "admin" && (
        <AdminPanel notify={notify} onBack={() => navigate("home")} />
      )}
      {view !== "editor" && view !== "world" && (
        <footer className="site-footer">
          <button className="footer-brand" onClick={() => navigate("home")}>
            MK~2 <span>REALITY ENGINE</span>
          </button>
          <p>
            {tr("Don’t Browse Reality. Create It.", "لا تتصفح الواقع. اصنعه.")}
          </p>
          <div>
            <button onClick={() => setSettings(true)}>
              <Settings2 size={14} />
              {tr("Experience settings", "إعدادات التجربة")}
            </button>
            <button
              onClick={() => (API_BASE ? setAuth(true) : setServices(true))}
            >
              <User size={14} />
              {user ? user.name : tr("Account", "الحساب")}
            </button>
            {user?.role === "ADMIN" && (
              <button onClick={() => navigate("admin")}>Admin</button>
            )}
            <span>© 2026 MK~2</span>
          </div>
        </footer>
      )}
      {intro && (
        <div className="intro-overlay">
          <div className="intro-canvas">
            <WorldCanvas
              scene={introScene}
              intro
              reducedMotion={reducedMotion}
              quality={quality}
            />
          </div>
          <div className="intro-light" />
          <div className="intro-portal" />
          <span className="intro-wordmark">MK~2</span>
          <p>YOUR REALITY STARTS HERE.</p>
          <button
            className="intro-skip"
            onClick={() => {
              setIntro(false);
              writePreference("mk2-visited", "1");
            }}
          >
            {tr("Skip intro", "تخطي المقدمة")}
            <ArrowRight size={14} />
          </button>
          <button
            className="button primary intro-enter"
            onClick={() => {
              setIntro(false);
              writePreference("mk2-visited", "1");
              navigate("explore");
            }}
          >
            {tr("Enter reality", "ادخل العالم")}
            <ArrowUpRight size={16} />
          </button>
        </div>
      )}
      {toast && (
        <div className="toast" role="status">
          <Check size={16} />
          {toast}
          <button
            className="icon-button"
            aria-label="Dismiss notification"
            onClick={() => setToast("")}
          >
            <X size={13} />
          </button>
        </div>
      )}
      {settings && (
        <div className="modal-backdrop" onClick={() => setSettings(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button
              className="modal-close icon-button"
              aria-label="Close"
              onClick={() => setSettings(false)}
            >
              <X size={18} />
            </button>
            <span className="tiny-label">FINE TUNE YOUR EXPERIENCE</span>
            <h2>{tr("A reality that fits you.", "تجربة تناسبك.")}</h2>
            <label>
              {tr("Graphics quality", "جودة الرسوم")}
              <select
                value={quality}
                onChange={(e) => setQuality(e.target.value as typeof quality)}
              >
                <option value="auto">
                  {tr(
                    "Auto · adapts to your device",
                    "تلقائي · يتكيف مع الجهاز",
                  )}
                </option>
                <option value="low">
                  {tr("Performance · mobile friendly", "أداء · مناسب للجوال")}
                </option>
                <option value="high">
                  {tr("High · desktop detail", "عالي · تفاصيل سطح المكتب")}
                </option>
              </select>
            </label>
            <label className="check-label">
              <input
                type="checkbox"
                checked={reducedMotion}
                onChange={(e) => setReducedMotion(e.target.checked)}
              />
              {tr("Reduce motion", "تقليل الحركة")}
            </label>
            <button className="button subtle full" onClick={toggleAudio}>
              {sound ? <Volume2 size={16} /> : <VolumeX size={16} />}{" "}
              {sound
                ? tr("Turn ambience off", "إيقاف الصوت")
                : tr("Turn ambience on", "تشغيل الصوت")}
            </button>
            <button
              className="button subtle full"
              onClick={() => {
                setSettings(false);
                setIntro(true);
              }}
            >
              <Play size={15} />
              {tr("Replay opening sequence", "إعادة تجربة الدخول")}
            </button>
            <p className="modal-note">
              {tr(
                "Auto lowers pixel density and particles on phones. Motion preferences are respected.",
                "يقلل الوضع التلقائي كثافة الرسوم والجسيمات في الهواتف ويحترم تفضيلات الحركة.",
              )}
            </p>
          </div>
        </div>
      )}
      {services && (
        <div className="modal-backdrop" onClick={() => setServices(false)}>
          <div
            className="modal services-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="modal-close icon-button"
              aria-label="Close"
              onClick={() => setServices(false)}
            >
              <X size={18} />
            </button>
            <span className="modal-orb">
              <Globe2 size={26} />
            </span>
            <span className="tiny-label">A REAL ENGINE. AN HONEST START.</span>
            <h2>{tr("Your reality is ready.", "عالمك جاهز.")}</h2>
            <p>
              {tr(
                "The core engine runs on your device. Cloud features connect through the included secure backend.",
                "المحرك الأساسي يعمل على جهازك. تُربط الخدمات السحابية عبر الخادم الآمن المرفق.",
              )}
            </p>
            <div className="service-row">
              <Check size={18} />
              <div>
                <strong>{tr("Ready now", "متاح الآن")}</strong>
                <p>
                  {tr(
                    "Three 3D worlds, visual editing, local saves, portable links, scene export, and a local prompt composer.",
                    "ثلاثة عوالم 3D، محرر بصري، حفظ محلي، مشاركة روابط، تصدير، ومصمم أوصاف محلي.",
                  )}
                </p>
              </div>
            </div>
            <div className="service-row muted">
              <Cloud size={18} />
              <div>
                <strong>
                  {API_BASE
                    ? "Cloud endpoint configured"
                    : tr("Connect to go further", "اربط الخدمات للتوسع")}
                </strong>
                <p>
                  {tr(
                    "PostgreSQL + backend for accounts, private publishing, community, and admin. An OpenAI key enables the AI architect. See README and .env.example.",
                    "PostgreSQL والخادم للحسابات والنشر الخاص والمجتمع والإدارة. مفتاح OpenAI يفعّل المصمم الذكي. راجع README و.env.example.",
                  )}
                </p>
              </div>
            </div>
            <button
              className="button primary full"
              onClick={() => {
                setServices(false);
                createWorld();
              }}
            >
              {tr("Start creating", "ابدأ الإنشاء")}
              <ArrowUpRight size={16} />
            </button>
          </div>
        </div>
      )}
      {auth && (
        <AuthModal
          user={user}
          setUser={setUser}
          onClose={() => setAuth(false)}
          notify={notify}
        />
      )}
    </div>
  );
}
function LayersIcon() {
  return <span className="layers-symbol">▱</span>;
}
function WorldCard({
  template: t,
  index,
  saved,
  ar,
  onEnter,
  onSave,
}: {
  template: (typeof TEMPLATES)[number];
  index: number;
  saved: boolean;
  ar: boolean;
  onEnter: () => void;
  onSave: () => void;
}) {
  return (
    <article className="world-card">
      <div
        className={"world-card-art art-" + t.id}
        onClick={onEnter}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === "Enter") onEnter();
        }}
        aria-label={`Enter ${t.name}`}
      >
        <img
          src={t.image}
          alt={t.name + " — a view of the explorable 3D scene"}
          loading="lazy"
        />
        <div className="card-art-shade" />
        <span className="card-number">
          0{index + 1} <span>/ WORLD</span>
        </span>
        <span className="card-type">
          <i style={{ background: t.color }} />
          {t.tags[0]}
        </span>
        <span className="card-enter">
          <ArrowUpRight size={22} />
        </span>
        <span className="card-coordinates">{t.coordinates}</span>
      </div>
      <div className="world-card-info">
        <div>
          <h3>
            <button onClick={onEnter}>{t.name}</button>
          </h3>
          <p>
            {ar
              ? {
                  skyborne: "مدينة معلقة فوق الغيوم",
                  neon: "المستقبل بعد آخر غروب",
                  temple: "أسرار في أعماق المحيط",
                }[t.id]
              : {
                  skyborne: "A little closer to the impossible.",
                  neon: "Tomorrow has a darker side.",
                  temple: "Let curiosity take you deeper.",
                }[t.id]}
          </p>
        </div>
        <button
          className={"save-world icon-button " + (saved ? "saved" : "")}
          onClick={onSave}
          aria-label={saved ? "Remove from favorites" : "Save world"}
        >
          <Bookmark size={18} fill={saved ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="world-card-footer">
        <span>◉ {ar ? "عالم تفاعلي" : "INTERACTIVE WORLD"}</span>
        <button onClick={onEnter}>
          {ar ? "استكشف" : "Explore"} <ArrowRight size={14} />
        </button>
      </div>
    </article>
  );
}
function AuthModal({
  user,
  setUser,
  onClose,
  notify,
}: {
  user: UserInfo | null;
  setUser: (u: UserInfo | null) => void;
  onClose: () => void;
  notify: (s: string) => void;
}) {
  const [register, setRegister] = useState(false),
    [name, setName] = useState(""),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const r = await api<{ user: UserInfo }>(
        "/api/auth/" + (register ? "register" : "login"),
        {
          method: "POST",
          body: JSON.stringify({
            email,
            password,
            ...(register ? { name } : {}),
          }),
        },
      );
      setUser(r.user);
      notify("Signed in as " + r.user.name);
      onClose();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button
          className="modal-close icon-button"
          aria-label="Close"
          onClick={onClose}
        >
          <X size={18} />
        </button>
        <span className="modal-orb">
          <User size={26} />
        </span>
        {user ? (
          <>
            <span className="tiny-label">YOUR CLOUD IDENTITY</span>
            <h2>{user.name}</h2>
            <p>{user.email}</p>
            <span className="profile-role">{user.role}</span>
            <button
              className="button subtle full"
              onClick={async () => {
                try {
                  await api("/api/auth/logout", { method: "POST" });
                  setUser(null);
                  onClose();
                  notify("Signed out.");
                } catch (e) {
                  notify((e as Error).message);
                }
              }}
            >
              <LogOut size={16} />
              Sign out
            </button>
          </>
        ) : (
          <>
            <span className="tiny-label">YOUR UNIVERSE, CONNECTED</span>
            <h2>
              {register ? "Create your account." : "Welcome back, creator."}
            </h2>
            <form onSubmit={submit}>
              {register && (
                <label>
                  Name
                  <input
                    required
                    maxLength={80}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    autoComplete="name"
                  />
                </label>
              )}
              <label>
                Email
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                />
              </label>
              <label>
                Password
                <input
                  type="password"
                  required
                  minLength={10}
                  maxLength={128}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={register ? "new-password" : "current-password"}
                />
              </label>
              {error && <p className="error-message">{error}</p>}
              <button className="button primary full" disabled={busy}>
                {busy ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <LogIn size={16} />
                )}{" "}
                {register ? "Create account" : "Sign in"}
              </button>
            </form>
            <button
              className="auth-switch"
              onClick={() => setRegister(!register)}
            >
              {register
                ? "Already a creator? Sign in"
                : "New here? Create an account"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
function AdminPanel({
  notify,
  onBack,
}: {
  notify: (s: string) => void;
  onBack: () => void;
}) {
  const [data, setData] = useState<any>(null),
    [error, setError] = useState("");
  const refresh = () =>
    api("/api/admin/overview")
      .then(setData)
      .catch((e) => setError(e.message));
  useEffect(() => {
    refresh();
  }, []);
  return (
    <main className="browse-page">
      <button className="button subtle small" onClick={onBack}>
        <ChevronLeft size={16} />
        Back
      </button>
      <div className="browse-heading">
        <span className="eyebrow">PROTECTED CONTROL ROOM</span>
        <h1>Engine administration.</h1>
        <p>
          Server verified administrator access. No administration credentials
          are stored in the interface.
        </p>
      </div>
      {error ? (
        <div className="error-message">{error}</div>
      ) : data ? (
        <>
          <div className="admin-stats">
            {Object.entries(data.counts).map(([k, v]) => (
              <div key={k}>
                <strong>{String(v)}</strong>
                <span>{k}</span>
              </div>
            ))}
          </div>
          <h3>Content moderation</h3>
          <div className="admin-list">
            {data.worlds.map((w: any) => (
              <article key={w.id}>
                <div>
                  <strong>{w.name}</strong>
                  <p>
                    {w.author.email} · {w.status} · {w.visibility}
                  </p>
                </div>
                <button
                  className="button subtle small"
                  onClick={async () => {
                    try {
                      await api("/api/admin/worlds/" + w.id, {
                        method: "PATCH",
                        body: JSON.stringify({ status: "APPROVED" }),
                      });
                      notify("World approved.");
                      refresh();
                    } catch (e) {
                      notify((e as Error).message);
                    }
                  }}
                >
                  Approve
                </button>
                <button
                  className="button danger small"
                  onClick={async () => {
                    try {
                      await api("/api/admin/worlds/" + w.id, {
                        method: "PATCH",
                        body: JSON.stringify({ status: "REJECTED" }),
                      });
                      notify("World rejected.");
                      refresh();
                    } catch (e) {
                      notify((e as Error).message);
                    }
                  }}
                >
                  Reject
                </button>
              </article>
            ))}
          </div>
          <h3>Users & roles</h3>
          <div className="admin-list">
            {data.users.map((u: any) => (
              <article key={u.id}>
                <strong>
                  {u.name} · {u.email}
                </strong>
                <select
                  value={u.role}
                  onChange={async (e) => {
                    try {
                      await api("/api/admin/users/" + u.id, {
                        method: "PATCH",
                        body: JSON.stringify({ role: e.target.value }),
                      });
                      refresh();
                    } catch (e) {
                      notify((e as Error).message);
                    }
                  }}
                >
                  <option>USER</option>
                  <option>ADMIN</option>
                </select>
              </article>
            ))}
          </div>
          <h3>Activity log</h3>
          <div className="admin-list">
            {data.logs.map((l: any) => (
              <article key={l.id}>
                <span>{l.action}</span>
                <small>{new Date(l.createdAt).toLocaleString()}</small>
              </article>
            ))}
          </div>
          <p className="storage-note">
            AI usage and template counts are included above. Library assets are
            code defined; upload and brand management are future modules.
          </p>
        </>
      ) : (
        <div className="page-loading">
          <Loader2 className="spin" />
          Verifying access…
        </div>
      )}
    </main>
  );
}
