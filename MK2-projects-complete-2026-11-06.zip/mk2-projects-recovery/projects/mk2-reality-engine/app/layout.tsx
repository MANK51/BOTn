import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "MK~2 Reality Engine — Create the extraordinary",
  description:
    "Don’t browse reality. Create it. Explore immersive 3D worlds and build your own universe with MK~2 Reality Engine.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
