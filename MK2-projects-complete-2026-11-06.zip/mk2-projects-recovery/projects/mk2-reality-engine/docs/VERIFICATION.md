# Verification record

Environment: managed Linux, Node 24.19, npm 11.9, Next.js 15.5.27. Date: 2026-10-14.

## Executed checks

| Check                    | Actual result                                                                                                                                                                                                                               |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run typecheck`      | Passed after repairing the browser-test canvas mock typing                                                                                                                                                                                  |
| `npm run build`          | Successful production static export; main route initial JS approximately 135 kB, renderer/editor loaded in separate chunks                                                                                                                  |
| `npm test`               | 12 passing tests: all template schemas, unsafe/unknown data rejection, bounded scene counts, unique IDs, Arabic sharing roundtrip, coordinate/color limits, bilingual composer, undo/redo and bounded history and oversized share transport |
| Basic Playwright run     | 10 passed: five complete workflows in desktop Chromium and touch-enabled iPhone 13 viewport emulation                                                                                                                                       |
| Touch gestures           | 1 mobile check passed: injected touch drag and two-finger pinch changed a rendered Neon Abyss scene; no horizontal overflow                                                                                                                 |
| Camera persistence       | 2 checks passed: orbit view saved as starting camera and verified in exported JSON, desktop and mobile                                                                                                                                      |
| Intro and reduced motion | 2 checks passed: first visit can be skipped, preference is recorded, and reduced motion avoids the automatic intro                                                                                                                          |
| API smoke                | 6 passed: honest health readiness, anonymous administration rejection, anonymous publishing rejection, foreign-origin mutation rejection, safe malformed JSON handling, explicit missing-database response                                  |
| Production preview       | HTTP 200 at local static server; actual browser entry, opening editor, editing, and saving; zero page JavaScript errors and no mobile horizontal overflow                                                                                   |
| Prisma                   | PostgreSQL schema parsed and Prisma client generated successfully                                                                                                                                                                           |

The normal browser workflows enter a real 3D world, open a point of interest, download a screenshot, change an element name/position, undo/redo, save to IndexedDB, reload the page and reopen the saved scene. They also open a portable share URL in another page, apply Arabic local-composer instructions to scene data, switch RTL, and verify editing/saving with WebGL explicitly unavailable.

The touch test ran with reduced motion to verify scene changes from gestures rather than ambient animation. Camera data was checked from the actual exported scene. Thumbnail images were captured from the three rendered worlds. Desktop and 390×844 layouts were visually inspected, including the live editor. Seventeen browser checks passed across the full basic run and targeted compatibility/interaction runs. The desktop copy of the mobile-only touch test is intentionally skipped.

## Fixes verified

- Separate development and production output directories prevent `next dev` / `next build` from interfering.
- Explicit accessible names preserve the mobile editor’s icon-only actions.
- Canvas/asset labels and weather control are accessible to browser automation.
- Intro buttons remain clickable above the actual WebGL layer.
- Camera reset and saved starting views update the actual camera.
- Capture requests without an active WebGL context show an explanation rather than silently doing nothing.
- Preferences tolerate blocked browser storage. Scene IDs have a fallback for browsers without `crypto.randomUUID`.

## Verification limits

- No PostgreSQL connection, OpenAI key or external cloud runtime was supplied. Account creation/session persistence, owner/private world access, database moderation, concurrent likes, AI quota transactions and real provider responses were not integration-tested against those services. API access guards and missing-service responses were executed. These features are included and configurable, but are not activated in the default deployed local mode.
- WebKit 27.2 was downloaded, but could not run because the system lacks GTK4, Graphene, Harfbuzz ICU, Manette, Hyphen and GLES libraries. The environment offers no sudo and its apt indexes did not resolve those packages. No WebKit/Safari test is claimed.
- Mobile checks use Chromium with an iPhone 13 viewport and touch context, not physical iPhone hardware. Real Safari performance, GPU memory/thermals, audio interruptions and iOS keyboard behavior remain to be verified on devices.
- No FPS, Lighthouse score or freeform 3D generation claim is made. Auto quality uses viewport/hardware heuristics; low quality disables bloom and reduces pixel density, stars and particles. Procedural geometry avoids network downloads of model assets.
- Public/private cloud publishing requires account services. Portable links contain the scene data, have no authentication, and do not synchronize updates. The Sites deployment is owner-private.

## Reproduce

```sh
npm install
npm run dev
npm run typecheck
npm test
npm run test:e2e -- --workers=2
# Start optional API separately, then:
npm run test:api
npm run build
WEB_PORT=3001 npm start
```

Browser configuration uses `/usr/bin/chromium`, or `PLAYWRIGHT_CHROMIUM_PATH`. For a WebKit-enabled environment, install Playwright WebKit and its OS dependencies, add a WebKit project, then repeat the core flows. Preserve the distinction between WebKit desktop simulation and actual iOS Safari.
