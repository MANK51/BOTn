# Connecting cloud services

The local engine needs no `.env`. To connect the included API:

1. Provision PostgreSQL. Copy `.env.example` to `.env`, set a real `DATABASE_URL`, and retain secrets only on the server.
2. Run `npm run db:generate` and `npm run db:push` against your intended database. `db:push` is a convenient initial setup; adopt Prisma migrations for production schema changes.
3. Run `npm run server`. `/api/health` reports actual database readiness and whether an AI key is configured.
4. Set `NEXT_PUBLIC_API_URL=http://localhost:4000` in `.env.local` and restart frontend development. The API reads `.env`, not `.env.local`. For deployed builds, set this public URL before building.
5. Register an account through the UI. To enable administration, set `ADMIN_EMAIL` to that registered address and run `npm run db:seed`. Roles are checked server side, and the UI reveals its administration action only after a server-verified ADMIN session.
6. Set `OPENAI_API_KEY` and `OPENAI_MODEL` on the API for AI requests. The editor checks the health endpoint before exposing AI mode. AI requests require a signed-in account and an enabled provider; otherwise the local composer remains available.

Production requires HTTPS and the exact `CLIENT_ORIGIN`. Mutation endpoints require an Origin header that matches. Cross-site session cookies need `SESSION_SAME_SITE=none` and secure cookies; Safari may still block third-party cookies, so prefer a same-site API or reverse proxy. Set `TRUST_PROXY=1` only behind a known single trusted reverse proxy.

## Routes

| Method | Route                                                       | Behavior                                                                                            |
| ------ | ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| GET    | `/api/health`                                               | Honest database/AI readiness                                                                        |
| POST   | `/api/auth/register`, `/api/auth/login`, `/api/auth/logout` | Accounts, secure sessions                                                                           |
| GET    | `/api/auth/me`                                              | Safe current profile, no password hash                                                              |
| GET    | `/api/worlds`                                               | Approved public gallery, 50 latest worlds                                                           |
| POST   | `/api/worlds`                                               | Owner creates/updates validated scene; visibility PUBLIC/PRIVATE; public edits return to moderation |
| GET    | `/api/worlds/:id`                                           | Public-approved or signed-in owner/admin only                                                       |
| DELETE | `/api/worlds/:id`                                           | Owner only                                                                                          |
| GET    | `/api/my/worlds`                                            | Owner cloud records                                                                                 |
| POST   | `/api/worlds/:id/like`, `/api/worlds/:id/favorite`          | Authenticated toggle with visibility checks                                                         |
| POST   | `/api/ai/scene`                                             | Authenticated `{prompt,scene}` to validated `{scene}`                                               |
| GET    | `/api/admin/overview`                                       | ADMIN-only counts, users, worlds, audit log                                                         |
| PATCH  | `/api/admin/worlds/:id`                                     | ADMIN-only moderation status                                                                        |
| PATCH  | `/api/admin/users/:id`                                      | ADMIN-only role change; cannot demote oneself                                                       |

API client errors are shown to users. Private worlds do not become portable private links; cloud sharing uses `#published=<id>` and server access checks. Local portable links always contain the scene and can be read by anyone who has them. No claim is made that hiding remix controls prevents copying public scene data.

AI reservations count provider attempts to cap spend even when providers fail or responses are invalid. PostgreSQL advisory locks serialize allowance reservations per user. Model output must pass the same strict scene schema as local import; it never executes code or generates arbitrary geometry. Database-specific constraints, concurrent publication/toggle behavior, operational quotas and provider integrations need end-to-end testing against the configured services.
