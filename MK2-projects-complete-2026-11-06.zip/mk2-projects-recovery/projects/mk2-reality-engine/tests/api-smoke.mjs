import assert from "node:assert/strict";
const base = process.env.TEST_API_URL || "http://localhost:4000";
const origin = process.env.CLIENT_ORIGIN || "http://localhost:3000";
const tests = [
  [
    "health, honest local readiness",
    async () => {
      const r = await fetch(base + "/api/health");
      assert.equal(r.status, 200);
      const d = await r.json();
      assert.equal(d.ok, true);
      if (!process.env.DATABASE_URL) assert.equal(d.database, false);
    },
  ],
  [
    "anonymous administration rejected",
    async () => {
      assert.equal((await fetch(base + "/api/admin/overview")).status, 401);
    },
  ],
  [
    "anonymous publishing rejected",
    async () => {
      assert.equal(
        (
          await fetch(base + "/api/worlds", {
            method: "POST",
            headers: { Origin: origin, "Content-Type": "application/json" },
            body: "{}",
          })
        ).status,
        401,
      );
    },
  ],
  [
    "cross-origin mutation rejected",
    async () => {
      assert.equal(
        (
          await fetch(base + "/api/auth/logout", {
            method: "POST",
            headers: {
              Origin: "https://untrusted.invalid",
              "Content-Type": "application/json",
            },
            body: "{}",
          })
        ).status,
        403,
      );
    },
  ],
  [
    "invalid JSON handled without a stack trace",
    async () => {
      const r = await fetch(base + "/api/auth/register", {
        method: "POST",
        headers: { Origin: origin, "Content-Type": "application/json" },
        body: "{bad",
      });
      assert.equal(r.status, 400);
      const d = await r.json();
      assert.equal("stack" in d, false);
    },
  ],
  [
    "missing database honestly reported",
    async () => {
      if (process.env.DATABASE_URL) return;
      const r = await fetch(base + "/api/auth/register", {
        method: "POST",
        headers: { Origin: origin, "Content-Type": "application/json" },
        body: "{}",
      });
      assert.equal(r.status, 503);
      assert.match((await r.json()).error, /not configured/);
    },
  ],
];
for (const [name, test] of tests) {
  await test();
  console.log("PASS " + name);
}
console.log(tests.length + " API smoke checks passed.");
