import { test, expect } from "@playwright/test";
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() =>
    location.search.includes("intro-test")
      ? undefined
      : localStorage.setItem("mk2-visited", "1"),
  );
  await page.goto("/");
});
test("explores real geometry, opens a point of interest, and downloads a capture", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Explore the worlds", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Enter Skyborne City", exact: true })
    .click();
  await expect(page.locator("canvas")).toBeVisible();
  await expect(page.locator(".world-top-overlay .viewport-badge")).toHaveText(
    "LIVE WORLD",
  );
  await page.locator(".poi-list button").first().click();
  await expect(page.locator(".poi-popup")).toContainText("Astral Gate");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Capture", exact: true }).click();
  expect((await download).suggestedFilename()).toContain(".png");
});
test("transforms an element, undo/redo, saves to IndexedDB, reloads and reopens", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Create your reality", exact: true })
    .click();
  await page.locator(".object-list button").first().click();
  await page.getByLabel("Element name", { exact: true }).fill("QA Island");
  await page.getByLabel("position X", { exact: true }).fill("4");
  await page.getByRole("button", { name: "Undo", exact: true }).click();
  await page.locator(".object-list button").first().click();
  await expect(page.getByLabel("position X", { exact: true })).toHaveValue("0");
  await page.getByRole("button", { name: "Redo", exact: true }).click();
  await page.locator(".object-list button").first().click();
  await expect(page.getByLabel("position X", { exact: true })).toHaveValue("4");
  await page.getByRole("button", { name: "Save world", exact: true }).click();
  await expect(page.getByRole("status")).toContainText("World saved");
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await expect(page.locator(".project-card")).toHaveCount(1);
  await page.reload();
  await page
    .getByRole("button", { name: "My workspace", exact: false })
    .click();
  await page
    .getByRole("button", { name: "Open in studio", exact: true })
    .click();
  await page.locator(".object-list button").first().click();
  await expect(page.getByLabel("Element name", { exact: true })).toHaveValue(
    "QA Island",
  );
  await expect(page.getByLabel("position X", { exact: true })).toHaveValue("4");
});
test("portable link opens the actual saved scene in a new page", async ({
  page,
  context,
}) => {
  await page
    .getByRole("button", { name: "Create your reality", exact: true })
    .click();
  await page
    .getByLabel("World name", { exact: true })
    .fill("Shared Reality QA");
  await page.getByRole("button", { name: "Share", exact: true }).click();
  await page
    .getByRole("button", { name: "Create portable share link", exact: true })
    .click();
  const url = await page.getByLabel("Share link", { exact: true }).inputValue();
  expect(url).toContain("#world=");
  const other = await context.newPage();
  await other.goto(url);
  await expect(
    other.getByRole("heading", { name: "Shared Reality QA", exact: true }),
  ).toBeVisible();
  await expect(other.locator("canvas")).toBeVisible();
});
test("local bilingual composer edits real scene data and RTL switches correctly", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "Create your reality", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Shape with words", exact: true })
    .click();
  await page
    .locator(".architect-modal textarea")
    .fill("خل السماء برتقالية، وزود الجزر مع مطر خفيف");
  await page
    .getByRole("button", { name: "Compose scene locally", exact: true })
    .click();
  await page.getByRole("button", { name: "Atmosphere", exact: true }).click();
  await expect(page.getByLabel("Sky color", { exact: true })).toHaveValue(
    "#38201c",
  );
  await expect(page.getByLabel("Weather", { exact: true })).toHaveValue("rain");
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await page
    .getByRole("button", { name: "Switch language", exact: true })
    .click();
  await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  await expect(
    page.getByRole("heading", { name: "عالم من صنعك." }),
  ).toBeVisible();
});
test("without WebGL the editor still adds assets and saves", async ({
  page,
}) => {
  await page.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    Object.defineProperty(HTMLCanvasElement.prototype, "getContext", {
      value: function (this: HTMLCanvasElement, type: string, ...args: any[]) {
        if (type === "webgl" || type === "webgl2") return null;
        return original.apply(this, [type, ...args] as any);
      },
    });
  });
  await page.reload();
  await page
    .getByRole("button", { name: "Create your reality", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "WebGL is unavailable" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Energy crystal", exact: true })
    .click();
  await expect(page.locator(".object-list")).toContainText("Crystal");
  await page.getByRole("button", { name: "Save world", exact: true }).click();
  await expect(page.getByRole("status")).toContainText("World saved");
});
test("touch orbit and pinch change the rendered world without horizontal overflow", async ({
  page,
  context,
  isMobile,
}) => {
  test.skip(!isMobile, "Touch gestures run in the mobile project.");
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page
    .getByRole("button", { name: "Explore the worlds", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Enter Neon Abyss", exact: true })
    .click();
  const canvas = page.locator("canvas");
  await expect(canvas).toBeVisible();
  await expect(page.locator(".world-top-overlay .viewport-badge")).toHaveText(
    "LIVE WORLD",
  );
  const before = await canvas.evaluate((c: HTMLCanvasElement) => c.toDataURL());
  const cdp = await context.newCDPSession(page);
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [{ x: 160, y: 290, id: 0 }],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchMove",
    touchPoints: [{ x: 240, y: 310, id: 0 }],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchStart",
    touchPoints: [
      { x: 130, y: 300, id: 0 },
      { x: 250, y: 300, id: 1 },
    ],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchMove",
    touchPoints: [
      { x: 90, y: 300, id: 0 },
      { x: 290, y: 300, id: 1 },
    ],
  });
  await cdp.send("Input.dispatchTouchEvent", {
    type: "touchEnd",
    touchPoints: [],
  });
  await expect
    .poll(() => canvas.evaluate((c: HTMLCanvasElement) => c.toDataURL()))
    .not.toBe(before);
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await cdp.detach();
});
test("orbit camera can become the saved starting view", async ({ page }) => {
  await page
    .getByRole("button", { name: "Create your reality", exact: true })
    .click();
  await expect(page.locator("canvas")).toBeVisible();
  const box = await page.locator("canvas").boundingBox();
  if (!box) throw new Error("No viewport");
  await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width * 0.7, box.y + box.height * 0.55, {
    steps: 12,
  });
  await page.mouse.up();
  await page.getByRole("button", { name: "Atmosphere", exact: true }).click();
  await page
    .getByRole("button", { name: "Set this view as home", exact: true })
    .click();
  const downloading = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export scene", exact: true }).click();
  const file = await (await downloading).path();
  const { readFile } = await import("node:fs/promises");
  const scene = JSON.parse(await readFile(file!, "utf8"));
  expect(scene.camera.position).not.toEqual([11, 6, 14]);
});
test("first visit WebGL intro can be skipped and reduced motion avoids it", async ({
  page,
}) => {
  await page.evaluate(() => localStorage.removeItem("mk2-visited"));
  await page.goto("/?intro-test=1");
  await expect(page.locator(".intro-overlay")).toBeVisible();
  await page.getByRole("button", { name: "Skip intro", exact: true }).click();
  await expect(page.locator(".intro-overlay")).toHaveCount(0);
  expect(await page.evaluate(() => localStorage.getItem("mk2-visited"))).toBe(
    "1",
  );
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.evaluate(() => localStorage.removeItem("mk2-visited"));
  await page.reload();
  await expect(page.locator(".intro-overlay")).toHaveCount(0);
  await expect(page.locator("canvas")).toBeVisible();
});
test("restricted preference storage and missing randomUUID do not prevent editing", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.addInitScript(() => {
    Object.defineProperty(window, "localStorage", {
      get() {
        throw new DOMException("Storage restricted", "SecurityError");
      },
    });
    Object.defineProperty(crypto, "randomUUID", { value: undefined });
  });
  await page.reload();
  await page
    .getByRole("button", { name: "Create your reality", exact: true })
    .click();
  await expect(page.locator(".object-list button").first()).toBeVisible();
  await page
    .getByRole("button", { name: "Energy crystal", exact: true })
    .click();
  await page.getByRole("button", { name: "Save world", exact: true }).click();
  await expect(page.getByRole("status")).toContainText("World saved");
});
