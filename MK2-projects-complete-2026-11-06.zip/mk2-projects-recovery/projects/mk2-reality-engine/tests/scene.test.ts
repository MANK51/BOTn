import { describe, it, expect, beforeEach } from "vitest";
import {
  SceneSchema,
  createScene,
  parsePrompt,
  encodeScene,
  decodeScene,
} from "../lib/scene";
import { useWorldStore } from "../lib/store";
describe("Scene validation and safe sharing", () => {
  it.each(["skyborne", "neon", "temple"] as const)(
    "creates a valid real %s scene",
    (template) => {
      const s = createScene(template);
      expect(SceneSchema.safeParse(s).success).toBe(true);
      expect(s.objects.length).toBeGreaterThan(9);
      expect(s.objects.some((o) => o.kind === "portal")).toBe(true);
    },
  );
  it("rejects executable fields, unknown assets, duplicate IDs, and excessive scenes", () => {
    const s = createScene();
    expect(SceneSchema.safeParse({ ...s, script: "alert(1)" }).success).toBe(
      false,
    );
    expect(
      SceneSchema.safeParse({
        ...s,
        objects: [{ ...s.objects[0], kind: "eval" }],
      }).success,
    ).toBe(false);
    expect(
      SceneSchema.safeParse({ ...s, objects: [s.objects[0], s.objects[0]] })
        .success,
    ).toBe(false);
    expect(
      SceneSchema.safeParse({
        ...s,
        objects: Array.from({ length: 81 }, (_, i) => ({
          ...s.objects[0],
          id: String(i),
        })),
      }).success,
    ).toBe(false);
  });
  it("roundtrips Arabic text without executing content", () => {
    const s = { ...createScene(), name: "عالمي الجديد <script>" };
    expect(decodeScene(encodeScene(s))).toEqual(s);
    expect(() => decodeScene("x".repeat(65001))).toThrow();
    expect(() => decodeScene("broken")).toThrow();
  });
  it("rejects non-finite coordinates and invalid color values", () => {
    const s = createScene();
    s.objects[0].position[0] = Infinity;
    expect(SceneSchema.safeParse(s).success).toBe(false);
    expect(
      SceneSchema.safeParse({
        ...createScene(),
        environment: { ...createScene().environment, sky: "url(javascript:x)" },
      }).success,
    ).toBe(false);
  });
});
describe("Bilingual local composer", () => {
  it("applies Arabic sky, island and rain requests to the actual config", () => {
    const s = createScene();
    const next = parsePrompt(
      "خل السماء برتقالية، وزود الجزر العائمة مع مطر خفيف",
      s,
    );
    expect(next.environment.sky).toBe("#38201c");
    expect(next.environment.weather).toBe("rain");
    expect(next.objects.length).toBe(s.objects.length + 3);
    expect(s.environment.sky).not.toBe(next.environment.sky);
  });
  it("chooses a temple only when composing a new scene", () => {
    expect(parsePrompt("underwater temple").template).toBe("temple");
    expect(parsePrompt("orange sky", createScene("neon")).template).toBe(
      "neon",
    );
  });
  it("never accepts empty input", () =>
    expect(() => parsePrompt("   ")).toThrow());
});
describe("World editing history", () => {
  beforeEach(() => useWorldStore.getState().setScene(createScene(), true));
  it("undoes and redoes a transform without losing a previous scene", () => {
    const store = useWorldStore.getState();
    const id = store.scene.objects[0].id;
    store.updateObject(id, { position: [8, 2, -1] });
    expect(useWorldStore.getState().scene.objects[0].position).toEqual([
      8, 2, -1,
    ]);
    store.undo();
    expect(useWorldStore.getState().scene.objects[0].position).toEqual([
      0, -1, 0,
    ]);
    store.redo();
    expect(useWorldStore.getState().scene.objects[0].position).toEqual([
      8, 2, -1,
    ]);
  });
  it("invalid edits do not enter history and history remains bounded", () => {
    const state = useWorldStore.getState();
    expect(() => state.updateEnvironment({ fog: 7 })).toThrow();
    expect(useWorldStore.getState().history).toHaveLength(0);
    for (let i = 0; i < 45; i++)
      state.updateEnvironment({ intensity: 1 + i / 100 });
    expect(useWorldStore.getState().history).toHaveLength(40);
  });
});

it("does not create an unreadable portable link for a maximum-detail scene", () => {
  const scene = createScene();
  const base = scene.objects[0];
  scene.objects = Array.from({ length: 80 }, (_, i) => ({
    ...base,
    id: String(i),
    name: "n".repeat(80),
    text: "a".repeat(160),
    description: "م".repeat(500),
  }));
  expect(SceneSchema.safeParse(scene).success).toBe(true);
  expect(() => encodeScene(scene)).toThrow(/Export the scene JSON/);
});
