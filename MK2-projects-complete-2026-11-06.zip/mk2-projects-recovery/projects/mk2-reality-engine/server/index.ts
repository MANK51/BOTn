import "dotenv/config";
import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import { randomBytes, createHash } from "node:crypto";
import { PrismaClient, Prisma, Role } from "@prisma/client";
import { z } from "zod";
import { SceneSchema } from "../lib/scene";
const db = new PrismaClient(),
  app = express();
const origin = process.env.CLIENT_ORIGIN || "http://localhost:3000";
const production = process.env.NODE_ENV === "production";
const secure = production || process.env.SESSION_COOKIE_SECURE === "true";
const sameSite = process.env.SESSION_SAME_SITE === "none" ? "none" : "lax";
if (sameSite === "none" && !secure)
  throw new Error(
    "Cross-site cookies require HTTPS and SESSION_COOKIE_SECURE=true.",
  );
const cookieOptions = {
  httpOnly: true,
  secure,
  sameSite: sameSite as "lax" | "none",
  path: "/api",
  maxAge: 7 * 24 * 60 * 60 * 1000,
};
if (process.env.TRUST_PROXY === "1") app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin, credentials: true }));
app.use(express.json({ limit: "150kb" }));
app.use(cookieParser());
app.use(
  "/api",
  rateLimit({
    windowMs: 60000,
    limit: 100,
    standardHeaders: "draft-8",
    legacyHeaders: false,
  }),
);
app.use("/api", (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  if (
    !["GET", "HEAD", "OPTIONS"].includes(req.method) &&
    req.headers.origin !== origin
  )
    return res.status(403).json({ error: "Request origin is not allowed." });
  next();
});
const hash = (s: string) => createHash("sha256").update(s).digest("hex");
type AuthRequest = Request & {
  actor?: { id: string; email: string; name: string; role: Role };
};
const safeUser = (u: {
  id: string;
  email: string;
  name: string;
  role: Role;
}) => ({ id: u.id, email: u.email, name: u.name, role: u.role });
const handler =
  (
    f: (
      req: AuthRequest,
      res: Response,
      next: NextFunction,
    ) => Promise<unknown>,
  ) =>
  (req: Request, res: Response, next: NextFunction) =>
    Promise.resolve(f(req as AuthRequest, res, next)).catch(next);
const needDb = (req: Request, res: Response, next: NextFunction) =>
  process.env.DATABASE_URL
    ? next()
    : res
        .status(503)
        .json({
          error:
            "Cloud database is not configured. Local editing and portable sharing remain available.",
        });
const optionalAuth = handler(async (req, res, next) => {
  const token = req.cookies?.mk2_session;
  if (typeof token === "string" && token.length === 64) {
    const s = await db.session.findUnique({
      where: { tokenHash: hash(token) },
      include: { user: true },
    });
    if (s && s.expiresAt > new Date()) req.actor = safeUser(s.user);
  }
  next();
});
const auth = handler(async (req, res, next) => {
  if (!req.cookies?.mk2_session)
    return res
      .status(401)
      .json({ error: "Sign in to use this cloud feature." });
  if (!process.env.DATABASE_URL)
    return res.status(503).json({ error: "Cloud database is not configured." });
  await new Promise<void>((resolve, reject) =>
    optionalAuth(req, res, (e) => (e ? reject(e) : resolve())),
  );
  if (!req.actor)
    return res
      .status(401)
      .json({ error: "Your session has expired. Sign in again." });
  next();
});
const admin = (req: AuthRequest, res: Response, next: NextFunction) =>
  req.actor?.role === "ADMIN"
    ? next()
    : res.status(403).json({ error: "Administrator access required." });
const authLimit = rateLimit({
  windowMs: 15 * 60000,
  limit: 20,
  standardHeaders: "draft-8",
  legacyHeaders: false,
});
async function audit(actorId: string, action: string, targetId?: string) {
  await db.auditLog.create({ data: { actorId, action, targetId } });
}
async function newSession(res: Response, userId: string) {
  const token = randomBytes(32).toString("hex");
  await db.session.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  await db.session.create({
    data: {
      userId,
      tokenHash: hash(token),
      expiresAt: new Date(Date.now() + cookieOptions.maxAge),
    },
  });
  res.cookie("mk2_session", token, cookieOptions);
}
app.get(
  "/api/health",
  handler(async (req, res) => {
    let database = false;
    if (process.env.DATABASE_URL)
      try {
        await db.$queryRaw`SELECT 1`;
        database = true;
      } catch {}
    res.json({
      ok: true,
      database,
      ai: database && !!process.env.OPENAI_API_KEY,
      mode: database ? "cloud" : "local",
      templates: 3,
    });
  }),
);
const credentials = z
  .object({
    email: z
      .string()
      .email()
      .max(254)
      .transform((v) => v.trim().toLowerCase()),
    password: z.string().min(10).max(128),
  })
  .strict();
app.post(
  "/api/auth/register",
  authLimit,
  needDb,
  handler(async (req, res) => {
    const input = credentials
      .extend({ name: z.string().trim().min(1).max(80) })
      .parse(req.body);
    const passwordHash = await bcrypt.hash(input.password, 12);
    const user = await db.user.create({
      data: { email: input.email, name: input.name, passwordHash },
    });
    await newSession(res, user.id);
    await audit(user.id, "ACCOUNT_REGISTERED");
    res.status(201).json({ user: safeUser(user) });
  }),
);
app.post(
  "/api/auth/login",
  authLimit,
  needDb,
  handler(async (req, res) => {
    const input = credentials.parse(req.body);
    const user = await db.user.findUnique({ where: { email: input.email } });
    const valid = await bcrypt.compare(
      input.password,
      user?.passwordHash ||
        "$2b$12$zTbMxOzcnK5wJGr7/ueePeAzMEfyidwdCZAZLfziXFhRZfi5rzmai",
    );
    if (!user || !valid)
      return res.status(401).json({ error: "Email or password is incorrect." });
    if (req.cookies?.mk2_session)
      await db.session.deleteMany({
        where: { tokenHash: hash(req.cookies.mk2_session) },
      });
    await newSession(res, user.id);
    await audit(user.id, "ACCOUNT_LOGIN");
    res.json({ user: safeUser(user) });
  }),
);
app.post(
  "/api/auth/logout",
  handler(async (req, res) => {
    if (
      process.env.DATABASE_URL &&
      typeof req.cookies?.mk2_session === "string"
    )
      await db.session.deleteMany({
        where: { tokenHash: hash(req.cookies.mk2_session) },
      });
    res.clearCookie("mk2_session", {
      httpOnly: true,
      secure,
      sameSite,
      path: "/api",
    });
    res.json({ ok: true });
  }),
);
app.get(
  "/api/auth/me",
  handler(async (req, res) => {
    if (!process.env.DATABASE_URL) return res.json({ user: null });
    await new Promise<void>((resolve, reject) =>
      optionalAuth(req, res, (e) => (e ? reject(e) : resolve())),
    );
    res.json({ user: req.actor || null });
  }),
);
app.get(
  "/api/worlds",
  needDb,
  handler(async (req, res) => {
    const worlds = await db.world.findMany({
      where: { visibility: "PUBLIC", status: "APPROVED" },
      orderBy: { updatedAt: "desc" },
      take: 50,
      select: {
        id: true,
        name: true,
        scene: true,
        author: { select: { name: true } },
        _count: { select: { likes: true } },
      },
    });
    res.json({ worlds });
  }),
);
app.get(
  "/api/my/worlds",
  auth,
  handler(async (req, res) => {
    res.json({
      worlds: await db.world.findMany({
        where: { authorId: req.actor!.id },
        orderBy: { updatedAt: "desc" },
        take: 100,
      }),
    });
  }),
);
const accessible = async (
  id: string,
  actorId?: string,
  adminAccess = false,
) => {
  const world = await db.world.findUnique({ where: { id } });
  if (!world) return null;
  if (
    world.authorId === actorId ||
    adminAccess ||
    (world.visibility === "PUBLIC" && world.status === "APPROVED")
  )
    return world;
  return null;
};
app.get(
  "/api/worlds/:id",
  needDb,
  optionalAuth,
  handler(async (req, res) => {
    const w = await accessible(
      String(req.params.id),
      req.actor?.id,
      req.actor?.role === "ADMIN",
    );
    if (!w)
      return res
        .status(404)
        .json({ error: "World not found or access is restricted." });
    const world = await db.world.findUnique({
      where: { id: w.id },
      include: {
        author: { select: { name: true } },
        _count: { select: { likes: true } },
      },
    });
    res.json({ world });
  }),
);
app.post(
  "/api/worlds",
  auth,
  handler(async (req, res) => {
    const input = z
      .object({ scene: SceneSchema, visibility: z.enum(["PUBLIC", "PRIVATE"]) })
      .strict()
      .parse(req.body);
    const old = await db.world.findUnique({ where: { id: input.scene.id } });
    if (old && old.authorId !== req.actor!.id)
      return res
        .status(403)
        .json({
          error:
            "You cannot update someone else’s world. Create a remix with a new ID.",
        });
    const data = {
      name: input.scene.name,
      scene: input.scene as unknown as Prisma.InputJsonValue,
      visibility: input.visibility,
      status: "PENDING" as const,
    };
    const world = old
      ? await db.world.update({ where: { id: old.id }, data })
      : await db.world.create({
          data: { ...data, id: input.scene.id, authorId: req.actor!.id },
        });
    await audit(req.actor!.id, "WORLD_SAVED", world.id);
    res.status(old ? 200 : 201).json({ world });
  }),
);
app.delete(
  "/api/worlds/:id",
  auth,
  handler(async (req, res) => {
    const world = await db.world.findUnique({
      where: { id: String(req.params.id) },
    });
    if (!world || world.authorId !== req.actor!.id)
      return res.status(404).json({ error: "World not found." });
    await db.world.delete({ where: { id: world.id } });
    await audit(req.actor!.id, "WORLD_DELETED", world.id);
    res.json({ ok: true });
  }),
);
app.post(
  "/api/worlds/:id/like",
  auth,
  handler(async (req, res) => {
    const w = await accessible(String(req.params.id), req.actor!.id);
    if (!w) return res.status(404).json({ error: "World not found." });
    const key = { userId: req.actor!.id, worldId: w.id };
    const old = await db.like.findUnique({ where: { userId_worldId: key } });
    if (old) await db.like.delete({ where: { userId_worldId: key } });
    else await db.like.create({ data: key });
    res.json({ liked: !old });
  }),
);
app.post(
  "/api/worlds/:id/favorite",
  auth,
  handler(async (req, res) => {
    const w = await accessible(String(req.params.id), req.actor!.id);
    if (!w) return res.status(404).json({ error: "World not found." });
    const key = { userId: req.actor!.id, worldId: w.id };
    const old = await db.favorite.findUnique({
      where: { userId_worldId: key },
    });
    if (old) await db.favorite.delete({ where: { userId_worldId: key } });
    else await db.favorite.create({ data: key });
    res.json({ saved: !old });
  }),
);
const aiLimit = rateLimit({
  windowMs: 60000,
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
});
app.post(
  "/api/ai/scene",
  auth,
  aiLimit,
  handler(async (req, res) => {
    if (!process.env.OPENAI_API_KEY)
      return res
        .status(503)
        .json({
          error: "AI is not configured. Set OPENAI_API_KEY on the server.",
        });
    const input = z
      .object({
        prompt: z.string().trim().min(1).max(2000),
        scene: SceneSchema,
      })
      .strict()
      .parse(req.body);
    const daily = Math.min(
      100,
      Math.max(1, Number(process.env.AI_DAILY_LIMIT) || 20),
    );
    const start = new Date();
    start.setUTCHours(0, 0, 0, 0);
    // A per-user transaction lock reserves allowance before calling the provider.
    const reservation = await db.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${req.actor!.id}))`;
      const count = await tx.aIUsage.count({
        where: { userId: req.actor!.id, createdAt: { gte: start } },
      });
      if (count >= daily) return null;
      return tx.aIUsage.create({ data: { userId: req.actor!.id } });
    });
    if (!reservation)
      return res
        .status(429)
        .json({ error: "Your daily AI allowance has been reached." });
    const description =
      "Return only a JSON object with key scene. Modify the supplied SceneConfig according to the user prompt. Scene shape: version 1,id,name,template skyborne|neon|temple, environment {sky hex6,accent hex6,intensity .1..3,fog 0...08,particles boolean,weather clear|rain},camera {position:[x,y,z]},objects [{id,kind island|tower|portal|crystal|tree|temple|text,name,position:[x,y,z],rotation:[x,y,z],scale:[x,y,z],color hex6,text optional,description optional}],allowRemix boolean. Max 80 objects. Numeric coordinates -100..100, scales .1..10. Unique object IDs. Keep scene ID/version/allowRemix. No code, URLs, scripts, or new asset kinds. This config places prebuilt assets; you cannot generate new freeform 3D models.";
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + process.env.OPENAI_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        messages: [
          { role: "system", content: description },
          { role: "user", content: JSON.stringify(input) },
        ],
        response_format: { type: "json_object" },
        temperature: 0.5,
        max_tokens: 12000,
      }),
      signal: AbortSignal.timeout(45000),
    });
    if (!response.ok)
      return res
        .status(502)
        .json({
          error: "The AI provider could not complete the request. Try later.",
        });
    const result: any = await response.json();
    let scene;
    try {
      scene = SceneSchema.parse(
        JSON.parse(result.choices?.[0]?.message?.content || "").scene,
      );
    } catch {
      return res
        .status(502)
        .json({
          error:
            "The AI response failed scene validation. Your world was not changed.",
        });
    }
    scene.id = input.scene.id;
    scene.allowRemix = input.scene.allowRemix;
    await audit(req.actor!.id, "AI_SCENE_COMPOSED", scene.id);
    res.json({ scene });
  }),
);
app.get(
  "/api/admin/overview",
  auth,
  admin,
  handler(async (req, res) => {
    const [usersCount, worldsCount, pending, aiRequests, users, worlds, logs] =
      await Promise.all([
        db.user.count(),
        db.world.count(),
        db.world.count({ where: { status: "PENDING" } }),
        db.aIUsage.count(),
        db.user.findMany({
          take: 100,
          orderBy: { createdAt: "desc" },
          select: { id: true, email: true, name: true, role: true },
        }),
        db.world.findMany({
          take: 100,
          orderBy: { updatedAt: "desc" },
          include: { author: { select: { email: true } } },
        }),
        db.auditLog.findMany({ take: 100, orderBy: { createdAt: "desc" } }),
      ]);
    res.json({
      counts: {
        users: usersCount,
        worlds: worldsCount,
        pending,
        aiRequests,
        templates: 3,
        assets: 7,
      },
      users,
      worlds,
      logs,
    });
  }),
);
app.patch(
  "/api/admin/worlds/:id",
  auth,
  admin,
  handler(async (req, res) => {
    const { status } = z
      .object({ status: z.enum(["PENDING", "APPROVED", "REJECTED"]) })
      .strict()
      .parse(req.body);
    await db.world.update({
      where: { id: String(req.params.id) },
      data: { status },
    });
    await audit(req.actor!.id, "WORLD_" + status, String(req.params.id));
    res.json({ ok: true });
  }),
);
app.patch(
  "/api/admin/users/:id",
  auth,
  admin,
  handler(async (req, res) => {
    const { role } = z
      .object({ role: z.enum(["USER", "ADMIN"]) })
      .strict()
      .parse(req.body);
    if (req.params.id === req.actor!.id && role === "USER")
      return res
        .status(400)
        .json({ error: "You cannot remove your own administrator role." });
    await db.user.update({
      where: { id: String(req.params.id) },
      data: { role },
    });
    await audit(req.actor!.id, "ROLE_" + role, String(req.params.id));
    res.json({ ok: true });
  }),
);
app.use((err: unknown, req: Request, res: Response, next: NextFunction) => {
  if (res.headersSent) return next(err);
  if (err instanceof z.ZodError)
    return res
      .status(400)
      .json({
        error: "Invalid request data.",
        issues: err.issues.map((i) => ({ path: i.path, message: i.message })),
      });
  if (
    err instanceof Prisma.PrismaClientKnownRequestError &&
    err.code === "P2002"
  )
    return res
      .status(409)
      .json({
        error: "An account or resource with these details already exists.",
      });
  if (err instanceof SyntaxError)
    return res.status(400).json({ error: "Invalid JSON request." });
  console.error(
    "API request failed:",
    req.method,
    req.path,
    err instanceof Error ? err.name : "UnknownError",
  );
  res
    .status(503)
    .json({
      error:
        "The service is temporarily unavailable. Your local world is safe.",
    });
});
const port = Number(process.env.API_PORT) || 4000;
app.listen(port, "0.0.0.0", () =>
  console.log(
    `MK~2 API ready on port ${port}. Database and AI require environment configuration.`,
  ),
);
const shutdown = () => {
  db.$disconnect().finally(() => process.exit(0));
};
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
