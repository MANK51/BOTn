import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { resolve, extname, join, sep } from "node:path";
const root = resolve("out"),
  port = Number(process.env.WEB_PORT) || 3000;
const mime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css",
  ".js": "text/javascript",
  ".json": "application/json",
  ".txt": "text/plain; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".webp": "image/webp",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".ico": "image/x-icon",
};
const server = createServer(async (req, res) => {
  try {
    if (!["GET", "HEAD"].includes(req.method)) {
      res.writeHead(405);
      return res.end();
    }
    const url = new URL(req.url, "http://localhost");
    let path = resolve(root, "." + decodeURIComponent(url.pathname));
    if (path !== root && !path.startsWith(root + sep)) {
      res.writeHead(403);
      return res.end();
    }
    const info = await stat(path).catch(() => null);
    if (info?.isDirectory()) path = join(path, "index.html");
    let body;
    try {
      body = await readFile(path);
    } catch {
      body = await readFile(join(root, "404.html"));
      res.statusCode = 404;
      path = "404.html";
    }
    res.setHeader(
      "Content-Type",
      mime[extname(path)] || "application/octet-stream",
    );
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader(
      "Cache-Control",
      path.includes("_next/static")
        ? "public, max-age=31536000, immutable"
        : "no-cache",
    );
    res.end(req.method === "HEAD" ? undefined : body);
  } catch {
    res.statusCode = 400;
    res.end("Invalid request.");
  }
});
server.listen(port, "0.0.0.0", () =>
  console.log(`MK~2 static production preview: http://localhost:${port}`),
);
