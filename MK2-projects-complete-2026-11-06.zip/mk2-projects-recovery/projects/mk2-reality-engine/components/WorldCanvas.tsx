"use client";
import React, { Suspense, useMemo, useRef, useEffect, useState } from "react";
import { Canvas, useFrame, useThree, ThreeEvent } from "@react-three/fiber";
import { OrbitControls, Stars, Html } from "@react-three/drei";
import { EffectComposer, Bloom } from "@react-three/postprocessing";
import * as THREE from "three";
import { SceneConfig, SceneObject } from "@/lib/scene";
export type WorldCanvasProps = {
  scene: SceneConfig;
  hero?: boolean;
  intro?: boolean;
  selectedId?: string | null;
  onSelect?: (id: string) => void;
  onReady?: () => void;
  captureRef?: React.MutableRefObject<(() => void) | null>;
  cameraRef?: React.MutableRefObject<(() => [number, number, number]) | null>;
  reducedMotion?: boolean;
  quality?: "auto" | "low" | "high";
};
function Glow({
  color,
  size = 5,
  position = [0, 0, 0],
}: {
  color: string;
  size?: number;
  position?: [number, number, number];
}) {
  const material = useMemo(
    () =>
      new THREE.ShaderMaterial({
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        uniforms: { color: { value: new THREE.Color(color) } },
        vertexShader:
          "varying vec2 vUv; void main(){ vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.); }",
        fragmentShader:
          "uniform vec3 color; varying vec2 vUv; void main(){float d=length(vUv-.5)*2.; float a=pow(max(0.,1.-d),3.)*.7; gl_FragColor=vec4(color,a); }",
      }),
    [color],
  );
  useEffect(() => () => material.dispose(), [material]);
  return (
    <mesh position={position} material={material}>
      <planeGeometry args={[size, size]} />
    </mesh>
  );
}
function Portal({ color, motion }: { color: string; motion: boolean }) {
  const g = useRef<THREE.Group>(null);
  useFrame((s, dt) => {
    if (g.current && motion) g.current.rotation.z += dt * 0.045;
  });
  return (
    <group>
      <Glow color={color} size={8} />
      <Glow color="#ffb478" size={3.1} position={[0, 0, -0.03]} />
      <mesh>
        <torusGeometry args={[1.55, 0.045, 12, 100]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
      <mesh position={[0, 0, -0.02]}>
        <torusGeometry args={[1.65, 0.017, 8, 100]} />
        <meshBasicMaterial color="#e7d9ff" toneMapped={false} />
      </mesh>
      <mesh position={[0, 0, 0.01]}>
        <torusGeometry args={[1.4, 0.012, 8, 100]} />
        <meshBasicMaterial color={color} />
      </mesh>
      <group ref={g}>
        {Array.from({ length: 40 }, (_, i) => (
          <mesh
            key={i}
            position={[
              Math.cos((i / 40) * Math.PI * 2) * 1.77,
              Math.sin((i / 40) * Math.PI * 2) * 1.77,
              0,
            ]}
            rotation={[0, 0, (i / 40) * Math.PI * 2]}
          >
            <boxGeometry args={[0.055, i % 5 === 0 ? 0.16 : 0.07, 0.035]} />
            <meshBasicMaterial color={i % 5 === 0 ? "#f4f0ff" : color} />
          </mesh>
        ))}
      </group>
      <pointLight color={color} intensity={8} distance={11} />
    </group>
  );
}
function Island({ color }: { color: string }) {
  return (
    <group>
      <mesh position={[0, -0.13, 0]}>
        <cylinderGeometry args={[1.35, 1.1, 0.38, 9]} />
        <meshStandardMaterial color={color} roughness={0.86} />
      </mesh>
      <mesh position={[0, -1.05, 0]} rotation={[0, 0.3, Math.PI]}>
        <coneGeometry args={[1.15, 1.9, 7]} />
        <meshStandardMaterial color={color} roughness={0.96} />
      </mesh>
      {Array.from({ length: 8 }, (_, i) => (
        <mesh
          key={i}
          position={[Math.cos(i * 0.8) * 1.05, -0.55, Math.sin(i * 0.8) * 1.05]}
          rotation={[i * 0.7, 0.4, i * 0.3]}
        >
          <dodecahedronGeometry args={[0.4, 0]} />
          <meshStandardMaterial
            color={i % 2 ? "#363248" : color}
            roughness={1}
          />
        </mesh>
      ))}
      <mesh position={[0, 0.08, 0]}>
        <cylinderGeometry args={[1.32, 1.32, 0.07, 9]} />
        <meshStandardMaterial color="#67747b" roughness={1} />
      </mesh>
    </group>
  );
}
function Tower({ color, accent }: { color: string; accent: string }) {
  return (
    <group>
      <mesh position={[0, 1.1, 0]}>
        <boxGeometry args={[0.68, 2.2, 0.68]} />
        <meshStandardMaterial color={color} metalness={0.3} roughness={0.6} />
      </mesh>
      <mesh position={[0, 2.5, 0]}>
        <coneGeometry args={[0.6, 0.8, 4]} />
        <meshStandardMaterial color="#403950" metalness={0.5} />
      </mesh>
      <mesh position={[0, 3.12, 0]}>
        <cylinderGeometry args={[0.015, 0.05, 0.6, 6]} />
        <meshBasicMaterial color={accent} />
      </mesh>
      {Array.from({ length: 6 }, (_, i) => (
        <group key={i}>
          <mesh position={[0, 0.3 + i * 0.32, 0.347]}>
            <boxGeometry args={[0.08, 0.16, 0.012]} />
            <meshBasicMaterial
              color={i % 2 ? "#ffcda4" : accent}
              toneMapped={false}
            />
          </mesh>
          <mesh position={[0.347, 0.3 + i * 0.32, 0]}>
            <boxGeometry args={[0.012, 0.16, 0.08]} />
            <meshBasicMaterial color={accent} />
          </mesh>
        </group>
      ))}
      <mesh position={[0, 0.06, 0]}>
        <boxGeometry args={[1, 0.12, 1]} />
        <meshStandardMaterial color="#6a6882" />
      </mesh>
    </group>
  );
}
function Temple({ color }: { color: string }) {
  return (
    <group>
      {[-1, 1].flatMap((x) =>
        [-1, 1].map((z) => (
          <mesh key={`${x}${z}`} position={[x, 0.9, z]}>
            <cylinderGeometry args={[0.17, 0.22, 1.8, 10]} />
            <meshStandardMaterial color={color} roughness={0.9} />
          </mesh>
        )),
      )}
      <mesh position={[0, 1.85, 0]}>
        <boxGeometry args={[2.7, 0.25, 2.7]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[0, 2.2, 0]} rotation={[0, Math.PI / 4, 0]}>
        <coneGeometry args={[2, 0.6, 4]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[3, 0.2, 3]} />
        <meshStandardMaterial color={color} />
      </mesh>
    </group>
  );
}
function SceneElement({
  object,
  accent,
  selected,
  onSelect,
  motion,
}: {
  object: SceneObject;
  accent: string;
  selected: boolean;
  onSelect?: (id: string) => void;
  motion: boolean;
}) {
  const stop = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    onSelect?.(object.id);
  };
  return (
    <group
      position={object.position}
      rotation={object.rotation}
      scale={object.scale}
      onClick={stop}
      onPointerOver={(e) => {
        if (onSelect) {
          e.stopPropagation();
          document.body.style.cursor = "pointer";
        }
      }}
      onPointerOut={() => {
        document.body.style.cursor = "auto";
      }}
    >
      {object.kind === "island" && <Island color={object.color} />}
      {object.kind === "tower" && (
        <Tower color={object.color} accent={accent} />
      )}
      {object.kind === "portal" && (
        <Portal color={object.color} motion={motion} />
      )}
      {object.kind === "temple" && <Temple color={object.color} />}
      {object.kind === "crystal" && (
        <group>
          <mesh position={[0, 0.5, 0]}>
            <octahedronGeometry args={[0.7, 0]} />
            <meshStandardMaterial
              color={object.color}
              emissive={object.color}
              emissiveIntensity={0.6}
              metalness={0.5}
              roughness={0.15}
            />
          </mesh>
          <pointLight color={object.color} intensity={1.2} distance={4} />
        </group>
      )}
      {object.kind === "tree" && (
        <group>
          <mesh position={[0, 0.55, 0]}>
            <cylinderGeometry args={[0.08, 0.15, 1.1, 6]} />
            <meshStandardMaterial color="#5a4140" />
          </mesh>
          {[0, 1, 2].map((i) => (
            <mesh key={i} position={[0, 1 + i * 0.3, 0]}>
              <coneGeometry args={[0.7 - i * 0.17, 0.8, 7]} />
              <meshStandardMaterial color={object.color} />
            </mesh>
          ))}
        </group>
      )}
      {object.kind === "text" && (
        <Html center>
          <span className="world-label">{object.text || object.name}</span>
        </Html>
      )}
      {selected && (
        <mesh position={[0, 0.4, 0]}>
          <boxGeometry args={[2, 2, 2]} />
          <meshBasicMaterial
            color="#30DFFF"
            wireframe
            transparent
            opacity={0.5}
          />
        </mesh>
      )}
    </group>
  );
}
function Particles({
  rain,
  motion,
  color,
  low,
}: {
  rain: boolean;
  motion: boolean;
  color: string;
  low: boolean;
}) {
  const ref = useRef<THREE.Points>(null);
  const positions = useMemo(() => {
    const count = low ? 160 : 550;
    const p = new Float32Array(count * 3);
    let seed = 123;
    const rand = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < p.length; i += 3) {
      p[i] = (rand() - 0.5) * 40;
      p[i + 1] = rand() * 18 - 5;
      p[i + 2] = (rand() - 0.5) * 30;
    }
    return p;
  }, [low]);
  useFrame((s, dt) => {
    if (!motion || !ref.current) return;
    ref.current.rotation.y += dt * 0.008;
    ref.current.position.x = THREE.MathUtils.lerp(
      ref.current.position.x,
      s.pointer.x * 0.5,
      0.02,
    );
    ref.current.position.y = THREE.MathUtils.lerp(
      ref.current.position.y,
      s.pointer.y * 0.25,
      0.02,
    );
    if (rain) {
      const a = ref.current.geometry.attributes.position.array as Float32Array;
      for (let i = 1; i < a.length; i += 3) {
        a[i] -= dt * 5;
        if (a[i] < -5) a[i] = 13;
      }
      ref.current.geometry.attributes.position.needsUpdate = true;
    }
  });
  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={rain ? 0.035 : 0.045}
        color={color}
        transparent
        opacity={0.65}
        depthWrite={false}
      />
    </points>
  );
}
function Scene({
  scene,
  hero,
  intro,
  selectedId,
  onSelect,
  onReady,
  captureRef,
  cameraRef,
  reducedMotion,
  low,
}: WorldCanvasProps & { low: boolean }) {
  const { gl, camera } = useThree();
  const motion = !reducedMotion;
  const controlsRef = useRef<any>(null);
  useEffect(() => {
    if (cameraRef)
      cameraRef.current = () =>
        camera.position.toArray() as [number, number, number];
    return () => {
      if (cameraRef) cameraRef.current = null;
    };
  }, [camera, cameraRef]);
  useFrame((state, dt) => {
    if (intro && motion) {
      camera.position.z = Math.max(5.8, camera.position.z - dt * 0.65);
      camera.position.x = THREE.MathUtils.lerp(
        camera.position.x,
        state.pointer.x * 0.45,
        0.035,
      );
      camera.lookAt(0, 0, 0);
    }
  });
  useEffect(() => {
    onReady?.();
    if (captureRef)
      captureRef.current = () => {
        const link = document.createElement("a");
        link.href = gl.domElement.toDataURL("image/png");
        link.download = "MK2-" + scene.name + ".png";
        link.click();
      };
    return () => {
      if (captureRef) captureRef.current = null;
    };
  }, [gl, camera, onReady, captureRef, scene.name]);
  useEffect(() => {
    camera.position.set(
      ...(hero
        ? ([8, 4.3, 13] as [number, number, number])
        : scene.camera.position),
    );
    controlsRef.current?.target.set(0, 1, 0);
    controlsRef.current?.update();
  }, [scene.template, scene.camera.position, hero, camera]);
  return (
    <>
      <color attach="background" args={[scene.environment.sky]} />
      <fogExp2
        attach="fog"
        args={[scene.environment.sky, scene.environment.fog]}
      />
      <ambientLight intensity={scene.environment.intensity * 0.7} />
      <directionalLight
        position={[3, 10, 5]}
        color={scene.template === "temple" ? "#a0ffed" : "#ffdac0"}
        intensity={scene.environment.intensity * 2}
      />
      <directionalLight
        position={[-6, 3, -5]}
        color={scene.environment.accent}
        intensity={2}
      />
      <Stars
        radius={60}
        depth={20}
        count={low ? 350 : 1400}
        factor={2}
        saturation={0.3}
        fade
        speed={motion ? 0.2 : 0}
      />
      <Glow
        color={
          scene.template === "skyborne" ? "#ffad79" : scene.environment.accent
        }
        size={35}
        position={[2, 3, -12]}
      />
      <Glow color="#a06bff" size={25} position={[-12, 6, -15]} />
      {scene.objects.map((o) => (
        <SceneElement
          key={o.id}
          object={o}
          accent={scene.environment.accent}
          selected={selectedId === o.id}
          onSelect={onSelect}
          motion={motion}
        />
      ))}
      {scene.environment.particles && (
        <Particles
          rain={scene.environment.weather === "rain"}
          motion={motion}
          color={scene.environment.accent}
          low={low}
        />
      )}
      {scene.template === "skyborne" &&
        Array.from({ length: 14 }, (_, i) => (
          <mesh
            key={i}
            position={[
              ((i % 5) - 2) * 5,
              -3.4 + Math.sin(i) * 0.5,
              Math.floor(i / 5) * 5 - 4,
            ]}
            scale={[4, 0.7, 2]}
          >
            <sphereGeometry args={[1, 12, 8]} />
            <meshStandardMaterial
              color="#b3a2bb"
              transparent
              opacity={0.16}
              depthWrite={false}
            />
          </mesh>
        ))}
      {scene.template === "temple" && (
        <mesh position={[0, -2.8, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[70, 70]} />
          <meshStandardMaterial color="#12363b" roughness={1} />
        </mesh>
      )}
      {!low && (
        <EffectComposer multisampling={0}>
          <Bloom
            intensity={0.55}
            luminanceThreshold={0.85}
            luminanceSmoothing={0.3}
            mipmapBlur
          />
        </EffectComposer>
      )}
      <OrbitControls
        ref={controlsRef}
        target={[0, 1, 0]}
        enabled={!intro}
        enablePan={!hero}
        enableZoom={!hero}
        enableRotate={!hero}
        autoRotate={hero && motion}
        autoRotateSpeed={0.25}
        minDistance={4}
        maxDistance={38}
        maxPolarAngle={Math.PI * 0.88}
        enableDamping
        dampingFactor={0.065}
      />
    </>
  );
}
class CanvasBoundary extends React.Component<
  { children: React.ReactNode; scene: SceneConfig },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? (
      <div className="webgl-fallback">
        <span>◈</span>
        <h3>Your universe, in light mode.</h3>
        <p>
          3D rendering is unavailable on this device. All editor controls and
          local saving still work.
        </p>
        <div style={{ background: this.props.scene.environment.sky }}>
          {this.props.scene.objects.slice(0, 12).map((o) => (
            <span key={o.id} style={{ color: o.color }}>
              {o.kind === "portal" ? "◎" : "◇"} {o.name}
            </span>
          ))}
        </div>
      </div>
    ) : (
      this.props.children
    );
  }
}
export default function WorldCanvas(props: WorldCanvasProps) {
  const [supported, setSupported] = useState<boolean | null>(null);
  const low =
    props.quality === "low" ||
    (props.quality !== "high" &&
      typeof window !== "undefined" &&
      (window.innerWidth < 768 || navigator.hardwareConcurrency <= 4));
  useEffect(() => {
    try {
      const c = document.createElement("canvas");
      const ctx = c.getContext("webgl2") || c.getContext("webgl");
      setSupported(!!ctx);
      (ctx as WebGLRenderingContext | null)
        ?.getExtension("WEBGL_lose_context")
        ?.loseContext();
    } catch {
      setSupported(false);
    }
  }, []);
  if (supported === null)
    return (
      <div className="canvas-loading">
        <span className="loading-ring" />
        <span>Preparing the render engine…</span>
      </div>
    );
  return (
    <CanvasBoundary scene={props.scene}>
      {supported ? (
        <Canvas
          dpr={low ? 1 : [1, 1.6]}
          camera={{
            position: props.hero ? [8, 4.3, 13] : props.scene.camera.position,
            fov: props.hero ? 44 : 50,
          }}
          gl={{
            antialias: !low,
            alpha: false,
            powerPreference: low ? "low-power" : "high-performance",
            preserveDrawingBuffer: true,
          }}
          frameloop={props.reducedMotion ? "demand" : "always"}
        >
          <Suspense fallback={null}>
            <Scene {...props} low={low} />
          </Suspense>
        </Canvas>
      ) : (
        <div className="webgl-fallback">
          <span>◈</span>
          <h3>WebGL is unavailable</h3>
          <p>
            You can still create, edit, and save your world using the controls.
          </p>
          <div>
            {props.scene.objects.slice(0, 10).map((o) => (
              <span key={o.id}>{o.name}</span>
            ))}
          </div>
        </div>
      )}
    </CanvasBoundary>
  );
}
