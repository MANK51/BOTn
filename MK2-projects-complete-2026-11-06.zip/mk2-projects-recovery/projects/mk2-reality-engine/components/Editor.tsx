"use client";
import dynamic from "next/dynamic";
import { useState, useRef, useEffect } from "react";
import {
  ArrowLeft,
  Save,
  Undo2,
  Redo2,
  Plus,
  Trash2,
  Sparkles,
  Eye,
  SlidersHorizontal,
  Layers,
  Sun,
  Camera,
  Download,
  Upload,
  Share2,
  X,
  Check,
  Move3D,
  Rotate3D,
  Maximize2,
  ChevronDown,
  Cloud,
  Copy,
  Loader2,
} from "lucide-react";
import { useWorldStore } from "@/lib/store";
import {
  SceneConfig,
  SceneSchema,
  ObjectKind,
  TEMPLATES,
  createScene,
  parsePrompt,
  encodeScene,
} from "@/lib/scene";
import { saveProject } from "@/lib/storage";
import { API_BASE, api } from "@/lib/api";
const WorldCanvas = dynamic(() => import("./WorldCanvas"), { ssr: false });
const assets: { kind: ObjectKind; icon: string; label: string; ar: string }[] =
  [
    { kind: "island", icon: "◒", label: "Floating island", ar: "جزيرة عائمة" },
    { kind: "tower", icon: "♜", label: "Astral tower", ar: "برج" },
    { kind: "portal", icon: "◎", label: "Light portal", ar: "بوابة ضوء" },
    { kind: "crystal", icon: "◇", label: "Energy crystal", ar: "بلورة" },
    { kind: "temple", icon: "⌂", label: "Ancient temple", ar: "معبد" },
    { kind: "tree", icon: "♠", label: "Celestial tree", ar: "شجرة" },
    { kind: "text", icon: "Aa", label: "Text marker", ar: "نص تفاعلي" },
  ];
export default function Editor({
  ar,
  onBack,
  notify,
  reducedMotion,
  aiAvailable = false,
  quality = "auto",
}: {
  ar: boolean;
  onBack: () => void;
  notify: (s: string) => void;
  reducedMotion: boolean;
  aiAvailable?: boolean;
  quality?: "auto" | "low" | "high";
}) {
  const cloudAi = !!API_BASE && aiAvailable;
  const store = useWorldStore();
  const { scene, selectedId } = store;
  const selected = scene.objects.find((o) => o.id === selectedId);
  const [tab, setTab] = useState("objects"),
    [preview, setPreview] = useState(false),
    [ai, setAi] = useState(false),
    [prompt, setPrompt] = useState(""),
    [busy, setBusy] = useState(false),
    [share, setShare] = useState(false),
    [saving, setSaving] = useState(false),
    [shareUrl, setShareUrl] = useState(""),
    [cloudVisibility, setCloudVisibility] = useState("PUBLIC");
  const captureRef = useRef<(() => void) | null>(null),
    cameraRef = useRef<(() => [number, number, number]) | null>(null),
    fileRef = useRef<HTMLInputElement>(null);
  const tr = (en: string, arab: string) => (ar ? arab : en);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).matches("input,textarea,select")) return;
      if ((e.metaKey || e.ctrlKey) && e.key === "z") {
        e.preventDefault();
        e.shiftKey ? store.redo() : store.undo();
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "s") {
        e.preventDefault();
        save();
      }
      if (e.key === "Delete" && selectedId) store.removeObject(selectedId);
    };
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  });
  async function save() {
    setSaving(true);
    try {
      await saveProject(scene);
      notify(
        tr("World saved on this device.", "تم حفظ العالم على هذا الجهاز."),
      );
    } catch {
      notify(
        tr(
          "Storage is unavailable. Export your scene to keep a copy.",
          "التخزين غير متاح. صدّر العالم لحفظ نسخة.",
        ),
      );
    } finally {
      setSaving(false);
    }
  }
  async function compose() {
    setBusy(true);
    try {
      const next = cloudAi
        ? (
            await api<{ scene: SceneConfig }>("/api/ai/scene", {
              method: "POST",
              body: JSON.stringify({ prompt, scene }),
            })
          ).scene
        : parsePrompt(prompt, scene);
      store.setScene(SceneSchema.parse(next));
      notify(tr("Your reality has been updated.", "تم تحديث عالمك."));
      setAi(false);
    } catch (e) {
      notify((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function download() {
    const b = new Blob([JSON.stringify(scene, null, 2)], {
      type: "application/json",
    });
    const u = URL.createObjectURL(b);
    const a = document.createElement("a");
    a.href = u;
    a.download = scene.name + ".mk2.json";
    a.click();
    URL.revokeObjectURL(u);
  }
  async function importFile(e: React.ChangeEvent<HTMLInputElement>) {
    try {
      const f = e.target.files?.[0];
      if (!f) return;
      if (f.size > 150000) throw new Error("Scene file is too large.");
      store.setScene(SceneSchema.parse(JSON.parse(await f.text())), true);
      notify(tr("Scene imported.", "تم استيراد العالم."));
    } catch {
      notify(
        tr(
          "Invalid scene file. Only validated MK~2 JSON scenes are accepted.",
          "ملف عالم غير صالح.",
        ),
      );
    }
    e.target.value = "";
  }
  async function makeShare() {
    try {
      await saveProject(scene);
      const url =
        location.origin +
        location.pathname +
        "#world=" +
        encodeURIComponent(encodeScene(scene));
      setShareUrl(url);
    } catch (e) {
      notify((e as Error).message);
    }
  }
  async function publish() {
    setBusy(true);
    try {
      const r = await api<{ world: { id: string } }>("/api/worlds", {
        method: "POST",
        body: JSON.stringify({ scene, visibility: cloudVisibility }),
      });
      setShareUrl(
        location.origin + location.pathname + "#published=" + r.world.id,
      );
      notify(
        tr("World published to your cloud account.", "تم نشر العالم في حسابك."),
      );
    } catch (e) {
      notify((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  const updateTuple = (
    key: "position" | "rotation" | "scale",
    axis: number,
    value: number,
  ) => {
    if (!selected || !Number.isFinite(value)) return;
    const v = [...selected[key]] as [number, number, number];
    v[axis] = value;
    try {
      store.updateObject(selected.id, { [key]: v });
    } catch {
      notify(tr("Value is outside scene limits.", "القيمة خارج حدود المشهد."));
    }
  };
  return (
    <div className={"editor " + (preview ? "preview-mode" : "")}>
      <div className="editor-bar">
        <button
          className="icon-button"
          aria-label={tr("Back", "العودة")}
          onClick={onBack}
        >
          <ArrowLeft size={18} />
        </button>
        <div className="editor-title">
          <span className="tiny-label">WORLD CREATOR</span>
          <input
            aria-label={tr("World name", "اسم العالم")}
            value={scene.name}
            maxLength={80}
            onChange={(e) =>
              e.target.value &&
              store.setScene({ ...scene, name: e.target.value })
            }
          />
        </div>
        <span className="local-indicator">
          <i />
          {tr("Local workspace", "مساحة محلية")}
        </span>
        <div className="editor-actions">
          <button
            className="icon-button"
            title="Undo"
            aria-label="Undo"
            disabled={!store.history.length}
            onClick={store.undo}
          >
            <Undo2 size={17} />
          </button>
          <button
            className="icon-button"
            title="Redo"
            aria-label="Redo"
            disabled={!store.future.length}
            onClick={store.redo}
          >
            <Redo2 size={17} />
          </button>
          <button
            aria-label={preview ? tr("Edit", "تعديل") : tr("Preview", "معاينة")}
            className="button subtle small"
            onClick={() => setPreview(!preview)}
          >
            <Eye size={16} />
            <span>
              {preview ? tr("Edit", "تعديل") : tr("Preview", "معاينة")}
            </span>
          </button>
          <button
            aria-label={tr("Share", "مشاركة")}
            className="button subtle small"
            onClick={() => {
              setShare(true);
              setShareUrl("");
            }}
          >
            <Share2 size={15} />
            <span>{tr("Share", "مشاركة")}</span>
          </button>
          <button
            aria-label={tr("Save world", "حفظ العالم")}
            className="button primary small"
            onClick={save}
          >
            {saving ? (
              <Loader2 size={16} className="spin" />
            ) : (
              <Save size={16} />
            )}
            <span>{tr("Save world", "حفظ العالم")}</span>
          </button>
        </div>
      </div>
      <div className="editor-body">
        <aside className="editor-sidebar left-sidebar">
          <div className="panel-tabs">
            <button
              className={tab === "objects" ? "active" : ""}
              onClick={() => setTab("objects")}
            >
              <Layers size={16} />
              {tr("Scene", "المشهد")}
            </button>
            <button
              className={tab === "environment" ? "active" : ""}
              onClick={() => setTab("environment")}
            >
              <Sun size={16} />
              {tr("Atmosphere", "الأجواء")}
            </button>
          </div>
          {tab === "objects" ? (
            <>
              <div className="panel-heading">
                {tr("YOUR ELEMENTS", "عناصر العالم")}
                <span>{scene.objects.length}/80</span>
              </div>
              <div className="object-list">
                {scene.objects.map((o) => (
                  <button
                    key={o.id}
                    className={selectedId === o.id ? "selected" : ""}
                    onClick={() => store.select(o.id)}
                  >
                    <span className="asset-symbol">
                      {assets.find((a) => a.kind === o.kind)?.icon}
                    </span>
                    <span>{o.name}</span>
                    <span
                      className="object-dot"
                      style={{ background: o.color }}
                    />
                  </button>
                ))}
              </div>
              <div className="panel-heading">
                {tr("ASSET LIBRARY", "مكتبة العناصر")}
                <Plus size={14} />
              </div>
              <div className="asset-grid">
                {assets.map((a) => (
                  <button
                    aria-label={ar ? a.ar : a.label}
                    key={a.kind}
                    disabled={scene.objects.length >= 80}
                    onClick={() => store.addObject(a.kind)}
                  >
                    <span>{a.icon}</span>
                    {ar ? a.ar : a.label}
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="environment-panel">
              <label>
                {tr("World template", "قالب العالم")}
                <select
                  value={scene.template}
                  onChange={(e) => {
                    if (
                      window.confirm(
                        tr(
                          "Replace this scene? Save your current world first.",
                          "استبدال المشهد؟ احفظ العالم الحالي أولًا.",
                        ),
                      )
                    )
                      store.setScene(
                        createScene(e.target.value as SceneConfig["template"]),
                      );
                  }}
                >
                  {TEMPLATES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                {tr("Sky color", "لون السماء")}
                <input
                  type="color"
                  value={scene.environment.sky}
                  onChange={(e) =>
                    store.updateEnvironment({ sky: e.target.value })
                  }
                />
              </label>
              <div className="sky-presets">
                {["#15101f", "#38201c", "#070c1c", "#071e27", "#1d3049"].map(
                  (c) => (
                    <button
                      title={c}
                      aria-label={"Sky " + c}
                      key={c}
                      style={{ background: c }}
                      onClick={() => store.updateEnvironment({ sky: c })}
                    />
                  ),
                )}
              </div>
              <label>
                {tr("Light color", "لون الإضاءة")}
                <input
                  type="color"
                  value={scene.environment.accent}
                  onChange={(e) =>
                    store.updateEnvironment({ accent: e.target.value })
                  }
                />
              </label>
              <label>
                {tr("Light intensity", "قوة الإضاءة")}{" "}
                <span>{scene.environment.intensity.toFixed(1)}</span>
                <input
                  type="range"
                  min="0.1"
                  max="3"
                  step="0.1"
                  value={scene.environment.intensity}
                  onChange={(e) =>
                    store.updateEnvironment({ intensity: +e.target.value })
                  }
                />
              </label>
              <label>
                {tr("Atmospheric fog", "الضباب")}
                <input
                  type="range"
                  min="0"
                  max="0.08"
                  step="0.002"
                  value={scene.environment.fog}
                  onChange={(e) =>
                    store.updateEnvironment({ fog: +e.target.value })
                  }
                />
              </label>
              <label className="check-label">
                <input
                  type="checkbox"
                  checked={scene.environment.particles}
                  onChange={(e) =>
                    store.updateEnvironment({ particles: e.target.checked })
                  }
                />
                {tr("Ambient particles", "الجسيمات")}
              </label>
              <label>
                {tr("Weather", "الطقس")}
                <select
                  aria-label={tr("Weather", "الطقس")}
                  value={scene.environment.weather}
                  onChange={(e) =>
                    store.updateEnvironment({
                      weather: e.target.value as "rain" | "clear",
                    })
                  }
                >
                  <option value="clear">
                    {tr("Clear skies", "سماء صافية")}
                  </option>
                  <option value="rain">{tr("Gentle rain", "مطر خفيف")}</option>
                </select>
              </label>
              <button
                className="button subtle full"
                onClick={() =>
                  store.setScene({
                    ...scene,
                    camera: { position: [11, 6, 14] },
                  })
                }
              >
                <Camera size={15} />
                {tr("Reset camera position", "إعادة ضبط الكاميرا")}
              </button>
              <button
                className="button subtle full"
                onClick={() => {
                  const position = cameraRef.current?.();
                  if (position)
                    store.setScene({ ...scene, camera: { position } });
                  else
                    notify(
                      tr("Open a WebGL scene first.", "افتح مشهد WebGL أولًا."),
                    );
                }}
              >
                <Camera size={15} />
                {tr("Set this view as home", "حفظ زاوية البداية")}
              </button>
            </div>
          )}
          <div className="sidebar-bottom">
            <button className="architect-button" onClick={() => setAi(true)}>
              <Sparkles size={18} />
              <div>
                <strong>Reality Architect</strong>
                <span>
                  {cloudAi
                    ? tr("AI assisted creation", "تصميم بمساعدة AI")
                    : tr("Local prompt composer", "مصمم أوصاف محلي")}
                </span>
              </div>
              <Plus size={16} />
            </button>
          </div>
        </aside>
        <div className="editor-viewport">
          <WorldCanvas
            scene={scene}
            selectedId={preview ? null : selectedId}
            onSelect={preview ? undefined : store.select}
            reducedMotion={reducedMotion}
            quality={quality}
            captureRef={captureRef}
            cameraRef={cameraRef}
          />
          <div className="viewport-top">
            <span className="viewport-badge">
              <i />
              {tr("LIVE VIEWPORT", "معاينة مباشرة")}
            </span>
            <span className="tiny-label">
              {scene.template.toUpperCase()} / PERSPECTIVE
            </span>
          </div>
          <div className="viewport-tools">
            <button
              className="icon-button"
              title="Screenshot"
              aria-label="Screenshot"
              onClick={() =>
                captureRef.current
                  ? captureRef.current()
                  : notify(
                      tr(
                        "Capture needs an active WebGL viewport.",
                        "التقاط الصور يتطلب معاينة WebGL نشطة.",
                      ),
                    )
              }
            >
              <Camera size={17} />
            </button>
            <button
              className="icon-button"
              title="Export scene"
              aria-label="Export scene"
              onClick={download}
            >
              <Download size={17} />
            </button>
            <button
              className="icon-button"
              title="Import scene"
              aria-label="Import scene"
              onClick={() => fileRef.current?.click()}
            >
              <Upload size={17} />
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".json"
              hidden
              onChange={importFile}
            />
          </div>
          <div className="viewport-bottom">
            <span>
              ◉{" "}
              {tr(
                "Drag to orbit · Pinch to zoom",
                "اسحب للدوران · باعد للتكبير",
              )}
            </span>
            <button className="button subtle small" onClick={() => setAi(true)}>
              <Sparkles size={14} />
              {tr("Shape with words", "صمّم بالكلمات")}
            </button>
          </div>
        </div>
        <aside className="editor-sidebar right-sidebar">
          <div className="panel-heading">
            <SlidersHorizontal size={15} />
            {tr("PROPERTIES", "الخصائص")}
            <button
              className="icon-button"
              aria-label={tr("Deselect element", "إلغاء التحديد")}
              onClick={() => store.select(null)}
            >
              <X size={13} />
            </button>
          </div>
          {selected ? (
            <div className="properties-panel">
              <div className="selected-type">
                {assets.find((a) => a.kind === selected.kind)?.icon}
                <span>{selected.kind.toUpperCase()}</span>
              </div>
              <label>
                {tr("Element name", "اسم العنصر")}
                <input
                  value={selected.name}
                  maxLength={80}
                  onChange={(e) =>
                    store.updateObject(selected.id, { name: e.target.value })
                  }
                />
              </label>
              {(["position", "rotation", "scale"] as const).map((key) => (
                <div className="transform-group" key={key}>
                  <span>
                    {key === "position" ? (
                      <Move3D size={14} />
                    ) : key === "rotation" ? (
                      <Rotate3D size={14} />
                    ) : (
                      <Maximize2 size={14} />
                    )}{" "}
                    {ar
                      ? {
                          position: "الموقع",
                          rotation: "الدوران",
                          scale: "الحجم",
                        }[key]
                      : key}
                  </span>
                  <div className="axis-fields">
                    {selected[key].map((v, i) => (
                      <label key={i}>
                        <span>{["X", "Y", "Z"][i]}</span>
                        <input
                          type="number"
                          aria-label={`${key} ${["X", "Y", "Z"][i]}`}
                          value={Math.round(v * 100) / 100}
                          step="0.1"
                          min={key === "scale" ? ".1" : "-100"}
                          max={key === "scale" ? "10" : "100"}
                          onChange={(e) => updateTuple(key, i, +e.target.value)}
                        />
                      </label>
                    ))}
                  </div>
                </div>
              ))}
              <label>
                {tr("Surface color", "لون العنصر")}
                <input
                  type="color"
                  value={selected.color}
                  onChange={(e) =>
                    store.updateObject(selected.id, { color: e.target.value })
                  }
                />
              </label>
              {selected.kind === "text" && (
                <label>
                  {tr("Display text", "النص")}
                  <input
                    value={selected.text || ""}
                    maxLength={160}
                    onChange={(e) =>
                      store.updateObject(selected.id, { text: e.target.value })
                    }
                  />
                </label>
              )}
              <label>
                {tr("Point of interest description", "وصف نقطة الاهتمام")}
                <textarea
                  rows={3}
                  maxLength={500}
                  value={selected.description || ""}
                  placeholder={tr(
                    "Add a story to this element…",
                    "أضف قصة لهذا العنصر…",
                  )}
                  onChange={(e) =>
                    store.updateObject(selected.id, {
                      description: e.target.value,
                    })
                  }
                />
              </label>
              <button
                className="button danger full"
                onClick={() => store.removeObject(selected.id)}
              >
                <Trash2 size={14} />
                {tr("Remove element", "حذف العنصر")}
              </button>
            </div>
          ) : (
            <div className="empty-selection">
              <Move3D size={30} />
              <h4>{tr("Make it your own.", "اجعله عالمك.")}</h4>
              <p>
                {tr(
                  "Select an element in the scene or the list to edit its properties.",
                  "اختر عنصرًا من المشهد أو القائمة لتعديل خصائصه.",
                )}
              </p>
              <span>
                {tr(
                  "Every detail is a possibility.",
                  "كل تفصيل هو احتمال جديد.",
                )}
              </span>
            </div>
          )}
          <div className="properties-footer">
            <span className="tiny-label">ENGINE v1.0</span>
            <p>
              {tr(
                "Projects stay on this device until you export or share them.",
                "تبقى المشاريع على هذا الجهاز حتى تصديرها أو مشاركتها.",
              )}
            </p>
          </div>
        </aside>
      </div>
      {ai && (
        <div className="modal-backdrop" onClick={() => setAi(false)}>
          <div
            className="modal architect-modal"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="modal-close icon-button"
              aria-label="Close"
              onClick={() => setAi(false)}
            >
              <X size={18} />
            </button>
            <span className="modal-orb">
              <Sparkles size={28} />
            </span>
            <span className="tiny-label">REALITY ARCHITECT</span>
            <h2>
              {tr("An idea. A whole universe.", "فكرة واحدة. عالم كامل.")}
            </h2>
            <p>
              {cloudAi
                ? tr(
                    "Describe a scene using our asset library. AI returns a validated configuration. Sign in to use your AI allowance.",
                    "صِف مشهدًا من مكتبة العناصر. سجّل الدخول لاستخدام AI.",
                  )
                : tr(
                    "Local composer: recognizes template, color, weather, and island requests in English and Arabic. This is a rule based tool; connect the backend to enable AI.",
                    "مصمم محلي: يفهم القوالب والألوان والطقس والجزر بالعربية والإنجليزية. يعتمد على قواعد محددة؛ فعّل الخادم لاستخدام AI.",
                  )}
            </p>
            <textarea
              value={prompt}
              maxLength={2000}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              placeholder={tr(
                "Make the sky orange, add more floating islands and gentle rain…",
                "خل السماء برتقالية، وزود الجزر العائمة وأضف مطرًا خفيفًا…",
              )}
            />
            <div className="prompt-chips">
              {[
                "Purple city with rain",
                "Orange sunset, more islands",
                "سماء برتقالية مع مطر",
              ].map((p) => (
                <button key={p} onClick={() => setPrompt(p)}>
                  {p}
                </button>
              ))}
            </div>
            <button
              className="button primary full"
              disabled={!prompt.trim() || busy}
              onClick={compose}
            >
              {busy ? (
                <Loader2 size={17} className="spin" />
              ) : (
                <Sparkles size={17} />
              )}{" "}
              {cloudAi
                ? tr("Generate scene", "توليد المشهد")
                : tr("Compose scene locally", "تصميم المشهد محليًا")}
            </button>
            <span className="modal-note">
              {tr(
                "Only library assets. Validated scene data. No generated code.",
                "عناصر المكتبة فقط. بيانات مشهد مُتحقق منها.",
              )}
            </span>
          </div>
        </div>
      )}
      {share && (
        <div className="modal-backdrop" onClick={() => setShare(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button
              className="modal-close icon-button"
              aria-label="Close"
              onClick={() => setShare(false)}
            >
              <X size={18} />
            </button>
            <span className="modal-orb">
              <Share2 size={26} />
            </span>
            <span className="tiny-label">LET SOMEONE INTO YOUR WORLD</span>
            <h2>{tr("Reality is better shared.", "شارك عالمك.")}</h2>
            <p>
              {tr(
                "A portable link contains your scene configuration. Anyone with the link can open it. Changes are not synchronized.",
                "الرابط يحمل بيانات المشهد، ويمكن لأي شخص يملكه فتحه. لا تتزامن التعديلات.",
              )}
            </p>
            <label className="check-label">
              <input
                type="checkbox"
                checked={scene.allowRemix}
                onChange={(e) =>
                  store.setScene({ ...scene, allowRemix: e.target.checked })
                }
              />
              {tr(
                "Allow others to remix this world",
                "السماح بنسخ العالم وتعديله",
              )}
            </label>
            <button className="button primary full" onClick={makeShare}>
              <Share2 size={16} />
              {tr("Create portable share link", "إنشاء رابط مشاركة")}
            </button>
            {shareUrl && (
              <div className="share-field">
                <input aria-label="Share link" value={shareUrl} readOnly />
                <button
                  className="icon-button"
                  aria-label="Copy link"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(shareUrl);
                      notify(tr("Link copied.", "تم نسخ الرابط."));
                    } catch {
                      notify(
                        tr(
                          "Select and copy the link manually.",
                          "حدد الرابط وانسخه يدويًا.",
                        ),
                      );
                    }
                  }}
                >
                  <Copy size={17} />
                </button>
              </div>
            )}
            <div className="cloud-note">
              <Cloud size={20} />
              <div>
                <strong>{tr("Cloud publishing", "النشر السحابي")}</strong>
                <p>
                  {API_BASE
                    ? tr(
                        "Publish to your account. Public scenes enter the community after review.",
                        "انشر إلى حسابك. العوالم العامة تظهر بعد المراجعة.",
                      )
                    : tr(
                        "Account publishing, private access, and synchronization require the configured backend and PostgreSQL.",
                        "يتطلب النشر بالحساب والوصول الخاص والمزامنة إعداد الخادم وPostgreSQL.",
                      )}
                </p>
              </div>
            </div>
            {API_BASE && (
              <>
                <select
                  value={cloudVisibility}
                  onChange={(e) => setCloudVisibility(e.target.value)}
                >
                  <option value="PUBLIC">Public</option>
                  <option value="PRIVATE">
                    Private · signed-in owner only
                  </option>
                </select>
                <button
                  className="button subtle full"
                  disabled={busy}
                  onClick={publish}
                >
                  {busy ? "Publishing…" : "Publish to cloud"}
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
