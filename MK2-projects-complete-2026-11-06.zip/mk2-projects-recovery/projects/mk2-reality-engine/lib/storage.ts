import { SceneConfig, SceneSchema } from "./scene";
export type SavedProject = {
  id: string;
  name: string;
  updatedAt: string;
  scene: SceneConfig;
};
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const r = indexedDB.open("mk2-reality", 1);
    r.onupgradeneeded = () =>
      r.result.createObjectStore("projects", { keyPath: "id" });
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
async function transaction<T>(
  mode: IDBTransactionMode,
  action: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("projects", mode);
    const request = action(tx.objectStore("projects"));
    let result: T;
    request.onsuccess = () => {
      result = request.result;
    };
    tx.oncomplete = () => {
      db.close();
      resolve(result);
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error);
    };
    tx.onabort = () => {
      db.close();
      reject(tx.error || new Error("Storage transaction failed"));
    };
  });
}
export async function saveProject(scene: SceneConfig) {
  const safe = SceneSchema.parse(scene);
  const p: SavedProject = {
    id: safe.id,
    name: safe.name,
    updatedAt: new Date().toISOString(),
    scene: safe,
  };
  await transaction("readwrite", (s) => s.put(p));
  return p;
}
export async function listProjects() {
  return (
    await transaction<SavedProject[]>("readonly", (s) => s.getAll())
  ).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}
export async function loadProject(id: string) {
  const p = await transaction<SavedProject | undefined>("readonly", (s) =>
    s.get(id),
  );
  return p ? { ...p, scene: SceneSchema.parse(p.scene) } : undefined;
}
export async function deleteProject(id: string) {
  await transaction("readwrite", (s) => s.delete(id));
}
export function favorites(): string[] {
  try {
    return JSON.parse(localStorage.getItem("mk2-favorites") || "[]");
  } catch {
    return [];
  }
}
export function toggleFavorite(id: string) {
  const a = favorites();
  const next = a.includes(id) ? a.filter((x) => x !== id) : [...a, id];
  localStorage.setItem("mk2-favorites", JSON.stringify(next));
  return next;
}
