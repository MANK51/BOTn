import { create } from "zustand";
import {
  SceneConfig,
  SceneObject,
  ObjectKind,
  createScene,
  createObject,
  SceneSchema,
} from "./scene";
type Store = {
  scene: SceneConfig;
  selectedId: string | null;
  history: SceneConfig[];
  future: SceneConfig[];
  setScene: (s: SceneConfig, reset?: boolean) => void;
  select: (id: string | null) => void;
  updateEnvironment: (e: Partial<SceneConfig["environment"]>) => void;
  addObject: (kind: ObjectKind) => void;
  updateObject: (id: string, p: Partial<SceneObject>) => void;
  removeObject: (id: string) => void;
  undo: () => void;
  redo: () => void;
};
export const useWorldStore = create<Store>((set, get) => {
  const commit = (scene: SceneConfig) => {
    const safe = SceneSchema.parse(scene);
    set({
      scene: safe,
      history: [...get().history, get().scene].slice(-40),
      future: [],
    });
  };
  return {
    scene: createScene(),
    selectedId: null,
    history: [],
    future: [],
    setScene: (s, reset = false) =>
      reset
        ? set({
            scene: SceneSchema.parse(s),
            history: [],
            future: [],
            selectedId: null,
          })
        : commit(s),
    select: (id) => set({ selectedId: id }),
    updateEnvironment: (e) =>
      commit({
        ...get().scene,
        environment: { ...get().scene.environment, ...e },
      }),
    addObject: (kind) => {
      const obj = createObject(kind);
      commit({ ...get().scene, objects: [...get().scene.objects, obj] });
      set({ selectedId: obj.id });
    },
    updateObject: (id, p) =>
      commit({
        ...get().scene,
        objects: get().scene.objects.map((o) =>
          o.id === id ? { ...o, ...p, id: o.id } : o,
        ),
      }),
    removeObject: (id) => {
      commit({
        ...get().scene,
        objects: get().scene.objects.filter((o) => o.id !== id),
      });
      set({ selectedId: null });
    },
    undo: () => {
      const h = get().history;
      if (h.length)
        set({
          scene: h[h.length - 1],
          history: h.slice(0, -1),
          future: [get().scene, ...get().future],
          selectedId: null,
        });
    },
    redo: () => {
      const f = get().future;
      if (f.length)
        set({
          scene: f[0],
          future: f.slice(1),
          history: [...get().history, get().scene],
          selectedId: null,
        });
    },
  };
});
