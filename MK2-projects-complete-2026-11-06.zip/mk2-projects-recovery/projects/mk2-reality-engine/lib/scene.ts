import { z } from "zod";
export function makeId() {
  if (typeof globalThis.crypto?.randomUUID === "function")
    return globalThis.crypto.randomUUID();
  if (globalThis.crypto?.getRandomValues)
    return Array.from(
      globalThis.crypto.getRandomValues(new Uint8Array(16)),
      (b) => b.toString(16).padStart(2, "0"),
    ).join("");
  return (
    "scene-" + Date.now().toString(36) + Math.random().toString(36).slice(2)
  );
}

const tuple = z.tuple([
  z.number().finite().min(-100).max(100),
  z.number().finite().min(-100).max(100),
  z.number().finite().min(-100).max(100),
]);
const color = z.string().regex(/^#[0-9a-fA-F]{6}$/);
export const ObjectSchema = z
  .object({
    id: z.string().min(1).max(80),
    kind: z.enum([
      "island",
      "tower",
      "portal",
      "crystal",
      "tree",
      "temple",
      "text",
    ]),
    name: z.string().max(80),
    position: tuple,
    rotation: tuple,
    scale: z.tuple([
      z.number().min(0.1).max(10),
      z.number().min(0.1).max(10),
      z.number().min(0.1).max(10),
    ]),
    color,
    text: z.string().max(160).optional(),
    description: z.string().max(500).optional(),
  })
  .strict();
export const SceneSchema = z
  .object({
    version: z.literal(1),
    id: z.string().min(1).max(80),
    name: z.string().min(1).max(80),
    template: z.enum(["skyborne", "neon", "temple"]),
    environment: z
      .object({
        sky: color,
        accent: color,
        intensity: z.number().min(0.1).max(3),
        fog: z.number().min(0).max(0.08),
        particles: z.boolean(),
        weather: z.enum(["clear", "rain"]),
      })
      .strict(),
    camera: z.object({ position: tuple }).strict(),
    objects: z.array(ObjectSchema).max(80),
    allowRemix: z.boolean(),
  })
  .strict()
  .superRefine((s, c) => {
    if (new Set(s.objects.map((o) => o.id)).size !== s.objects.length)
      c.addIssue({ code: "custom", message: "Object IDs must be unique" });
  });
export type SceneConfig = z.infer<typeof SceneSchema>;
export type SceneObject = z.infer<typeof ObjectSchema>;
export type ObjectKind = SceneObject["kind"];
export type TemplateId = SceneConfig["template"];
export const TEMPLATES = [
  {
    id: "skyborne" as const,
    name: "Skyborne City",
    subtitle: "ABOVE THE ORDINARY",
    description:
      "A city suspended between golden skies and the impossible. Follow the light to the Astral Gate.",
    color: "#bc9aff",
    image: "/art/skyborne.png",
    tags: ["Fantasy", "Floating islands"],
    coordinates: "28.4° N / 92.1° E",
  },
  {
    id: "neon" as const,
    name: "Neon Abyss",
    subtitle: "AFTER THE LAST SUNSET",
    description:
      "An electric metropolis at the edge of tomorrow. Discover the energy core beneath its violet skyline.",
    color: "#30DFFF",
    image: "/art/neon.png",
    tags: ["Sci-fi", "Cyberpunk"],
    coordinates: "06.8° N / 41.7° W",
  },
  {
    id: "temple" as const,
    name: "The Forgotten Temple",
    subtitle: "SOME SECRETS RUN DEEP",
    description:
      "Below the surface, an ancient sanctuary waits. Explore luminous crystals and a forgotten ocean portal.",
    color: "#59dac7",
    image: "/art/temple.png",
    tags: ["Mystery", "Underwater"],
    coordinates: "12.6° S / 73.2° E",
  },
];
export function createObject(kind: ObjectKind): SceneObject {
  return {
    id: makeId(),
    kind,
    name:
      kind === "portal"
        ? "Astral Gate"
        : kind.charAt(0).toUpperCase() + kind.slice(1),
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1],
    color: kind === "portal" ? "#bc9aff" : "#8790b7",
    ...(kind === "text" ? { text: "Your reality begins here" } : {}),
  };
}
export function createScene(template: TemplateId = "skyborne"): SceneConfig {
  const objects: SceneObject[] = [];
  function add(
    kind: ObjectKind,
    p: [number, number, number],
    scale: [number, number, number] = [1, 1, 1],
    color = "#8790b7",
    name?: string,
  ) {
    objects.push({
      ...createObject(kind),
      position: p,
      scale,
      color,
      ...(name ? { name } : {}),
    });
  }
  if (template === "skyborne") {
    add("island", [0, -1, 0], [2.7, 1.6, 2.7], "#434465", "The Citadel");
    add("portal", [0, 2, -1], [1.55, 1.55, 1.55], "#bc9aff", "Astral Gate");
    for (let i = 0; i < 9; i++) {
      const a = i * 0.72;
      add(
        "tower",
        [Math.cos(a) * 2, -0.7, Math.sin(a) * 1.7],
        [0.5, 0.7 + (i % 3) * 0.4, 0.5],
        "#797baf",
      );
    }
    add("island", [-5, 0, -3], [1.6, 1.3, 1.6], "#41425d", "Cloudhaven");
    add("tower", [-5, 0.1, -3], [0.9, 1.6, 0.9], "#a29ac7");
    add("island", [5, -0.5, -5], [1.6, 1.3, 1.6], "#484264", "The Outer Isles");
    add("tower", [5, -0.4, -5], [0.8, 2, 0.8], "#9a8fb7");
    add("island", [-4, -2, 4], [1.2, 1, 1.2], "#37364d");
    add("crystal", [-4, -0.5, 4], [0.6, 0.9, 0.6], "#b3a0ff");
  } else if (template === "neon") {
    add("island", [0, -2, 0], [4, 0.6, 4], "#121329", "Neon District");
    for (let i = 0; i < 18; i++) {
      const x = ((i % 6) - 2.5) * 2,
        z = Math.floor(i / 6) * -3;
      add(
        "tower",
        [x, -1, z],
        [0.8, 1.2 + ((i * 7) % 5) * 0.5, 0.8],
        i % 2 ? "#352465" : "#182e47",
      );
    }
    add("portal", [0, 1.5, 2], [1.3, 1.3, 1.3], "#30DFFF", "Energy Core");
    add("crystal", [-2, 0, 4], [0.7, 1, 0.7], "#865CFF", "Signal Crystal");
  } else {
    add("island", [0, -2, 0], [4, 0.8, 4], "#23454a", "Seabed");
    add("temple", [0, -1.3, 0], [1.5, 1.5, 1.5], "#799b92", "The Sanctuary");
    add("portal", [0, 1.2, -0.6], [1, 1, 1], "#59dac7", "Tidal Gate");
    for (let i = 0; i < 7; i++) {
      add(
        "crystal",
        [Math.cos(i) * 4, -1, Math.sin(i) * 4],
        [0.5, 0.8 + (i % 3) * 0.25, 0.5],
        "#53c6bd",
      );
    }
  }
  return SceneSchema.parse({
    version: 1,
    id: makeId(),
    name: TEMPLATES.find((t) => t.id === template)!.name,
    template,
    environment: {
      sky:
        template === "skyborne"
          ? "#15101f"
          : template === "neon"
            ? "#070c1c"
            : "#071e27",
      accent:
        template === "skyborne"
          ? "#bc9aff"
          : template === "neon"
            ? "#30DFFF"
            : "#59dac7",
      intensity: 1.2,
      fog: 0.017,
      particles: true,
      weather: "clear",
    },
    camera: { position: [11, 6, 14] },
    objects,
    allowRemix: true,
  });
}
export function parsePrompt(
  prompt: string,
  current?: SceneConfig,
): SceneConfig {
  if (!prompt.trim()) throw new Error("Describe your world first.");
  const p = prompt.toLowerCase();
  let scene = current
    ? structuredClone(current)
    : createScene(
        /underwater|temple|معبد|تحت الماء/.test(p)
          ? "temple"
          : /cyber|neon|dark|نيون|مظلم/.test(p)
            ? "neon"
            : "skyborne",
      );
  if (/orange|sunset|برتقالي|غروب/.test(p)) scene.environment.sky = "#38201c";
  if (/purple|violet|بنفسج/.test(p)) scene.environment.accent = "#a17aff";
  if (/blue|أزرق/.test(p)) scene.environment.accent = "#30DFFF";
  if (/rain|مطر/.test(p)) scene.environment.weather = "rain";
  if (/clear|صافي|بدون مطر/.test(p)) scene.environment.weather = "clear";
  if (/more|add|زود|أضف|اضف/.test(p) && /island|جزر|جزيرة/.test(p))
    for (let i = 0; i < 3 && scene.objects.length < 80; i++)
      scene.objects.push({
        ...createObject("island"),
        position: [-7 + i * 7, -1 - i, -6],
        scale: [1.3, 1.3, 1.3],
      });
  if (/portal|بواب/.test(p) && !scene.objects.some((o) => o.kind === "portal"))
    scene.objects.push({ ...createObject("portal"), position: [0, 2, 0] });
  return SceneSchema.parse(scene);
}
export function encodeScene(scene: SceneConfig) {
  const json = JSON.stringify(SceneSchema.parse(scene));
  const encoded = btoa(
    Array.from(new TextEncoder().encode(json), (c) =>
      String.fromCharCode(c),
    ).join(""),
  );
  if (encoded.length > 65000)
    throw new Error(
      "This world is too large for a portable link. Export the scene JSON instead.",
    );
  return encoded;
}
export function decodeScene(encoded: string): SceneConfig {
  if (encoded.length > 65000)
    throw new Error("Shared scene exceeds the size limit.");
  const bytes = Uint8Array.from(atob(encoded), (c) => c.charCodeAt(0));
  return SceneSchema.parse(JSON.parse(new TextDecoder().decode(bytes)));
}
