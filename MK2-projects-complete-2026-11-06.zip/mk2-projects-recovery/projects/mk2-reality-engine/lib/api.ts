export const API_BASE = process.env.NEXT_PUBLIC_API_URL || "";
export async function api<T = any>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  if (!API_BASE)
    throw new Error(
      "Cloud services are not configured. Your projects are saved on this device.",
    );
  const r = await fetch(API_BASE + path, {
    ...options,
    credentials: "include",
    headers: { "Content-Type": "application/json", ...options.headers },
  });
  const data = await r.json();
  if (!r.ok) throw new Error(data.error || "The request failed.");
  return data;
}
