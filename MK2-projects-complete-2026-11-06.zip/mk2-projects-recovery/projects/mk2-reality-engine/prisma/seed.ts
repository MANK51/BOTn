import "dotenv/config";
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  if (!email)
    throw new Error(
      "Set ADMIN_EMAIL to an existing registered account. No default admin is created.",
    );
  const user = await db.user.findUnique({ where: { email } });
  if (!user)
    throw new Error(
      "Register this account through the API before promoting it.",
    );
  await db.user.update({ where: { id: user.id }, data: { role: "ADMIN" } });
  await db.auditLog.create({
    data: { actorId: user.id, action: "ADMIN_PROMOTED", targetId: user.id },
  });
  console.log("Existing account promoted to administrator.");
}
main()
  .catch(() => {
    console.error(
      "Admin promotion failed. Verify database access and that ADMIN_EMAIL is registered.",
    );
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());
