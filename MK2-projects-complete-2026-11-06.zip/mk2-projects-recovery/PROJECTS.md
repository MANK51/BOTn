# فهرس المشاريع — حزمة الاستعادة

جُمعت المصادر المتاحة بتاريخ 2026-11-06. ابدأ بقراءة [START_HERE.md](START_HERE.md) ثم [دليل الاستعادة](RESTORE_GUIDE.md).

| المشروع والتفاصيل | حالة المصدر | الملفات | تعديلات Git | المصدر | التاريخ |
| --- | --- | ---: | ---: | --- | --- |
| [ومضة](details/wamda-app-34128a68.md) | موجود | 13 | 1 | [الملفات](projects/wamda-app-34128a68/) | [Git bundle](history/wamda-app-34128a68.bundle) |
| [Getsup — حمّل التطبيق](details/athar-personal-folio.md) | موجود | 13 | 4 | [الملفات](projects/athar-personal-folio/) | [Git bundle](history/athar-personal-folio.bundle) |
| [MK~2 — أفكار تتحوّل إلى تجارب](details/mk2-odyssey.md) | موجود | 34 | 2 | [الملفات](projects/mk2-odyssey/) | [Git bundle](history/mk2-odyssey.bundle) |
| [MK~2 — مساحة التحكم](details/mk2-control-center.md) | موجود | 32 | 1 | [الملفات](projects/mk2-control-center/) | [Git bundle](history/mk2-control-center.bundle) |
| [آية ويدجت — نسخة الويب](details/ayah-widget-web-1022.md) | مستودع فارغ | 0 | 0 | غير متوفر | غير متوفر |
| [MK~2 Reality Engine](details/mk2-reality-engine.md) | موجود | 51 | 1 | [الملفات](projects/mk2-reality-engine/) | [Git bundle](history/mk2-reality-engine.bundle) |
| [لك قلب](details/a-heart-for-you.md) | موجود | 41 | 6 | [الملفات](projects/a-heart-for-you/) | [Git bundle](history/a-heart-for-you.bundle) |
| [مراجعات القدرات](details/qudrat-review.md) | موجود | 148 | 5 | [الملفات](projects/qudrat-review/) | [Git bundle](history/qudrat-review.bundle) |
| [MK~2 REALMS](details/mk2-realms.md) | موجود | 77 | 7 | [الملفات](projects/mk2-realms/) | [Git bundle](history/mk2-realms.bundle) |
| [كاشف API](details/api-discovery-checker.md) | مستودع فارغ | 0 | 0 | غير متوفر | غير متوفر |
| [MK~2 — عالمي الرقمي](details/mk2-digital.md) | موجود | 177 | 26 | [الملفات](projects/mk2-digital/) | [Git bundle](history/mk2-digital.bundle) |
| [تحدي اليوم](details/challenge-today.md) | موجود | 126 | 10 | [الملفات](projects/challenge-today/) | [Git bundle](history/challenge-today.bundle) |
| [كودك — مولّد الأكواد](details/codek-micro-tools.md) | موجود | 123 | 6 | [الملفات](projects/codek-micro-tools/) | [Git bundle](history/codek-micro-tools.bundle) |
| [MKk2movi](details/mkk2movi.md) | موجود | 350 | 50 | [الملفات](projects/mkk2movi/) | [Git bundle](history/mkk2movi.bundle) |

تفاصيل متطلبات التشغيل والخدمات في [requirements.json](requirements.json)، وبيانات المواقع الأصلية في [catalog.json](catalog.json).

آية ويدجت وكاشف API مسجلان في Sites لكن مستودعات مصدرهما ما زالت فارغة. صفحة Getsup هي كود صفحة التحميل والإدارة المتاح؛ لا يحتوي مصدرها كود التطبيق الخارجي أو ملفات APK غير المحفوظة فيه.

تاريخ إعداد بعض صفحات تفاصيل المشاريع القديمة سابق لتاريخ الحزمة؛ معرّفات SHA للمصادر غير المتغيرة مطابقة لها. استُبدلت صفحة الأفلام بتفاصيل أحدث مصدر متاح.
