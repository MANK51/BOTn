# MK~2 REALMS

منصة عربية تعمل كتطبيق مصغر داخل Telegram، تجمع العوالم والتحديات والفعاليات والمكافآت وبوتًا ولوحة إدارة. التفاصيل أدناه تصف ملفات المصدر المؤرشفة؛ أُضيف التوثيق في 2026-10-30 دون تشغيل البناء أو الاختبارات.

## الوظائف الموجودة في المصدر

- إنشاء العوالم وإدارة عضويتها ودعواتها ومنشوراتها، وإنشاء التحديات ومراحلها ومحاولاتها وحفظ النتائج لاستئنافها.
- نقاط وXP ومكافأة يومية ومتجر عناصر تجميلية ومخزون وتجهيز عناصر الملف الشخصي، مع منع صرف المكافأة نفسها مرتين.
- فعاليات تتضمن ألغازًا وتصويتًا ومساهمات، إضافة إلى فرق وإشعارات وتذاكر دعم وتقارير.
- بوت Telegram عبر webhook، وتحقق خادمي من هوية Telegram وصلاحيات الإدارة، وسجل تدقيق وتصدير للنسخ الاحتياطية.

## التقنيات والتخزين

React 19.2.6 وTypeScript 5.9.3، مع Vinext 1.0.0-beta.5 وتوافق توجيه Next 16.3.4 وVite 8.0.13. الخادم Cloudflare Worker، والتخزين Cloudflare D1 بالربط `DB`، والمخطط والهجرات عبر Drizzle ORM/Kit. الأيقونات من Lucide، والاختبارات عبر `tsx` وواجهة اختبارات Node.

يلزم Node.js 22.13 أو أحدث وnpm. تسجيل الدخول الفعلي يتطلب بوتًا صالحًا وفتح التطبيق داخل Telegram بعنوان HTTPS عام. يُسجل webhook لدى Telegram بعد إعداد النشر. الأصول المحلية ضمن `public/assets/`؛ المصدر لا يحتوي قاعدة بيانات التشغيل أو أسرارها.

## الإعداد والأوامر

من مجلد [المشروع](../projects/mk2-realms/):

```bash
npm ci
cp .env.example .dev.vars
npm run check
npm test
npm run build
```

تُضبط القيم محليًا في `.dev.vars` وفق [ملف المثال](../projects/mk2-realms/.env.example). الأسماء الأساسية هي `TELEGRAM_BOT_TOKEN` و`TELEGRAM_WEBHOOK_SECRET` و`BOT_USERNAME` و`APP_URL` و`ADMIN_TELEGRAM_IDS`؛ ويتضمن المثال أيضًا `ADMIN_OWNER_ID` و`ADMIN_OWNER_EMAIL` و`INSTALL_SECRET` للوظائف الاختيارية. يستعمل جزء الإدارة `BOT_TOKEN` كاسم بديل لبعض عمليات البوت؛ المسارات الأساسية تعتمد `TELEGRAM_BOT_TOKEN`. لا تُدرج قيم الأسرار في Git.

بعد البناء، تحتاج قاعدة محلية جديدة إلى تطبيق هجرات `drizzle/*.sql` مرة واحدة باستعمال إعداد `dist/server/wrangler.json` ومسار الحفظ `.wrangler/state`، ثم نسخ `.dev.vars` إلى `dist/server/.dev.vars` قبل `npm start`. راجع خطوات ذلك في [README_AR.md](../projects/mk2-realms/README_AR.md)؛ لا تُعِد تطبيق جميع الهجرات على قاعدة موجودة.

| الأمر المتاح | تعريفه في `package.json` |
| --- | --- |
| `npm run dev` | `vinext dev` لتطوير الواجهة |
| `npm run build` | `vinext build` |
| `npm start` | `wrangler dev --config dist/server/wrangler.json --local --persist-to .wrangler/state --ip 127.0.0.1` |
| `npm run check` | `tsc --noEmit` |
| `npm test` | `tsx --test tests/*.test.ts` |
| `npm run db:generate` | `drizzle-kit generate` لتوليد هجرة، دون تطبيقها تلقائيًا |

هذه أوامر متاحة في المصدر؛ لم تُنفَّذ ضمن إعداد هذا التوثيق.

## ملفات للبدء

- [app/RealmsApp.tsx](../projects/mk2-realms/app/RealmsApp.tsx): واجهة التطبيق، و[app/admin/AdminApp.tsx](../projects/mk2-realms/app/admin/AdminApp.tsx): واجهة الإدارة.
- [lib/api.ts](../projects/mk2-realms/lib/api.ts)، [lib/platform.ts](../projects/mk2-realms/lib/platform.ts)، [lib/events.ts](../projects/mk2-realms/lib/events.ts): مسارات التطبيق ومنطق العوالم والمكافآت والفعاليات.
- [lib/bot.ts](../projects/mk2-realms/lib/bot.ts) و[lib/security.ts](../projects/mk2-realms/lib/security.ts): تكامل Telegram والتحقق من الطلبات.
- [db/schema.ts](../projects/mk2-realms/db/schema.ts) و[drizzle/](../projects/mk2-realms/drizzle/): المخطط والهجرات؛ [tests/](../projects/mk2-realms/tests/): اختبارات المنصة.
- [API-CONTRACT.md](../projects/mk2-realms/API-CONTRACT.md) و[EVENTS-CONTRACT.md](../projects/mk2-realms/EVENTS-CONTRACT.md): العقود التفصيلية؛ [scripts/restore-backup.mjs](../projects/mk2-realms/scripts/restore-backup.mjs): تحويل نسخة التصدير إلى SQL محليًا.

التحديث الدوري للفعاليات يستعمل HTTP، وتطورها يحدث أثناء الطلبات؛ لا يوجد مجدول مستقل أو بوت polling دائم. إنشاء بعض أنواع التحديات في الواجهة معطّل حتى اكتمال أدوات تحريرها، ولا توجد مشتريات Telegram Stars في هذه النسخة.

## النشر ومرجع الأرشيف

- الرابط المسجل في Sites: <https://realms.mk2space.cfd>؛ الجمهور المسجل في 2026-10-30: عام (`public`). لم يُجرَ فحص حي للرابط ضمن هذه المراجعة.
- تاريخ إنشاء المشروع: 2026-10-09.
- التزام المصدر: `0ee6c27fbc3ef5ea9b9136b8a8da981bb7ff0f3d`.
- الملفات المؤرشفة: **77**؛ التزامات سجل المصدر: **7**، وفق [manifest.json](../manifest.json).
- [نسخة المصدر](../projects/mk2-realms/)، [حزمة سجل Git](../history/mk2-realms.bundle)، [تعريف الاعتماديات والأوامر](../projects/mk2-realms/package.json).
