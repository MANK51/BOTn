# MK~2 Reality Engine

تفاصيل لقطة المصدر المؤرشفة، أُعدت في 30 أكتوبر 2026.

| البيان | القيمة |
| --- | --- |
| الموقع المنشور المسجل | [https://mk2-reality-engine.m2000m1400.chatgpt.site](https://mk2-reality-engine.m2000m1400.chatgpt.site) |
| جمهور الموقع المسجل | وصول مخصص (`custom`)، وفق بيانات Sites المسجلة |
| تاريخ إنشاء المشروع | 2026-10-14 |
| ملفات المصدر | 51 |
| التزامات Git المحفوظة | 1 |
| SHA المصدر | `414703e5c9a65fed4cf2ba59ced298c7c453707f` |

المعلومات أعلاه من [سجل الأرشيف](../manifest.json) وبيانات Sites بتاريخ إعداد الوثيقة. الجمهور يصف الموقع المستضاف؛ الرابط لم يُفحص بمتصفح في هذه المراجعة.

## الفكرة والمزايا

تجربة لإنشاء واستكشاف عوالم ثلاثية الأبعاد، بواجهة إنجليزية وعربية. تتضمن ثلاثة قوالب عالم، ومحررًا لاختيار عناصر إجرائية وتعديل مواضعها ودورانها وحجمها وألوانها، وإعدادات جوية ونقاط اهتمام وتراجعًا وإعادة ومعاينة. تدعم التقاط صورة، واستيراد المشهد وتصديره، وحفظ المشاريع والمفضلة محليًا.

المشاركة المحمولة تضع بيانات المشهد داخل جزء الرابط، ولا تزامن التعديلات اللاحقة. يستطيع من يملك الرابط قراءة بيانات المشهد إذا سمحت استضافة الموقع بدخوله. مؤلف الأوامر المحلي يتعرف على تعليمات عربية وإنجليزية محددة؛ ليس نموذج ذكاء اصطناعي حرًا.

يتضمن المصدر خلفية اختيارية للحسابات والجلسات والعوالم السحابية ومعرض خاضع للمراجعة، بالإضافة إلى تكامل OpenAI اختياري لتوليد إعداد مشهد متحقق منه. وجود هذا الكود لا يثبت اتصال قاعدة البيانات أو مزود الذكاء الاصطناعي في الموقع الحالي.

## التقنية والتشغيل

Next.js `15` وReact `19` وTypeScript، مع Three.js وReact Three Fiber وDrei وpostprocessing، وإدارة حالة Zustand والتحقق عبر Zod. الخلفية الاختيارية Express `5` وPrisma `6` مع PostgreSQL. توجد أدوات Vitest وPlaywright. يتطلب المشروع Node.js `22` أو أحدث بحسب README.

ثبّت الحزم باستخدام `npm ci`. تعمل الواجهة المحلية الأساسية دون مفاتيح خدمات؛ يتطلب الرسم متصفحًا يدعم WebGL.

| الأمر المتاح | وظيفته |
| --- | --- |
| `npm run dev` | تشغيل واجهة Next.js للتطوير. |
| `npm run build` | بناء التصدير الثابت داخل `out/`. |
| `npm start` | معاينة `out/` عبر خادم الملفات المحلي. |
| `npm run server` | تشغيل API الاختياري في عملية منفصلة. |
| `npm run db:generate` | توليد Prisma Client. |
| `npm run db:push` | تطبيق مخطط Prisma على قاعدة البيانات المحددة. |
| `npm run db:seed` | إجراء تهيئة الإدارة للحساب الموجود؛ يحتاج قاعدة البيانات والإعداد المناسب. |
| `npm run typecheck` | فحص TypeScript دون إنتاج ملفات. |
| `npm test` | اختبارات Vitest. |
| `npm run test:e2e` | اختبارات المتصفح بواسطة Playwright. |
| `npm run test:api` | فحوص API؛ تحتاج تشغيل الخادم. |

هذه أوامر موجودة في الحزمة، ولم تُشغّل أثناء إعداد الوثيقة.

## الإعداد والتخزين

أسماء متغيرات التطبيق موثقة في [.env.example](../projects/mk2-reality-engine/.env.example): `NEXT_PUBLIC_API_URL`، `API_PORT`، `CLIENT_ORIGIN`، `DATABASE_URL`، `OPENAI_API_KEY`، `OPENAI_MODEL`، `AI_DAILY_LIMIT`، `ADMIN_EMAIL`، `SESSION_COOKIE_SECURE`، `SESSION_SAME_SITE`، `TRUST_PROXY`. تتوفر أيضًا أسماء `WEB_PORT` للمعاينة، و`PLAYWRIGHT_CHROMIUM_PATH` و`TEST_API_URL` للفحوص.

تُحفظ المشاريع المحلية في IndexedDB والمفضلة في تخزين المتصفح؛ حذف بيانات المتصفح يزيلها. التصدير إلى ملف وسيلة للنسخ الاحتياطي. الخدمات السحابية تحتاج PostgreSQL وخادم Node مستقلًا، ويحتاج تكامل OpenAI مفتاحًا على الخادم. إعداد عنوان API العام جزء من بناء الواجهة، وليس سرًا يوضع في متصفح الزائر. أرشيف المصدر لا يشمل قواعد بيانات التشغيل أو إعدادات الأسرار.

## ملفات التعديل

- [الواجهة الرئيسية](../projects/mk2-reality-engine/app/page.tsx) و[المحرر](../projects/mk2-reality-engine/components/Editor.tsx).
- [عارض العالم](../projects/mk2-reality-engine/components/WorldCanvas.tsx).
- [مخطط المشهد والقوالب وترميز المشاركة](../projects/mk2-reality-engine/lib/scene.ts).
- [حالة المحرر](../projects/mk2-reality-engine/lib/store.ts) و[التخزين المحلي](../projects/mk2-reality-engine/lib/storage.ts).
- [خادم API](../projects/mk2-reality-engine/server/index.ts) و[مخطط PostgreSQL](../projects/mk2-reality-engine/prisma/schema.prisma).
- [دليل الخلفية](../projects/mk2-reality-engine/docs/BACKEND.md) و[الحزم والأوامر](../projects/mk2-reality-engine/package.json).

## النسخة المحفوظة

[مجلد المصدر](../projects/mk2-reality-engine/) · [تاريخ Git بصيغة bundle](../history/mk2-reality-engine.bundle). عدد الملفات والالتزامات يخص لقطة المصدر الموضحة أعلاه، ولا يشمل وثيقة التفاصيل.
